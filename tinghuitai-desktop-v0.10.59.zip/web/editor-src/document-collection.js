'use strict';
// Keep operation identity across retries; an explicit collection after undo gets a new identity.
module.exports=function collectionClient({session,meeting,source,sync,api,refresh,locate,operation=()=>crypto.randomUUID()}){
 const operations=new Map(),pending=new Map(),organizing=new Map();
 function restored(s,meetingId,moduleId){const key=s.id+':'+meetingId+':'+moduleId;if(!operations.has(key)){const saved=(s.collections||[]).find(c=>c.key===meetingId+':'+moduleId);if(saved)operations.set(key,{id:saved.operationId,receipt:saved});}return operations.get(key);}
 async function run(moduleId,undo,selection,chapterId,artifactSelection){
  const s=session(),meetingId=meeting();if(!s||!meetingId)throw Error('Open the solution document first');
  const key=s.id+':'+meetingId+':'+moduleId;
  if(pending.has(key))return pending.get(key);
  const task=(async()=>{
   if(!await sync(s)||s.dirty||s!==session()||meetingId!==meeting())throw Error('Save the current document before collecting');
   let op=restored(s,meetingId,moduleId);if(undo&&!op?.receipt)throw Error('No saved selection to undo');
   if(!undo&&(!op||op.receipt?.undone)){op={id:operation()};operations.set(key,op);}
   const receipt=await api({action:undo?'undoCollection':'collect',id:s.id,meetingId,moduleId,operationId:op.receipt?.operationId||op.id,expectedRevision:s.revision,sourceRevision:source()?.revision,...(chapterId?{chapterId}:{}),...(!undo&&selection?{chatSelection:{jobId:selection.jobId,reply:selection.reply,quote:selection.quote}}:{}),...(!undo&&artifactSelection?{artifactSelection:{jobId:artifactSelection.jobId,artifactId:artifactSelection.artifactId}}:{})});
   op.receipt=receipt;op.id=receipt.operationId;
   await refresh(s);
   if(s===session()&&meetingId===meeting()&&!receipt.undone)locate(s,receipt.blockId);
   return receipt;
  })();pending.set(key,task);
  try{return await task;}finally{if(pending.get(key)===task)pending.delete(key);}
 }
 async function organize(moduleId,options={}){
  const s=session(),meetingId=meeting();if(!s||!meetingId)throw Error('Open the solution document first');
  const op=restored(s,meetingId,moduleId);if(!op?.receipt||op.receipt.undone)throw Error('Collect this material before organizing');
  const key=s.id+':'+meetingId+':'+moduleId+':'+op.id;if(organizing.has(key))return organizing.get(key);
  const task=(async()=>{
   if(!await sync(s)||s.dirty||s!==session()||meetingId!==meeting())throw Error('Save the current document before organizing');
   if(op.receipt.undone)throw Error('Collection was undone');
   let result;
   try{result=await api({action:'organizeCollection',id:s.id,meetingId,moduleId,operationId:op.id,lang:options.lang,question:options.question});}
   catch(error){
    // A lost response is not proof that the durable operation failed. Read
    // its existing state once; never submit a second model job to recover it.
    await refresh(s);
    const saved=(s.collections||[]).find(c=>c.key===meetingId+':'+moduleId&&c.operationId===op.id&&!c.undone);
    if(!saved?.organization)throw error;
    result=saved;
   }
   if(!op.receipt.undone&&op.receipt.operationId===result.operationId)op.receipt=result;
   await refresh(s);return result;
  })();organizing.set(key,task);try{return await task;}finally{if(organizing.get(key)===task)organizing.delete(key);}
 }
 async function resolve(moduleId,proposalId,decision,owner){
  const s=session(),meetingId=meeting();if(!s||!meetingId)throw Error('Open the solution document first');
  if(!await sync(s)||s.dirty||s!==session()||meetingId!==meeting())throw Error('Save the current document before reviewing');
  const op=owner?{id:owner.operationId,receipt:owner}:restored(s,meetingId,moduleId);if(!op?.receipt||op.receipt.undone)throw Error('This selection is no longer current');
  const result=await api({action:'resolveCollection',id:s.id,meetingId,moduleId,collectionMeetingId:owner?.collectionMeetingId||meetingId,operationId:op.id,proposalId,decision,expectedRevision:s.revision});
  op.receipt=result;await refresh(s);return result;
 }
 return {resolve,collect:(moduleId,selection,chapterId,artifactSelection)=>run(moduleId,false,selection,chapterId,artifactSelection),undo:moduleId=>run(moduleId,true),organize};
};
