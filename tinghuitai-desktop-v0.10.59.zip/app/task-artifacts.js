'use strict';
// The model remains read-only. The host saves only its returned draft in a
// task-owned directory; no model path or executable HTML is accepted.
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
const publicReceipt=({taskPackage,fullTaskReference,...receipt})=>Object.fromEntries(Object.entries(receipt).filter(([,v])=>v!==undefined));
const fail=(text,status=409)=>Object.assign(Error(text),{status});
const escape=x=>String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function markdown(text){
 const lines=text.split('\n'),html=[];let code=false,codeLines=[];
 const inline=s=>escape(s).replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>');
 const cells=s=>s.trim().replace(/^\|/,'').replace(/\|$/,'').split('|').map(x=>inline(x.trim()));
 for(let i=0;i<lines.length;i++){
  const line=lines[i];
  if(/^```/.test(line)){if(code){html.push('<pre>'+escape(codeLines.join('\n'))+'</pre>');codeLines=[];}code=!code;continue;}
  if(code){codeLines.push(line);continue;}
  if(line.includes('|')&&/^\s*\|?\s*:?-{3,}/.test(lines[i+1]||'')){
   const head=cells(line);i++;const rows=[];while(i+1<lines.length&&lines[i+1].includes('|'))rows.push(cells(lines[++i]));
   html.push('<div class="table"><table><thead><tr>'+head.map(x=>'<th>'+x+'</th>').join('')+'</tr></thead><tbody>'+rows.map(r=>'<tr>'+r.map(x=>'<td>'+x+'</td>').join('')+'</tr>').join('')+'</tbody></table></div>');continue;
  }
  const heading=/^(#{1,6})\s+(.+)/.exec(line);if(heading){const h=Math.min(heading[1].length+1,6);html.push('<h'+h+'>'+inline(heading[2])+'</h'+h+'>');}
  else if(/^\s*[-*]\s+/.test(line))html.push('<p class="bullet">• '+inline(line.replace(/^\s*[-*]\s+/,''))+'</p>');
  else if(line.trim())html.push('<p>'+inline(line)+'</p>');
 }
 if(code)html.push('<pre>'+escape(codeLines.join('\n'))+'</pre>');return html.join('');
}
function render(title,text){return '<!doctype html><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'"><meta name="viewport" content="width=device-width"><style>body{margin:0;background:#fafaf7;color:#292b26;font:16px/1.65 system-ui}main{max-width:900px;margin:auto;padding:24px}h1{font-size:24px;line-height:1.3}h2{font-size:21px}h3{font-size:18px}p{margin:10px 0;overflow-wrap:anywhere}.bullet{margin:4px 0}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f0f1eb;padding:12px}small{color:#74786e}.table{overflow:auto}table{border-collapse:collapse;width:100%;font-size:14px}td,th{text-align:left;padding:10px;border-bottom:1px solid #dadcd4}th{background:#f0f1eb}</style><main><small>AI draft · editable · not submitted</small>'+markdown(text)+'</main>';}

function persist(dataDir,request,out){
 const generation=request.candidateId&&out.generationReceipt;
 const modelResponse=generation?.kind==='model-response'&&typeof generation.id==='string'&&generation.id&&typeof generation.provider==='string'&&generation.provider&&Number.isFinite(Date.parse(generation.receivedAt));
 if(!request.requestId||(!(out.codexThreadId&&out.codexTurnId)&&!modelResponse)||typeof out.text!=='string'||!out.text.trim()||Buffer.byteLength(out.text)>400000)throw fail('Draft receipt incomplete',502);
 const id=hash(request.requestId),root=path.join(dataDir,'task-artifacts'),dir=path.join(root,id),body=out.text.trim()+'\n',sha256=hash(body);
 fs.mkdirSync(root,{recursive:true,mode:0o700});
 if(fs.existsSync(dir)){const prior=JSON.parse(fs.readFileSync(path.join(dir,'receipt.json'),'utf8'));if(prior.sha256!==sha256||prior.turnId!==out.codexTurnId||prior.generationReceipt?.id!==generation?.id)throw fail('Existing task draft differs; start a new revision');read(dataDir,id,'md');return publicReceipt(prior);}
 const stage=fs.mkdtempSync(path.join(root,'.draft-'));
 const receipt={schema:1,id,revision:1,state:'draft_saved',submitted:false,requestId:request.requestId,threadId:out.codexThreadId,turnId:out.codexTurnId,...(generation?{generationReceipt:generation}:{}),...(request.candidateId?{candidateId:request.candidateId,candidateHash:request.candidateHash}:{}),sha256,created:new Date().toISOString(),title:request.comment.slice(0,120),model:out.model||'',contextFingerprint:request.contextFingerprint||'',taskPackage:request.taskPackage||null,fullTaskReference:request.fullTaskReference?Object.fromEntries(Object.entries(request.fullTaskReference).filter(([k])=>k!=='content')):null};
 try{for(const [name,value]of [['draft.md',body],['preview.html',render(receipt.title,body)],['receipt.json',JSON.stringify(receipt,null,2)]])fs.writeFileSync(path.join(stage,name),value,{mode:0o600});fs.renameSync(stage,dir);}finally{fs.rmSync(stage,{recursive:true,force:true});}
 return publicReceipt(receipt);
}
function read(dataDir,id,format){
 if(typeof id!=='string'||!/^[a-f0-9]{64}$/.test(id)||!['md','html'].includes(format))throw fail('Invalid artifact reference',400);
 const dir=path.join(dataDir,'task-artifacts',id);
 try{const receipt=JSON.parse(fs.readFileSync(path.join(dir,'receipt.json'),'utf8')),draft=fs.readFileSync(path.join(dir,'draft.md'),'utf8');if(hash(draft)!==receipt.sha256)throw fail('Draft integrity check failed');return {type:format==='html'?'text/html; charset=utf-8':'text/markdown; charset=utf-8',body:format==='html'?render(receipt.title,draft):draft};}catch(e){if(e.code==='ENOENT')throw fail('Draft not found',404);throw e;}
}
module.exports={persist,read};
