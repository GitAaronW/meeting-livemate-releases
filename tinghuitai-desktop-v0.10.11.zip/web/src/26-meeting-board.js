async function workspaceShareAction(message){
      const controls={lark:'share-lark',slack:'share-slack',full:'x-full',transcript:'x-verb',pdf:'x-pdf',copy:'copy',workspace:'save-hub'};
      const control=controls[message.action],id=message.sessionId;
      if(!control||!id)return;
      if(running&&cur?.id!==id){note(ui==='en'?'End the current meeting before exporting another.':'请先结束当前会议，再导出其他会议。',true);return;}
      try{
        const r=await fetch(relayBase()+'/export-state?ids='+encodeURIComponent(id)+'&token='+encodeURIComponent(cfg.relayToken||''),{cache:'no-store',signal:AbortSignal.timeout(8000)});
        if(!r.ok)throw Error('HTTP '+r.status);
        const selected=(await r.json()).sessions.find(x=>x.id===id);
        if(!selected)throw Error(ui==='en'?'Meeting not found':'未找到对应会议');
        if(!running){cur=normalizeSession(selected);resetSigs();render();}
        document.getElementById(control).click();
      }catch(error){note(error.message,true);}
}
// Keep the existing recorder and controls as the application shell. Its primary
// content is the same workspace used after the meeting, not a second data store.
{ // The recorder always uses the canonical meeting canvas.
  const frame = document.getElementById('workspace-frame');
  document.getElementById('app').classList.add('workspace-primary');
  frame.hidden = false;
  // Meeting navigation owns a full-page document, while existing recorder handlers
  // remain the single source of truth behind compact controls.
  const chrome=document.createElement('style');chrome.textContent=`
  body:not(.document-home-open) #app.workspace-primary{display:block;position:relative;height:100dvh;overflow:hidden;background:#fafaf7}
  body:not(.document-home-open) #app.workspace-primary>.hdr,body:not(.document-home-open) #app.workspace-primary>.ftr,body:not(.document-home-open) #app.workspace-primary>#post-cards{display:none!important}
  body:not(.document-home-open) #app.workspace-primary>#workspace-frame,body:not(.document-home-open) #app.workspace-primary>#work-frame{position:absolute;inset:0;width:100%;height:100%;border:0}
  .meeting-dock{flex-wrap:wrap;justify-content:center;position:fixed;z-index:42;bottom:24px;left:50%;transform:translateX(-50%);width:min(860px,calc(100vw - 40px));display:flex;gap:10px;align-items:center;pointer-events:none}
  .meeting-dock>*{pointer-events:auto}.meeting-dock button,.meeting-dock summary{font:inherit;font-size:14px;color:#42483e;border:0;background:transparent;cursor:pointer;padding:11px 13px}
  .meeting-recorder,.meeting-ask{border:1px solid #e0e3d9;border-radius:28px;background:#fffefa;box-shadow:0 3px 12px #24351b08;display:flex;align-items:center}
  .meeting-recorder{flex:none}.meeting-recorder>button{white-space:nowrap}.meeting-recorder details{position:relative}.meeting-recorder summary{list-style:none;padding:10px}.meeting-recorder nav{position:absolute;bottom:52px;left:0;width:200px;display:flex;flex-direction:column;padding:6px;background:#fffefa;border:1px solid #e0e3d9;border-radius:12px;box-shadow:0 5px 22px #24351b14}.meeting-recorder nav button{text-align:left;border-radius:7px}.meeting-recorder nav button:hover{background:#f0f2e9}
  .meeting-ask{flex:1;min-width:0;padding:2px 7px}.meeting-ask input{flex:1;min-width:0;border:0;background:transparent;outline:none;padding:12px;font:inherit;font-size:14px}.meeting-ask button{padding:8px 10px}.meeting-dock meter{width:22px;height:12px;accent-color:#718c72}.meeting-dock meter[hidden]{display:none}
  .meeting-composer-slot{flex-basis:100%;min-width:0}.meeting-dock>button{min-height:44px;border-radius:20px;background:#fffefa;border:1px solid #e0e3d9}.meeting-dock button:focus-visible{outline:2px solid #6255ad;outline-offset:3px}
  body.document-home-open .meeting-dock{display:none}.dh-home-toggle{top:18px!important;left:20px!important}.meeting-dock[hidden]{display:none}
  @media(max-width:600px){.meeting-dock{bottom:14px;width:calc(100vw - 24px);gap:5px}.meeting-dock button{padding:10px 8px}.meeting-ask input{padding:10px 5px}}
  `;document.head.append(chrome);
  const dock=document.createElement('div');dock.className='meeting-dock';
  const recorder=document.createElement('div');recorder.className='meeting-recorder';
  const recordButton=document.createElement('button'),audio=document.createElement('meter');recordButton.type='button';audio.min=0;audio.max=1;audio.value=0;audio.hidden=true;audio.setAttribute('aria-label','Audio input level');
  const options=document.createElement('details'),arrow=document.createElement('summary'),nav=document.createElement('nav');arrow.textContent='⌃';options.append(arrow,nav);
  const transcriptButton=document.createElement('button'),modeButton=document.createElement('button');transcriptButton.type=modeButton.type='button';transcriptButton.className='meeting-transcript';nav.append(modeButton);const browserButton=document.createElement('button'),systemButton=document.createElement('button');browserButton.type=systemButton.type='button';nav.append(systemButton,browserButton);const micButton=document.createElement('button');micButton.type='button';nav.append(micButton);micButton.onclick=()=>{if(window.thtSelectCapture?.(true,'asr'))options.open=false;};browserButton.onclick=()=>{if(window.thtSelectCapture?.(true))options.open=false;};systemButton.onclick=()=>{if(window.thtSelectCapture?.(false))options.open=false;};const pauseButton=document.createElement('button');pauseButton.type='button';nav.append(pauseButton);pauseButton.onclick=async()=>{try{await nativeRequest('command',{sessionId:nativeState.sessionId,command:nativeState.phase==='paused'?'resume':'pause'});options.open=false;}catch(e){note(e.message,true);}};recorder.append(audio,recordButton,options);
  const ask=document.createElement('div');ask.id='meeting-composer-slot';ask.className='meeting-composer-slot';const intelligence=document.createElement('button');intelligence.type='button';intelligence.className='meeting-intelligence';intelligence.setAttribute('aria-controls','myagent-panel');intelligence.onclick=()=>window.myAgentToggle?.();const fallbackButton=document.createElement('button');fallbackButton.type='button';fallbackButton.hidden=true;fallbackButton.onclick=()=>{if(window.thtSelectCapture?.(true))document.getElementById('start')?.click();};const summaryButton=document.createElement('button');summaryButton.type='button';summaryButton.className='meeting-summary';summaryButton.onclick=()=>frame.contentWindow.postMessage({type:'tht-summary-toggle'},location.origin);dock.append(recorder,fallbackButton,summaryButton,transcriptButton,intelligence,ask);document.body.append(dock);const notice=document.getElementById('notice');document.getElementById('app').append(notice);notice.style.cssText='position:fixed;top:12px;left:80px;right:80px;z-index:55;border-radius:8px;max-height:100px;overflow:auto';
  function composerLayout(){const rect=dock.getBoundingClientRect(),bottom=Math.max(90,Math.ceil(innerHeight-rect.top+16));document.documentElement.style.setProperty('--meeting-composer-bottom',bottom+'px');frame.contentWindow.postMessage({type:'tht-composer-layout',bottom},location.origin);}
  new ResizeObserver(composerLayout).observe(dock);window.addEventListener('resize',composerLayout);frame.addEventListener('load',composerLayout);
  let preparedJoin=null;
  recordButton.onclick=()=>document.getElementById(running||nativeState.active?'stop':'start')?.click();
  transcriptButton.onclick=()=>{options.open=false;frame.contentWindow.postMessage({type:'tht-transcript-toggle'},location.origin);};
  modeButton.onclick=()=>{options.open=false;document.getElementById('mode-chip')?.click();};

  window.addEventListener('tht-proactive-data',e=>{preparedJoin=e.detail.source?.kind==='note'?e.detail.source.calendarEvent:null;});
  function dockState(){const en=ui==='en',active=running||nativeState.active,clock=document.getElementById('clock')?.textContent||'00:00';recordButton.textContent=active?(en?'■ End · ':'■ 结束 · ')+clock:(en?'Start recording':'开始听会');recordButton.disabled=active?document.getElementById('stop').disabled:document.getElementById('start').disabled;transcriptButton.textContent=en?'Transcript':'实时转写';modeButton.hidden=nativeState.available&&!window.thtBrowserCapture;fallbackButton.hidden=active||!nativeState.error||window.thtBrowserCapture;fallbackButton.textContent=en?'Use browser recording':'改用浏览器录音';micButton.disabled=active;micButton.textContent=(window.thtBrowserCapture&&window.thtBrowserMode==='asr'?'✓ ':'')+(en?'Microphone · in person':'麦克风 · 线下会');browserButton.hidden=!nativeState.available;systemButton.hidden=!nativeState.available;browserButton.disabled=systemButton.disabled=active;browserButton.textContent=(window.thtBrowserCapture&&window.thtBrowserMode!=='asr'?'✓ ':'')+(en?'Browser recording · temporary':'浏览器录音 · 临时');systemButton.textContent=(!window.thtBrowserCapture?'✓ ':'')+(en?'System audio + microphone':'系统声音 + 麦克风');modeButton.textContent=en?'Recording options':'录音方式';pauseButton.hidden=!nativeState.active;pauseButton.textContent=nativeState.phase==='paused'?(en?'Resume':'继续'):(en?'Pause':'暂停');intelligence.textContent=en?'✦ Intelligence':'✦ 主动智能';intelligence.setAttribute('aria-expanded',String(!document.getElementById('myagent-panel')?.hidden));arrow.setAttribute('aria-label',en?'Recording menu':'录音菜单');summaryButton.textContent=en?'AI summary':'AI 总结';for(const button of [recordButton,transcriptButton,modeButton,fallbackButton,micButton,browserButton,systemButton,pauseButton,summaryButton,intelligence])button.setAttribute('aria-label',button.textContent.replace(/^[✓✦■]\s*/,''));dock.hidden=!workFrame.hidden;}
  window.addEventListener('tht-native-status',e=>{audio.value=Math.max(0,Math.min(1,Number(e.detail.audioLevel)||0));audio.hidden=!e.detail.active;dockState();});
  setInterval(dockState,500);

  let previous = '', ready = false, viewedMeetingId = new URLSearchParams(location.search).get('id') || sessionStorage.getItem('tht-selected-meeting') || '', wasRunning=running, requestedModule=new URLSearchParams(location.search).get('module')||'', navigationId='', requestedAt=Number((location.hash.match(/(?:^#|&)t=(\d+(?:\.\d+)?)/)||[])[1]||0);
  const workFrame=document.getElementById('work-frame');
  function workRoute(view,sourceId=''){const raw=String(view||'focus'),p=new URLSearchParams(raw),name=p.get('view')||raw.split('&')[0]||'focus',q=new URLSearchParams();if(p.get('node'))q.set('node',p.get('node'));if(sourceId||p.get('source'))q.set('source',sourceId||p.get('source'));return encodeURIComponent(name)+(q.size?'&'+q:'');}
  function saveRoute(mode,view='',replace=false){
    const q=new URLSearchParams(location.search);if(viewedMeetingId)q.set('id',viewedMeetingId);else q.delete('id');
    if(mode==='work'){q.set('view','work');q.set('tab',workRoute(view||workFrame.contentWindow?.location.hash.slice(1)||'focus'));}else{q.delete('view');q.delete('tab');}
    const next=location.pathname+(q.toString()?'?'+q:'')+location.hash;
    if(next!==location.pathname+location.search+location.hash)history[replace?'replaceState':'pushState'](null,'',next);
    sessionStorage.setItem('tht-selected-meeting',viewedMeetingId);
  }
  window.thtCloseWorkbench=(restore=false)=>{workFrame.hidden=true;frame.hidden=false;if(!restore)saveRoute('meeting');syncWorkspace(true);};
  window.thtDraftMeetingItem=item=>{
    if(!ready||frame.hidden||item?.meetingId!==viewedMeetingId)return false;
    try{return frame.contentWindow.thtDraftMeetingItem?.(item)===true;}catch{return false;}
  };
  window.thtOpenWorkbench=(view,restore=false,sourceId='')=>{
    if(!view&&!workFrame.hidden){window.thtCloseWorkbench();return;}
    const target=workRoute(view,sourceId);
    if(!workFrame.getAttribute('src'))workFrame.src='work.html?shell=1#'+target;
    else if(view&&workFrame.contentWindow.location.hash!=='#'+target){
      const child=workFrame.contentWindow;
      child.history.replaceState(null,'','#'+target);
      child.dispatchEvent(new child.HashChangeEvent('hashchange'));
    }
    frame.hidden=true;workFrame.hidden=false;if(!restore)saveRoute('work',view);syncWorkspace(true);
  };
  window.thtOpenMeeting=(nextId,atSec,moduleId)=>{
    if(!nextId)return;
    navigationId=crypto.randomUUID();
    requestedModule=moduleId||'';
    requestedAt=Number(atSec)>0?Number(atSec):0;
    viewedMeetingId=String(nextId||'');
    if(!document.body.classList.contains('document-home-open'))window.thtMountComposer?.(ask,{page:'meeting',contextId:viewedMeetingId});
    const hash=Number(atSec)>0?'#t='+Number(atSec):'';
    const q=new URLSearchParams(location.search);q.set('id',viewedMeetingId);q.delete('view');q.delete('tab');if(requestedModule)q.set('module',requestedModule);else q.delete('module');const next=location.pathname+'?'+q+hash;if(next!==location.pathname+location.search+location.hash)history.pushState(null,'',next);
    window.thtCloseWorkbench();
  };
  function restoreRoute(){const q=new URLSearchParams(location.search);viewedMeetingId=q.get('id')||'';requestedModule=q.get('module')||'';navigationId=crypto.randomUUID();requestedAt=Number((location.hash.match(/(?:^#|&)t=(\d+(?:\.\d+)?)/)||[])[1]||0);sessionStorage.setItem('tht-selected-meeting',viewedMeetingId);q.get('view')==='work'?window.thtOpenWorkbench(q.get('tab')||'focus',true):window.thtCloseWorkbench(true);}
  function recoverNestedShell(child){
    try{const u=new URL(child.contentWindow.location.href);if(u.origin!==location.origin)return false;
      if(/\/tinghuitai\/(?:index\.html)?$/.test(u.pathname)){
        if(child===frame){ready=false;frame.src='meeting-board.html?embedded=1'+(viewedMeetingId?'&id='+encodeURIComponent(viewedMeetingId):'');}else workFrame.src='work.html?shell=1';
        window.thtOpenMeeting(u.searchParams.get('id')||viewedMeetingId,Number(u.hash.slice(3)),u.searchParams.get('module')||'');return true;
      }
    }catch{}return false;
  }
  function syncWorkspace(force=false) {
    if (!ready) return;
    document.getElementById('b-assistant').textContent='✦ MyAgent';
    document.getElementById('b-work-top').textContent=workFrame.hidden?(ui==='en'?'Workbench':'工作台'):(ui==='en'?'← Meeting':'← 听会台');
    const active=running||nativeState.active;
    if(active&&!wasRunning){viewedMeetingId=nativeState.sessionId||cur?.id||'';workFrame.hidden=true;frame.hidden=false;}wasRunning=active;
    const context = {type:'tht-context', lang:ui, moduleId:requestedModule,navigationId,
      preparedEventId:active&&(!viewedMeetingId||viewedMeetingId===(nativeState.sessionId||cur?.id))?(cur?.joinedEvent?.eventId||window.thtMeetingJoin?.eventId||''):'', sessionId:viewedMeetingId || (active&&nativeState.sessionId) || (cur?.id && (active || cur.transcript?.length) ? cur.id : ''), active,nativeCapture:nativeState.active&&nativeState.captureMode==='native',atSec:requestedAt};
    const key = JSON.stringify(context);
    if(force || key!==previous) { previous=key;frame.contentWindow.postMessage(context,location.origin);if(workFrame.getAttribute('src'))workFrame.contentWindow.postMessage({type:'tht-language',lang:ui},location.origin); }
  }
  frame.onload=()=>{if(recoverNestedShell(frame))return;ready=true;syncWorkspace(true);};
  workFrame.onload=()=>{if(!recoverNestedShell(workFrame))syncWorkspace(true);};
  window.addEventListener('popstate',restoreRoute);
  frame.src='meeting-board.html?embedded=1'+(viewedMeetingId?'&id='+encodeURIComponent(viewedMeetingId):'');
  restoreRoute();
  window.addEventListener('hashchange',()=>{previous='';syncWorkspace(true);});
  setInterval(syncWorkspace,1000);
  window.addEventListener('tht-native-status',e=>{syncWorkspace(true);if(ready)frame.contentWindow.postMessage({type:'tht-audio-level',level:e.detail.audioLevel||0,active:e.detail.active},location.origin);});
  const button=document.getElementById('b-assistant');
  button.textContent='✦ MyAgent';
  button.setAttribute('aria-controls','myagent-panel');
  button.addEventListener('click',e=>{
    e.preventDefault();e.stopImmediatePropagation();
    window.myAgentOpen?.();
  },true);
  document.getElementById('b-this').addEventListener('click',e=>{
    e.preventDefault();e.stopImmediatePropagation();
    window.thtCloseWorkbench();frame.contentWindow.postMessage({type:'tht-export'},location.origin);
  },true);
  window.addEventListener('message',async e=>{
    if(e.origin!==location.origin)return;
    if(![frame.contentWindow,workFrame.contentWindow].includes(e.source))return;
    if(e.data?.type==='tht-record-panels'&&e.source===frame.contentWindow){summaryButton.setAttribute('aria-expanded',String(e.data.summary!=='closed'));transcriptButton.setAttribute('aria-expanded',String(e.data.transcript!=='closed'));return;}
    if(e.data?.type==='tht-calendar-join'&&e.source===frame.contentWindow){window.thtJoinCalendarEvent?.(e.data.event);return;}
    if(e.data?.type==='tht-proactive-data'){window.dispatchEvent(new CustomEvent('tht-proactive-data',{detail:e.data}));return;}
    if(e.data?.type==='tht-work-open')window.thtOpenWorkbench(e.data.view);
    if(e.data?.type==='tht-agent-open'){window.myAgentOpen?.();return;}
    if(e.data?.type==='tht-agent-ask'){window.myAgentAsk?.(e.data.quote,e.data.question||'',e.data.meta||{});return;}
    if(e.data?.type==='tht-open-meeting'){window.thtOpenMeeting(e.data.id,e.data.atSec,e.data.moduleId);return;}
    if(e.data?.type==='tht-work-view'){if(e.source===workFrame.contentWindow&&!workFrame.hidden)saveRoute('work',e.data.view);return;}
    if(e.source===workFrame.contentWindow){
      if(e.data?.type==='tht-work-return')window.thtCloseWorkbench();
      if(e.data?.type==='tht-open-meeting')window.thtOpenMeeting(e.data.id,e.data.atSec,e.data.moduleId);
      if(e.data?.type==='tht-language'&&['zh','en'].includes(e.data.lang))document.querySelector('[data-ui="'+e.data.lang+'"]')?.click();
      return;
    }
    if(e.source!==frame.contentWindow)return;
    if(e.data?.type==='tht-navigation-opened'&&e.data.navigationId===navigationId){navigationId='';requestedModule='';requestedAt=0;return;}
    if(e.data?.type==='tht-result-opened'&&e.data.moduleId===requestedModule){requestedModule='';return;}
    if(e.data?.type==='tht-selected-meeting'){if(e.data.reason==='context'&&viewedMeetingId&&e.data.id!==viewedMeetingId)return;viewedMeetingId=e.data.id;sessionStorage.setItem('tht-selected-meeting',viewedMeetingId);const q=new URLSearchParams(location.search);q.set('id',viewedMeetingId);history.replaceState(null,'',location.pathname+(q.toString()?'?'+q:'')+location.hash);}
    if(e.data?.type==='tht-share-action'){
      await workspaceShareAction(e.data);
    }
    if(e.data?.type==='tht-assistant-state')button.setAttribute('aria-expanded',String(e.data.open));
    if(e.data?.type==='tht-language' && ['zh','en'].includes(e.data.lang))document.querySelector('[data-ui="'+e.data.lang+'"]')?.click();
    if(e.data?.type==='tht-app-panel'&&e.data.mode==='material'){document.getElementById('b-this').onclick();document.getElementById('more-title').textContent=ui==='en'?'Add meeting material':'补充会议资料';return;}
    if(e.data?.type==='tht-app-panel')document.getElementById(({settings:'gear2',history:'b-hist',update:'m-update',smallwindow:'b-native'})[e.data.mode])?.click();
  });
}
