  // ===== 补充材料：图片 / PDF 上传，存在 Mac 上，会中助手用 Read 打开来看 =====
  const assetMsg = m => { const e=$('#asset-msg'); if(e) e.textContent = m||''; };
  const assetUrl = (id,name) => relayBase()+'/assets?id='+encodeURIComponent(id)+'&name='+encodeURIComponent(name)+'&token='+encodeURIComponent(cfg.relayToken||'');
  function renderAssets(items){
    const grid=$('#asset-grid'); if(!grid) return;
    const list=items||[];
    const send=$('#asset-send'); if(send) send.disabled = assetBusy || (!list.length && !(($('#personal-notes')||{}).value||'').trim());
    grid.innerHTML = list.map(a=>{
      const pdf=/\.pdf$/i.test(a.name);
      const body = pdf ? '<div class="pdf">PDF</div>' : '<img loading="lazy" alt="'+esc(a.name)+'" src="'+esc(assetUrl(cur&&cur.id,a.name))+'">';
      const short=a.name.replace(/^\d{14}-/,'');
      return '<div class="asset" data-name="'+esc(a.name)+'" title="'+esc(short)+'">'+body+'<div class="n">'+esc(short)+'</div><button class="x" type="button" aria-label="删除">×</button></div>';
    }).join('');
    grid.querySelectorAll('.asset .x').forEach(b=>b.onclick=async()=>{
      const name=b.closest('.asset').dataset.name;
      if(!confirm(ui==='en'?('Remove '+name+'?'):('删掉「'+name.replace(/^\d{14}-/,'')+'」？'))) return;
      try{
        const r=await fetch(relayBase()+'/assets?token='+encodeURIComponent(cfg.relayToken||''),{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({id:cur&&cur.id,remove:name}),signal:AbortSignal.timeout(15000)});
        const j=await r.json(); if(!j.ok) throw new Error(j.error||('HTTP '+r.status));
        renderAssets(j.items); assetMsg(ui==='en'?'Removed.':'已删掉。');
      }catch(e){ assetMsg((ui==='en'?'Remove failed: ':'没删成：')+(e.message||e)); }
    });
  }
  async function loadAssets(){
    if(!cur||!macOnline){ renderAssets([]); return; }
    try{
      const r=await fetch(relayBase()+'/assets?id='+encodeURIComponent(cur.id)+'&token='+encodeURIComponent(cfg.relayToken||''),{cache:'no-store',signal:AbortSignal.timeout(8000)});
      if(!r.ok) throw new Error('HTTP '+r.status);
      const j=await r.json(); renderAssets(j.items||[]);
    }catch(e){ renderAssets([]); }
  }
  async function uploadAssets(files, source='upload'){
    if(!cur){ assetMsg(ui==='en'?'Start or open a meeting first.':'先开始或打开一场会议。'); return; }
    if(!macOnline){ assetMsg(ui==='en'?'Mac is offline - material is stored on the Mac.':'材料存在 Mac 上，需要先连上 Mac。'); return; }
    const list=[...files].filter(f=>/^image\//.test(f.type)||f.type==='application/pdf');
    if(!list.length){ assetMsg(ui==='en'?'Only images and PDF.':'只收图片和 PDF。'); return; }
    let done=0;
    for(const f of list){
      if(f.size>15e6){ assetMsg((ui==='en'?'Too big (15MB max): ':'超过 15MB：')+f.name); continue; }
      assetMsg((ui==='en'?'Uploading ':'上传中 ')+(done+1)+'/'+list.length+'…');
      try{
        const dataUrl=await new Promise((res,rej)=>{ const fr=new FileReader(); fr.onload=()=>res(fr.result); fr.onerror=()=>rej(new Error('读取失败')); fr.readAsDataURL(f); });
        const r=await fetch(relayBase()+'/assets?token='+encodeURIComponent(cfg.relayToken||''),{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({id:cur.id,name:f.name,dataUrl,source,capturedAt:new Date(f.lastModified||Date.now()).toISOString()}),signal:AbortSignal.timeout(60000)});
        const j=await r.json().catch(()=>null);
        if(!j||!j.ok) throw new Error((j&&j.error)||('HTTP '+r.status));
        renderAssets(j.items); done++;
      }catch(e){ assetMsg((ui==='en'?'Upload failed: ':'没传上去：')+(e.message||e)); return; }
    }
    assetMsg(done?((ui==='en'?'Added ':'加了 ')+done+(ui==='en'?' file(s). The assistant can open them.':' 个，助手会打开来看。')):'');
  }
  function renderAnalysis(){
    const box=$('#asset-analysis'); if(!box) return;
    const a=(cur&&cur.assetAnalysis)||null;
    if(!a||!a.at){ box.innerHTML=''; return; }
    const when=new Date(a.at).toLocaleString(ui==='en'?'en-US':'zh-CN',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'});
    const parts=[];
    if(a.overall) parts.push('<div class="aa"><b>'+(ui==='en'?'Overall · ':'整体 · ')+esc(when)+'</b>'+esc(a.overall)+'</div>');
    for(const f of (a.files||[])) parts.push('<div class="aa"><b>'+esc(String(f.name||'').replace(/^\d{14}-/,''))+'</b>'+esc(f.summary||'')+'</div>');
    box.innerHTML=parts.join('');
  }
  let assetBusy=false;
  // 交给助手看，不用站在这儿等。点一下就告诉用户收到了、可以关掉面板；
  // 真正的读图放到后台跑，看完了写进这一场并提醒一句。会中最忌讳被一个转圈按钮钉住。
  async function analyzeAssets(){
    if(assetBusy||!cur) return;
    const grid=$('#asset-grid'); const names=[...grid.querySelectorAll('.asset')].map(x=>x.dataset.name);
    const notes=($('#personal-notes').value||'').trim();
    if(!names.length&&!notes){ $('#asset-send-msg').textContent=ui==='en'?'Nothing to send yet.':'还没有可发送的内容。'; return; }
    const en = ui==='en';
    const sess = cur;                      // 后台跑的时候用户可能已经切了场次，结果只回写这一场
    assetBusy=true;
    const btn=$('#asset-send'); const label=btn.textContent;
    btn.disabled=true; btn.textContent=en?'Got it':'已收到';
    $('#asset-send-msg').textContent = en
      ? 'Got it — reading in the background. You can close this; I will tell you when it is done.'
      : '收到了，助手在后台看。可以关掉这个面板，看完会提示你。';
    const done = (msg, bad) => {
      // 面板还开着就写在面板里，已经关了就用顶部那条提示
      const box=$('#asset-send-msg');
      const dlg=$('#meeting-notes');
      if(dlg&&dlg.open&&box) box.textContent=msg; else note(msg, !!bad);
      if(!(dlg&&dlg.open)) setTimeout(()=>note(''), 6000);
    };
    try{
      const r=await fetch(relayBase()+'/assets?token='+encodeURIComponent(cfg.relayToken||''),{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({id:sess.id,analyze:true,names,note:notes}),signal:AbortSignal.timeout(180000)});
      const j=await r.json(); if(!r.ok) throw new Error(j.error||('HTTP '+r.status));
      const raw=String(j.text||'').trim().replace(/^```(?:json)?\s*/,'').replace(/\s*```$/,'');
      let parsed=null; try{ parsed=JSON.parse(raw); }catch{ const i=raw.indexOf('{'),k=raw.lastIndexOf('}'); if(i>=0&&k>i){ try{ parsed=JSON.parse(raw.slice(i,k+1)); }catch{} } }
      if(!parsed||typeof parsed!=='object') throw new Error(en?'Model did not return usable JSON.':'助手没给出可用的结果');
      const files=(Array.isArray(parsed.files)?parsed.files:[]).filter(x=>x&&typeof x.summary==='string'&&x.summary.trim())
        .map(x=>({name:String(x.name||'').slice(0,120),summary:x.summary.trim().slice(0,400)}));
      const overall=typeof parsed.overall==='string'?parsed.overall.trim().slice(0,200):'';
      if(!files.length&&!overall) throw new Error(en?'Model returned nothing.':'助手没看出内容');
      sess.assetAnalysis={files,overall,at:Date.now(),count:names.length};
      persist(); if(cur===sess) renderAnalysis();
      done(en?'Material read — it goes into the meeting record.':'材料看完了，这段会随会议一起归档。');
    }catch(e){
      done((en?'Could not read it: ':'没看成：')+(e.message||e), true);
    }finally{ assetBusy=false; const b=$('#asset-send'); if(b){ b.disabled=false; b.textContent=label; } }
  }
  (function wireAssets(){
    const drop=$('#asset-drop'), input=$('#asset-input'), camera=$('#asset-camera-input');
    if(!drop||!input) return;
    $('#asset-add').onclick=()=>input.click();
    if(camera){ $('#asset-camera').onclick=()=>camera.click(); camera.onchange=()=>{ uploadAssets(camera.files,'photo'); camera.value=''; }; }
    drop.addEventListener('click',e=>{ if(e.target===drop) $('#personal-notes').focus(); });
    input.onchange=()=>{ uploadAssets(input.files); input.value=''; };
    ['dragenter','dragover'].forEach(k=>drop.addEventListener(k,e=>{e.preventDefault();drop.classList.add('over');}));
    ['dragleave','drop'].forEach(k=>drop.addEventListener(k,e=>{e.preventDefault();drop.classList.remove('over');}));
    drop.addEventListener('drop',e=>{ if(e.dataTransfer&&e.dataTransfer.files&&e.dataTransfer.files.length) uploadAssets(e.dataTransfer.files); });
    $('#asset-send').onclick=analyzeAssets;
    $('#personal-notes').addEventListener('input',()=>{ const b=$('#asset-send'); if(b) b.disabled=assetBusy||(!$('#asset-grid').querySelector('.asset')&&!($('#personal-notes').value||'').trim()); });
    $('#meeting-notes').addEventListener('paste',e=>{
      const items=[...((e.clipboardData&&e.clipboardData.items)||[])].filter(x=>x.kind==='file');
      if(!items.length) return;
      e.preventDefault(); uploadAssets(items.map(x=>x.getAsFile()).filter(Boolean));
    });
  })();

  $('#personal-notes').oninput=()=>{if(!cur)return;cur.notes=$('#personal-notes').value;persist();if(asrWs?.readyState===1)asrWs.send(JSON.stringify({type:'notes',notes:cur.notes}));};
  function updateFooterLabels(){ $('#meeting-more-label').textContent=archiveEnglish()?'More':'更多';$('#mk-doc').textContent=(archiveEnglish()?'Meeting archive':'会议档案')+(cur?.archiveDirty?(archiveEnglish()?' · Edits pending':' · 修改待归档'):'')+(archiveAttention?' · '+archiveAttention+(archiveEnglish()?' need attention':' 项待处理'):'');$('#b-notes').textContent=archiveEnglish()?'Material':'补充材料';}
  setInterval(()=>{updateFooterLabels();refreshArchive();},10000);
  async function currentMeetingMarkdown(includeTranscript=true){
    if(!cur)return '';
    const r=await fetch(relayBase()+'/meeting-board?id='+encodeURIComponent(cur.id)+'&export=md&token='+encodeURIComponent(cfg.relayToken||''),{cache:'no-store'});
    if(!r.ok)throw Error(ui==='en'?'Could not export this meeting':'这场会议暂时无法导出');
    return (await r.text())+(includeTranscript?'\n\n'+mdVerbatim().replace(/^# /,'## '):'');
  }
  $('#x-full').onclick=async()=>{if(!cur)return;try{dl(fileBase()+'_完整纪要.md',await currentMeetingMarkdown(),'text/markdown');closeSheets();note(ui==='en'?'Exported this meeting with its transcript.':'已导出这场会议及逐字稿。');}catch(e){note(e.message,true);}};
  // 3) 逐字稿 MD = 只有原话
  function mdVerbatim(){
    const L = [`# ${cur.title||'会议'} · 逐字稿`, '', dtStr(), '', `共 ${cur.transcript.length} 句。以下为原话，未含任何要点、待办或事实核查。`, ''];
    cur.transcript.forEach(x => L.push(`**${hms(x.at).slice(0,5)}**${x.spk?' `'+spkName(x.spk)+'`':''}　${x.text}`, ''));
    return L.join('\n');
  }
  $('#x-verb').onclick = () => { if (!cur) return; dl(fileBase()+'_逐字稿.md', mdVerbatim(), 'text/markdown'); closeSheets(); note(T('dl_verb')||'已导出逐字稿（只有原话）。'); setTimeout(()=>note(''),3000); };
  // PDF prints the current meeting canvas; it never reconstructs an archive page.
  $('#x-pdf').onclick=()=>{if(!cur)return;closeSheets();const f=document.getElementById('workspace-frame');if(f&&!f.hidden)f.contentWindow.postMessage({type:'tht-print'},location.origin);else window.print();};
  $('#copy').onclick=async()=>{if(!cur)return;try{await navigator.clipboard.writeText(await currentMeetingMarkdown());note(ui==='en'?'Copied meeting Markdown.':'已复制会议 Markdown。');}catch(e){note(e.message,true);}};
  $('#clear').onclick = () => { if (running || !cur) return; if (!confirm(T('clearConfirm')||'删除这一场的转写和分析？')) return; state.sessions = state.sessions.filter(s=>s.id!==cur.id); cur = null; persist(); el.tr.innerHTML='<div class="empty">已清空。</div>'; el.hl.innerHTML=''; $('#hl-pinned').innerHTML='';$('#hl-pinned').hidden=true; el.ck.innerHTML=''; el.sum.innerHTML=''; el.ctr.textContent=el.chl.textContent=el.cck.textContent='0'; };

  cfg.key='';cfg.relayToken=window.THT_BOOT?.relayToken||cfg.relayToken;
  // 远端窗口（没有 THT_BOOT）留着「Mac 中转口令」这一格，手机才有地方填口令
  ['s-provider','s-key','s-base','s-quick','s-model'].concat(window.THT_BOOT?['s-relay']:[]).forEach(id=>document.getElementById(id)?.closest('.field')?.setAttribute('hidden',''));
