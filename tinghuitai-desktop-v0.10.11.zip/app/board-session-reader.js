'use strict';
// One reader per request: historical directories are indexed once, while live
// sessions and enhanced content are still read at the moment they are needed.
module.exports=function({live,pipeline,exportState}){
 let jobs,history;
 return id=>{
  const current=live.get(id);if(current)return current;
  if(!jobs)jobs=new Map(pipeline.list().map(j=>[String(j.sessionId),j]));
  const enhanced=pipeline.result(id,jobs.get(String(id))||null);if(enhanced)return enhanced;
  if(!history)history=new Map(exportState().sessions.map(s=>[String(s.id),s]));
  return history.get(String(id));
 };
};
