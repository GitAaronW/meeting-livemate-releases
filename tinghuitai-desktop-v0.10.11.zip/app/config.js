'use strict';
const fs=require('fs'),path=require('path'),os=require('os'),crypto=require('crypto');
const dataDir=path.resolve(process.env.THT_DATA_DIR||path.join(os.homedir(),'Library/Application Support/Tinghuitai'));
process.env.THT_DATA_DIR=dataDir;
process.umask(0o077);fs.mkdirSync(dataDir,{recursive:true,mode:0o700});
const file=path.join(dataDir,'settings.json');
const defaults={developerPreviewEnabled:false,PRESET_VERSION:'',ASR_PROVIDER:'',DEEPGRAM_API_KEY:'',MEMORY_PROJECTION_DIR:'',LLM_PROVIDER:'',FREE_AI_URL:'',FREE_AI_TOKEN:'',VOLC_APP_KEY:'',VOLC_ACCESS_KEY:'',VOLC_RESOURCE_ID:'volc.seedasr.sauc.duration',DEEPSEEK_API_KEY:'',NOTION_TOKEN:'',GOOGLE_DRIVE_PATHS:'',LLM_BASE_URL:'https://api.deepseek.com',LLM_MODEL:'deepseek-chat',LLM_MODEL_QUICK:'',LLM_QUICK_ROUTE:'auto',LLM_MODEL_LIVE:'sonnet',LLM_MODEL_POST:'fable',LLM_MODEL_POST_FALLBACK:'opus',LLM_LIVE_THINKING:'0',LLM_MODEL_THINK:'opus',VERIFY_LIVE:'on',VERIFY_THINKING:'8000',THINK_PASS:'on',TRIAGE_CONTEXT_DELTA:'0',ACTIVE_INTELLIGENCE_MODE:'rapid',ACTIVE_INTELLIGENCE_FAST_MS:'5000',ACTIVE_INTELLIGENCE_SWEEP_MS:'60000',ACTIVE_INTELLIGENCE_SLOW_MS:'60000',ACTIVE_INTELLIGENCE_SLOW_GAP_MS:'180000',ARCHIVE_TARGET:'local',THT_ARCHIVE_OWNER_ID:'',AUDIO_RETENTION_DAYS:'30',JEV_API_KEY:'',JEV_GATE:'on',JEV_THRESHOLD:'0.25',JEV_MIN_GAP_MS:'2000',LOCAL_GATE:'on',DECISION_BOARD_DIR:'',MEETING_PUSH:'off',MEETING_PUSH_SELF_NAMES:'',MEETING_PUSH_MIN_GAP_MS:'120000',MEETING_PUSH_TO:'',MEETING_DM_PUSH:'on'};   // DECISION_BOARD_DIR：决策板夜间导出目录（app/decision-board.js，默认 <PROJECT_CONTEXT_DIR>/kb_backup）；MEETING_PUSH*：会中飞书提醒白名单推送（app/push-whitelist.js，THT-R4：默认 off = 零推送，分诊照跑）   // LLM_LIVE_THINKING：会中分诊（live 档）走 claude 命令行时的思考预算。默认不带思考（'0'；实测分诊 2,000 多输出 token 大半是思考，回放中位 15.2 s → 5.1 s、条目数没少），设 '1' 或更大恢复思考（值 = 预算上限），'' = 不干预沿用命令行默认   // TRIAGE_CONTEXT_DELTA：项目背景「hash 不变只给占位」，默认 '0' 关（claude -p 每次新进程，模型看不见「上一次」，占位那轮没有背景可对照），'1' 启用   // JEV_*：逐句门卫（app/jev-gate.js），JEV_GATE=on 且有密钥才调；密钥只在 settings.json（2026-09-22 Aaron 确认上云链路）   // AUDIO_RETENTION_DAYS：录音保留天数，0 = 不清理；文字永不删（2026-09-22 Aaron 定）
// JEV_REALTIME 是 JEV_GATE 的别名（批 5，2026-09-22）：老设置 / 需求单里写的是 JEV_REALTIME，读进来当 JEV_GATE 用；两个都写了以 JEV_GATE 为准。
function aliasJev(j){const out={...j};if(out.JEV_GATE===undefined||out.JEV_GATE==='') {if(out.JEV_REALTIME!==undefined&&out.JEV_REALTIME!=='') out.JEV_GATE=out.JEV_REALTIME;} return out;}
function load(){const j=JSON.parse(fs.readFileSync(file,'utf8'));if(!j.RELAY_TOKEN)throw Error('本机配置不完整，请恢复 settings.json');return {...defaults,...aliasJev(j)};}
function save(j){const temp=file+'.tmp';fs.writeFileSync(temp,JSON.stringify(j,null,2),{mode:0o600});fs.chmodSync(temp,0o600);fs.renameSync(temp,file);}
// 首次启动：如果安装包里带了 preset.json（Aaron 给家人预配好的凭据），就用它开箱即用。
// preset 只读一次，读完不删原文件（重装还能用），但凭据只会落进本机 settings.json（权限 600）。
function readPreset(){
  for(const dir of [path.join(__dirname,'..'), __dirname]){
    const f=path.join(dir,'preset.json');
    try{ if(fs.existsSync(f)){ const j=JSON.parse(fs.readFileSync(f,'utf8')); const out={};
      for(const k of Object.keys(defaults)) if(typeof j[k]==='string'&&j[k]) out[k]=j[k];
      return out; } }catch(e){}
  }
  return {};
}
// 升级仅填空白，版本变化也不覆盖用户已有的模型、语音或 JEV 设置。
function presetPatch(cur,preset){
  const patch={};
  for(const [k,v] of Object.entries(preset)) if(k!=='PRESET_VERSION'&&!cur[k]) patch[k]=v;
  if(preset.PRESET_VERSION&&cur.PRESET_VERSION!==preset.PRESET_VERSION) patch.PRESET_VERSION=preset.PRESET_VERSION;
  return Object.keys(patch).length?patch:null;
}
function applyPreset(cur){return presetPatch(cur,readPreset());}
if(!fs.existsSync(file)){
  const p=readPreset(); const ver=p.PRESET_VERSION||''; delete p.PRESET_VERSION;
  save({...defaults,...p,...(ver?{PRESET_VERSION:ver}:{}),RELAY_TOKEN:crypto.randomBytes(32).toString('hex')});
}else{
  try{
    const cur=JSON.parse(fs.readFileSync(file,'utf8'));
    const patch=applyPreset(cur);
    // Preserve the old implicit mode on upgrades; only a fresh install defaults to rapid.
    let migrated=false;
    for(const [key,value] of Object.entries({ACTIVE_INTELLIGENCE_MODE:'legacy',ACTIVE_INTELLIGENCE_FAST_MS:'7000',JEV_GATE:aliasJev(cur).JEV_GATE||'off',JEV_THRESHOLD:'0.5'})){
      if(!cur[key]){cur[key]=value;migrated=true;}
    }
    if(patch||migrated)save({...cur,...patch});
  }catch(e){}
}
module.exports={dataDir,file,load,save,defaults,aliasJev,presetPatch};
