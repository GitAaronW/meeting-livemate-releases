'use strict';
// The browser and disk store use exactly the same open document schema.
const {getSchema,Extension,StarterKit,TableKit,Image,TaskList,TaskItem}=require('./mother-document-runtime');
const Blocks=Extension.create({name:'documentBlocks',addGlobalAttributes(){return [{types:['paragraph','heading','blockquote','bulletList','orderedList','codeBlock','table','image','horizontalRule','taskList'],attributes:{blockId:{default:null},sourceRef:{default:null},candidateId:{default:null},sourceRefs:{default:null},aiComments:{default:null},draft:{default:null,parseHTML:element=>element.getAttribute('data-draft'),renderHTML:attrs=>attrs.draft?{'data-draft':attrs.draft}:{}}}}];}});
const extensions=()=>[StarterKit.configure({undoRedo:false}),TableKit.configure({table:{resizable:true}}),Image.configure({allowBase64:true}),TaskList,TaskItem.configure({nested:true}),Blocks];
const schema=getSchema(extensions());
const empty=()=>({type:'doc',content:[{type:'paragraph'}]});
function validate(json){
 if(!json||json.type!=='doc'||JSON.stringify(json).length>6000000)throw Error('Document is too large or invalid');
 let count=0;const seen=new Set();
 function visit(n,depth){
  if(++count>16000||depth>40||!n||!schema.nodes[n.type])throw Error('Invalid document structure');
  for(const [k,v] of Object.entries(n.attrs||{})){
   if(['blockId','sourceRef','candidateId','draft','alt','title','language'].includes(k)&&v!=null&&(typeof v!=='string'||v.length>1000))throw Error('Invalid block attribute');
  }
  if(n.attrs?.sourceRefs!=null&&(!Array.isArray(n.attrs.sourceRefs)||n.attrs.sourceRefs.length>100||n.attrs.sourceRefs.some(r=>typeof r!=='string'||r.length>1000)))throw Error('Invalid source references');
  if(n.attrs?.aiComments!=null&&(typeof n.attrs.aiComments!=='string'||n.attrs.aiComments.length>4000))throw Error('Invalid block comments');
  if(depth===1&&n.attrs?.blockId){if(seen.has(n.attrs.blockId))throw Error('Duplicate block id');seen.add(n.attrs.blockId);}
  if(n.type==='taskItem'&&typeof n.attrs?.checked!=='boolean')throw Error('Invalid task state');
  if(n.type==='image'&&!/^data:image\/(?:png|jpeg|jpg|webp|gif);base64,[A-Za-z0-9+/=]+$/.test(n.attrs?.src||''))throw Error('Images must be embedded raster images');
  for(const m of n.marks||[]){if(!schema.marks[m.type])throw Error('Invalid mark');if(m.type==='link'&&!safeLink(m.attrs?.href||''))throw Error('Unsafe link');}
  for(const c of n.content||[])visit(c,depth+1);
 }
 visit(json,0);const doc=schema.nodeFromJSON(json);doc.check();return doc.toJSON();
}
function safeLink(value){try{const u=new URL(value);return ['https:','http:','mailto:'].includes(u.protocol)&&!u.username&&!u.password;}catch{return false;}}
function text(value){
 const s=String(value||''),nodes=[];let cursor=0;const pattern=/\[([^\]]+)\]\(([^\s)]+)\)/g;let match;
 while((match=pattern.exec(s))){if(!safeLink(match[2]))continue;if(match.index>cursor)nodes.push({type:'text',text:s.slice(cursor,match.index)});nodes.push({type:'text',text:match[1],marks:[{type:'link',attrs:{href:match[2],target:'_blank',rel:'noopener noreferrer'}}]});cursor=pattern.lastIndex;}
 if(cursor<s.length)nodes.push({type:'text',text:s.slice(cursor)});return nodes;
}
const paragraph=s=>({type:'paragraph',...(s?{content:text(s)}:{})});
function fromMarkdown(markdown){
 const lines=String(markdown||'').split(/\r?\n/),out=[];
 for(let i=0;i<lines.length;i++){
  const line=lines[i].trim();if(!line)continue;
  if(line.startsWith('|')&&/^\s*\|?\s*:?-{3}/.test(lines[i+1]||'')){
   const cells=s=>s.trim().replace(/^\||\|$/g,'').split('|').map(v=>v.trim());
   const rows=[cells(line)];i+=2;for(;i<lines.length&&lines[i].trim().startsWith('|');i++)rows.push(cells(lines[i]));i--;
   const cols=Math.min(30,rows[0].length);out.push({type:'table',content:rows.slice(0,150).map((r,j)=>({type:'tableRow',content:Array.from({length:cols},(_,k)=>({type:j?'tableCell':'tableHeader',content:[paragraph(r[k]||'')]}))}))});continue;
  }
  const h=/^(#{1,6})\s+(.+)$/.exec(line);
  if(h){out.push({type:'heading',attrs:{level:h[1].length},content:text(h[2])});continue;}
  const task=/^[-*]\s+\[([ xX])\]\s+(.+)$/.exec(line);
  if(task){let list=out.at(-1);if(list?.type!=='taskList'){list={type:'taskList',content:[]};out.push(list);}list.content.push({type:'taskItem',attrs:{checked:task[1].toLowerCase()==='x'},content:[paragraph(task[2])]});continue;}
  const li=/^[-*]\s+(.+)$/.exec(line);
  if(li){let list=out.at(-1);if(list?.type!=='bulletList'){list={type:'bulletList',content:[]};out.push(list);}list.content.push({type:'listItem',content:[paragraph(li[1])]});continue;}
  out.push(paragraph(line));
 }
 return validate({type:'doc',content:out.length?out:[paragraph('')]});
}
module.exports={schema,extensions,validate,empty,fromMarkdown,paragraph,Blocks};
