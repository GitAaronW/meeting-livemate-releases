'use strict';
// The native panel is a second view of the same Session, never another archive.
const fs=require('fs'),path=require('path'),crypto=require('crypto'),{execFile}=require('child_process');
const journal=require('./session-journal');
// A test helper has a separate bundle identity; production never reads the override.
const APP=process.env.THT_TEST==='1'&&path.isAbsolute(process.env.THT_NATIVE_TEST_APP||'')?process.env.THT_NATIVE_TEST_APP:path.join(__dirname,'native-capture','TinghuitaiCapture.app');
const BIN=path.join(APP,'Contents','MacOS','TinghuitaiCapture');
function available(){return process.platform==='darwin'&&fs.existsSync(BIN);}
function meetingLink(value){
  if(typeof value!=='string')throw Error('请粘贴完整的会议链接');
  let u;try{u=new URL(value);}catch{throw Error('请粘贴完整的飞书 / Lark 或 Google Meet 会议链接');}
  if(u.protocol!=='https:'||u.username||u.password||u.port||value.length>2000)throw Error('invalid_meeting_link');
  const valid=u.hostname==='meet.google.com'?/^\/[a-z]{3}-[a-z]{4}-[a-z]{3}\/?$/.test(u.pathname):['vc.feishu.cn','vc.larksuite.com','vc-sg.larksuite.com'].includes(u.hostname)&&/^\/j\/\d{9}\/?$/.test(u.pathname);
  if(!valid)throw Error('目前支持飞书 / Lark 的 /j/ 会议链接与 Google Meet 会议链接');
  return u.href;
}
function rules(dataDir){
  const fallback=JSON.parse(fs.readFileSync(path.join(__dirname,'native-insight-rules.json'),'utf8'));
  let x;try{x=JSON.parse(fs.readFileSync(path.join(dataDir,'state','native-insight-rules.json'),'utf8'));}catch{x=fallback;}
  return {revision:String(x.revision||fallback.revision).slice(0,40),prompt:typeof x.prompt==='string'&&x.prompt.trim()?x.prompt.slice(0,6000):fallback.prompt,
    minGapMs:Math.max(1000,Math.min(60000,Number(x.minGapMs)||fallback.minGapMs)),recentSentences:Math.max(1,Math.min(6,Number(x.recentSentences)||6)),maxTextChars:Math.max(200,Math.min(2400,Number(x.maxTextChars)||2400))};
}
function jpegSize(b){
  if(b.length<4||b[0]!==255||b[1]!==216)throw Error('invalid_jpeg');
  for(let i=2;i<b.length;){if(b[i++]!==255)throw Error('invalid_jpeg');while(b[i]===255)i++;const m=b[i++];if(m===217||m===218)break;if(m===1||(m>=208&&m<=215))continue;
    if(i+2>b.length)break;const n=b.readUInt16BE(i);if(n<2||i+n>b.length)break;
    if([192,193,194].includes(m)){if(n<8)break;return {width:b.readUInt16BE(i+5),height:b.readUInt16BE(i+3)};}i+=n;
  }throw Error('invalid_jpeg');
}
function cards(text,sourceIds){
  const json=String(text||'').trim().replace(/^```(?:json)?\s*/,'').replace(/\s*```$/,'');const j=JSON.parse(json);
  const clean=x=>{if(!x||typeof x.text!=='string'||!x.text.trim())return null;const refs=(Array.isArray(x.sourceIds)?x.sourceIds:[]).filter(id=>sourceIds.has(id)).slice(0,6);if(!refs.length)return null;return {text:x.text.trim().slice(0,1200),sourceIds:refs};};
  return {suggestion:clean(j.suggestion),insights:(Array.isArray(j.insights)?j.insights:[]).slice(0,2).map(clean).filter(Boolean)};
}
// A source-backed judgment can replace its repeated lightweight explanation.
// Keep different useful points, even when they cite the same sentence.
function mergeJudgmentCards(next, signals, en=false, existing=[]) {
  const {repeated}=require('./grounded-card-dedupe');
  const fresh=new Set(signals);
  for(const item of [...signals,...existing.filter(x=>!fresh.has(x))].filter(x=>x.channel==='judgment'&&!x.stale&&!x.supersededBy)){
    const card={text:(en?'AI interpretation: ':'AI 解读：')+item.point.slice(0,1200),sourceIds:item.sourceRefs.map(x=>x.segId)};
    const meaning={...card,text:item.point.slice(0,1200)};
    if(next.suggestion&&repeated(next.suggestion,meaning))next.suggestion=null;
    next.insights=next.insights.filter(x=>!repeated(x,meaning));
    if(fresh.has(item)&&next.insights.length<2)next.insights.push(card);
  }
  return next;
}
// A bounded presentation history lives on the same persisted Session.
function panelCards(session,current,{append=false,now=Date.now}={}) {
  const stamp = item => {
    if(!item?.text)return null;
    const sourceIds=(item.sourceIds||[]).slice(0,6);
    const row=(session?.transcript||[]).find(r=>sourceIds.includes(r.id||r.segId));
    const raw=row?.t??row?.atSec??row?.at;
    const seconds=Number.isFinite(Number(raw))&&raw!==null&&raw!==undefined&&Number(raw)>=0&&Number(raw)<1e9?Number(raw):null;
    const clock=seconds===null?(typeof raw==='string'&&/^\d+:\d{2}$/.test(raw)?raw:''):Math.floor(seconds/60)+':'+String(Math.floor(seconds%60)).padStart(2,'0');
    const speaker=row?.speaker||row?.spk||row?.who||'';
    return {...item,sourceIds,key:crypto.createHash('sha256').update(item.text+'|'+sourceIds.join(',')).digest('hex').slice(0,16),sourceLabel:[clock,speaker].filter(Boolean).join(' · ')};
  };
  const suggestion=stamp(current?.suggestion),insights=(current?.insights||[]).slice(0,2).map(stamp).filter(Boolean);
  const existing=(session?.nativeInsights?.history||[]).slice(-40);
  const candidates=append?[...[suggestion,...insights].filter(Boolean).map(x=>({...x,kind:x===suggestion?'suggestion':'insight',createdAt:now()}))]:[];
  // Browser capture already journals prior judgements/fact checks; reuse them.
  const journal=(session?.factchecks||[]).filter(x=>!x.stale).slice(-40).map(x=>stamp({text:x.point||x.claim||x.md||'',sourceIds:(x.sourceRefs||[]).map(r=>typeof r==='string'?r:(r.segId||r.id)),superseded:!!x.supersededBy,kind:x.channel==='judgment'?'judgment':'insight',createdAt:x.createdAt})).filter(Boolean);
  const history=new Map();for(const x of [...existing,...journal,...candidates])history.set(x.key,x);
  const result={...current,suggestion,insights,history:[...history.values()].slice(-40)};
  return result;
}
class InsightFeed {
  constructor({dataDir,session,ask,onChange=()=>{},onDeliverable=()=>{},onSignals=()=>{},detectionContext=()=>null,now=Date.now,log=()=>{}}){Object.assign(this,{dataDir,session,ask,onChange,onDeliverable,onSignals,detectionContext,now,log});this.revision=0;this.epoch=0;this.handled=0;this.lastCall=0;this.busy=false;this.enabled=true;this.closed=false;this.seen=new Set();this.image=null;this.cardState={suggestion:null,insights:[]};this.calls=0;this.phase='listening';}
  text(event){if(this.closed||!this.enabled)return false;const key=String(event.key||'');const text=String(event.text||'').trim().slice(0,4000);if(!key||key.length>120||!text||this.seen.has(key))return false;this.seen.add(key);if(this.seen.size>2000)this.seen.delete(this.seen.values().next().value);const count=this.session.transcript.length;this.session.onMacResult({type:'final',text});if(this.session.transcript.length===count)return false;this.changed();return true;}
  frame(encoded){if(this.closed||!this.enabled)return false;const b=Buffer.from(String(encoded||''),'base64');if(!b.length||b.length>160000)throw Error('frame_too_large');const size=jpegSize(b);if(size.width>960||size.height>960||size.width<32||size.height<32)throw Error('frame_dimensions');const hash=crypto.createHash('sha256').update(b).digest('hex');if(this.image?.hash===hash)return false;
    const dir=path.join(this.dataDir,'state','native-frames',this.session.id);fs.mkdirSync(dir,{recursive:true,mode:0o700});const file=path.join(dir,hash+'.jpg');fs.writeFileSync(file,b,{mode:0o600});this.image={hash,path:file,mime:'image/jpeg',capturedAt:new Date(this.now()).toISOString()};this.session.nativeCurrentFrame=this.image;this.changed();return true;}
  changed(){this.revision++;this.schedule();}
  schedule(){if(this.closed||!this.enabled||this.busy||this.timer||this.revision<=this.handled)return;const cfg=rules(this.dataDir);const wait=Math.max(120,this.lastCall+cfg.minGapMs-this.now());this.timer=setTimeout(()=>{this.timer=null;this.run();},wait);this.timer.unref?.();}
  async run(){if(this.closed||!this.enabled||this.busy||this.revision<=this.handled)return;this.busy=true;const revision=this.revision,epoch=this.epoch,editEpoch=this.session.editEpoch||0;this.handled=revision;this.lastCall=this.now();const cfg=rules(this.dataDir);const image=this.image&&this.now()-Date.parse(this.image.capturedAt)<=120000?this.image:null;
    const rows=this.session.transcript.slice(-cfg.recentSentences).map(x=>({id:x.id,t:x.t,at:x.at,speaker:x.speaker,text:String(x.text||'')}));let budget=cfg.maxTextChars;for(let i=rows.length-1;i>=0;i--){rows[i].text=budget>0?rows[i].text.slice(-budget):'';budget-=rows[i].text.length;}const recent=rows.filter(x=>x.text);const ids=new Set(recent.map(x=>x.id));if(image)ids.add('screen');
    this.phase='thinking';this.calls++;this.onChange();
    try{const liveSignals=require('./live-signals'),context=this.detectionContext(this.session),selection=require('./live-draft-selection'),binding=selection.create(this.session.id,recent,context);const raw=await this.ask(require('./native-live-prompt').build(require('./native-work-decision').cardPolicy(cfg.prompt),this.session.uiLang),JSON.stringify({language:this.session.uiLang,evidenceScope:{recentSourceIds:recent.map(r=>r.id),meetingStartedAt:this.session.start||null},transcript:recent,screen:image?'当前共享画面':null,previousJudgments:liveSignals.context(this.session),decisionThread:liveSignals.decisionThread(this.session),draftContext:binding.input}),{sessionId:this.session.id,purpose:'native-live',...require('./context-pack').stamp(context),images:image?[image]:[],tools:false,thinkGuide:false,json:true,timeoutMs:25000});
      if(this.closed||!this.enabled||epoch!==this.epoch)return;if(editEpoch!==(this.session.editEpoch||0)){this.phase='listening';this.onChange();return;}if(typeof raw!=='string'||!raw.trim())throw Error('model_empty_response');const next=cards(raw,ids);const parsed=JSON.parse(String(raw).replace(/^```(?:json)?\s*/,'').replace(/\s*```$/,''));const decision=selection.assess(parsed,binding,selection.create(this.session.id,recent,this.detectionContext(this.session)));const {deliverable,...record}=decision;this.session.nativeDraftDecision={...record,at:new Date(this.now()).toISOString()};if(decision.state==='invalid')this.log('native draft protocol '+decision.code);if(deliverable)this.onDeliverable(this.session,deliverable,recent);require('./live-confirmations').offer(this.session,parsed.confirmation,recent);
      const signals=this.onSignals(this.session,parsed,recent)||[];
      mergeJudgmentCards(next,signals,this.session.uiLang==='en',this.session.factchecks||[]);
      this.cardState=next;this.phase='listening';this.ruleRevision=cfg.revision;this.onChange(next);}
    catch(e){if(!this.closed&&this.enabled&&epoch===this.epoch){this.phase='model_unavailable';this.log('native insight '+e.message);this.onChange();}}
    finally{this.busy=false;this.pruneFrames();this.schedule();}
  }
  pruneFrames(){const dir=path.join(this.dataDir,'state','native-frames',this.session.id);try{for(const f of fs.readdirSync(dir))if(f!==path.basename(this.image?.path||'')&&/^[a-f0-9]{64}\.jpg$/.test(f))fs.unlinkSync(path.join(dir,f));}catch{}}
  pause(value){if(value){this.image=null;this.session.nativeCurrentFrame=null;}this.epoch++;this.enabled=!value;clearTimeout(this.timer);this.timer=null;this.handled=this.revision;this.phase=value?'paused':'listening';this.onChange();}
  close(){this.image=null;this.session.nativeCurrentFrame=null;this.epoch++;this.closed=true;this.enabled=false;clearTimeout(this.timer);this.timer=null;this.phase='ended';this.onChange();if(!this.busy)this.pruneFrames();}
}
function normalizeInputs(rows){return (Array.isArray(rows)?rows:[]).filter(d=>d&&typeof d.uid==='string'&&d.uid&&typeof d.name==='string').slice(0,100).map(d=>({uid:d.uid.slice(0,300),name:d.name.slice(0,200),isDefault:!!d.isDefault}));}
function create({dataDir,startSession,activeSession,ask,port,onDeliverable=()=>{},onSignals=()=>{},detectionContext=()=>null,log=()=>{},openMain=require('./desktop-open').openMain,canLaunch=available,launch=execFile,watchMeetings=false,config=()=>({}),prepareStart=j=>j,onCaptureReady=()=>{}}){
  let current=null,command='',launching=false,launchCommand='',pendingJoinUrl='',pendingStart=null,pendingStartAt=0,launchGeneration=0,startupError='';
  if(watchMeetings&&canLaunch())launch('/usr/bin/open',['-g','-n','-a',APP,'--args','--server','http://127.0.0.1:'+port,'--watch'],{timeout:6000},e=>{if(e)log('meeting watcher '+e.message);});
  const owners=require('./native-owner').create({active:token=>(current?.owner===token&&!current.session.finalized)||(!!pendingStart&&pendingOwner===token)});let pendingOwner='';
  let browserCommand='',browserCommandSession='',browserView='expanded',inputUID='',inputDevices=[];
  const panelPresence=require('./meeting-presence').create();
  const browserSession=()=>{const s=activeSession();return s&&!s.finalized&&!s.nativeCapture&&!(current&&current.session===s&&!s.finalized)?s:null;};
  const transcriptSeconds=value=>{const parts=String(value??'').split(':');const n=parts.length>1&&parts.length<=3&&parts.every(x=>/^\d+(?:\.\d+)?$/.test(x))?parts.reduce((seconds,x)=>seconds*60+Number(x),0):Number(value);return Number.isFinite(n)?Math.max(0,n):0;};
  const recentTranscript=s=>(s?.transcript||[]).slice(-120).map(r=>({t:transcriptSeconds(r.t),text:String(r.text||'').slice(0,2000)}));
  const status=()=>{
    if(pendingStart&&Date.now()-pendingStartAt>120000){pendingStart=null;pendingOwner='';pendingJoinUrl='';launchCommand='';launchGeneration++;launching=false;startupError='录音启动超时，请重试';}
    const s=browserSession();
    if(s)return {available:canLaunch(),active:true,captureMode:'browser',recentTranscript:recentTranscript(s),gate:s.jev?.snapshot?.()||null,startedAt:s.startTs||Date.parse(s.start)||null,sessionId:s.id,title:s.title||'',phase:s.miniPaused?'paused':'listening',target:null,confirmation:require('./live-confirmations').visible(s),cards:panelCards(s,s.nativeInsights||{suggestion:null,insights:(s.factchecks||[]).filter(x=>!x.stale&&!x.supersededBy&&(!x.channel||x.channel==='judgment')).slice(-2).map(x=>({text:(x.channel==='judgment'?'AI 解读：':'')+(x.point||x.claim||x.md||''),sourceIds:(x.sourceRefs||[]).map(r=>r.segId||r)}))}),command:browserCommandSession===s.id?browserCommand:'',audioSeconds:Math.max(0,(Date.now()-(s.startTs||Date.now()))/1000),audioLevel:Date.now()-(s.audioLevelAt||0)<1200&&!s.miniPaused?s.audioLevel||0:0,error:'',view:browserView};
    return {starting:!!pendingStart,pendingSessionId:pendingStart?.sessionId||'',captureReady:!!current&&!current.session.finalized&&!!current.captureReady,available:canLaunch(),active:!!current&&!current.session.finalized,captureMode:'native',recentTranscript:current&&!current.session.finalized?recentTranscript(current.session):[],startedAt:current?.session.startTs||Date.parse(current?.session.start)||null,sessionId:current&&!current.session.finalized?current.session.id:'',title:current?.session.title||'',phase:current?.feed.phase||'idle',target:current?.target||null,confirmation:require('./live-confirmations').visible(current?.session),cards:panelCards(current?.session,current?.feed.cardState||{suggestion:null,insights:[]}),calls:current?.feed.calls||0,command:current&&!current.session.finalized?command:launchCommand,meetingUrl:pendingJoinUrl,audioSeconds:current?.audioSeconds||0,audioLevel:Date.now()-(current?.audioLevelAt||0)<1200?current?.audioLevel||0:0,frames:current?.frames||0,inputUID:current?.inputUID||'',inputName:current?.inputName||'',inputDevices,audioSource:'system-microphone',audioEvidence:current?.audioEvidence||null,requestedInputUID:inputUID,microphoneChange:current?.microphoneChange||null,microphoneReceipt:current?.microphoneReceipt||null,error:current&&!current.session.finalized?current.error||'':startupError,view:current?.view||'expanded'};
  };
  const notify=()=>{if(current){current.session.nativeInsights={...panelCards(current.session,current.feed.cardState,{append:true}),phase:current.feed.phase,ruleRevision:current.feed.ruleRevision||'',calls:current.feed.calls};current.session.checkpoint();current.session.broadcast({type:'native-status',...status()});}};
  const audioConfig=(e=config())=>{const provider=e.ASR_PROVIDER||'volc';return provider==='deepgram'&&e.DEEPGRAM_API_KEY?{transport:'pcm',provider:'deepgram'}:provider!=='mac'&&e.VOLC_APP_KEY&&e.VOLC_ACCESS_KEY?{transport:'pcm',provider:'volc'}:{transport:'text',provider:'mac'};};
  async function start(j,owner=''){if(owner&&!owners.has(owner))throw Error('native_owner_unknown');if(pendingStart&&pendingOwner!==owner)throw Error('native_start_owner_changed');if(owner&&owners.status(owner).quitRequested)throw Error('native_owner_quitting');if(owner&&browserSession())throw Error('browser_capture_owns_this_meeting');if(current&&!current.session.finalized)throw Error('native_capture_already_active');const other=activeSession();const target=j.target||{bundleId:'',title:'',windowId:0};
    if(!target||typeof target.bundleId!=='string'||typeof target.title!=='string'||!Number.isInteger(target.windowId))throw Error('meeting_window_required');
    const intent=pendingStart||prepareStart(j);
    const session=other||startSession({...intent,nativeCapture:true,source:'mac-native',title:intent.title||target.title.slice(0,200),lang:intent.lang||j.lang||'zh',uiLang:intent.uiLang||j.uiLang||'zh'});pendingStart=null;pendingOwner='';
    if(other){other.enableNativeCapture();other.broadcast({type:'native-handoff',sessionId:other.id});}
    const feed=new InsightFeed({dataDir,session,ask,onChange:notify,onDeliverable,onSignals,detectionContext,log});current={session,feed,owner,target:{bundleId:target.bundleId.slice(0,120),title:target.title.slice(0,200),windowId:target.windowId},lastHeartbeat:Date.now(),audioSeconds:0,frames:0,audioIngress:require('./native-audio').createIngress()};const asr=audioConfig(session.env||config());session.onNativeTranscript=()=>{if(asr.transport==='pcm')feed.changed();};if(asr.transport==='pcm')session.enableNativeAudio(asr.provider);current.asr=asr;startupError='';command='';launchCommand='';notify();return {...status(),inputUID,audioPath:session.audioPath,asr:current.asr};
  }
  async function end(){if(!current)return status();command='';current.feed.close();await current.session.finalize('原生会议已结束');notify();return status();}
  const lease=setInterval(()=>{if(current&&!current.session.finalized&&Date.now()-current.lastHeartbeat>20000){if(current.error!=='小窗连接中断，本机录音可继续，正在等待重连'){current.error='小窗连接中断，本机录音可继续，正在等待重连';notify();}}},5000);lease.unref();
  async function route(req,res,u,local){const p=u.pathname.replace(/^\/asr-relay/,'');if(!p.startsWith('/native/'))return false;
    const send=(code,j)=>{res.writeHead(code,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(j));return true;};if(!local)return send(403,{error:'native_local_only'});
    if(req.headers.origin&&req.headers.origin!==`http://127.0.0.1:${port}`&&req.headers.origin!==`http://localhost:${port}`)return send(403,{error:'native_origin_rejected'});
    const owner=String(req.headers['x-tht-native-owner']||'');
    const ownedStatus=()=>{
      const result=status(),own=owner&&owners.has(owner)?owners.status(owner):null;
      if(result.command==='quit'||(!result.active&&pendingOwner!==owner))result.command='';
      if(own){
        if(own.quitRequested)result.command='quit';
        if(!current?.owner||current.owner===owner)result.panelPolicy=owners.panelPolicy(owner,result.sessionId,result.active);
      }
      const presence=panelPresence.visible(result.sessionId);
      if(presence!==null){
        const dismissed=panelPresence.dismissed(result.sessionId)||own?.dismissedSessionId===result.sessionId;
        result.panelPolicy={managed:true,sessionId:result.sessionId,show:!!result.active&&!presence&&own?.mainForeground!==true&&!dismissed&&result.command!=='quit'};
      }else if(!result.active&&panelPresence.known())result.panelPolicy={managed:true,sessionId:'',show:false};
      return result;
    };
    if(req.method==='GET'&&p==='/native/owner-status'){try{return send(200,{ok:true,...owners.status(owner)});}catch(e){return send(409,{error:e.message});}}
    if(req.method==='GET'&&p==='/native/status')return send(200,ownedStatus());
    if(req.method==='GET'&&p==='/native/audio-config')return send(200,{...audioConfig(),inputUID});
    if(req.method==='GET'&&p==='/native/rules')return send(200,rules(dataDir));
    let j={};if(req.method==='POST'||req.method==='PUT'){try{const chunks=[];let n=0;for await(const c of req){n+=c.length;if(n>240000)throw Error('payload_too_large');chunks.push(c);}j=JSON.parse(Buffer.concat(chunks).toString()||'{}');}catch(e){return send(400,{error:e.message});}}
    try{
      if(req.method==='POST'&&p==='/native/owner-register')return send(200,{ok:true,...owners.register(owner,j.pid||0)});
      if(req.method==='POST'&&p==='/native/panel-presence'){const s=status();if(!s.active||s.sessionId!==j.sessionId)throw Error('meeting_changed');panelPresence.update(j.clientId,j.sessionId,j.foreground);return send(200,{ok:true});}
      if(req.method==='POST'&&p==='/native/owner-visibility')return send(200,{ok:true,...owners.visibility(owner,j.foreground)});
      if(req.method==='POST'&&p==='/native/owner-panel-dismiss'){const s=status();if(!s.active||!j.sessionId||s.sessionId!==j.sessionId||current&&!current.session.finalized&&current.owner&&current.owner!==owner)throw Error('native_panel_session_changed');if(owner)owners.dismissPanel(owner,j.sessionId);else panelPresence.dismiss(j.sessionId);return send(200,{ok:true});}
      if(req.method==='POST'&&p==='/native/owner-helper-ready')return send(200,{ok:true,...owners.helperReady(owner,j.pid)});
      if(req.method==='POST'&&p==='/native/owner-open-main'){owners.openMain(owner,j.sessionId);return send(200,{ok:true});}
      if(req.method==='POST'&&p==='/native/owner-quit'){owners.requestQuit(owner);if(pendingOwner===owner){pendingStart=null;pendingOwner='';pendingJoinUrl='';launchCommand='';}return send(200,{ok:true,...owners.status(owner)});}
      if(req.method==='POST'&&p==='/native/owner-quit-failed'){owners.failed(owner,j.error);return send(200,{ok:true});}
      if(req.method==='POST'&&p==='/native/owner-quit-ready'){
        if(pendingOwner===owner||current?.owner===owner&&!current.session.finalized)throw Error('native_meeting_not_saved');
        owners.saved(owner);return send(200,{ok:true});
      }
      if(req.method==='POST'&&p==='/native/owner-release'){owners.release(owner);return send(200,{ok:true});}
      if(owner&&!owners.has(owner))throw Error('native_owner_unknown');
      if(req.method==='POST'&&p==='/native/input-devices'){if(!owner||!owners.has(owner))throw Error('native_owner_unknown');if(current&&!current.session.finalized&&current.owner&&owner!==current.owner)throw Error('native_capture_owned_by_another_window');inputDevices=normalizeInputs(j.inputDevices);return send(200,{ok:true});}
      if(req.method==='POST'&&p==='/native/input-preference'){if(status().active)throw Error('capture_already_active');const uid=String(j.inputUID||'');if(uid&&!inputDevices.some(d=>d.uid===uid))throw Error('microphone_disconnected');inputUID=uid;return send(200,{ok:true,inputUID});}
      if(req.method==='POST'&&p==='/native/open-main'){const sessionId=j.sessionId||status().sessionId||'';const result=await openMain({port,sessionId});return send(200,{ok:true,...result});}
      if(req.method==='POST'&&(p==='/native/launch'||p==='/native/join')){
        if(!canLaunch())return send(503,{error:'原生小窗尚未安装'});
        if(owner&&owners.status(owner).quitRequested)throw Error('native_owner_quitting');
        if(owner&&current&&!current.session.finalized&&current.owner!==owner)throw Error('native_capture_owned_by_another_window');
        if(owner&&browserSession())throw Error('browser_capture_owns_this_meeting');
        if(pendingStart&&pendingOwner!==owner)throw Error('native_start_owner_changed');
        if(pendingStart&&Date.now()-pendingStartAt>120000){pendingStart=null;pendingOwner='';pendingJoinUrl='';launchCommand='';}
        const joinUrl=p==='/native/join'?meetingLink(j.url):'';
        if(joinUrl&&status().active){
          if(!j.sessionId||j.sessionId!==current?.session.id)return send(409,{error:'已有会议正在录制，请先结束这场再加入另一场'});
          const failure=await new Promise(resolve=>launch('/usr/bin/open',[joinUrl],{timeout:6000},resolve));
          return failure?send(503,{error:'会议链接未能打开，请重试；现有录音仍在继续'}):send(200,{ok:true,...status()});
        }
        const queued=!!launchCommand;
        const intent=(j.autoStart||p==='/native/join')&&!status().active?prepareStart(j):null;
        if(intent&&pendingStart&&pendingStart.sessionId!==intent.sessionId)throw Error('另一场会议正在接入，请先取消或完成');
        if(p==='/native/join'){
          const url=joinUrl;
          if(pendingJoinUrl&&pendingJoinUrl!==url)return send(409,{error:'正在打开另一场会议，请先在小窗处理'});
          pendingJoinUrl=url;launchCommand='start';
        }
        if(intent){startupError='';pendingStart=intent;pendingOwner=owner;pendingStartAt=Date.now();}
        if((j.autoStart||joinUrl)&&!status().active)launchCommand='start';
        if(joinUrl&&!queued){
          const failure=await new Promise(resolve=>launch('/usr/bin/open',[joinUrl],{timeout:6000},resolve));
          if(failure){launchCommand='';pendingJoinUrl='';pendingStart=null;pendingOwner='';return send(503,{error:'会议链接未能打开，请重试'});}
        }
        if(!launching&&!queued){
          launching=true;const generation=++launchGeneration,launchedIntent=pendingStart;
          const failure=await new Promise(resolve=>launch('/usr/bin/open',['-g','-n','-a',APP,'--args','--server','http://127.0.0.1:'+port,...((j.autoStart||joinUrl)&&!status().active?['--start']:[]),...(owner?['--owner',owner]:[]),'--locale',j.lang==='en'?'en-US':'zh-CN','--ui-lang',j.uiLang==='en'?'en':'zh'],{timeout:6000},resolve));
          if(generation===launchGeneration)launching=false;
          if(failure){if(pendingStart===launchedIntent){launchCommand='';pendingJoinUrl='';pendingStart=null;pendingOwner='';}log('native launch '+failure.message);return send(503,{error:'录音小窗未能启动，请重试'});}
        }
        if(owner){
          // open(1) succeeding proves launch dispatch only, not that the existing
          // singleton watcher accepted the owner. Confirm the helper receipt.
          const deadline=Date.now()+4000;
          while(!owners.status(owner).helperPid&&Date.now()<deadline)await new Promise(r=>setTimeout(r,50));
          if(!owners.status(owner).helperPid){
            if(pendingOwner===owner){pendingStart=null;pendingOwner='';pendingJoinUrl='';launchCommand='';}
            return send(503,{error:'录音小窗未确认接入，请关闭闲置旧小窗后重试；现有录音未被中断'});
          }
        }
        return send(200,{ok:true,...status()});
      }
      if(pendingStart&&pendingOwner!==owner&&['/native/cancel-start','/native/launch-ack'].includes(p))throw Error('native_start_owner_changed');
      if(req.method==='POST'&&p==='/native/cancel-start'){if(!status().active){pendingStart=null;pendingOwner='';pendingJoinUrl='';launchCommand='';launching=false;launchGeneration++;startupError=typeof j.error==='string'?j.error.slice(0,200):'';}return send(200,{ok:true,...status()});}
      if(req.method==='POST'&&p==='/native/launch-ack'){launchCommand='';pendingJoinUrl='';return send(200,{ok:true});}
      if(req.method==='PUT'&&p==='/native/rules'){if(typeof j.prompt!=='string'||!j.prompt.trim()||j.prompt.length>6000)throw Error('invalid_prompt');journal.write(path.join(dataDir,'state','native-insight-rules.json'),j);return send(200,{ok:true,rules:rules(dataDir)});}
      if(req.method==='POST'&&p==='/native/start')return send(200,{ok:true,...await start(j,owner)});
      if(current&&!current.session.finalized&&current.owner&&owner!==current.owner&&p!=='/native/rules'&&!(p==='/native/microphone-switch'&&!owner&&[`http://127.0.0.1:${port}`,`http://localhost:${port}`].includes(req.headers.origin)))throw Error('native_capture_owned_by_another_window');
      if(req.method==='POST'&&p==='/native/confirmation'){
        const session=browserSession()||current?.session;if(!session||session.id!==j.sessionId)return send(409,{error:'meeting_changed'});
        const confirmation=require('./live-confirmations').respond(session,j.confirmationId,j.response,{dataDir,text:j.text});return send(200,{ok:true,confirmation,...status()});
      }
      const browser=browserSession();
      if(browser){
        if(j.sessionId!==browser.id)return send(409,{error:'meeting_changed'});
      if(req.method==='POST'&&p==='/native/heartbeat'){if(['expanded','compact','transcript','hidden'].includes(j.view))browserView=j.view;return send(200,{ok:true,...ownedStatus()});}
        if(req.method==='POST'&&p==='/native/browser-state'){browser.miniPaused=!!j.paused;return send(200,{ok:true,...status()});}
        if(req.method==='POST'&&p==='/native/browser-ack'){if(j.command===browserCommand&&browserCommandSession===browser.id){browserCommand='';browserCommandSession='';}return send(200,{ok:true,...status()});}
        if(req.method==='POST'&&p==='/native/command'){if(!['stop','pause','resume'].includes(j.command))throw Error('invalid_command');browserCommand=j.command;browserCommandSession=browser.id;browser.broadcast?.({type:'native-view-command',command:browserCommand});return send(200,{ok:true,...status()});}
        return send(409,{error:'browser_capture_owns_this_meeting'});
      }
      if(!current||current.session.finalized)return send(409,{error:'no_native_meeting'});
      if(j.sessionId!==current.session.id)return send(409,{error:'meeting_changed'});
      if(req.method==='POST'&&p==='/native/microphone-switch'){
        const uid=String(j.inputUID||'');if(uid&&!inputDevices.some(d=>d.uid===uid))throw Error('microphone_disconnected');
        if(current.microphoneChange&&Date.now()>current.microphoneChange.expiresAt){current.microphoneReceipt={requestId:current.microphoneChange.requestId,ok:false,error:'录音端未确认切换，可重试；请以实际声音来源为准'};current.microphoneChange=null;}
        if(current.microphoneChange){if(current.microphoneChange.inputUID===uid)return send(200,{ok:true,...status()});throw Error('microphone_switch_pending');}
        current.microphoneChange={requestId:require('crypto').randomUUID(),inputUID:uid,expiresAt:Date.now()+20000};return send(200,{ok:true,...status()});
      }
      if(req.method==='POST'&&p==='/native/microphone-ack'){
        const change=current.microphoneChange;if(!change||change.requestId!==j.requestId){if(current.microphoneReceipt?.requestId===j.requestId)return send(200,{ok:true,...status()});return send(409,{error:'microphone_request_changed'});}
        const error=String(j.error||'').slice(0,200);
        if(!error){current.inputUID=String(j.inputUID||'');current.inputName=String(j.inputName||'');inputUID=change.inputUID;}
        current.microphoneReceipt={requestId:change.requestId,ok:!error,error};current.microphoneChange=null;notify();return send(200,{ok:true,...status()});
      }
      if(req.method==='POST'&&p==='/native/ready'){if(!current.captureReady){onCaptureReady(current.session);current.captureReady=true;}return send(200,{ok:true,...status()});}
      if(req.method==='POST'&&p==='/native/heartbeat'){if(Array.isArray(j.inputDevices))inputDevices=normalizeInputs(j.inputDevices);current.inputUID=String(j.inputUID||current.inputUID||'').slice(0,300);current.inputName=String(j.inputName||current.inputName||'').slice(0,200);if(j.audioEvidence&&typeof j.audioEvidence==='object')current.audioEvidence=Object.fromEntries(['microphoneFrames','systemFrames','microphonePeak','systemPeak','microphoneLevel','systemLevel'].map(k=>[k,Math.max(0,Number(j.audioEvidence[k])||0)]));current.audioLevel=Math.max(0,Math.min(1,Number(j.audioLevel)||0));current.audioLevelAt=Date.now();current.lastHeartbeat=Date.now();current.session.lastAudioTs=Date.now();if(['expanded','compact','transcript','hidden'].includes(j.view)&&current.view!==j.view){current.view=j.view;notify();}current.audioSeconds=Math.max(current.audioSeconds,Math.max(0,Number(j.audioSeconds)||0));if(typeof j.error==='string'&&current.error!==j.error){current.error=String(j.error).slice(0,200);notify();}return send(200,{ok:true,...ownedStatus()});}
      if(req.method==='POST'&&p==='/native/audio'){if(current.asr.transport!=='pcm')throw Error('native_audio_not_configured');if(current.feed.phase==='paused')throw Error('native_audio_paused');const result=current.audioIngress.accept(j,pcm=>current.session.sendAudio(pcm));return send(200,{ok:true,...result});}
      if(req.method==='POST'&&p==='/native/text')return send(200,{ok:true,accepted:current.feed.text(j)});
      if(req.method==='POST'&&p==='/native/frame'){const accepted=current.feed.frame(j.jpeg);if(accepted)current.frames++;return send(200,{ok:true,accepted});}
      if(req.method==='POST'&&p==='/native/pause'){command='';current.feed.pause(!!j.paused);notify();return send(200,{ok:true,...status()});}
      if(req.method==='POST'&&p==='/native/end')return send(200,{ok:true,...await end()});
      if(req.method==='POST'&&p==='/native/command'){if(!['stop','pause','resume'].includes(j.command))throw Error('invalid_command');command=j.command;return send(200,{ok:true,...status()});}
      return send(404,{error:'native_route_not_found'});
    }catch(e){return send(409,{error:String(e.message).slice(0,200)});}
  }
  return {route,status,requestCommand(sessionId,value){if(!current||current.session.finalized||current.session.id!==sessionId)return false;if(!['stop','pause','resume'].includes(value))return false;command=value;return true;},close(){clearInterval(lease);current?.feed.close();}};
}
module.exports={meetingLink,panelCards,mergeJudgmentCards,available,rules,jpegSize,cards,InsightFeed,create};
