'use strict';
// Host originals and detector interpretations travel separately. This is input
// provenance, not an entailment check or a second evidence store.
function original(row,id=row.id){
 return {id,speaker:row.speaker||row.spk||row.who||'',text:String(row.text||'')};
}
function workIntent(text){return {text,status:'unconfirmed-ai-interpretation',isEvidence:false};}
function build(text,rows,sourceIds,{prefix=''}={}){
 const ids=new Set(sourceIds||[]);
 return {workIntent:workIntent(text),triggerEvidence:rows.filter(r=>ids.has(r.id)).map(r=>original(r,prefix+r.id)),surroundingEvidence:rows.slice(-6).filter(r=>!ids.has(r.id)).map(r=>original(r,prefix+r.id))};
}
module.exports={original,workIntent,build};
