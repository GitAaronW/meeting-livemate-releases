'use strict';
// Presentation only. No recording, navigation or session finalization is controlled here.
function create({now=Date.now,ttl=6000}={}){
 let current=null,dismissedSession='';
 return {
  update(clientId,sessionId,foreground){
   if(typeof clientId!=='string'||!/^[a-zA-Z0-9-]{8,100}$/.test(clientId)||typeof sessionId!=='string'||!sessionId||sessionId.length>200||typeof foreground!=='boolean')throw Error('native_presence_invalid');
   // A background/history tab cannot displace the focused meeting page.
   if(current&&current.sessionId===sessionId&&current.clientId!==clientId&&now()-current.at<ttl&&(!foreground||current.foreground))return false;
   current={clientId,sessionId,foreground,at:now()};return true;
  },
  known(){return current!==null;},
  // A closed or crashed page stops renewing its lease. It must not leave the capsule hidden.
  visible(sessionId){return current&&current.sessionId===sessionId?(now()-current.at<ttl?current.foreground:false):null;},
  dismiss(sessionId){dismissedSession=sessionId;},
  dismissed(sessionId){return !!sessionId&&dismissedSession===sessionId;}
 };
}
module.exports={create};
