'use strict';
// An explicit Quit capability belongs to one native main window. A lost
// heartbeat, a page navigation, or an unrelated browser never invokes it.
function create({isAlive = pid => { try { process.kill(pid, 0); return true; } catch (e) { return e.code !== 'ESRCH'; } }, active = () => false} = {}) {
  const owners = new Map();
  const valid = token => typeof token === 'string' && /^[a-f0-9]{64}$/.test(token);
  function get(token) {
    if (!valid(token) || !owners.has(token)) throw Error('native_owner_unknown');
    return owners.get(token);
  }
  return {
    register(token, mainPid = 0) {
      if (!valid(token)) throw Error('native_owner_invalid');
      if (mainPid && (!Number.isSafeInteger(mainPid) || mainPid < 1)) throw Error('native_main_pid_invalid');
      if (!owners.has(token)) {
        // Reclaim only an explicitly identified, exited main window with no
        // live helper and no pending/current meeting. Never infer Quit from age.
        for (const [key, value] of owners) {
          if (value.mainPid && !isAlive(value.mainPid) && (!value.helperPid || !isAlive(value.helperPid)) && !active(key)) owners.delete(key);
        }
        if (owners.size >= 8) throw Error('native_owner_capacity');
        owners.set(token, { mainPid, helperPid: 0, quitRequested: false, readyToQuit: false, error: '', openSerial:0, openSessionId:'', mainForeground:null, dismissedSessionId:'' });
      }
      const owner=owners.get(token);
      if(mainPid){
        if(owner.mainPid&&owner.mainPid!==mainPid&&isAlive(owner.mainPid))throw Error('native_main_owner_conflict');
        owner.mainPid=mainPid;
      }
      return this.status(token);
    },
    has(token) { return valid(token) && owners.has(token); },
    helperReady(token, pid) {
      const owner = get(token);
      if (!Number.isSafeInteger(pid) || pid < 1) throw Error('native_helper_pid_invalid');
      if (owner.helperPid && owner.helperPid !== pid && (isAlive(owner.helperPid) || active(token))) throw Error('native_helper_owner_conflict');
      owner.helperPid = pid;
      return this.status(token);
    },
    requestQuit(token) { const owner = get(token); owner.quitRequested = true; owner.error = ''; return this.status(token); },
    failed(token, error) {
      const owner = get(token); owner.quitRequested = false; owner.readyToQuit = false;
      owner.error = String(error || 'native_save_unconfirmed').slice(0, 200);
    },
    saved(token) { const owner = get(token); if (!owner.quitRequested) throw Error('native_quit_not_requested'); owner.readyToQuit = true; },
    openMain(token, sessionId) { const owner=get(token);owner.openSerial++;owner.openSessionId=String(sessionId||'').slice(0,200); },
    visibility(token, foreground) {
      if (typeof foreground !== 'boolean') throw Error('native_visibility_invalid');
      get(token).mainForeground=foreground;return this.status(token);
    },
    dismissPanel(token, sessionId) { get(token).dismissedSessionId=String(sessionId||'').slice(0,200); },
    panelPolicy(token, sessionId, activeMeeting) {
      const owner=get(token),id=String(sessionId||'');
      return {managed:typeof owner.mainForeground==='boolean',sessionId:id,
        show:!!activeMeeting&&!!id&&owner.mainForeground===false&&!owner.quitRequested&&owner.dismissedSessionId!==id};
    },
    status(token) { const owner = get(token); return { ...owner }; },
    release(token) {
      const owner = get(token);
      if (active(token)) throw Error('native_meeting_not_saved');
      if (owner.helperPid && !owner.readyToQuit) throw Error('native_helper_not_saved');
      owners.delete(token);
    }
  };
}
module.exports = { create };
