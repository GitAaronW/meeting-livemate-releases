  // ===== 火山 ASR（经 Mac 中转）=====
  let safetyRecording = null, backupHealthy = false, asrStarting = false;
  let audioQueue = [], audioQueueBytes = 0;
  let asrWs = null, asrCtx = null, asrNode = null, asrStream = null, asrRetry = 0;
  // —— 两路声源能量对比：对方（系统声/标签页）vs 我（麦克风）——
  let spkTrack = null, lastFinalAt = 0, asrStallNotice = '';
  let asrMix = null, asrThemNode = null, asrMicNode = null, asrMicStream = null;
  // 线上会开着开着，旁边的人凑过来一起聊了——这时候要的是整个房间，不该让人停掉这场重开。
  // 只重新拿一次麦克风（换掉降噪那组参数），会议窗口的声音和这条连接都不断。
  // Virtual/aggregate inputs may contain meeting audio. Preserve their unprocessed signal.
  function browserInputConstraints(deviceId, label, room=false){
    const virtual=!!deviceId&&/blackhole|loopback|larkaudiodevice|virtual|aggregate|虚拟|聚合|听会台线上会/i.test(label||'');
    const processed=!room&&!virtual;
    return {audio:Object.assign({channelCount:virtual?2:1,echoCancellation:processed,noiseSuppression:processed,autoGainControl:processed},deviceId?{deviceId:{exact:deviceId}}:{})};
  }
  let micSwitchPending = false;
  async function switchMicrophone(deviceId, room = startedMode === 'asr-room', label = cfg.micLabel || ''){
    if (micSwitchPending || !running || !asrCtx || !asrMix || !asrMicStream) return false;
    micSwitchPending = true;
    const ctx0=asrCtx, stream0=asrStream, meeting0=cur, old=asrMicStream, oldNode=asrMicNode;
    let mic, node;
    try {
      mic=await navigator.mediaDevices.getUserMedia(browserInputConstraints(deviceId,label,room));
      if (!running || cur!==meeting0 || asrCtx!==ctx0 || asrStream!==stream0) throw new Error(ui==='en'?'Recording changed before the microphone was ready.':'麦克风就绪前录音状态已改变。');
      node=ctx0.createMediaStreamSource(mic); node.connect(asrMix); await ctx0.resume();
      if (!running || cur!==meeting0 || asrCtx!==ctx0 || asrStream!==stream0) throw new Error('Recording changed');
      asrMicNode=node; asrMicStream=mic;
      stream0._extra=(stream0._extra||[]).filter(x=>x && x!==old).concat([mic]);
      try { oldNode?.disconnect(); } catch(e){}
      old.getTracks().forEach(t=>t.stop());
      try { startSpkTrack(ctx0,asrThemNode,node); } catch(e){}
      return true;
    } catch(e){
      try { node?.disconnect(); mic?.getTracks().forEach(t=>t.stop()); } catch(ignore){}
      note((ui==='en'?'Microphone unchanged: ':'麦克风未更换：')+(e.message||e),true); return false;
    } finally { micSwitchPending=false; }
  }
  let sharedAudioPending=false, asrSharedStream=null;
  async function addSharedAudio(){
    if(sharedAudioPending||!running||!asrCtx||!asrMix||!asrMicStream)return false;
    sharedAudioPending=true;
    const ctx0=asrCtx,output=asrStream,meeting=cur,mix=asrMix,old=asrSharedStream,oldNode=asrThemNode;
    let shared,node;
    const owns=()=>running&&cur===meeting&&asrCtx===ctx0&&asrStream===output;
    try{
      // Called directly from a user click: retain browser sharing consent.
      shared=await navigator.mediaDevices.getDisplayMedia({video:true,audio:{echoCancellation:false,noiseSuppression:false}});
      if(!owns())throw Error('Recording changed');
      if(!shared.getAudioTracks().some(t=>t.readyState!=='ended'))throw Error(ui==='en'?'Select the meeting tab and enable Share audio.':'请选择会议标签页，并勾选「分享音频」。');
      node=ctx0.createMediaStreamSource(shared);node.connect(mix);await ctx0.resume();
      if(!owns())throw Error('Recording changed');
      asrSharedStream=shared;asrThemNode=node;
      output._extra=(output._extra||[]).filter(x=>x&&x!==old).concat([shared]);
      try{oldNode?.disconnect();old?.getTracks().forEach(t=>t.stop());}catch(e){}
      try{startSpkTrack(ctx0,node,asrMicNode);}catch(e){}
      const ended=()=>{
        if(!owns()||asrSharedStream!==shared)return;
        if(shared.getAudioTracks().some(t=>t.readyState!=='ended')&&shared.getVideoTracks().some(t=>t.readyState!=='ended'))return;
        try{node.disconnect();}catch(e){}shared.getTracks().forEach(t=>t.stop());
        output._extra=output._extra.filter(x=>x!==shared);asrSharedStream=null;asrThemNode=null;startSpkTrack(ctx0,null,asrMicNode);
        note(ui==='en'?'Meeting sharing ended. Your microphone is still recording.':'会议声音共享已结束，麦克风仍在录音。',true);
      };
      shared.getTracks().forEach(t=>t.addEventListener('ended',ended));
      el.src.textContent=ui==='en'?'Shared meeting audio + microphone':'共享会议声音 + 麦克风';
      note(ui==='en'?'Sharing connected; waiting for meeting audio input. Existing recording continues.':'共享已连接，等待会议音频输入，当前录音继续。');return true;
    }catch(e){
      try{node?.disconnect();shared?.getTracks().forEach(t=>t.stop());}catch(ignore){}
      note((ui==='en'?'Audio sharing unchanged: ':'会议声音未更换：')+(e.message||e),true);return false;
    }finally{sharedAudioPending=false;}
  }
  function startSpkTrack(ctx, nThem, nMe){
    stopSpkTrack();
    const mk = n => { if (!n) return null; const an = ctx.createAnalyser(); an.fftSize = 512; n.connect(an); return an; };
    const A = mk(nThem), B = mk(nMe); if (!A && !B) return;
    const ba = new Float32Array(512), bb = new Float32Array(512);
    const rms = (an, b) => { an.getFloatTimeDomainData(b); let x=0; for (let i=0;i<b.length;i++) x += b[i]*b[i]; return Math.sqrt(x/b.length); };
    const log = [];
    const timer = setInterval(() => { const t = Date.now(); log.push({t, a: A?rms(A,ba):null, b: B?rms(B,bb):null}); while (log.length && t - log[0].t > 180000) log.shift(); }, 80);
    spkTrack = {log, timer, both:!!(A&&B), cleanup(){for(const [node,an] of [[nThem,A],[nMe,B]])if(an)try{node.disconnect(an);}catch(e){}}};
  }
  function stopSpkTrack(){ if (spkTrack) { clearInterval(spkTrack.timer); spkTrack.cleanup?.(); spkTrack = null; } }
  function whoSpoke(from, to){
    if (!spkTrack?.both) return null;
    let a = 0, b = 0, n = 0;
    for (const e of spkTrack.log) if (e.t >= from && e.t <= to) { a += e.a; b += e.b; n++; }
    if (n < 3) return null;
    const q = 0.004 * n;
    if (a < q && b < q) return null;
    const confidence = Math.max(0, Math.min(1, Math.max(a,b) / Math.max(0.000001,a+b)));
    if (a > b * 1.5) return {who:'them',confidence};
    if (b > a * 1.5) return {who:'me',confidence};
    return null;
  }
  // Transport activity alone cannot prove that the selected inputs contain audio.
  function captureHealth(samples, previous, tracks, contextState, paused, now){
    if(paused)return {state:'paused',level:0,zeroSince:0};
    if(contextState!=='running')return {state:'suspended',level:0,zeroSince:0};
    const liveTracks=tracks.filter(t=>t.readyState!=='ended'&&t.enabled);
    if(!liveTracks.length)return {state:'input-ended',level:0,zeroSince:0};
    if(liveTracks.every(t=>t.muted))return {state:'input-muted',level:0,zeroSince:0};
    let power=0,nonzero=false;for(const v of samples){power+=v*v;if(v!==0)nonzero=true;}
    const zeroSince=nonzero?0:(previous?.zeroSince||now);
    return {state:nonzero?'receiving':now-zeroSince>=10000?'no-signal':'waiting',level:samples.length?Math.sqrt(power/samples.length):0,zeroSince,degraded:liveTracks.length<tracks.length||liveTracks.some(t=>t.muted)};
  }
  function setBrowserAudioPaused(paused){
    // Pause both the relay input and the independent backup, keeping the same session.
    if(paused)safetyRecording?.pause?.();else safetyRecording?.resume?.();
    window.thtMiniPaused=paused;
    if(cur?.captureHealth)cur.captureHealth={...cur.captureHealth,state:paused?'paused':'waiting',level:0,zeroSince:0};
    window.dispatchEvent(new CustomEvent('tht-audio-health',{detail:cur?.captureHealth}));
  }
  // Input levels cannot prove that remote speech was captured or transcribed.
  function sourceInputHealth(stream, level, fresh, paused){
    if(!stream)return {state:'not-connected',level:0};
    const live=stream.getAudioTracks().filter(t=>t.readyState!=='ended'&&t.enabled);
    if(!live.length)return {state:'input-ended',level:0};
    if(live.every(t=>t.muted))return {state:'input-muted',level:0};
    if(paused)return {state:'paused',level:0};
    return {state:!fresh?'waiting':level>0.0001?'level-detected':'quiet',level:fresh?level||0:0};
  }
  let captureHealthTimer=null,lastAudioCallback=0,captureHealthState='';
  function publishCaptureHealth(health){
    if(!cur)return;
    const sample=spkTrack?.log.at(-1),fresh=!!sample&&Date.now()-sample.t<1000;
    health.sources={input:sourceInputHealth(asrMicStream,asrSharedStream?sample?.b:Math.hypot(sample?.a||0,sample?.b||0),fresh,!!window.thtMiniPaused),shared:sourceInputHealth(asrSharedStream,sample?.a,fresh,!!window.thtMiniPaused)};
    health.sourceKind=asrSharedStream?'shared-and-input':/blackhole|loopback|virtual|aggregate|虚拟|聚合|larkaudiodevice/i.test(cfg.micLabel||'')?'virtual-routing-unverified':'input-only';
    cur.captureHealth=health;
    const signature=[health.state,health.sourceKind,health.sources.input.state,health.sources.shared.state,ui].join(':');
    if(signature===captureHealthState)return;captureHealthState=signature;
    window.dispatchEvent(new CustomEvent('tht-audio-health',{detail:health}));
    let status=document.getElementById('capture-health');
    if(!status){status=document.createElement('span');status.id='capture-health';document.getElementById('recording-safety-status')?.after(status);}
    status.replaceChildren();
    const messages={
      'no-signal':['未收到声音，请检查会议共享音频和麦克风。','No audio signal. Check shared audio and your microphone.'],
      'input-ended':['音频输入已停止。','Audio input has ended.'],
      'input-muted':['音频输入被静音。','Audio input is muted.'],
      'suspended':['浏览器采音已挂起。','Browser audio capture is suspended.'],
      'callback-stalled':['浏览器未送来音频。','The browser is not delivering audio.']
    };
    const names={'level-detected':['有输入电平','input level detected'],quiet:['当前安静','currently quiet'],waiting:['等待输入','waiting for input'],'not-connected':['未连接','not connected'],'input-ended':['已停止','ended'],'input-muted':['已静音','muted'],paused:['已暂停','paused']};
    const input=names[health.sources.input.state][ui==='en'?1:0],shared=names[health.sources.shared.state][ui==='en'?1:0];
    status.append(document.createTextNode(ui==='en'?' · Input: '+input+' · Shared meeting audio: '+shared:' · 所选输入：'+input+' · 共享会议声音：'+shared));
    if(health.sources.shared.state==='not-connected'){
      status.append(document.createTextNode(ui==='en'?' · Remote meeting audio is not connected. ':' · 尚未接入线上会议声音。'));
      const connect=document.createElement('button');connect.className='btn sm';connect.textContent=ui==='en'?'Connect meeting audio':'接入会议声音';
      connect.onclick=async()=>{connect.disabled=true;try{await addSharedAudio();}finally{connect.disabled=false;}};status.append(connect);
    }
    if(health.sourceKind==='virtual-routing-unverified')status.append(document.createTextNode(ui==='en'?' · Virtual routing unverified':' · 虚拟设备的会议路由未验证'));
    if(messages[health.state]){
      status.append(document.createTextNode(' · '+messages[health.state][ui==='en'?1:0]+' '));
      const retry=document.createElement('button');retry.className='btn sm';retry.textContent=ui==='en'?'Reconnect audio':'重新连接声音';
      retry.onclick=async()=>{if(!running||asrStarting)return;retry.disabled=true;try{await reconnectAudioInput();}catch(e){note((ui==='en'?'Could not reconnect audio: ':'重新连接声音失败：')+e.message,true);}finally{retry.disabled=false;}};
      status.append(retry);
    }
  }
  async function reconnectAudioInput(){
    if(!running||!cur||asrStarting)return;
    // Deliberate user action only. Preserve the meeting, its edits and the ASR session ID.
    asrStarting=true;
    const retainedShared=asrSharedStream?.getAudioTracks().some(t=>t.readyState!=='ended')?asrSharedStream:null;
    const reservation=!retainedShared&&['asr-tab','asr-room'].includes(startedMode)?reserveBrowserDisplay():null;
    if(reservation)window.thtDisplayReservation=reservation;
    try{
      clearInterval(captureHealthTimer);captureHealthTimer=null;
      if(safetyRecording){await safetyRecording.stop();safetyRecording=null;}
      try{asrNode?.disconnect();await asrCtx?.close();}catch{}
      for(const stream of [asrStream,...(asrStream?._extra||[])])if(stream!==retainedShared)stream?.getTracks().forEach(t=>t.stop());
      // The new stream may use a different sample rate: do not replay old PCM as new-rate audio.
      if(audioQueueBytes){const rate=asrCtx?.sampleRate;if(rate>0)cur.untranscribedSeconds=(cur.untranscribedSeconds||0)+audioQueueBytes/(rate*2);cur.transcriptionInterrupted=true;}
      asrNode=asrCtx=asrStream=asrMix=asrThemNode=asrMicNode=asrMicStream=asrSharedStream=null;stopSpkTrack();audioQueue=[];audioQueueBytes=0;
      await asrAudioUp(retainedShared);asrReopen();
    }finally{reservation?.dispose();if(window.thtDisplayReservation===reservation)window.thtDisplayReservation=null;asrStarting=false;}
  }
  async function asrAudioUp(retainedShared=null){
    if (asrStream) return;
    const acquired=[];
    const own=stream=>{acquired.push(stream);return stream;};
    try {
    const __m = retainedShared?(startedMode==='asr-room'?'asr-room':'asr-tab'):(startedMode || el.lang.value);
    if (__m === 'asr-tab' || __m === 'asr-room') {
      const roomMode = (__m === 'asr-room');
      const ds = own(retainedShared||await (window.thtDisplayReservation?window.thtDisplayReservation.take():navigator.mediaDevices.getDisplayMedia({video:true, audio:{echoCancellation:false, noiseSuppression:false}})));
      if (!ds.getAudioTracks().length) { throw new Error('没有勾选「分享音频」。选会议所在的标签页或整个屏幕时，勾上音频再确认。'); }
      // Keep the selected display stream alive until the recording ends.
      // 一个人在工位：开降噪和回声消除，只收自己，旁边同事的闲聊别进来。
      // 会议室里还有人：全关，要的就是整个房间。
      const mic = own(await navigator.mediaDevices.getUserMedia(browserInputConstraints(cfg.micId||'',cfg.micLabel||'',roomMode)).catch(e=>{throw new Error('麦克风不可用，无法完整记录你的发言：'+e.message);}));
      asrCtx = new (window.AudioContext||window.webkitAudioContext)();
      const mix = asrCtx.createMediaStreamDestination();
      const nThem = asrCtx.createMediaStreamSource(ds); nThem.connect(mix);
      const nMe = mic ? asrCtx.createMediaStreamSource(mic) : null; if (nMe) nMe.connect(mix);
      startSpkTrack(asrCtx, nThem, nMe);
      // 会中要换收音方式：只换麦克风这一路，会议窗口那一路和这条会议连接都不动
      asrSharedStream=ds; asrMix = mix; asrThemNode = nThem; asrMicNode = nMe; asrMicStream = mic;
      asrStream = mix.stream; asrStream._extra = [ds, mic].filter(Boolean);
      el.src.textContent = roomMode ? '会议窗口声音 + 整个房间 → 分「线上」和「在场」两路' : '会议窗口声音 + 你的麦克风（已降噪）→ 分「线上」和「我」两路';
      window.__roomMode = roomMode;
    } else if ((startedMode || el.lang.value) === 'asr-sys') {
      const con = {audio: Object.assign({channelCount:2, echoCancellation:false, noiseSuppression:false, autoGainControl:false}, cfg.micId ? {deviceId:{exact: cfg.micId}} : {})};
      const st = own(await navigator.mediaDevices.getUserMedia(con));
      asrCtx = new (window.AudioContext||window.webkitAudioContext)();
      const src0 = asrCtx.createMediaStreamSource(st);
      const mix = asrCtx.createMediaStreamDestination();
      const chs = (st.getAudioTracks()[0].getSettings().channelCount) || 1;
      if (chs >= 2) {
        const sp = asrCtx.createChannelSplitter(2);
        src0.connect(sp);
        const gT = asrCtx.createGain(), gM = asrCtx.createGain();
        sp.connect(gT, 0); sp.connect(gM, 1);
        gT.connect(mix); gM.connect(mix);
        startSpkTrack(asrCtx, gT, gM);
        el.src.textContent = T('src_sys2')||'聚合设备双轨 → 火山（左=对方，右=我）';
      } else {
        src0.connect(mix);
        startSpkTrack(asrCtx,null,src0);
        el.src.textContent = T('src_sys1')||'聚合设备单轨 → 火山（分不出说话人）';
      }
      asrMix=mix; asrMicNode=src0; asrMicStream=st;
      asrStream = mix.stream; asrStream._extra = [st];
    } else {
      const mic = own(await navigator.mediaDevices.getUserMedia(browserInputConstraints(cfg.micId||'',cfg.micLabel||'')));
      asrCtx = new (window.AudioContext||window.webkitAudioContext)();
      asrMix=asrCtx.createMediaStreamDestination(); asrMicNode=asrCtx.createMediaStreamSource(mic); asrMicNode.connect(asrMix); asrMicStream=mic;
      asrStream=asrMix.stream; asrStream._extra=[mic];
      startSpkTrack(asrCtx,null,asrMicNode);
      el.src.textContent = T('src_mic')||'本机麦克风 → 火山 ASR';
    }
    await asrCtx.resume();
    cur.captureHealth={state:'waiting',level:0,zeroSince:0};
    backupHealthy=true;
    try { safetyRecording = await RecordingSafety.start(asrStream,cur.id,(status,data)=>{
      $('#recording-safety-status').textContent=status==='saved'?(cur.transcriptionInterrupted?(ui==='en'?'Transcription interrupted; browser audio backup is saving.':'转写仍中断；浏览器正在保存音频备份。'):cur.untranscribedSeconds?(ui==='en'?'Some audio needs recovery from this browser backup':'部分音频需从本浏览器备份恢复'):(ui==='en'?'Audio saved in this browser':'原始录音已存本浏览器')):(ui==='en'?'Audio backup failed — export available recording now':'录音备份失败，请立即导出已有录音');
      if(status==='error'){backupHealthy=false;}
      if(status==='error')note((ui==='en'?'Audio backup error: ':'录音备份异常：')+(data.message||data),true);
    });
    } catch(e){safetyRecording=null;backupHealthy=false;$('#recording-safety-status').textContent=ui==='en'?'Browser backup unavailable; live transcription continues. Keep this page open.':'浏览器备份不可用，实时转写继续。请保持页面打开并检查 Mac 保存状态。';note((ui==='en'?'Local storage error: ':'本机存储异常：')+e.message,true);}
    if(window.thtMiniPaused)safetyRecording?.pause?.();
    const captureStream=asrStream, captureContext=asrCtx, captureSession=cur;
    const ownsCapture=()=>running&&asrStream===captureStream&&asrCtx===captureContext&&cur===captureSession;
    const inputTracks=()=> (captureStream._extra?.length?captureStream._extra:[captureStream]).flatMap(s=>s.getAudioTracks());
    const checkInput=()=>{if(!ownsCapture())return;const h=captureHealth([],cur.captureHealth,inputTracks(),asrCtx.state,!!window.thtMiniPaused,Date.now());if(h.state==='waiting'||h.state==='no-signal'){if(Date.now()-lastAudioCallback>5000)publishCaptureHealth({...h,state:'callback-stalled'});}else publishCaptureHealth(h);};
    for(const track of inputTracks())for(const event of ['ended','mute','unmute'])track.addEventListener(event,checkInput);
    lastAudioCallback=Date.now();clearInterval(captureHealthTimer);captureHealthTimer=setInterval(checkInput,1000);
    const src = asrCtx.createMediaStreamSource(asrStream);
    asrNode = asrCtx.createScriptProcessor(4096, 1, 1);
    const captureNode=asrNode;
    asrNode.onaudioprocess = e => {
      if(!ownsCapture()||asrNode!==captureNode)return;
      const f = e.inputBuffer.getChannelData(0);
      const tracks=inputTracks();
      lastAudioCallback=Date.now();
      publishCaptureHealth(captureHealth(f,cur.captureHealth,tracks,asrCtx.state,!!window.thtMiniPaused,lastAudioCallback));
      if(window.thtMiniPaused)return;
      updateAudioMeter(f); const b = new Int16Array(f.length); for (let i=0;i<f.length;i++){ const v = Math.max(-1, Math.min(1, f[i])); b[i] = v < 0 ? v*0x8000 : v*0x7FFF; } if(!asrWs || asrWs.readyState!==1 || asrWs.bufferedAmount>1024*1024){audioQueue.push(b.buffer);audioQueueBytes+=b.byteLength;while(audioQueueBytes>asrCtx.sampleRate*2*30){const dropped=audioQueue.shift().byteLength;audioQueueBytes-=dropped;cur.untranscribedSeconds=(cur.untranscribedSeconds||0)+dropped/(asrCtx.sampleRate*2);$('#recording-safety-status').textContent=backupHealthy&&safetyRecording?(ui==='en'?'Connection interrupted: check this browser backup for missing audio.':'断网超过30秒，请核对本浏览器备份并补转。'):(ui==='en'?'Audio has been lost: connection and backup unavailable. Use another recorder now.':'音频已丢失：连接中断且备份不可用，请立即改用其他录音方式。');}return;}for(const chunk of audioQueue)asrWs.send(chunk);audioQueue=[];audioQueueBytes=0;asrWs.send(b.buffer); };
    src.connect(asrNode); asrNode.connect(asrCtx.destination);
    } catch(error) {
      // Inputs can exist before asrStream is assigned (for example, AudioContext fails).
      // Release every acquired track so a failed start never leaves the microphone on.
      clearInterval(captureHealthTimer);captureHealthTimer=null;
      try { await safetyRecording?.stop?.(); } catch(e) {} safetyRecording=null;
      for(const node of [asrNode,asrThemNode,asrMicNode])try { node?.disconnect?.(); } catch(e) {}
      const tracks=new Set([...acquired,asrStream].filter(s=>s&&s!==retainedShared).flatMap(s=>s.getTracks()));
      for(const track of tracks)try { track.stop(); } catch(e) {}
      try { await asrCtx?.close?.(); } catch(e) {}
      try { stopSpkTrack(); } catch(e) {}
      asrNode=asrCtx=asrStream=asrMix=asrThemNode=asrMicNode=asrMicStream=asrSharedStream=null;
      asrSharedStream=retainedShared;
      if(retainedShared){cur.captureHealth={state:'suspended',level:0,zeroSince:0};publishCaptureHealth(cur.captureHealth);}
      throw error;
    }
  }
  function asrReopen(){
    const w = asrWs; asrWs = null;
    if (w) { try { w.onclose = null; w.onmessage = null; w.onerror = null; w.onopen = null; } catch(e){} try { w.close(); } catch(e){} }
    asrOpen();
  }
  let asrGen = 0;                      // 连接代号：只认最新一条连接的消息
  const seenFinals = [];               // 最近的 final 指纹，跨连接去重
  // 同一句在 20 秒内又来一次，多半是转写重发。但「嗯」「对」「hmm」这种短应答
  // 人真的会连说几次——2026-09-12 在一场真实会议上数过：195 条重复里 188 条是短应答，
  // 只有 7 条够长。所以只挡长句，短的一律放行。
  const DUP_MIN = 12;
  function isDup(text){
    const now = Date.now(), key = String(text).replace(/\s+/g,'');
    if (key.length < DUP_MIN) return false;
    while (seenFinals.length && now - seenFinals[0].t > 20000) seenFinals.shift();
    if (seenFinals.some(x => x.k === key)) return true;
    seenFinals.push({k:key, t:now});
    if (seenFinals.length > 60) seenFinals.shift();
    return false;
  }
  function asrOpen(){
    if (asrWs) { try { asrWs.onopen = asrWs.onmessage = asrWs.onclose = asrWs.onerror = null; asrWs.close(); } catch(e){} asrWs = null; }
    if (!cfg.relayToken) { note('火山 ASR 需要「Mac 中转口令」，去 ⚙︎ 填。', true); return; }
    const recordingSession = cur;
    const gen = ++asrGen;
    const ws = new WebSocket(`${wsBase()}?token=${encodeURIComponent(cfg.relayToken)}`);
    ws.binaryType = 'arraybuffer';
    asrWs = ws;
    const mine = () => (gen === asrGen && asrWs === ws);
    ws.onopen = () => { if (!mine()) { try { ws.close(); } catch(e){} return; }
      asrRetry = 0; note('');
      ws.send(JSON.stringify({type:'start', sessionId: cur.id, continuationToken:cur.continuationToken,continuationEpoch:cur.continuationEpoch, title: cur.title||'', notes:cur.notes||'', source: /Mobile|Android|iPhone/.test(navigator.userAgent)?'手机':'电脑', lang: relayLang(), uiLang: ui, rate: asrCtx ? asrCtx.sampleRate : 16000, hotwords: allHotwords(), brief: effectiveBrief(cur), fixes: parseFixes(briefFix), transcriptEdits:cur.transcriptEdits||[], names: cur.names||{}, ...meetingContextPayload(cur)}));
    };
    ws.onmessage = ev => {
      const cur = recordingSession;
      if (!mine()) return;                                  // 旧连接的消息一律丢弃
      let m; try { m = JSON.parse(ev.data); } catch(e) { return; }
      if (m.type === 'partial') { interim = m.text || ''; render(); }
      else if (m.type === 'final' && m.text) { cur.transcriptionInterrupted=false;
        interim = '';
        // Relay deduplicates utterance IDs/timestamps; repeated spoken words are valid.                          // 20 秒内同一句只收一次
        const now = Date.now();
        if (isDup(m.text)) return;                       // 长句在 20 秒内重发，丢掉
        const ownerSignal = m.speaker ? null : whoSpoke(lastFinalAt || (now - 8000), now);
        const spk = m.speaker ? String(m.speaker) : (ownerSignal&&ownerSignal.who)||'';
        lastFinalAt = now;
        cur.transcript.push({at: now, t: Math.round((now-cur.start)/1000), text: m.text, spk, seg: m.seg||''});
        // 识别语言选「自动」时，攒够几句就去认一次是中文还是英文。
        // 这一行以前漏了，于是「自动」这个选项从来没真正生效过（2026-09-12 补）。
        try { maybeDetectTongue(); } catch(e){}
        if(ownerSignal && asrWs?.readyState===1) asrWs.send(JSON.stringify({type:'spk',who:ownerSignal.who,confidence:ownerSignal.confidence,at:now}));
        persist(); render();
      }
      else if (m.type === 'speaker_update' && cur.transcript[m.index]) {cur.transcript[m.index].spk=m.speaker;resetSigs();render();}
        else if (m.type === 'owner_attribution_update' && cur.transcript[m.index]) {cur.transcript[m.index].ownerAttribution=m.attribution;cur.ownerQuestions=Array.isArray(m.ownerQuestions)?m.ownerQuestions:cur.ownerQuestions;persist();render();}
        else if (m.type === 'owner_attribution_batch') {for(const row of cur.transcript||[])if(String(row.spk||row.speaker||row.who||'')===String(m.speaker||''))row.ownerAttribution={candidate:m.verdict==='me'?true:m.verdict==='not_me'?false:null,source:'manual',confidence:m.verdict==='unknown'?0:1,correctedByUser:true,updatedAt:Date.now()};cur.ownerQuestions=Array.isArray(m.ownerQuestions)?m.ownerQuestions:cur.ownerQuestions;persist();}
        else if (m.type === 'owner_question_update' && m.question) {cur.ownerQuestions=cur.ownerQuestions||[];const i=cur.ownerQuestions.findIndex(q=>q.id===m.question.id);if(i>=0)cur.ownerQuestions[i]=m.question;else cur.ownerQuestions.push(m.question);persist();}
        else if (m.type === 'assets') renderAssets(m.items||[]);
        else if (m.type === 'revise') applyRevise(m);
        else if (m.type === 'recomputed') applyRecomputed(m);
        else if (m.type === 'condensed') applyCondensed(m);
        else if (m.type === 'stale') markStale(m);
        else if (m.type === 'feedback') applyFeedback(m);
        else if (m.type === 'thread') applyThreadMsg(m);
        else if (m.type === 'insightAction') applyInsightAction(m);
        else if (m.type === 'calendar' || m.type === 'namefix' || m.type === 'namefix_undone') applyCalendarMsg(m);
        else if (m.type === 'snapshot' && m.session) {cur.continuationEpoch=m.session.continuationEpoch||'';delete cur.continuationToken;delete cur.continuationOriginal; window.dispatchEvent(new CustomEvent('tht-recorder-ready',{detail:{id:cur.id}}));cur.calendar = m.session.calendar || null; if (m.session.threads && typeof m.session.threads === 'object') cur.threads = m.session.threads; cur.nameFixCount = (m.session.nameFixes || []).length; persist(); renderCalendar(); }   // 续场 / 重连时把日历和纠名计数接回来
      else if (m.type === 'summary' && m.text) { cur.summary = m.text; cur.relayHandled = true; persist(); render(); }
      // R1：中转 12 分钟收不到音频就自己把这场收尾，然后发这条。页面原来只记一笔就接着录——
      // 手机锁屏再解锁那种场合，后半场其实一个字都没进库，人却毫无察觉。服务端那边已经结束了，
      // 本机再录也没有去处：直接停下，并且用红条把「后面的没录上」说明白。
      else if (m.type === 'ended') { cur.relayHandled=true;persist();refreshArchive();
        if(running){ stopAll(false);
          note(ui==='en'?'The Mac ended this meeting; anything spoken after that was not recorded. Please start a new meeting.'
                        :'服务端已经结束了这场会，后面的内容没有被记录。请重新开始一场。','danger'); } }
      else if (m.type === 'stall') { cur.transcriptionInterrupted=true;asrStallNotice=m.message||m.reason||(T('stall_relay')||'实时识别中断，录音仍在保存。');note(asrStallNotice,true);persist(); }
      else if (m.type === 'stall_clear') { cur.transcriptionInterrupted=false;if(el.notice.textContent===asrStallNotice)note('');asrStallNotice='';persist(); }
      else if (m.type === 'llm_down') setLlmDown(true, m.message||'');
      else if (m.type === 'llm_degraded') setLlmDegraded(!!m.on, m.message||'');
      else if (m.type === 'attention') { try { setAttention(m.attention); } catch(e){} }
      else if (m.type === 'llm_up') { setLlmDown(false); note(ui==='en'?'Model is back; analysis resumes.':'模型已恢复，分析继续'); }
      else if (m.type === 'error') note('中转报错：' + (m.message||''), true);
    };
    ws.onclose = (ev) => {
      if (!mine()) return;                                   // 旧连接关掉不触发重连
      asrWs = null;
      if(ev.code===4409){if(running)stopAll(false);note(ui==='en'?'This meeting has already ended. Start a new meeting to continue.':'上一场已结束并保留，请点开始听会新建一场。',true);return;}
      if (!(running && asrMode)) return;
      asrRetry++;
      const why = ev && ev.code===4401 ? '口令不对（⚙︎ 里核对）' : ev && ev.code===1006 ? '连接被中断（网络/funnel）' : (ev && ev.reason) || ('code '+(ev&&ev.code));
      note(`中转断开：${why}；第 ${asrRetry} 次重连…`, true);
      setTimeout(() => { if (running && asrMode && gen === asrGen) asrOpen(); }, Math.min(15000, 2000*asrRetry));
    };
  }
  window.addEventListener('beforeunload',e=>{if(running){e.preventDefault();e.returnValue='';}});
  $('#recording-recovery').onclick=async()=>{
    const box=$('#recording-recovery-list');box.textContent='读取中…';$('#recording-recovery-dialog').showModal();
    try{const rows=await RecordingSafety.list();box.textContent=rows.length?(ui==='en'?'Total: ':'总占用：')+(rows.reduce((n,r)=>n+r.bytes,0)/1048576).toFixed(1)+' MB':'本浏览器暂无录音 / No local recordings';
      for(const r of rows.sort((a,b)=>b.started-a.started)){const p=document.createElement('p'),btn=document.createElement('button');btn.className='btn';btn.textContent=new Date(r.started).toLocaleString()+' · '+(r.bytes/1048576).toFixed(1)+' MB · '+(r.state==='error'?'保存出错 / Save error':!r.ended?'未正常收尾 / Not finalized':!r.chunks?'无音频片段 / No chunks':'已收尾 / Finalized')+' · 导出 / Export';btn.onclick=async()=>{try{const b=await RecordingSafety.blob(r.id),url=URL.createObjectURL(b),a=document.createElement('a');a.href=url;a.download=r.id+(r.mime.includes('mp4')?'.m4a':'.webm');a.click();setTimeout(()=>URL.revokeObjectURL(url),60000);}catch(e){note(e.message,true);}};p.append(btn);if(!(running&&r.sessionId===cur?.id)){const del=document.createElement('button');del.className='btn sm';del.textContent=ui==='en'?'Delete backup':'删除备份';del.onclick=async()=>{if(!confirm(ui==='en'?'Delete this local audio backup permanently? Export it first if needed.':'永久删除这份本机录音备份？需要保留请先导出。'))return;try{await RecordingSafety.remove(r.id);p.remove();}catch(e){note(e.message,true);}};p.append(del);}box.append(p);}
    }catch(e){box.textContent='读取失败：'+e.message;}
  };
