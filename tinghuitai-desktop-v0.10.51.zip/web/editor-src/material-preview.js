'use strict';
// Render only supplied local content. Hover/focus never reads an external page.
function preview(item={},lang='zh'){
 const en=lang==='en',clean=v=>String(v||'').replace(/\\([_~*])/g,'$1');
 let url;try{url=new URL(clean(item.url), 'https://local.invalid');}catch{return null;}
 const internal=String(item.url||'').startsWith('/tinghuitai/?id=')&&item.meetingRecord===true;
 if((!internal&&!/^https?:\/\//i.test(clean(item.url)))||url.username||url.password||(!internal&&!['https:','http:'].includes(url.protocol))||(!internal&&url.hostname==='local.invalid'))return null;
 const href=internal?item.url:url.href,title=clean(item.title)||url.hostname;
 const partial=item.bodyState==='partial'||item.bodyCoverage?.complete===false;
 const state=item.previewState==='loading'?'loading':item.previewState==='no-access'?'no-access':item.previewState==='error'?'error':partial?'partial':item.read?'ready':'unread';
 const labels={loading:['正在读取…','Loading…'],'no-access':['无法访问 · 请在原文页面检查账号权限','Access unavailable · Check your account on the original page'],error:['暂时无法预览 · 可打开原文','Preview unavailable · Open the original'],partial:['内容未完整读取 · 请查看原文','Incomplete content · View the original'],ready:['本机已保存的内容','Locally saved content'],unread:['正文尚未读取 · 可打开原文','Content not read · Open the original']};
 return {href,title,state,label:labels[state][en?1:0],excerpt:state==='ready'?String(item.excerpt||''):'',openLabel:en?'Open original ↗':'打开原文 ↗'};
}
module.exports={preview};
