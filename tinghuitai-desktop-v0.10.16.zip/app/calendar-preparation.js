'use strict';
// User-opened and background preparation share event identity and edit protection.
const requests=new WeakMap();
async function prepare(ctx,event){
   const ev=require('./premeeting-brief').normalizeEvent(event);if(!ev||typeof ev.eventId!=='string'||!ev.eventId||ev.eventId.length>500||!Number.isFinite(Date.parse(ev.start))||!Number.isFinite(Date.parse(ev.end))||Date.parse(ev.end)<=Date.parse(ev.start))throw Error('Invalid calendar event');
   const requestKey=String(ev.calendarId||'')+'\0'+ev.eventId;let generations=requests.get(ctx.hub);if(!generations){generations=new Map();requests.set(ctx.hub,generations);}const generation=Symbol();generations.set(requestKey,generation);
   let meetingUrl='';try{const link=new URL(ev.meetingUrl);if(link.protocol==='https:'&&!link.username&&!link.password)meetingUrl=link.href;}catch{}
   const calendarId=String(ev.calendarId||'').slice(0,500),hash=value=>require('crypto').createHash('sha256').update(value).digest('hex').slice(0,32),legacyId='calendar-'+hash(ev.eventId);let noteId='calendar-'+hash(calendarId?calendarId+'\0'+ev.eventId:ev.eventId),source=ctx.hub.data.sources.find(s=>s.key==='session:'+noteId);if(!source){const legacy=ctx.hub.data.sources.find(s=>s.key==='session:'+legacyId);if(legacy&&(!legacy.calendarEvent?.calendarId||legacy.calendarEvent.calendarId===calendarId)){source=legacy;noteId=legacy.sessionId||legacyId;}}
   let attendees=require('./premeeting-brief').calendarAttendees(ev);if(typeof ctx.calendarAttendees==='function'){try{const loaded=await ctx.calendarAttendees(ev);if(Array.isArray(loaded))attendees=loaded;else if(!attendees.length)attendees=source?.calendarEvent?.attendeeList||[];}catch{if(!attendees.length)attendees=source?.calendarEvent?.attendeeList||[];}}
   if(generations.get(requestKey)!==generation){const e=Error('会议准备已被更新的请求取代，请刷新后重试');e.status=409;throw e;}
   source=ctx.hub.data.sources.find(s=>s.key==='session:'+noteId)||source;
   const calendarEvent={eventId:ev.eventId,calendarId,title:String(ev.title||'Meeting').slice(0,200),start:ev.start,end:ev.end,meetingUrl,description:String(ev.description||ev.agendaText||'').slice(0,4000),attendeeList:attendees.slice(0,100).map(p=>({name:String(typeof p==='string'?p:p?.name||'').slice(0,80),open_id:String(p?.open_id||'').slice(0,200),declined:p?.declined===true}))};
   if(!source||JSON.stringify(source.calendarEvent)!==JSON.stringify(calendarEvent))source=ctx.hub.source({key:'session:'+noteId,sessionId:noteId,title:calendarEvent.title,kind:source?.kind||'note',channel:'听会台',date:ev.start,calendarEvent,body:''});
   const preparation=require('./premeeting-brief').preparationModule(ctx.hub.data,source,calendarEvent,{purpose:'current-work'}),modules=source.board?.modules||[],priorPreparation=modules.find(m=>m.id==='premeeting-materials');
   if(!priorPreparation?.edited){const next=modules.filter(m=>m.id!=='premeeting-materials');if(preparation)next.unshift(preparation);if(JSON.stringify(modules)!==JSON.stringify(next))source=ctx.hub.update('sources',source.id,{board:{...source.board,modules:next}},source.revision);}
   ctx.hub.save();return {id:noteId,source,generation};
}
function isCurrent(ctx,event,generation){return requests.get(ctx.hub)?.get(String(event.calendarId||'')+'\0'+event.eventId)===generation;}
module.exports={prepare,isCurrent};
