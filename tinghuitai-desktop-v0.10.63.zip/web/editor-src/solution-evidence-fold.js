'use strict';
const {Extension}=require('@tiptap/core');
const {Plugin,PluginKey,TextSelection}=require('@tiptap/pm/state');
const {Decoration,DecorationSet}=require('@tiptap/pm/view');
const key=new PluginKey('solutionEvidenceFold');
// View-only folding: never remove, reorder or rewrite document content.
function sections(doc){
 const found=[];let current=null;
 doc.forEach((node,pos)=>{
  if(current&&node.type.name==='heading'&&node.attrs.level<=current.level){current.end=pos;current=null;}
  if(node.type.name==='heading'&&node.attrs.sourceRef==='solution-section:4'){
   current={id:node.attrs.blockId||'solution-section:4',pos,from:pos+node.nodeSize,end:doc.content.size,level:node.attrs.level,headingEnd:pos+node.nodeSize-1};found.push(current);
  }
 });return found;
}
function folded(section,opened){return !opened.has(section.id);}
function foldState(tr,opened){
 const next=new Set(opened),toggle=tr.getMeta(key);
 if(toggle){if(next.has(toggle))next.delete(toggle);else next.add(toggle);}
 // Explicit cursor movement into hidden content must reveal it, including Find.
 if(tr.selectionSet&&!toggle)for(const s of sections(tr.doc))if(tr.selection.from>=s.from&&tr.selection.from<s.end)next.add(s.id);
 return next;
}
const extension=Extension.create({
 name:'solutionEvidenceFold',addOptions(){return {lang:'zh'};},
 addProseMirrorPlugins(){const en=this.options.lang==='en';return [new Plugin({key,state:{init:()=>new Set(),apply:foldState},props:{decorations(state){
  const decorations=[],opened=key.getState(state);
  for(const s of sections(state.doc)){
   const closed=folded(s,opened);
   decorations.push(Decoration.widget(s.headingEnd,view=>{
    const button=document.createElement('button');button.type='button';button.className='solution-fold-toggle';button.contentEditable='false';button.textContent=closed?'▸':'▾';
    button.setAttribute('aria-label',en?'Evidence and revisions': '依据与修订记录');button.setAttribute('aria-expanded',String(!closed));
    button.onmousedown=e=>e.preventDefault();button.onclick=e=>{e.preventDefault();const current=sections(view.state.doc).find(v=>v.id===s.id);if(!current)return;const tr=view.state.tr.setMeta(key,s.id);if(!closed&&view.state.selection.from>=current.from&&view.state.selection.from<current.end)tr.setSelection(TextSelection.create(tr.doc,current.headingEnd));view.dispatch(tr);};return button;
   },{key:s.id+':'+closed,stopEvent:()=>true,side:1}));
   if(closed)state.doc.forEach((node,pos)=>{if(pos>=s.from&&pos<s.end)decorations.push(Decoration.node(pos,pos+node.nodeSize,{class:'solution-evidence-hidden'}));});
  }
  return DecorationSet.create(state.doc,decorations);
 }}})];}
});
module.exports={extension,sections,foldState,folded,key};
