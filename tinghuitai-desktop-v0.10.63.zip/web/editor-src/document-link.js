'use strict';
// A local navigation link is neither a public share nor permission to rebind.
function href(origin,meetingId,documentId){
 if(!meetingId||!documentId)return '';
 const url=new URL('/tinghuitai/',origin);url.searchParams.set('id',meetingId);url.searchParams.set('document',documentId);return url.href;
}
function requested(url,meetingId){
 try{const query=new URL(url).searchParams;return query.get('id')===meetingId?query.get('document')||'':'';}catch{return '';}
}
function target(url,meetingId,linkedId){
 const id=requested(url,meetingId);return {id:id||linkedId||'',mismatch:!!id&&id!==linkedId};
}
module.exports={href,requested,target};
