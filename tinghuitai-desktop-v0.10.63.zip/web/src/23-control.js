  // ===== 控制 =====
  el.tongue.onchange = () => {
    try { localStorage.setItem('tht-tongue', el.tongue.value); } catch(e){}
    const label = el.tongue.selectedOptions[0].text;
    if (!running) { note('语言：' + label); setTimeout(()=>note(''), 2000); return; }
    if (asrMode) { asrReopen(); note('语言切到「'+label+'」，同一场继续。'); }
    else if (!imeMode) { try { rec && rec.stop(); } catch(e){} rec = makeRec(); if (rec) { try { rec.start(); } catch(e){} } note('语言切到「'+label+'」。'); }
    else note(T('imeLang')||'输入法听写的语言在输入法里切。', true);
    setTimeout(()=>note(''), 3000);
  };
  el.lang.onchange = () => { updateModeChip(); if (running) { note('这场进行中，识别方式结束后再换；语言可以随时切。', true); el.lang.value = (cur && cur.lang) || 'auto'; updateModeChip(); } };
  // Invoke the sharing selector in the click stack, before network preflight consumes activation.
  function reserveBrowserDisplay(){
    let stream=null,error=null,claimed=false,disposed=false;
    let request;try { request=navigator.mediaDevices.getDisplayMedia({video:true,audio:{echoCancellation:false,noiseSuppression:false}}); } catch(e) { request=Promise.reject(e); }
    const ready=Promise.resolve(request).then(value=>{stream=value;if(disposed)stream.getTracks().forEach(t=>t.stop());return value;},e=>{error=e;});
    return {async validate(){const value=await ready;if(error)throw error;if(disposed)throw new Error('Recording start cancelled');if(!value.getAudioTracks().length)throw new Error(ui==='en'?'No shared audio. Select the meeting tab and enable Share audio.':'没有共享音轨，请选择会议标签页并勾选共享声音。');},async take(){claimed=true;const value=await ready;if(error)throw error;if(disposed)throw new Error('Recording start cancelled');return value;},dispose(){if(claimed)return;disposed=true;if(stream)stream.getTracks().forEach(t=>t.stop());}};
  }
  async function confirmRecordingSwitch(current,next){
    return new Promise(resolve=>{
      const dialog=document.createElement('dialog');dialog.className='recording-switch-dialog';
      const heading=document.createElement('h2');heading.textContent=ui==='en'?'Switch meeting?':'切换会议？';
      const message=document.createElement('p');message.textContent=ui==='en'?`Finish and save “${current.title||'Current meeting'}”, then join “${next.title||'New meeting'}”?`:`结束并保存「${current.title||'当前会议'}」，然后加入「${next.title||'新会议'}」？`;
      let settled=false;const finish=value=>{if(settled)return;settled=true;dialog.close();dialog.remove();resolve(value);};
      const cancel=document.createElement('button');cancel.textContent=ui==='en'?'Keep recording':'继续当前录音';cancel.onclick=()=>finish(false);
      const proceed=document.createElement('button');proceed.textContent=ui==='en'?'Finish and join':'结束当前并加入';proceed.onclick=()=>finish(true);
      dialog.addEventListener('cancel',e=>{e.preventDefault();finish(false);});dialog.append(heading,message,cancel,proceed);document.body.append(dialog);dialog.showModal();cancel.focus?.();
    });
  }
  let recordingStartPending=false,failedBrowserSession=null,newNativeNoteRequest=null;
  function idForNewRecording(){
    const id=new URLSearchParams(location.search).get('id')||sessionStorage.getItem('tht-selected-meeting')||'';
    return id;
  }
  window.thtStartRecording = async (calendarEvent=null,{newMeeting=false,continueMeetingId=''}={}) => {
    if(newMeeting&&continueMeetingId)return false;
    if(recordingStartPending||nativeState.starting)return false;
    const selectedId=continueMeetingId||(!newMeeting&&!calendarEvent?idForNewRecording():'');
    if((running||nativeState.active)&&!calendarEvent){
      const activeId=nativeState.sessionId||cur?.id||'';
      if(!newMeeting&&!calendarEvent&&(!selectedId||selectedId===activeId)){
        if(nativeState.phase==='paused')await nativeRequest('command',{sessionId:activeId,command:'resume'});
        window.thtOpenMeeting?.(activeId);return true;
      }
      note(ui==='en'?'Another meeting is recording.':'另一场会议正在录制，请先结束。',true);return false;
    }
    recordingStartPending=true;el.start.disabled=true;
    const intent=calendarEvent?.eventId?{eventId:calendarEvent.eventId,calendarId:calendarEvent.calendarId||'',title:calendarEvent.title||'',start:calendarEvent.start,end:calendarEvent.end,attendeeList:calendarEvent.attendeeList||calendarEvent.attendees||[]}:null;
    if(intent)window.thtMeetingJoin=intent;
    let accepted=false;
    const explicitBrowser=window.thtCaptureChoice==='browser';
    // Native is the default even before the first status poll has completed.
    // Browser capture remains explicit compatibility behavior, never an automatic fallback.
    const systemPreferred=!explicitBrowser;
    const useBrowser=explicitBrowser;
    const browserMode=window.thtBrowserMode||'asr-tab';
    window.thtBrowserCapture=useBrowser;
    const reservation=useBrowser&&['asr-tab','asr-room'].includes(browserMode)?reserveBrowserDisplay():null;
    if(reservation)window.thtDisplayReservation=reservation;
    try{
    if(!await checkMac()){if(!cfg.relayToken&&!window.THT_BOOT){note(ui==='en'?'This window has no relay passcode. Open Settings and paste it into “Mac relay passcode”, or reopen from the link with the passcode.':'这个窗口没有口令：点「设置」把口令粘进「Mac 中转口令」，或删掉主屏幕图标、用带口令的链接重新添加。',true);return false;}note(ui==='en'?'Recording service unavailable. Reopen the installed app.':'录音服务未连接，请重新打开听会台；无需重复填写模型 Key。',true);return false;}
    const localNative=['localhost','127.0.0.1'].includes(new URL(relayBase(),location.href).hostname);
    const native=localNative?await nativeRequest('status').catch(e=>{if(!useBrowser)throw e;return {available:false,active:false};}):{available:false};nativeStatus(native);
    if(running&&!native.active){note(ui==='en'?'Another meeting is recording.':'另一场会议正在录制，请先结束。',true);return false;}
    if(native.active){
      let same=!newMeeting&&!intent&&(!selectedId||selectedId===native.sessionId);
      if(intent){
        const response=await fetch(relayBase()+'/meeting-board?id='+encodeURIComponent(native.sessionId)+'&token='+encodeURIComponent(cfg.relayToken||window.THT_BOOT?.relayToken||''));
        if(response.ok){const current=await response.json(),event=current.source?.calendarEvent;same=event?.eventId===intent.eventId&&(event.calendarId||'')===intent.calendarId;}
      }
      if(same){if(native.phase==='paused')await nativeRequest('command',{sessionId:native.sessionId,command:'resume'});window.thtOpenMeeting?.(native.sessionId);accepted=true;return true;}
      if(!intent||!systemPreferred||!await confirmRecordingSwitch(native,intent))return false;
      const beforeStop=await nativeRequest('status');
      if(beforeStop.active&&beforeStop.sessionId!==native.sessionId)throw Error(ui==='en'?'The recording changed. Please retry.':'当前录音已变化，请重新点击加入。');
      if(beforeStop.active)await nativeRequest('command',{sessionId:native.sessionId,command:'stop'});
      const deadline=Date.now()+15000;let state=await nativeRequest('status');
      while(state.active&&state.sessionId===native.sessionId&&Date.now()<deadline){await new Promise(r=>setTimeout(r,200));state=await nativeRequest('status');}
      nativeStatus(state);if(state.active)throw Error(ui==='en'?'Still saving the recording. Retry after it finishes.':'正在保存录音，完成后请再点加入。');

    }
    if(native.available&&systemPreferred){
      let id=continueMeetingId||(intent||newMeeting?'':idForNewRecording());
      let prepared=null;
      if(newMeeting){
        // Prepare a persistent blank destination before permission prompts or helper launch.
        // Retain the request ID after an ambiguous response so retry cannot duplicate it.
        newNativeNoteRequest=newNativeNoteRequest||crypto.randomUUID();
        const response=await fetch(relayBase()+'/meeting-board?token='+encodeURIComponent(cfg.relayToken||window.THT_BOOT?.relayToken||''),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'new-note',requestId:newNativeNoteRequest,lang:ui}),signal:AbortSignal.timeout(10000)});
        const out=await response.json();if(!response.ok)throw Error(out.error||'Could not create meeting notes');
        if(!out.id)throw Error('Missing new meeting ID');id=out.id;newNativeNoteRequest=null;window.thtOpenMeeting?.(id);
      }
      if(intent||id){
        const response=await fetch(relayBase()+'/meeting-board?token='+encodeURIComponent(cfg.relayToken||window.THT_BOOT?.relayToken||''),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:continueMeetingId?'continue-context':'start-context',sessionId:id||undefined,event:intent,uiLang:ui,lang:ui==='en'?'en':'zh'}),signal:AbortSignal.timeout(10000)});
        const out=await response.json();if(!response.ok)throw Error(out.error||'Could not open meeting notes');
        prepared=out.prepared;if(!prepared?.sessionId)throw Error('Missing prepared meeting ID');id=prepared.sessionId;
      }
      if(id&&!newMeeting)window.thtOpenMeeting?.(id);
      const result=await nativeRequest('launch',{autoStart:true,sessionId:id,continuationToken:prepared?.continuationToken,uiLang:ui,lang:prepared?.lang||(newMeeting?(ui==='en'?'en':'zh'):(cur?.lang||'zh')),brief:prepared?(prepared.brief||(newMeeting?effectiveBrief(null):'')):effectiveBrief(newMeeting?null:cur)});
      const connecting=ui==='en'?'Connecting system audio and microphone…':'正在接入系统声音和麦克风…';note(connecting);el.notice.dataset.nativeStartNotice='1';el.notice.dataset.nativeStartText=connecting;nativeStatus(result);accepted=true;return true;
    }
    window.thtBrowserCapture=useBrowser;
    if(!useBrowser){note(ui==='en'?'System audio recorder is unavailable. Reopen the installed app and retry.':'系统录音端尚未连接，请重新打开听会台后重试。',true);return false;}
    await loadServerSettings();
    if (!window.THT_BOOT) await refreshBoot();   // 远端窗口：boot 只能靠带口令的 /setup 拿，点开始前再确认一次（09-22）
    // 一把钥匙都没配的人，点开始时直接按本机转写起：不用注册、不用填任何东西。
    // 这一步也会顺带拉起系统的语音识别授权弹窗。这台机器用不了本机转写才去设置页。
    if (!boot.asrConfigured) {
      if (!boot.macAsrAvailable) {
        note(ui==='en'?'This Mac cannot transcribe on-device. Connect a transcription service first.':'这台机器用不了本机转写，先接一个转写服务。', true);
        openSettings('asr'); return false;
      }
      el.start.disabled = true;
      try {
        const r = await fetch('/setup', {method:'POST', headers:{'content-type':'application/json','x-tht-token':cfg.relayToken||''}, body: JSON.stringify({ASR_PROVIDER:'mac'})});
        if (!r.ok) throw new Error(String(r.status));
        boot.asrConfigured = true; boot.asrProvider = 'mac'; updateReadyBar();
        note(ui==='en'?'Using on-device transcription. Approve the system prompt if it appears.':'这场用本机转写。系统弹出语音识别授权时点允许。');
        setTimeout(()=>note(''), 6000);
      } catch(e) {
        note(ui==='en'?'Could not switch to on-device transcription; open settings.':'切本机转写没成功，去设置页看看。', true);
        openSettings('asr'); el.start.disabled = false; return false;
      }
      el.start.disabled = false;
    }
    if(reservation)await reservation.validate();
    const joinedEvent=continueMeetingId?null:intent||(newMeeting?null:window.thtMeetingJoin);
    if(joinedEvent||window.thtBrowserCapture){
      let resume=!continueMeetingId&&!newMeeting&&failedBrowserSession&&cur?.id===failedBrowserSession.id&&(!intent||failedBrowserSession.joinedEvent?.eventId===intent.eventId)?failedBrowserSession:null;
      const id=continueMeetingId||(intent||newMeeting?'':idForNewRecording());
      if(!resume&&(id||joinedEvent)){
        const response=await fetch(relayBase()+'/meeting-board?token='+encodeURIComponent(cfg.relayToken||window.THT_BOOT?.relayToken||''),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:continueMeetingId?'continue-context':'start-context',sessionId:id,event:joinedEvent||undefined,uiLang:ui,lang:intent?(ui==='en'?'en':'zh'):(cur?.lang||'zh')}),signal:AbortSignal.timeout(10000)});
        const out=await response.json();if(!response.ok)throw Error(out.error||'Could not open meeting notes');
        const prepared=out.prepared;if(!prepared?.sessionId)throw Error('Missing prepared meeting ID');
        resume={...newSession('mac',browserMode),...prepared.snapshot,...prepared,id:prepared.sessionId,start:prepared.snapshot?.start||Date.now(),end:null};
        if(continueMeetingId)resume.continuationOriginal=structuredClone(prepared.snapshot);
      }
      accepted=(await startAll(resume,browserMode))===true;return accepted;
    }
    accepted=(await startAll(null))===true;return accepted;
    }catch(e){note(e.message,true);if(systemPreferred)el.notice.dataset.nativeErrorText=e.message;return false;}finally{if(intent&&!accepted&&window.thtMeetingJoin===intent)window.thtMeetingJoin=null;reservation?.dispose();if(window.thtDisplayReservation===reservation)window.thtDisplayReservation=null;recordingStartPending=false;el.start.disabled=asrStarting;}
  };
  el.start.onclick = () => window.thtStartRecording();
  $('#k-test').onclick = () => selfTest();
  async function startAll(resume, force){
    if(running||nativeState.active)return false;
    const mode = force && force!=='auto' ? force : resolveMode();
    imeMode = mode === 'ime'; asrMode = mode.startsWith('asr');
    // 本机口令由服务端随页面注入（THT_BOOT），点开始时直接拿，不要求用户先「保存设置」一次。
    // 以前要求 cfg.relayToken 非空，而它只有保存设置才写入、保存时又是从 THT_BOOT 抄的；
    // THT_BOOT 拿不到（页面被判成非本机）时保存也补不上，就成了「开始→弹设置→保存→再弹」的死循环。
    if (asrMode && !cfg.relayToken) {
      const t = window.THT_BOOT && window.THT_BOOT.relayToken;
      if (t) { cfg.relayToken = t; try { localStorage.setItem('tht-settings', JSON.stringify(cfg)); } catch(e){} }
      else {
        // bootstrap.js 被拒时页面拿不到任何信息；再问一次 /setup，它的 403 正文里写着是哪条没过
        let why = '';
        try { const r = await fetch('/setup', {cache:'no-store'}); if (!r.ok) { const j = await r.json().catch(()=>({})); if (j && j.error) why = '（' + String(j.error).replace(/^设置只能在本机打开：?/, '') + '）'; } } catch(e){}
        note((ui==='en'
          ? 'This window did not get the local token, so recording cannot start. Use the window that 启动.command opens (http://127.0.0.1:' + location.port + '/) and turn off any browser proxy.'
          : '这个窗口没拿到本机口令，开不了录音。请用「启动.command」打开的那个窗口（http://127.0.0.1:' + location.port + '/），并关掉浏览器代理再试。') + why, true);
        return false;
      }
    }
    // Model credentials live on the server, not in cfg.key.
    if (!imeMode && !asrMode) { rec = makeRec(); if (!rec) return false; }
    if (viewWs) { try { viewWs.close(); } catch(e){} viewWs = null; }
    if (resume) { cur = resume; cur.end = null;cur.fixes=parseFixes(briefFix);const index=state.sessions.findIndex(s=>s.id===cur.id);if(index<0)state.sessions.push(cur);else state.sessions[index]=cur; } else { cur = newSession(asrMode?'mac':(imeMode?'ime':'browser'), mode); state.sessions.push(cur); }
    if(window.thtMeetingJoin&&!cur.continuationOriginal){cur.joinedEvent={...window.thtMeetingJoin};cur.title=cur.joinedEvent.title||'';window.thtMeetingJoin=null;}
    startedMode = mode;
    state.live = cur.id; lastAnalyzedLen = cur.transcript.map(x=>x.text).join('\n').length; interim = ''; lastFinal = ''; stickBottom = true;
    if (imeMode) { const ta=$('#ime'); ta.hidden=false; ta.value=''; imeUsed=0; imeLastLen=0; imeLastChange=Date.now(); setTimeout(()=>ta.focus(),50); note('输入法听写：点文本框 → 输入法的麦克风 → 说。'); el.src.textContent = T('src_ime')||'输入法听写'; }
    else if (asrMode) { cur.captureStarting=true; }
    else { try { rec.start(); el.src.textContent = T('src_browser')||'浏览器识别'; } catch(e) { note('无法启动识别：' + e.message, true); return false; } }
    running = true; updateModeChip(); el.start.hidden = true; el.stop.hidden = false; activeTab = 'tr'; applyTab();
    el.status.textContent = asrMode?(ui==='en'?'Starting audio…':'正在启动录音…'):(T('st_live')||'正在听'); el.status.className = asrMode?'pill':'pill live'; note(''); persist();
    resetSigs(); keepAwake(); render();window.dispatchEvent(new CustomEvent('tht-recording-started',{detail:{id:cur.id}}));
    stallWarned = false; stallTries = 0; fellBack = false;lastStallRetry=0;
    timer = setInterval(() => { const sec = Math.round((Date.now()-cur.start)/1000); el.clock.textContent = fmt(sec);
      // Intentionally paused or still acquiring audio is not a transcription outage.
      if (asrMode && running && !cur.captureStarting && !window.thtMiniPaused) {
        const quiet = Date.now() - (lastFinalAt || cur.start);
        const wsBad = !asrWs || asrWs.readyState !== 1;
        const heardSound = Date.now() - lastLoudAt < 90000;   // 最近 90 秒房间里有人出过声
        // 90 秒一帧音频都没来 = 采音这条路断了（切了音频设备、系统收回麦克风权限、标签页被节流），
        // 这种要单独算一种断线：它连"安静"都算不上，lastLoudAt 会一直冻在那儿，只看 heardSound 反而更晚发现。
        const noPcm = asrMode && Date.now() - meterLast > 90000;
        if ((wsBad || noPcm || (quiet > 90000 && heardSound)) && sec > 30) {
          if (quiet > 30000 && Date.now()-lastStallRetry>(stallTries<2?30000:120000)) {                       // 先自己救两次，不打扰他
            stallTries++; lastStallRetry = Date.now();
            stallNoticeShown = true;
            note((T('stall_auto')||'转写断了，正在自动重连（第 ') + stallTries + (T('stall_auto2')||' 次）…'), true);
            asrReopen();
          } else if (!fellBack) {
            fellBack = true;cur.transcriptionInterrupted=true;stallNoticeShown=true;
            note(backupHealthy&&safetyRecording?(ui==='en'?'Transcription interrupted. Check Audio backups to recover missing content.':'转写暂时中断，请核对「录音备份」并补转缺失内容。'):(ui==='en'?'Transcription and browser backup are unavailable. Use another recorder now.':'转写中断且浏览器备份不可用，请立即改用其他录音方式。'),true);
          }
        }
        if (!wsBad && !noPcm && quiet < 90000) {
          stallTries = 0; stallWarned = false; fellBack=false;
          // 恢复了就把提示撤掉。只撤自己发的那条：notice 是全局唯一一行，
          // 直接 note('') 会顺手把"录音备份失败"之类别人的警告一起抹掉。
          if (stallNoticeShown) { stallNoticeShown = false; cur.transcriptionInterrupted = false; if (mine(el.notice && el.notice.textContent)) note(''); }
        }
      } if (imeMode) imeIngest(false); if (sec % 40 === 0 && macOnline && !asrMode) analyze(false); const lastAt = cur.transcript.length ? cur.transcript[cur.transcript.length-1].at : cur.start; if (!asrMode && sec > 120 && Date.now() - lastAt > (cfg.autoEndMin||12)*60000) { note(`超过 ${cfg.autoEndMin||12} 分钟没人说话，自动结束。`); stopAll(true); } }, 1000);
    if(asrMode){const startingSession=cur;try{await asrStart();startingSession.captureStarting=false;if(!running||cur!==startingSession)return false;failedBrowserSession=null;persist();return true;}catch(e){startingSession.captureStarting=false;failedBrowserSession=startingSession;if(cur===startingSession)await stopAll(false,{discardUnstarted:!!startingSession.continuationOriginal});if(startingSession.continuationOriginal){const original=startingSession.continuationOriginal;Object.keys(startingSession).forEach(k=>delete startingSession[k]);Object.assign(startingSession,original,{pendingUpload:false});failedBrowserSession=null;persist();}note((ui==='en'?'Could not start recording: ':'录音启动失败：')+(e.message||e),true);return false;}}
    return true;
  }
  // 当前显示的这行提示是不是"转写断了"这一类（撤提示时只撤自己的）
  function mine(t){ return !t || /转写|Transcription|重连|reconnect/i.test(String(t)); }
  el.stop.onclick = () => stopAll(true);
  async function stopAll(summarize,{discardUnstarted=false}={}){
    if (!running) return;
    const endingSession=cur;if(endingSession)endingSession.captureStarting=false;
    if (imeMode) { imeIngest(true); $('#ime').hidden = true; }
    el.start.disabled=true;
    const endDelivered=asrMode?asrStop():false;
    running = false; updateModeChip(); state.live = null; try { rec && rec.stop(); } catch(e){}
    clearInterval(timer); try { wake && wake.release(); } catch(e){}
    el.stop.hidden = true; el.start.hidden = false;
    if (endingSession) { endingSession.end = Date.now(); endingSession.title = endingSession.title || (endingSession.transcript[0] && endingSession.transcript[0].text.slice(0,24)) || ('会议 ' + hms(endingSession.start).slice(0,5)); persist(); }
    if (asrMode && summarize) { endingSession.pendingUpload=true;endingSession.archiveAwaitingSince=Date.now();endingSession.archiveRetryCount=0;endingSession.uploadAfter=Date.now()+130000;persist();note(endDelivered?(ui==='en'?'Recording ended. Waiting for archive confirmation.':'录音已结束，等待归档确认。'):(ui==='en'?'Not delivered to Mac. Saved locally; will retry.':'尚未送达 Mac，已存本机，将自动重试。'),!endDelivered);checkMac().then(uploadPending);setTimeout(refreshArchive,2500); }
    else { if (summarize) await analyze(true); if (endingSession&&!discardUnstarted) { endingSession.pendingUpload = true; persist(); checkMac().then(uploadPending); } }
    el.start.disabled=asrStarting;
    el.status.textContent = T('st_ended')||'已结束'; el.status.className = 'pill'; el.src.textContent = '—';
    if(!discardUnstarted&&endingSession?.transcript.length)hubAPI('session',{session:endingSession}).catch(e=>note('工作台同步失败：'+e.message,true));
    if (endingSession && endingSession.summary) openSheet('#sh-sum');
    render(); setTimeout(()=>{ checkMac().then(()=>{ viewerConnect(); updateStatusIdle(); }); }, 3000);
  }
