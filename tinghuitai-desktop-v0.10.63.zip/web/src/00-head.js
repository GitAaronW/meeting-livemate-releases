
(() => {
  const $ = s => document.querySelector(s);
  const el = {clock:$('#clock'),status:$('#status'),start:$('#start'),stop:$('#stop'),lang:$('#lang'),tongue:$('#tongue'),notice:$('#notice'),src:$('#src'),
    tr:$('#tr'),hl:$('#hl'),ck:$('#ck'),sum:$('#sum'),hist:$('#hist'),ctr:$('#c-tr'),chl:$('#c-hl'),cck:$('#c-ck'),main:$('#main'),jump:$('#jump')};
  const esc = s => String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const fmt = sec => String(Math.floor(sec/60)).padStart(2,'0')+':'+String(sec%60).padStart(2,'0');
  const hms = ts => new Date(ts).toTimeString().slice(0,8);
  // warn 传 true 是黄条；传 'danger' 多一条红边，留给「已经丢了东西」这种必须看见的事，别滥用。
  const dismissedNotices = new Set(); let lastNotice = null;
  const noticeScope = () => window.location?.href || '';
  const noticeChanged = () => window.dispatchEvent(new Event('tht-notice-change'));
  const renderNotice = (record, restore = false) => {
    const {msg, warn, meetingId, action, scope} = record;
    const key = JSON.stringify([scope, meetingId, msg, String(warn||''), action?.label||'']);
    el.notice.dataset.meetingId = meetingId;
    el.notice.hidden = !msg || (!restore && dismissedNotices.has(key));
    el.notice.textContent = '';
    el.notice.className = 'notice'+(warn?' warn':'')+(warn==='danger'?' danger':'');
    el.notice.setAttribute('role', 'status');
    if (msg) {
      lastNotice = record;
      const text = document.createElement('span'); text.className = 'notice-message'; text.textContent = msg + (action?'  ':''); el.notice.appendChild(text);
      if (action) {
        const b = document.createElement('button'); b.type = 'button'; b.className = 'btn sm'; b.textContent = action.label;
        b.onclick = () => { note(''); if (scope===noticeScope()) action.fn(); }; el.notice.appendChild(b);
      }
      const close = document.createElement('button'); close.type = 'button'; close.className = 'notice-close';
      // Empty text keeps existing exact-message checks and recovery timers intact.
      close.setAttribute('aria-label', document.documentElement.lang==='en'?'Dismiss notification':'关闭通知');
      close.onclick = () => {
        dismissedNotices.add(key);
        if (dismissedNotices.size>32) dismissedNotices.delete(dismissedNotices.values().next().value);
        el.notice.hidden = true; noticeChanged();
      };
      el.notice.appendChild(close);
    }
    noticeChanged();
  };
  const note = (msg, warn, meetingId = '') => renderNotice({msg:msg||'', warn, meetingId, scope:noticeScope()});
  const noteAction = (msg, label, fn) => renderNotice({msg, warn:true, meetingId:'', scope:noticeScope(), action:{label, fn}});
  window.thtHasNotice = () => !!lastNotice && lastNotice.scope===noticeScope();
  window.thtRestoreNotice = () => { if (window.thtHasNotice()) renderNotice(lastNotice, true); };
  const buzz = () => { try { navigator.vibrate && navigator.vibrate(30); } catch(e){} };
