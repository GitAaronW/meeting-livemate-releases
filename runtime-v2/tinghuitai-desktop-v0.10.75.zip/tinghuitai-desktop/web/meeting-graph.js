'use strict';
// Shared by the browser renderer and server validation. Edges are explicit;
// a list of nodes never implies an order or relationship.
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.MeetingGraph=api;})(typeof globalThis==='object'?globalThis:this,()=>{
 function normalizeChart(raw){
 if(raw===null)return null;
 if(raw?.kind!=='numeric-comparison'||
  typeof raw.sourceId!=='string'||!raw.sourceId.trim()||raw.sourceId.length>160||typeof raw.quote!=='string'||raw.quote.length>1000||
  typeof raw.metric!=='string'||!raw.metric.trim()||raw.metric.length>80||
  typeof raw.unit!=='string'||!/^\p{L}[\p{L}/%µμ]*$|^%$/u.test(raw.unit)||raw.unit.length>20||
  !Array.isArray(raw.points)||raw.points.length<2||raw.points.length>8)throw Error('invalid numeric comparison');
 const metric=raw.metric.trim(),labels=new Set(),points=[];
 // Every measurement must explicitly repeat the same unit. Exact whole-number
 // or decimal text is retained; no rounding or parsing of ranges/exponents.
 for(const point of raw.points){
  if(typeof point?.label!=='string'||!point.label.trim()||point.label.length>80||/[\n:：,，;；]/.test(point.label)||
   typeof point.valueText!=='string'||!/^(?:0|[1-9]\d*)(?:\.\d+)?$/.test(point.valueText))throw Error('invalid numeric comparison');
  const label=point.label.trim(),key=label.toLocaleLowerCase('en-US'),value=Number(point.valueText);
  if(labels.has(key)||!Number.isFinite(value)||value>Number.MAX_SAFE_INTEGER||
   (value===0&&/[1-9]/.test(point.valueText)))throw Error('invalid numeric comparison');
  labels.add(key);points.push({label,value,valueText:point.valueText});
 }
 const escape=s=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
 // Require the quote itself to state the complete comparison. Extra wording,
 // qualifiers, different metrics, missing units and additional numbers do not
 // silently become a chart. They remain available as ordinary short prose.
 const measurement=p=>escape(p.label)+'\\s*[:：]?\\s*'+escape(p.valueText)+'\\s*'+escape(raw.unit);
 const statement='^\\s*'+escape(metric)+'\\s*[:：]\\s*'+points.map(measurement).join('\\s*[,，;；]\\s*')+'\\s*[。.]?\\s*$';
 if(!new RegExp(statement,'u').test(raw.quote))throw Error('invalid numeric comparison');
 return {kind:'numeric-comparison',metric,unit:raw.unit,points,sourceId:raw.sourceId,quote:raw.quote};
 }
 const validId=x=>typeof x==='string'&&/^[\w-]{1,80}$/.test(x);
 function normalize(nodes,edges){
  if(!Array.isArray(nodes)||nodes.length>30)throw Error('invalid diagram nodes');
  const ids=new Set(),out=nodes.map((n,i)=>{
   if(!n||typeof n.label!=='string'||n.label.length>240||typeof (n.detail||'')!=='string'||(n.detail||'').length>1000)throw Error('invalid diagram node');
   const id=n.id===undefined?'node-'+i:n.id;if(!validId(id)||ids.has(id))throw Error('invalid diagram node id');ids.add(id);
   if(n.role!==undefined&&!['input','process','decision','output','constraint'].includes(n.role))throw Error('invalid diagram role');return {id,label:n.label,detail:n.detail||'',...(n.role?{role:n.role}:{})};
  });
  if(!Array.isArray(edges)||edges.length>90)throw Error('invalid diagram edges');
  const seen=new Set(),relations=edges.map(e=>{
   if(!e||!ids.has(e.from)||!ids.has(e.to)||typeof (e.label||'')!=='string'||(e.label||'').length>160)throw Error('invalid diagram relationship');
   const key=e.from+'\0'+e.to+'\0'+(e.label||'');if(seen.has(key))throw Error('duplicate diagram relationship');seen.add(key);
   return {from:e.from,to:e.to,label:e.label||''};
  });return {nodes:out,edges:relations};
 }
 // Keep English words intact; CJK and oversized tokens can wrap by character.
 function labelLines(label,limit=23){
  const tokens=label.match(/[A-Za-z0-9]+(?:['’-][A-Za-z0-9]+)*|\s+|[^A-Za-z0-9\s]/gu)||[],lines=[];let line='';
  const width=text=>Array.from(text).reduce((sum,c)=>sum+(c.charCodeAt(0)>255?2:1),0);
  for(let token of tokens){if(/^\s+$/.test(token)){if(line&&!line.endsWith(' '))line+=' ';continue;}
   while(width(token)>limit){if(line.trim())lines.push(line.trim());let part='',used=0;for(const char of token){const size=width(char);if(part&&used+size>limit)break;part+=char;used+=size;}lines.push(part);line='';token=token.slice(part.length);}
   if(width(line+token)>limit&&line.trim()){lines.push(line.trim());line='';}line+=token;
  }if(line.trim())lines.push(line.trim());return lines.length?lines:[''];
 }
 function compactChain(graph){
  if(graph.nodes.length<2||graph.nodes.length>3||graph.edges.length!==graph.nodes.length-1)return null;
  const incoming=new Map(),outgoing=new Map();for(const e of graph.edges){if(e.from===e.to||incoming.has(e.to)||outgoing.has(e.from))return null;incoming.set(e.to,e);outgoing.set(e.from,e);}
  const roots=graph.nodes.filter(n=>!incoming.has(n.id));if(roots.length!==1)return null;
  const byId=new Map(graph.nodes.map(n=>[n.id,n])),ordered=[],seen=new Set();let id=roots[0].id,y=16;
  while(id&&!seen.has(id)){seen.add(id);const n=byId.get(id),height=Math.max(60,28+Math.min(4,labelLines(n.label).length)*20);ordered.push({...n,x:16,y,width:210,height});const edge=outgoing.get(id);y+=height+(edge?Math.max(42,Math.min(3,Math.ceil(edge.label.length/18))*18+16):0);id=edge?.to;}
  if(ordered.length!==graph.nodes.length)return null;
  const positions=new Map(ordered.map(n=>[n.id,n]));const connections=graph.edges.map(e=>{const a=positions.get(e.from),b=positions.get(e.to),x=a.x+a.width/2,end=b.y;return {...e,path:`M ${x} ${a.y+a.height} L ${x} ${end}`,arrow:`M ${x-5} ${end-8} L ${x} ${end} L ${x+5} ${end-8}`,labelX:x,labelY:(a.y+a.height+end)/2};});
  return {...graph,nodes:ordered,connections,width:242,height:y+16};
 }
 // Only a complete, explicit two-route diamond receives this presentation.
 // Other branches, isolated nodes and cycles retain the general layout.
 function compactFork(graph){
  if(graph.nodes.length!==4||graph.edges.length!==4)return null;
  const incoming=new Map(graph.nodes.map(n=>[n.id,[]])),outgoing=new Map(graph.nodes.map(n=>[n.id,[]]));
  for(const e of graph.edges){incoming.get(e.to).push(e);outgoing.get(e.from).push(e);}
  const roots=graph.nodes.filter(n=>incoming.get(n.id).length===0&&outgoing.get(n.id).length===2),ends=graph.nodes.filter(n=>incoming.get(n.id).length===2&&outgoing.get(n.id).length===0);
  if(roots.length!==1||ends.length!==1)return null;
  const root=roots[0],end=ends[0],middle=graph.nodes.filter(n=>n!==root&&n!==end);
  if(!middle.every(n=>incoming.get(n.id).length===1&&incoming.get(n.id)[0].from===root.id&&outgoing.get(n.id).length===1&&outgoing.get(n.id)[0].to===end.id))return null;
  const height=n=>Math.max(60,28+Math.min(4,labelLines(n.label).length)*20),rootH=height(root),midH=Math.max(...middle.map(height)),branchY=16+rootH+72,endY=branchY+midH+50;
  const positions=[{...root,x:137,y:16,width:210,height:rootH},...middle.map((n,i)=>({...n,x:16+i*242,y:branchY,width:210,height:height(n)})),{...end,x:137,y:endY,width:210,height:height(end)}],byId=new Map(positions.map(n=>[n.id,n]));
  const connections=graph.edges.map(e=>{const a=byId.get(e.from),b=byId.get(e.to),sx=a.x+105,sy=a.y+a.height,ex=b.x+105,ey=b.y,mid=(sy+ey)/2;return {...e,path:`M ${sx} ${sy} C ${sx} ${mid}, ${ex} ${mid}, ${ex} ${ey}`,arrow:`M ${ex-5} ${ey-8} L ${ex} ${ey} L ${ex+5} ${ey-8}`,labelX:(sx+ex)/2,labelY:mid};});
  return {...graph,nodes:positions,connections,width:484,height:endY+height(end)+16};
 }
 // A small rooted tree reads top-to-bottom at full text size; do not shrink
 // a wide desktop diagram until its labels are illegible.
 function compactTree(graph){
  if(graph.nodes.length<5||graph.nodes.length>8||graph.edges.length!==graph.nodes.length-1)return null;
  const children=new Map(graph.nodes.map(n=>[n.id,[]])),incoming=new Map(graph.nodes.map(n=>[n.id,0]));
  for(const e of graph.edges){children.get(e.from).push(e.to);incoming.set(e.to,incoming.get(e.to)+1);}
  const roots=graph.nodes.filter(n=>incoming.get(n.id)===0);if(roots.length!==1||graph.nodes.some(n=>incoming.get(n.id)>1))return null;
  const levels=[],seen=new Set(),queue=[{id:roots[0].id,rank:0}];
  for(let i=0;i<queue.length;i++){const {id,rank}=queue[i];if(seen.has(id))return null;seen.add(id);(levels[rank]||=[]).push(id);for(const child of children.get(id))queue.push({id:child,rank:rank+1});}
  if(seen.size!==graph.nodes.length||levels.some(row=>row.length>2))return null;
  const byId=new Map(graph.nodes.map(n=>[n.id,n])),positions=[];let y=16;
  for(const row of levels){let height=0;for(const [index,id] of row.entries()){const n=byId.get(id),h=28+labelLines(n.label).length*20+(n.detail?8+labelLines(n.detail,26).length*18:0);height=Math.max(height,h);positions.push({...n,x:row.length===1?176:16+index*320,y,width:210,height:h});}y+=height+68;}
  const placed=new Map(positions.map(n=>[n.id,n]));
  const connections=graph.edges.map(e=>{const a=placed.get(e.from),b=placed.get(e.to),sx=a.x+105,sy=a.y+a.height,ex=b.x+105,ey=b.y,mid=(sy+ey)/2;return {...e,path:`M ${sx} ${sy} C ${sx} ${mid}, ${ex} ${mid}, ${ex} ${ey}`,arrow:`M ${ex-5} ${ey-8} L ${ex} ${ey} L ${ex+5} ${ey-8}`,labelX:(sx+ex)/2,labelY:mid};});
  return {...graph,nodes:positions,connections,width:562,height:y-52,compactTree:true};
 }
 function layout(nodes,edges,options={}){
  const graph=normalize(nodes,edges);if(options.compact){const compact=compactChain(graph)||compactFork(graph)||compactTree(graph);if(compact)return compact;}const next=new Map(graph.nodes.map(n=>[n.id,[]]));for(const e of graph.edges)next.get(e.from).push(e.to);
  // Strongly connected components keep loops together. Rank only the acyclic
  // component graph so branch, merge and feedback links cannot hang layout.
  let index=0;const indices=new Map(),low=new Map(),stack=[],active=new Set(),components=[];
  function visit(id){indices.set(id,index);low.set(id,index++);stack.push(id);active.add(id);for(const to of next.get(id)){if(!indices.has(to)){visit(to);low.set(id,Math.min(low.get(id),low.get(to)));}else if(active.has(to))low.set(id,Math.min(low.get(id),indices.get(to)));}if(low.get(id)===indices.get(id)){const c=[];let v;do{v=stack.pop();active.delete(v);c.push(v);}while(v!==id);components.push(c);}}
  for(const n of graph.nodes)if(!indices.has(n.id))visit(n.id);
  const membership=new Map();components.forEach((c,i)=>c.forEach(id=>membership.set(id,i)));
  const outgoing=components.map(()=>new Set()),incoming=components.map(()=>0),ranks=components.map(()=>0);
  for(const e of graph.edges){const a=membership.get(e.from),b=membership.get(e.to);if(a!==b&&!outgoing[a].has(b)){outgoing[a].add(b);incoming[b]++;}}
  const queue=incoming.map((v,i)=>v===0?i:null).filter(v=>v!==null);for(let i=0;i<queue.length;i++){const a=queue[i];for(const b of outgoing[a]){ranks[b]=Math.max(ranks[b],ranks[a]+1);if(--incoming[b]===0)queue.push(b);}}
  // Size cards to their text rather than reserving a full paragraph of blank space.
  const rows=new Map(),positions=graph.nodes.map(n=>{const rank=ranks[membership.get(n.id)],y=rows.get(rank)||24,height=Math.max(60,28+Math.min(4,labelLines(n.label).length)*20);rows.set(rank,y+height+32);return {...n,x:24+rank*390,y,width:210,height};});
  const tallest=Math.max(0,...rows.values());for(const n of positions)n.y+=(tallest-rows.get(ranks[membership.get(n.id)]))/2;
  const byId=new Map(positions.map(n=>[n.id,n]));
  const lanes=new Map();
  const connections=graph.edges.map(edge=>{
   const a=byId.get(edge.from),b=byId.get(edge.to),right=b.x>a.x,same=b.x===a.x,startX=a.x+(right||same?a.width:0),endX=b.x+(right?0:b.width),startY=a.y+a.height/2,endY=b.y+b.height/2;
   const key=[a.id,b.id].sort().join('|'),lane=lanes.get(key)||0;lanes.set(key,lane+1);
   let path,labelX,labelY;if(same){const bend=Math.max(startX,endX)+40+lane*56+(a.id===b.id?24:0);path=a.id===b.id?`M ${startX} ${startY-20} C ${bend+45} ${startY-65}, ${bend+45} ${startY+65}, ${endX} ${endY+20}`:`M ${startX} ${startY} C ${bend} ${startY}, ${bend} ${endY}, ${endX} ${endY}`;labelX=startX*.25+bend*.75;labelY=(startY+endY)/2+(lane%2?18:-18);}else{const mid=(startX+endX)/2,offset=lane===0?0:(lane%2?1:-1)*Math.ceil(lane/2)*44;path=`M ${startX} ${startY} C ${mid} ${startY+offset}, ${mid} ${endY+offset}, ${endX} ${endY}`;labelX=mid;labelY=startY*.68+endY*.32+offset*.75;}
   const tipY=a.id===b.id?endY+20:endY,sign=right?1:-1;
   return {...edge,path,arrow:`M ${endX-sign*8} ${tipY-5} L ${endX} ${tipY} L ${endX-sign*8} ${tipY+5}`,labelX,labelY:labelY-8};
  });
  return {...graph,nodes:positions,connections,width:Math.max(360,...positions.map(n=>n.x+320),...connections.map(e=>e.labelX+100)),height:Math.max(120,...positions.map(n=>n.y+n.height+24))};
 }
 const tones={input:['#edf2fc','#7d95bc'],process:['#f0f4ef','#94a58d'],decision:['#fff5e4','#bea16a'],output:['#f1edfa','#a091ba'],constraint:['#faeeec','#bd928a']};
 const tone=role=>tones[role]||['#f6f6f3','#c7cbc3'];
 function render(value,document){
  const g=layout(value.nodes,value.edges,{compact:true}),ns='http://www.w3.org/2000/svg',wrap=document.createElement('div');wrap.className='meeting-graph-preview';const english=(document.documentElement?.lang||'zh').startsWith('en');
  const svg=document.createElementNS(ns,'svg');svg.setAttribute('viewBox',`0 0 ${g.width} ${g.height}`);svg.setAttribute('role','img');svg.setAttribute('aria-label','Meeting relationship diagram');svg.style.width='100%';svg.style.height='auto';svg.style.maxWidth=g.width+'px';svg.style.display='block';
  const element=(tag,attrs,text)=>{const e=document.createElementNS(ns,tag);for(const [k,v] of Object.entries(attrs))e.setAttribute(k,String(v));if(text!==undefined)e.textContent=text;svg.append(e);return e;};
  for(const e of g.connections){element('path',{d:e.path,stroke:'#8b9d91','stroke-width':2,fill:'none'});element('path',{d:e.arrow,stroke:'#8b9d91','stroke-width':2,fill:'none'});}
  // Draw labels after all connectors, with their own backing so a crossing line
  // cannot run through the text. Full relationship text is retained in <title>.
  for(const e of g.connections){if(!e.label)continue;const lines=e.label.match(/.{1,18}/gu)||[''],shown=lines.slice(0,3);if(lines.length>3)shown[2]=shown[2].slice(0,15)+'…';const w=Math.min(154,Math.max(...shown.map(t=>Array.from(t).reduce((n,c)=>n+(/[\u3000-\uffff]/u.test(c)?13:7),0)))+16),h=shown.length*18+8;element('rect',{x:e.labelX-w/2,y:e.labelY-h/2,width:w,height:h,rx:5,fill:'#fffefb'});const text=element('text',{x:e.labelX,y:e.labelY-h/2+17,'text-anchor':'middle','font-size':13,fill:'#565e59'});shown.forEach((line,i)=>{const span=document.createElementNS(ns,'tspan');span.setAttribute('x',e.labelX);span.setAttribute('dy',i?'18':'0');span.textContent=line;text.append(span);});const title=document.createElementNS(ns,'title');title.textContent=e.label;text.append(title);}
  for(const n of g.nodes){const colors=tone(n.role);element('rect',{x:n.x,y:n.y,width:n.width,height:n.height,rx:14,fill:colors[0],stroke:colors[1]});const text=element('text',{x:n.x+14,y:n.y+30,'font-size':15,fill:'#252a26'});const lines=labelLines(n.label);lines.slice(0,4).forEach((value,i)=>{const line=document.createElementNS(ns,'tspan');line.setAttribute('x',String(n.x+14));line.setAttribute('dy',i?'20':'0');line.textContent=i===3&&lines.length>4?value.replace(/.$/u,'…'):value;text.append(line);});const title=document.createElementNS(ns,'title');title.textContent=n.label+(n.detail?'\n'+n.detail:'');text.append(title);}
  const viewport=document.createElement('div');viewport.style.cssText='max-height:min(360px,45vh);overflow:auto';viewport.append(svg);viewport.tabIndex=0;viewport.setAttribute('aria-label',english?'Scroll relationship diagram':'滚动查看关系图');wrap.append(viewport);const expand=document.createElement('button');expand.type='button';expand.textContent=english?'⤢ View full diagram':'⤢ 查看全图';expand.setAttribute('aria-label','Expand diagram / 放大图表');expand.title='Expand diagram / 放大图表';expand.onclick=()=>{const dialog=document.createElement('dialog');dialog.style.cssText='width:min(1200px,94vw);max-width:94vw;max-height:90vh;border:1px solid #dbe3d8;border-radius:14px;padding:16px;background:#fffefb;overflow:auto';const close=document.createElement('button');close.type='button';close.textContent='×';close.setAttribute('aria-label','Close diagram / 关闭图表');close.onclick=()=>dialog.close();const enlarged=svg.cloneNode(true);enlarged.style.width='100%';enlarged.style.height='auto';enlarged.style.maxHeight='75vh';dialog.append(close,enlarged);for(const n of g.nodes){const item=document.createElement('p'),label=document.createElement('strong');label.textContent=n.label;item.append(label);if(n.detail)item.append(document.createTextNode(' — '+n.detail));dialog.append(item);}const view=document.defaultView,notify=open=>{if(view&&view.parent!==view)view.parent.postMessage({type:'tht-document-modal',open},view.location.origin);};dialog.addEventListener('close',()=>{notify(false);dialog.remove();},{once:true});document.body.append(dialog);dialog.showModal();notify(true);};const toolbar=document.createElement('div');toolbar.style.cssText='display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px;font-size:12px;color:#586551';const count=document.createElement('span');count.textContent=english?g.nodes.length+' nodes · '+g.edges.length+' relationships':g.nodes.length+' 个节点 · '+g.edges.length+' 条关系';expand.style.cssText='border:1px solid #dbe3d8;border-radius:8px;background:#fff;padding:5px 10px;cursor:pointer;color:#344b3b;white-space:nowrap';toolbar.append(expand);wrap.insertBefore(toolbar,viewport);return wrap;
 }
 function chartForRows(raw,rows){try{const c=normalizeChart(raw),matches=rows.filter(r=>r.id===c.sourceId);return matches.length===1&&!matches[0].stale&&String(matches[0].text||'').trim()===c.quote.trim()?c:null;}catch{return null;}}
 function renderChart(raw,document){
  const c=normalizeChart(raw),figure=document.createElement('figure');figure.className='meeting-numeric-preview';figure.style.cssText='margin:12px 0;padding:12px;border:1px solid #dbe3d8;border-radius:12px;min-width:0';
  const caption=document.createElement('figcaption');caption.textContent=c.metric+' ('+c.unit+')';caption.style.cssText='font-weight:600;margin-bottom:10px';figure.append(caption);
  const max=Math.max(...c.points.map(p=>p.value));
  for(const p of c.points){const row=document.createElement('div'),label=document.createElement('span'),value=document.createElement('span'),track=document.createElement('div'),bar=document.createElement('div');row.style.cssText='margin:10px 0;overflow-wrap:anywhere';label.textContent=p.label;value.textContent=p.valueText+' '+c.unit;value.style.cssText='float:right;margin-left:12px;font-variant-numeric:tabular-nums';track.style.cssText='clear:both;height:8px;margin-top:6px;border-radius:4px;background:#edf0eb;overflow:hidden';bar.style.cssText='height:100%;background:#789783;border-radius:4px;width:'+(max>0?p.value/max*100:0)+'%';track.setAttribute('aria-hidden','true');track.append(bar);row.append(label,value,track);figure.append(row);}
  const source=document.createElement('details'),summary=document.createElement('summary'),quote=document.createElement('blockquote');summary.textContent=(document.documentElement?.lang||'zh').startsWith('en')?'Source · '+c.sourceId:'原文 · '+c.sourceId;quote.textContent=c.quote;quote.style.cssText='margin:8px 0;overflow-wrap:anywhere';source.append(summary,quote);figure.append(source);return figure;
 }
 // API marks revisions stale after any underlying human or AI edit. Never apply
 // unverified storage revisions. A fresh explicit comment may revise a manual base.
 function effectiveCandidate(module,revisions,rows){
  const saved=revisions?.[module.id];
  if(!saved||saved.stale!==false){if(module.chart&&Array.isArray(rows))return {...module,chart:chartForRows(module.chart,rows)};return module;}
  const next={...module,body:saved.body,sourceRefs:saved.sourceRefs};
  if(saved.nodes!==undefined){const g=normalize(saved.nodes,saved.edges===undefined?[]:saved.edges);next.nodes=g.nodes;next.edges=g.edges;}
  if(saved.chart!==undefined)next.chart=normalizeChart(saved.chart);
  if(next.chart&&Array.isArray(rows))next.chart=chartForRows(next.chart,rows);
  return next;
 }
 return {normalize,normalizeChart,chartForRows,layout,render,renderChart,tone,labelLines,effectiveCandidate};
});
