'use strict';
const variants={"arm64":{"runtime":{"node":"v22.23.2","v8":"12.4.254.21-node.56","platform":"darwin","arch":"arm64"},"sourceLength":41673},"x64":{"runtime":{"node":"v22.23.2","v8":"12.4.254.21-node.56","platform":"darwin","arch":"x64"},"sourceLength":41673}};
const selected=variants[process.arch];
if(!selected||process.version!==selected.runtime.node||process.versions.v8!==selected.runtime.v8||process.platform!==selected.runtime.platform)throw new Error('Meeting LiveMate: incompatible bundled Node runtime');
require('node:v8').setFlagsFromString('--no-lazy --no-flush-bytecode');
const script=new (require('node:vm').Script)('"'+'\u200b'.repeat(selected.sourceLength-2)+'"',{cachedData:require('node:fs').readFileSync(__filename+'.jsc.'+process.arch),filename:__filename});
if(script.cachedDataRejected)throw new Error('Meeting LiveMate: bytecode rejected');
const run=script.runInThisContext();
run.call(module.exports,module.exports,require,module,__filename,__dirname);
