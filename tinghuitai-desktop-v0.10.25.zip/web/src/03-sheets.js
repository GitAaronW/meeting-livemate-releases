  // ===== 抽屉 =====
  const scrim = $('#scrim');
  function openSheet(id){ closeSheets(); $(id).classList.add('open'); scrim.hidden = false; }
  // 同一个按钮按第二次就关掉（Apple HIG：取消 = 撤回，一个动作一个入口）
  function toggleSheet(id, before){ const el = $(id); if (el && el.classList.contains('open')) { closeSheets(); return false; } if (before) before(); openSheet(id); return true; }
  function toggleDialog(id, before){ const d = $(id); if (d && d.open) { d.close(); return false; } if (before) before(); return true; }
  function closeSheets(){ document.querySelectorAll('.sheet').forEach(s=>s.classList.remove('open')); scrim.hidden = true; }
  scrim.onclick = closeSheets;
  // 抽屉（.sheet）不是 <dialog>，拿不到浏览器自带的 Esc。不补这一下，
  // 「所有弹窗关闭方式统一」就只统一了一半：会议列表和开会方式按 Esc 没反应。
  document.addEventListener('keydown', e => {
    if (e.key !== 'Escape' || e.defaultPrevented) return;
    if (document.querySelector('dialog[open]')) return;          // 弹窗自己会处理
    if (!document.querySelector('.sheet.open')) return;
    e.preventDefault(); closeSheets();
  });
  document.querySelectorAll('.sheet [data-close]').forEach(b => b.onclick = closeSheets);
  $('#b-sum').onclick = () => toggleSheet('#sh-sum');
  $('#b-hist').onclick = () => { if (!toggleSheet('#sh-hist', () => { board.trash = false; renderHist(); })) return; refreshBoard().then(()=>{ if (anyArchiving()) startArchivePoll(); }).catch(()=>{}); };
  $('#hist-trash').onclick = () => { board.trash = !board.trash; const tb = $('#hist-trash'); tb.textContent = board.trash ? (ui==='en'?'← Back':'← 返回看板') : ((ui==='en'?'Recently deleted ':'最近删除 ')+'('+(board.trashList||[]).length+')'); renderHist(); };
  const MODE_OPTS_ZH = [
    ['asr','线下会','使用手机或电脑收录现场声音。'],
    ['asr-tab','线上会（我一个人）','只收会议窗口的声音和你自己说话。麦克风开降噪，旁边同事的闲聊不会被记进去。开始时选会议窗口并勾选共享音频。'],
    ['asr-room','线上 + 线下（会议室）','会议窗口的声音，加上整个房间的讨论。关掉降噪，屋里谁说话都收；会议软件里闭麦不影响。开始时选会议窗口并勾选共享音频。'],
    ['asr-sys','线上会 · 用虚拟声卡收音','装过 BlackHole / Loopback 这类虚拟声卡、不想每次去选标签页的人用这个。效果和上面的线上会一样。'],
    ['ime','备用 · Mac 自带听写','火山连不上时临时用，只认你对着麦克风说的话。'],
    ['browser','备用 · 浏览器识别','火山连不上时临时用，准确率看浏览器，一般比火山差不少。'],
  ];
  const MODE_OPTS_EN = [
    ['asr','In person','Capture the room with your phone or computer.'],
    ['asr-tab','Online (just me)','Captures the meeting audio and your own voice, with noise suppression so nearby chatter is not recorded.'],
    ['asr-room','Online + room','Meeting audio plus everyone in the room. Noise suppression off. Muting yourself in the meeting app does not affect it.'],
    ['asr-sys','Online · via virtual audio device','For people who set up BlackHole / Loopback and do not want to pick a tab each time. Same result as Online above.'],
    ['ime','Backup · macOS dictation','Temporary fallback when the transcription service is unreachable.'],
    ['browser','Backup · browser recognition','Temporary fallback; accuracy depends on the browser and is usually worse.'],
  ];
  const MODE_OPTS_GET = () => (ui === 'en' ? MODE_OPTS_EN : MODE_OPTS_ZH);
  async function renderModeList(){
    const box=$('#mode-list');
    box.textContent=ui==='en'?'Loading audio inputs…':'正在读取声音来源…';
    const nativeInput=nativeState.active?nativeState.captureMode!=='browser':(nativeState.available&&!window.thtBrowserCapture);
    let inputs=[];
    try { inputs=(await navigator.mediaDevices.enumerateDevices()).filter(d=>d.kind==='audioinput' && !['default','communications'].includes(d.deviceId)); } catch(e){}
    const auto=ui==='en'?'Auto · recommended':'自动 · 推荐';
    const desc=ui==='en'?'System default microphone. No device selection needed.':'使用系统默认麦克风，无需先选设备。';
    const rows=nativeInput?[{id:'',label:auto,desc:ui==='en'?'Computer audio + system default microphone':'电脑系统声音 + 系统默认麦克风'},...(nativeState.inputDevices||[]).map(d=>({id:d.uid,label:d.name,desc:''}))]:[{id:'',label:auto,desc},...inputs.map((d,i)=>({id:d.deviceId,label:d.label||(ui==='en'?'Microphone ':'麦克风 ')+(i+1),desc:''}))];
    box.replaceChildren();
    for(const row of rows){
      const button=document.createElement('button');button.type='button';button.className='mode-opt';
      button.textContent=row.label;button.setAttribute('aria-selected',String((nativeInput?(nativeState.requestedInputUID??cfg.nativeInputUID??''):(cfg.micId||''))===row.id));
      if(row.desc){const hint=document.createElement('small');hint.textContent=row.desc;button.append(hint);}
      button.onclick=async()=>{
        button.disabled=true;
        if(nativeInput){
          try{
            if(nativeState.active){
              const sid=nativeState.sessionId,result=await nativeRequest('microphone-switch',{sessionId:sid,inputUID:row.id}),requestId=result.microphoneChange?.requestId;
              if(!requestId)throw Error(ui==='en'?'Switch not accepted':'未接收到切换请求');
              let receipt=null;
              for(let i=0;i<12;i++){await new Promise(r=>setTimeout(r,500));const state=await nativeRequest('status');nativeStatus(state);if(state.sessionId!==sid||!state.active)throw Error(ui==='en'?'Meeting changed':'会议状态已变化');if(state.microphoneReceipt?.requestId===requestId){receipt=state.microphoneReceipt;break;}}
              if(!receipt)throw Error(ui==='en'?'Awaiting recorder confirmation; switch is still pending':'等待录音端确认，切换请求仍在处理中');if(!receipt.ok)throw Error(receipt.error);
            }else {await nativeRequest('input-preference',{inputUID:row.id});nativeStatus(await nativeRequest('status'));}
            cfg.nativeInputUID=row.id;try{localStorage.setItem('tht-settings',JSON.stringify(cfg));}catch(e){}updateModeChip();closeSheets();return;
          }catch(e){note(e.message,true);button.disabled=false;return;}
        }
        if(running && !await switchMicrophone(row.id,startedMode==='asr-room',row.id?row.label:'')){button.disabled=false;return;}
        cfg.micId=row.id;cfg.micLabel=row.id?row.label:'';
        try{localStorage.setItem('tht-settings',JSON.stringify(cfg));}catch(e){}
        if(!running){el.lang.value='asr';window.thtBrowserCapture=true;window.thtBrowserMode='asr';}
        updateModeChip();closeSheets();
      }; box.append(button);
    }
    if(running&&(!nativeState.active||nativeState.captureMode==='browser')){
      const shared=document.createElement('button');shared.type='button';shared.className='mode-opt';
      shared.textContent=ui==='en'?'Connect / change shared meeting audio':'接入／更换共享会议声音';
      const hint=document.createElement('small');hint.textContent=ui==='en'?'Select the meeting tab and enable Share audio. Recording continues.':'选择会议标签页并勾选分享音频；当前会议继续录音。';shared.append(hint);
      shared.onclick=async()=>{shared.disabled=true;if(await addSharedAudio())closeSheets();else shared.disabled=false;};box.append(shared);
    }
    if(!running&&!nativeState.active){if(nativeState.available){const system=document.createElement('button');system.type='button';system.className='mode-opt';system.textContent=ui==='en'?'Computer audio + microphone':'电脑系统声音 + 麦克风';system.onclick=()=>{if(window.thtSelectCapture?.(false))closeSheets();};box.append(system);}const button=document.createElement('button');button.type='button';button.className='mode-opt';button.textContent=ui==='en'?'Shared tab / screen audio + microphone':'共享标签页／屏幕声音 + 麦克风';button.onclick=()=>{el.lang.value='asr-tab';window.thtBrowserCapture=true;window.thtBrowserMode='asr-tab';updateModeChip();closeSheets();};box.append(button);}
  }
  // 工作台原来是普通链接，点一下会把当前页面整个换掉——开会中点一下录音就没了。
  // 工作台是另一个去处（总待办池、知识条目），不是一个设置项——放在导航行里。
  // 2026-09-12 我一度把它藏进设置，等于弄丢了一个入口。
  const openWorkHub = e => { if (e) e.preventDefault(); window.thtOpenWorkbench(); };
  $('#work-link').onclick = openWorkHub;
  $('#b-work-top') && ($('#b-work-top').onclick = openWorkHub);
  $('#b-memory').onclick = () => window.thtOpenWorkbench('memory');
  $('#mode-chip').onclick = () => { toggleSheet('#sh-mode', renderModeList); };
  // L-11：从 Mac 找回原来只在「往期会议」右上角有，启动时发现 Mac 上有未结束的会只能发一句提示
  // 让用户自己去翻。现在抽成函数，启动那一个恢复入口直接调它。
  async function pullFromMac(msgEl){
    const m = msgEl || $('#hist-msg'); if (m) m.textContent = T('pull_wait')||'从 Mac 找回中……';
    try {
      // 「从 Mac 找回」要把每一场的全文搬回本机，所以这一条显式要全量（D6 之后默认不带逐字稿）
      const r = await fetch(relayBase()+'/export-state?full=1&token='+encodeURIComponent(cfg.relayToken||''), {cache:'no-store'});
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const d = await r.json();
      const have = new Set(state.sessions.map(x=>x.id));
      let n = 0;
      (d.sessions||[]).forEach(x => { if (x && x.id && !have.has(x.id)) { state.sessions.push(normalizeSession(x)); n++; } });
      if (n) persist();
      await refreshBoard();
      if (m) m.textContent = n ? ((T('pull_ok')||'找回 ') + n + (T('pull_ok2')||' 场。')) : (T('pull_none')||'Mac 上没有这台设备缺的场次。');
      return n;
    } catch(e){ if (m) m.textContent = (T('pull_fail')||'找不回：') + (e.message||e) + (T('pull_fail2')||'（Mac 在线吗？）'); throw e; }
  }
  $('#hist-pull').onclick = () => pullFromMac().catch(()=>{});
