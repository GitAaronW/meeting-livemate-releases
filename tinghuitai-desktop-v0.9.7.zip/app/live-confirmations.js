'use strict';
// One interruption at a time. Session journal is the trace; confirmed decisions
// use the existing memory database, never a second memory store.
const crypto=require('crypto');
const TTL=5*60*1000,COOLDOWN=2*60*1000;
function visible(session,now=Date.now()){
 if(!session||session.finalized||session.end)return null;
 return (session.liveConfirmations||[]).find(x=>x.state==='pending'&&now-x.createdAt<TTL)||null;
}
function offer(session,raw,rows,now=Date.now()){
 if(!raw||session.finalized||session.end||visible(session,now))return null;
 if(!['action','conflict','blocker'].includes(raw.impact))return null;
 const question=String(raw.question||'').trim(),statement=String(raw.statement||'').trim();
 if(!question||question.length>180||!statement||statement.length>500)return null;
 const valid=new Map((rows||[]).map(x=>[x.id,x]));
 const refs=[...new Set(Array.isArray(raw.sourceIds)?raw.sourceIds:[])].filter(id=>valid.has(id)).slice(0,4);
 const quote=String(raw.quote||'').trim(),whyNow=String(raw.whyNow||'').trim();
 if(!refs.length||quote.length<6||quote.length>500||!refs.some(id=>String(valid.get(id).text||'').includes(quote))||whyNow.length<12||whyNow.length>300||/^(信息很重要|需要确认|重要决定|请确认)[。！!]*$/.test(whyNow))return null;
 const key=crypto.createHash('sha256').update(statement.replace(/\s+/g,'')).digest('hex');
 const trace=session.liveConfirmations||(session.liveConfirmations=[]);
 if(trace.some(x=>x.key===key)||trace.some(x=>now-x.createdAt<COOLDOWN))return null;
 const previousStates=trace.map(x=>x.state);
 for(const x of trace)if(x.state==='pending')x.state='expired';
 const item={id:crypto.randomUUID(),key,question,statement,impact:raw.impact,quote,whyNow,sourceRefs:refs.map(id=>({segId:id,text:String(valid.get(id).text||'').slice(0,600),at:valid.get(id).at??valid.get(id).t??null,speaker:valid.get(id).speaker||''})),state:'pending',createdAt:now};
 trace.push(item);if(session.checkpoint?.(false,{force:true})===false){trace.pop();trace.forEach((x,i)=>x.state=previousStates[i]);return null;}session.broadcast?.({type:'live-confirmation',confirmation:item});return item;
}
function respond(session,itemId,action,{dataDir,text='',now=Date.now()}={}){
 if(!['confirm','correct','later'].includes(action))throw Error('invalid confirmation action');
 const item=session?.liveConfirmations?.find(x=>x.id===itemId);
 if(!item)throw Error('confirmation not found');
 if(item.state!=='pending'){if(item.responseAction===action&&(action!=='correct'||item.response===String(text).trim()))return item;const e=Error('这条判断已处理，请刷新');e.status=409;throw e;}
 if(now-item.createdAt>=TTL||session.finalized||session.end){const e=Error('讨论已变化，请重新确认');e.status=409;throw e;}
 if(action==='correct'&&(!String(text).trim()||String(text).length>2000))throw Error('请写下你的纠正');
 const response=action==='confirm'?item.statement:action==='correct'?String(text).trim():'';
 const before={...item};
 const owner=require('./owner-tracking').loadOwnerProfile(dataDir);
 const apply=()=>{
  Object.assign(item,{state:action==='later'?'deferred':action==='correct'?'corrected':'confirmed',response,responseAction:action,respondedAt:now,actor:owner.displayName,actorId:owner.id});
  if(session.checkpoint?.(false,{force:true})===false)throw Error('确认记录保存失败，请重试');
 };
 try{
  if(action==='later')apply();
  else{
   const mem=require('./memory'),db=mem.open(dataDir);if(!db)throw Error('确认记忆暂不可用，内容未确认');
   mem.inTx(db,()=>{
    const cardId='live-'+item.id;
    let card=db.prepare('SELECT * FROM cards WHERE id=?').get(cardId);
    if(!card)card=mem.putCard(db,{id:cardId,kind:'decision',text:response,state:'active',project:session.projectId||'',meeting_id:session.id,meeting_title:session.title||'',source_refs:[...item.sourceRefs,{type:'user-confirmation',actorId:owner.id,actor:owner.displayName,at:new Date(now).toISOString(),action}],source_type:'user',speaker:owner.displayName,confirmed:1,human_edited:1,needs_review:0,confidence:1,change_reason:owner.displayName+' 在会中'+(action==='correct'?'纠正并确认':'确认')});
    if(!card)throw Error('确认保存失败');item.memoryId=cardId;apply();
   });
  }
 }catch(e){for(const key of Object.keys(item))delete item[key];Object.assign(item,before);session.checkpoint?.(false,{force:true});throw e;}
 session.broadcast?.({type:'live-confirmation',confirmation:item});return item;
}
const prompt='\n可选字段 confirmation：仅在有具体来源、重要选择确实阻塞下一步时提出，最多一条。普通摘要、建议、记忆候选和已明确要求制作的草稿不问。没有具体冲突/取舍就省略。格式 {"question":"具体询问用户的一句话","statement":"确认按钮代表同意的完整决定","impact":"action|conflict|blocker","whyNow":"具体说明未回答会阻塞什么行动或哪个重要冲突","quote":"本轮转写中的准确原话","sourceIds":["本轮来源句子id"]}。这是待确认的 AI 提案，模型的自评置信度不能证明它值得打扰，更不能自称已确认。';
module.exports={visible,offer,respond,prompt};
