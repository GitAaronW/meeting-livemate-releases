'use strict';
// 服务端签发的待确认动作。客户端只拿随机 id，不能改工具名或参数。
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const journal = require('./session-journal');
const TTL_MS = 30 * 60 * 1000;
const okId = v => /^a-[0-9a-f]{24}$/.test(String(v || ''));

function fileOf(dataDir, id) { return path.join(dataDir, 'state', 'agent-actions', id + '.json'); }
function stage(dataDir, value) {
  if (!dataDir || !value || !value.proposal) throw Error('待确认动作不完整');
  const id = 'a-' + crypto.randomBytes(12).toString('hex'), now = Date.now();
  const doc = { id, createdAt: now, expiresAt: now + TTL_MS, sessionId: String(value.sessionId || '').slice(0, 80),
    caller: String(value.caller || 'ui').slice(0, 40), summary: String(value.summary || '').slice(0, 1000), proposal: value.proposal };
  journal.write(fileOf(dataDir, id), doc);
  return doc;
}
function read(dataDir, id) {
  if (!okId(id)) return null;
  const doc = journal.read(fileOf(dataDir, id));
  if (!doc || doc.id !== id || Number(doc.expiresAt) < Date.now()) return null;
  return doc;
}
module.exports = { stage, read, okId, fileOf, TTL_MS };
