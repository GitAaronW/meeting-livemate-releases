'use strict';
// Secondary credentials are capture/read credentials, never owner credentials.
const CAPTURE = new Set(['', '/asr-relay', '/tinghuitai'].flatMap(prefix => ['session', 'audio', 'assets'].map(name => prefix+'/'+name)));
function writeAccess({ method, pathname, authed, owner, view }) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(method)) return null;
  if (!authed) return { status: 401, error: '请连接 Mac / Unauthorized' };
  if (view || (!owner && !CAPTURE.has(pathname))) {
    return { status: 403, error: '此操作需要本机或主口令，查看链接与录音口令不能执行 / Owner access required' };
  }
  return null;
}
module.exports = { writeAccess };
