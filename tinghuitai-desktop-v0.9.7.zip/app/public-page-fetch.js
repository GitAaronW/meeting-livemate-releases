'use strict';
// Unauthenticated title lookup only. Resolve every address, then pin the TLS
// connection to one validated address; never ask DNS again during connection.
const dns = require('dns').promises, https = require('https'), net = require('net');
const denied = new net.BlockList();
for (const [ip, bits] of [['0.0.0.0',8],['10.0.0.0',8],['100.64.0.0',10],['127.0.0.0',8],['169.254.0.0',16],['172.16.0.0',12],['192.0.0.0',24],['192.0.2.0',24],['192.88.99.0',24],['192.168.0.0',16],['198.18.0.0',15],['198.51.100.0',24],['203.0.113.0',24],['224.0.0.0',4],['240.0.0.0',4]]) denied.addSubnet(ip,bits,'ipv4');
const v6Global = new net.BlockList(), v6Denied = new net.BlockList();
v6Global.addSubnet('2000::',3,'ipv6');
for (const [ip,bits] of [['2001::',23],['2001:db8::',32],['2002::',16],['3fff::',20]]) v6Denied.addSubnet(ip,bits,'ipv6');
function publicAddress(ip) {
  const family = net.isIP(ip);
  return family===4 ? !denied.check(ip,'ipv4') : family===6 && v6Global.check(ip,'ipv6') && !v6Denied.check(ip,'ipv6');
}
function publicUrl(value) {
  try {
    const u = new URL(value), host = u.hostname.replace(/^\[|\]$/g,'');
    if (u.protocol!=='https:' || u.username || u.password || (u.port && u.port!=='443') || /(^localhost$|\.(local|internal|lan)$)/i.test(host)) return null;
    if (net.isIP(host) && !publicAddress(host)) return null;
    return u;
  } catch { return null; }
}
function withAbort(promise, signal) {
  if (!signal) return promise;
  if (signal.aborted) return Promise.reject(Error('Aborted'));
  let abort;
  return Promise.race([promise,new Promise((_,reject)=>{abort=()=>reject(Error('Aborted'));signal.addEventListener('abort',abort,{once:true});})]).finally(()=>signal.removeEventListener('abort',abort));
}
function create({lookup=(host,opts)=>dns.lookup(host,opts), request=https.request, cap=300000}={}) {
  return async function fetchPublic(value, {signal, headers={}}={}) {
    const u=publicUrl(value);if(!u)throw Error('Not a public HTTPS URL');
    const host=u.hostname.replace(/^\[|\]$/g,''), literal=net.isIP(host);
    const addresses=literal?[{address:host,family:literal}]:await withAbort(lookup(host,{all:true,verbatim:true}),signal);
    if(!Array.isArray(addresses)||!addresses.length||addresses.some(a=>!publicAddress(a.address)))throw Error('DNS contains a non-public address');
    if(signal?.aborted)throw Error('Aborted');
    const pinned=addresses[0];
    return new Promise((resolve,reject)=>{
      let req,done=false;
      const finish=(err,value)=>{if(done)return;done=true;signal?.removeEventListener('abort',abort);err?reject(err):resolve(value);};
      const abort=()=>{req?.destroy(Error('Aborted'));finish(Error('Aborted'));};
      signal?.addEventListener('abort',abort,{once:true});
      try {
        req=request(u,{method:'GET',agent:false,headers:{accept:'text/html,application/xhtml+xml','user-agent':'Tinghuitai title lookup','accept-encoding':'identity'},
          servername:literal?undefined:host,
          lookup:(_hostname,opts,callback)=>opts?.all?callback(null,[pinned]):callback(null,pinned.address,pinned.family)},res=>{
          const response=bytes=>({status:res.statusCode,ok:res.statusCode>=200&&res.statusCode<300,headers:{get:name=>res.headers[name.toLowerCase()]||null},text:async()=>bytes.toString('utf8')});
          const type=String(res.headers['content-type']||'');
          if(res.statusCode<200||res.statusCode>=300||(type&&!/html|xml|text\/plain/i.test(type))){finish(null,response(Buffer.alloc(0)));res.destroy();return;}
          const chunks=[];let size=0;
          res.on('data',chunk=>{const b=Buffer.from(chunk),remaining=cap-size;chunks.push(b.subarray(0,remaining));size+=Math.min(b.length,remaining);if(size>=cap){finish(null,response(Buffer.concat(chunks)));res.destroy();}});
          res.on('end',()=>finish(null,response(Buffer.concat(chunks))));
          res.on('error',err=>finish(err));res.on('aborted',()=>finish(Error('Response interrupted')));
        });
        req.on('error',err=>finish(err));req.setTimeout(5000,abort);req.end();
      } catch(e){req?.destroy();finish(e);}
    });
  };
}
module.exports={create,fetch:create(),publicAddress,publicUrl};
