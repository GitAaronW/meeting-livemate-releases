'use strict';
const fs=require('fs'),path=require('path'),os=require('os');
const {execFile,execFileSync,spawn}=require('child_process');

function localUrl({port=47823,sessionId='',setup=false}={}){
  if(!Number.isInteger(Number(port))||Number(port)<1||Number(port)>65535)throw Error('invalid_port');
  if(typeof sessionId!=='string'||(sessionId&&!/^[\w-]{1,100}$/.test(sessionId)))throw Error('invalid_meeting_id');
  return `http://127.0.0.1:${port}/tinghuitai/${setup?'setup.html':'index.html'}${sessionId?'?id='+encodeURIComponent(sessionId):''}`;
}
function findApp(port,{roots=['/Applications',path.join(os.homedir(),'Applications'),path.join(os.homedir(),'Applications','Chrome Apps.localized')],readPlist}={}){
  readPlist ||= file=>JSON.parse(execFileSync('/usr/bin/plutil',['-convert','json','-o','-',file],{encoding:'utf8',timeout:2000}));
  for(const root of roots){let names;try{names=fs.readdirSync(root);}catch{continue;}
    for(const name of names.filter(x=>x.endsWith('.app'))){try{
      const info=readPlist(path.join(root,name,'Contents','Info.plist'));
      const u=new URL(info.CrAppModeShortcutURL);
      if(u.origin!==`http://127.0.0.1:${port}`||!u.pathname.startsWith('/tinghuitai/')||!/^[a-p]{32}$/.test(info.CrAppModeShortcutID||''))continue;
      return {appId:info.CrAppModeShortcutID};
    }catch{}}
  }return null;
}
function launchSpec(options={},env={}){
  const url=localUrl(options),port=Number(options.port||47823),platform=env.platform||process.platform;
  if(platform!=='darwin')throw Error('desktop_open_mac_only');
  const chrome=env.chrome||'/Applications/Google Chrome.app';
  const exists=env.exists||fs.existsSync;
  if(!exists(chrome))return {mode:'browser',url,command:'/usr/bin/open',args:[url]};
  const app=(env.findApp||findApp)(port);
  // Chromium's app shortcuts switch preserves the installed app's identity and
  // overrides its launch URL. No profile, app ID or user name is copied between users.
  // `open -a Chrome --args` drops the switches when Chrome is already running.
  // The executable forwards them through Chromium's existing process singleton.
  return {mode:app?'installed-app':'app-window',url,command:path.join(chrome,'Contents/MacOS/Google Chrome'),args:app?['--app-id='+app.appId,'--app-launch-url-for-shortcuts-menu-item='+url]:['--app='+url]};
}
async function openMain(options={},env={}){
  const spec=launchSpec(options,env);
  if(spec.mode==='browser')await new Promise((resolve,reject)=>(env.execFile||execFile)(spec.command,spec.args,{timeout:6000},e=>e?reject(e):resolve()));
  else await new Promise((resolve,reject)=>{const child=(env.spawn||spawn)(spec.command,spec.args,{detached:true,stdio:'ignore'});child.once('error',reject);child.once('spawn',()=>{child.unref();resolve();});});
  return {mode:spec.mode,url:spec.url};
}
module.exports={localUrl,findApp,launchSpec,openMain};
