'use strict';
// Board-specific proposal binding. Actual writes stay in local-agent/tools.
const {proposalOf}=require('./local-agent'),{hash}=require('./send-gate');
const SIGN='— 由 Meeting LiveMate 协助发送。';
function identity(dataDir, provider) {
 const p=require('./owner-tracking').loadOwnerProfile(dataDir);
 const name=p.displayName==='我'?'':p.displayName;
 const ai=typeof provider==='string'?provider.replace(/[\r\n\x00-\x1f<>]/g,'').trim().slice(0,80):'';
 return {version:1,ownerId:p.id,name,ai:ai&&ai!=='unknown'?ai:'Meeting LiveMate'};
}
function validateIdentity(job,dataDir) {
 if(!['lark.message.send','slack.message.send'].includes(job.pendingProposal?.name))return;
 const current=identity(dataDir), saved=job.attribution;
 if(!saved||saved.version!==1||saved.ownerId!==current.ownerId||saved.name!==current.name){
  const e=Error('发送身份已更新，请重新生成并核对消息 / Sender identity changed; review a new draft');e.status=409;throw e;
 }
}
function fingerprint(source,moduleId){const m=source?.board?.modules.find(m=>m.id===moduleId);return hash([source?.projectManual?source.projectId||'':'',moduleId?m||null:source?.board||{modules:[]}]);}
function seal(proposal, attribution){
 const p=proposalOf({action:proposal});if(!p)throw Error('动作参数无效 / Invalid action parameters');
 if(['lark.message.send','slack.message.send'].includes(p.name)){
  const sign=attribution?`— 由 ${attribution.ai}${attribution.name?' 代 '+attribution.name+' ':' 协助'}发送。`:SIGN;
  // Replace only a trailing generated attribution, never names in the message body.
  p.args.text=p.args.text.replace(/(?:\n\s*)?— 由 [^\r\n]*?(?:发送。?|代回。?)\s*$/u,'').trimEnd()+'\n\n'+sign;
  const checked=proposalOf({action:p});if(!checked)throw Error('消息加署名后过长，请缩短 / Shorten the message to include its signature');return checked;
 }
 return p;
}
function safeUrl(value){try{const u=new URL(value);return ['https:','http:'].includes(u.protocol)&&!u.username&&!u.password?u.href:'';}catch{return '';}}
function result(out,lang='zh'){
 const d=out?.result?.data||{},url=safeUrl(d.url);
 const ok=out?.ok===true&&out?.result?.ok===true&&out?.receipt?.status==='sent';
 return {ok,uncertain:!!out?.uncertain||!!(out?.ok&&!ok),error:out?.error||out?.reason||'',
  text:ok?(lang==='en'?'Action completed':'已执行'):out?.text||(lang==='en'?'Check the destination; no successful receipt was received':'未收到成功回执，请核对对方记录'),url:ok?url:'',note:typeof d.note==='string'?d.note.slice(0,2000):''};
}
module.exports={fingerprint,seal,safeUrl,result,SIGN,identity,validateIdentity};
