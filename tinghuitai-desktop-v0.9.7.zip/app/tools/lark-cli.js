'use strict';
// 全仓只有这一处真正拼 lark-cli 的命令行。工具登记表里的飞书工具和找人都从这里走。
// 搬自 app/actions.js（2026-09-22）：那边原来自己跑命令，现在改成调登记表。
const fs = require('fs'), path = require('path'), { execFile } = require('child_process');

function binPath() { return process.env.THT_LARK_CLI || 'lark-cli'; }
// 装没装：绝对路径直接看文件，裸名字在 PATH 里找一遍。找不到就让 available 说清楚缺什么。
function binInstalled() {
  const b = binPath();
  if (b.includes('/')) { try { fs.accessSync(b, fs.constants.X_OK); return true; } catch (e) { return false; } }
  for (const dir of String(process.env.PATH || '').split(':')) {
    if (!dir) continue;
    try { fs.accessSync(path.join(dir, b), fs.constants.X_OK); return true; } catch (e) {}
  }
  return false;
}
const larkAvailable = () => (binInstalled() ? { ok: true } : { ok: false, reason: '未接：本机找不到 lark-cli（装好并 lark-cli auth login 之后自动可用）' });

const clip = (s, n) => String(s == null ? '' : s).slice(0, n);

function structuredFailure(error) {
  const raw = typeof error === 'string' ? error : JSON.stringify(error || {});
  const code = String(error && typeof error === 'object' ? (error.code || error.status || error.statusCode || '') : '').toLowerCase();
  const text = (code + ' ' + raw).toLowerCase();
  const transport = /econnreset|econnrefused|etimedout|ehostunreach|enetunreach|epipe|socket\s*hang\s*up|network\s*error|timed?\s*out|timeout/.test(text);
  if (transport) return { definite: false, message: raw };
  const status = Number(code);
  const remoteReject = (status >= 400 && status < 500)
    || /permission|forbidden|unauthori[sz]ed|access denied|invalid|bad request|not found|rejected|拒绝|无权限|没权限|参数|不存在|未授权/.test(text);
  return { definite: remoteReject, message: raw };
}

// 跑一条命令，只认 JSON 输出。失败一律返回 {ok:false,error}，不抛。
// 写命令的关键边界：进程一旦可能已经启动，网络断开、普通非零退出和坏回包都不能证明远端没写入。
// 只有本机明确无法启动进程，或远端以结构化 JSON 明确拒绝，才允许上层清掉 pending 收据。
function runCli(args, { execImpl = execFile, log = () => {}, timeout = 60000 } = {}) {
  return new Promise(resolve => {
    execImpl(binPath(), args, { timeout, maxBuffer: 8e6 }, (err, out, errOut) => {
      let j = null; try { j = JSON.parse(String(out).trim()); } catch (e) {}
      if (j && (j.ok === false || j.error)) {
        const failure = structuredFailure(j.error);
        return resolve({ ok: false, error: clip((j.error && (j.error.message || j.error)) || '飞书拒绝了这次请求', 200), ...(!failure.definite ? { uncertain: true } : {}) });
      }
      if (err) {
        const code = String(err.code == null ? '' : err.code).toUpperCase();
        const preExecutionFailure = ['ENOENT', 'EACCES', 'ENOTDIR', 'EPERM'].includes(code);
        return resolve({ ok: false, error: clip(String((errOut || err.message || '')), 200) || 'lark-cli 没跑起来', uncertain: !preExecutionFailure });
      }
      if (!j) return resolve({ ok: false, error: 'lark-cli 返回的不是 JSON', uncertain: true });
      resolve({ ok: true, json: j });
    });
    log('lark-cli ' + args.slice(0, 2).join(' '));
  });
}

const norm = s => String(s || '').normalize('NFKC').toLowerCase().replace(/[\s\p{P}\p{S}]/gu, '');

// 名字 → open_id。解析不到的原样回给调用方，写进说明里，不硬发。
// 真实返回是一个扁平的 users[]：{open_id, localized_name, matched_query}（2026-09-22 实测）。
async function resolveIds(names, opts = {}) {
  const list = (names || []).filter(Boolean);
  if (!list.length) return { ok: true, ids: [], missing: [], users: [] };
  const r = await runCli(['contact', '+search-user', '--queries', list.join(','), '--as', 'user', '--exclude-external-users', '--format', 'json'], opts);
  if (!r.ok) return { ok: false, error: r.error, ids: [], missing: list, users: [] };
  const users = [];
  const walk = v => {
    if (!v || typeof v !== 'object') return;
    if (typeof v.open_id === 'string' && v.open_id) users.push({ id: v.open_id, name: String(v.localized_name || v.name || v.en_name || ''), matched: String(v.matched_query || '') });
    for (const x of Object.values(v)) walk(x);
  };
  walk(r.json);
  const ids = [], missing = [], hits = [];
  for (const n of list) {
    // 名字全等的那一个；没有全等的，这个关键词只搜出一个人才认。搜「Alex」出来两个 Alex 就不猜——
    // 邀请发错人是真外发，宁可写进 missing 让他自己补。
    const exact = users.filter(u => norm(u.name) === norm(n));
    const byQuery = users.filter(u => norm(u.matched) === norm(n));
    const hit = exact.length === 1 ? exact[0] : (!exact.length && byQuery.length === 1 ? byQuery[0] : null);
    if (hit && hit.id) { if (!ids.includes(hit.id)) ids.push(hit.id); hits.push({ query: n, name: hit.name, openId: hit.id }); }
    else missing.push(n);
  }
  return { ok: true, ids, missing, users: hits };
}

// 文档 token → 可打开的链接与标题。只读；域名由 lark-cli 回读（drive +inspect 的 data.url），不在代码里手拼（需求单 §3）。
// 失败返回 {ok:false,error}，调用方自己决定退路（例如只写来源名不附链接）。
async function docInspect(token, opts = {}) {
  const t = String(token || '').trim();
  if (!/^[A-Za-z0-9]{10,64}$/.test(t)) return { ok: false, error: '文档 token 不像样' };
  const r = await runCli(['drive', '+inspect', '--url', t, '--type', 'docx', '--as', 'user', '--format', 'json'], { timeout: 12000, ...opts });
  if (!r.ok) return { ok: false, error: r.error, uncertain: false };
  const d = (r.json && r.json.data) || {};
  const url = String(d.url || '').trim();
  if (!/^https:\/\//.test(url)) return { ok: false, error: 'lark-cli 没回链接' };
  return { ok: true, url, title: clip(d.title || '', 120), token: String(d.token || t) };
}

// 建一条飞书任务（洞察卡「定日期」用，批 3）。写类：调用方自己过确认门禁再来。返回 {ok,url,id} 或 {ok:false,error,uncertain}
async function taskCreate({ summary, description = '', assignee = '', due = '' }, opts = {}) {
  const s = clip(String(summary || '').trim(), 120);
  if (!s) return { ok: false, error: '任务标题是空的' };
  const a = ['task', '+create', '--summary', s];
  if (description) a.push('--description', clip(description, 2000));
  if (/^(?:ou_|cli_)[A-Za-z0-9]{1,64}$/.test(assignee)) a.push('--assignee', assignee);
  // 裸 YYYY-MM-DD 会被 1.0.96 发成本地 0 点的 is_all_day，飞书按 UTC 日归一后早一天（09-22 e2e：传 09-29 回读 09-28）。
  // 发成当天 18:00 Asia/Shanghai 的 ISO 时刻，日期不会漂；date: 前缀 1.0.96 解析失败，不用。
  if (/^\d{4}-\d{2}-\d{2}$/.test(due)) a.push('--due', due + 'T18:00:00+08:00');
  a.push('--as', 'user', '--format', 'json');
  const r = await runCli(a, { timeout: 30000, ...opts });
  if (!r.ok) return { ok: false, error: r.error, uncertain: !!r.uncertain };
  const dig = (o, ...ps) => { for (const p of ps) { const v = p.split('.').reduce((x, k) => (x && typeof x === 'object' ? x[k] : undefined), o); if (v != null && v !== '') return String(v); } return ''; };
  const url = dig(r.json, 'data.task.url', 'data.url'), id = dig(r.json, 'data.task.guid', 'data.task.task_id', 'data.guid');
  // 命令成功但回包里没有链接也没有编号：任务可能建了也可能没建，按 uncertain 报失败（门禁要 retryConfirmed 才重试），不把空链接当成功写进卡片（Codex 8b2bdefd 初审 F4）
  if (!url && !id) return { ok: false, error: '飞书回包里没有任务链接和编号', uncertain: true };
  return { ok: true, url, id };
}

// 私聊发一条 markdown（交给某人 handoff 用，2026-09-24）。写类：调用方自己过确认门禁再来。
async function messageSend({ openId, markdown }, opts = {}) {
  if (!/^ou_[A-Za-z0-9]{1,64}$/.test(String(openId || ''))) return { ok: false, error: '收件人 open_id 不像样' };
  const md = clip(String(markdown || '').trim(), 4000);
  if (!md) return { ok: false, error: '消息是空的' };
  const r = await runCli(['im', '+messages-send', '--user-id', openId, '--markdown', md, '--as', 'user', '--format', 'json'], { timeout: 30000, ...opts });
  if (!r.ok) return { ok: false, error: r.error, uncertain: !!r.uncertain };
  const d = (r.json && r.json.data) || {};
  return { ok: true, messageId: String(d.message_id || (d.message && d.message.message_id) || '') };
}

// 私聊发一张交互卡片（会后自动推送给本人用，2026-09-25）。card = 卡片 JSON 对象；idem = 飞书侧幂等键（≤50 字）。
async function cardSend({ openId, card, idem = '' }, opts = {}) {
  if (!/^ou_[A-Za-z0-9]{1,64}$/.test(String(openId || ''))) return { ok: false, error: '收件人 open_id 不像样' };
  if (!card || typeof card !== 'object') return { ok: false, error: '卡片是空的' };
  const args = ['im', '+messages-send', '--user-id', openId, '--msg-type', 'interactive', '--content', JSON.stringify(card), '--as', 'user', '--format', 'json'];
  if (idem) args.push('--idempotency-key', clip(String(idem), 50));
  const r = await runCli(args, { timeout: 30000, ...opts });
  if (!r.ok) return { ok: false, error: r.error, uncertain: !!r.uncertain };
  const d = (r.json && r.json.data) || {};
  return { ok: true, messageId: String(d.message_id || (d.message && d.message.message_id) || '') };
}

// 现在 lark-cli 登录的是谁（open_id）。拿不到回 ''。
async function selfOpenId(opts = {}) {
  const r = await runCli(['contact', '+get-user', '--as', 'user', '--format', 'json'], { timeout: 25000, ...opts });
  const u = r.ok && r.json && r.json.data && r.json.data.user;
  return (u && u.open_id) ? String(u.open_id) : '';
}

// 新建一份 XML 文档（本人身份，天然 owner）。返回 {ok,token,url}。
async function docCreate({ title, content }, opts = {}) {
  const t = clip(String(title || '').trim(), 120);
  if (!t) return { ok: false, error: '文档标题是空的' };
  const r = await runCli(['docs', '+create', '--title', t, '--content', String(content || ''), '--doc-format', 'xml', '--as', 'user', '--format', 'json'], { timeout: 30000, ...opts });
  if (!r.ok) return { ok: false, error: r.error, uncertain: !!r.uncertain };
  const doc = ((r.json && r.json.data) || {}).document || {};
  const token = String(doc.document_id || ''), url = String(doc.url || '');
  if (!token) return { ok: false, error: '飞书回包里没有文档 token', uncertain: true };
  return { ok: true, token, url };
}

// 在文档末尾追加一段 XML（docs +update --command append）。返回 {ok,revision}。
async function docAppend({ token, content }, opts = {}) {
  const t = String(token || '').trim();
  if (!/^[A-Za-z0-9]{10,64}$/.test(t)) return { ok: false, error: '文档 token 不像样' };
  const c = String(content || '').trim();
  if (!c) return { ok: false, error: '要追加的内容是空的' };
  const r = await runCli(['docs', '+update', '--doc', t, '--command', 'append', '--content', c, '--doc-format', 'xml', '--as', 'user', '--format', 'json'], { timeout: 30000, ...opts });
  if (!r.ok) return { ok: false, error: r.error, uncertain: !!r.uncertain };
  const doc = ((r.json && r.json.data) || {}).document || {};
  return { ok: true, revision: doc.revision_id == null ? '' : String(doc.revision_id) };
}

// 读飞书文档正文（markdown），主题差异拿它当基线（09-25 审核：原来基线是空的，会写出重复内容）。只读。
async function docFetchMarkdown(token, opts = {}) {
  const t = String(token || '').trim();
  if (!/^[A-Za-z0-9]{10,64}$/.test(t)) return { ok: false, error: '文档 token 不像样' };
  const r = await runCli(['docs', '+fetch', '--doc', t, '--doc-format', 'markdown', '--as', 'user', '--format', 'json'], { timeout: 30000, ...opts });
  if (!r.ok) return { ok: false, error: r.error };
  const doc = ((r.json && r.json.data) || {}).document || {};
  return { ok: true, markdown: String(doc.content || '') };
}

// 主题文档写回：先让 docs parser 校验 XML，再追加。同一条的幂等由调用方 send-gate 包住整个函数，
// 因此已有收据时 parse 和 update 都不会重复调用。
async function docValidateAppend({ token, content }, opts = {}) {
  const t = String(token || '').trim();
  if (!/^[A-Za-z0-9]{10,64}$/.test(t)) return { ok: false, error: '文档 token 不像样' };
  const c = String(content || '').trim();
  if (!c) return { ok: false, error: '要追加的内容是空的' };
  const parsed = await runCli(['docs', '+script', '--command', 'parse', '--content', c, '--as', 'user', '--format', 'json'], { timeout: 30000, ...opts });
  if (!parsed.ok) return { ok: false, error: parsed.error, uncertain: false };
  const assessment = parsed.json && parsed.json.data && parsed.json.data.assessment;
  if (!assessment || assessment.status !== 'passed') return { ok: false, error: 'XML 校验未通过', uncertain: false };
  return docAppend({ token: t, content: c }, opts);
}

module.exports = { binPath, binInstalled, larkAvailable, runCli, structuredFailure, resolveIds, docInspect, taskCreate, messageSend, cardSend, selfOpenId, docCreate, docAppend, docValidateAppend, docFetchMarkdown, clip, norm };
