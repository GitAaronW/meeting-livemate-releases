'use strict';
// Read-only inbound adapters. The current user's credentials define the scope.
const slack = require('./slack'), lark = require('./lark-cli');
const check = r => { if (!r.ok) throw Object.assign(Error(r.error || '读取失败'),{retryAfter:r.retryAfter,status:r.status}); return r.data || r.json?.data || r.json; };
const localTime=v=>{const d=new Date(v),offset=-d.getTimezoneOffset(),sign=offset>=0?'+':'-',pad=n=>String(n).padStart(2,'0');return new Date(d.getTime()+offset*60000).toISOString().slice(0,19)+sign+pad(Math.floor(Math.abs(offset)/60))+':'+pad(Math.abs(offset)%60);};
const seconds = v => { const n=Number(v); return Number.isFinite(n)?(n>1e12?n/1000:n):0; };
function text(v) {
 if(typeof v==='string'){try{return text(JSON.parse(v));}catch{return v;}}
 if(Array.isArray(v))return v.map(text).join('\n');
 if(v&&typeof v==='object'){if(v.text)return String(v.text);return Object.entries(v).filter(([k])=>!['image_key','file_key','user_id','style'].includes(k)).map(([,x])=>text(x)).join(' ');}
 return '';
}
function slackThread(m){
 if(m.thread_ts)return m.thread_ts;
 try{const u=new URL(m.permalink);if(u.protocol==='https:'&&/(^|\.)slack\.com$/.test(u.hostname)&&/^\d+\.\d+$/.test(u.searchParams.get('thread_ts')||''))return u.searchParams.get('thread_ts');}catch{}
 return m.ts;
}
function slackMessage(m,account,flow){return {provider:'slack',account:account.key,id:m.ts,channel:m.channel?.id||m.channel,channelName:m.channel?.name||m.channelName||'',thread:slackThread(m),
 sender:m.user||'',senderType:m.bot_id||m.subtype==='bot_message'?'bot':'user',deleted:!!m.deleted,scope:flow,
 addressed:flow==='dm'||String(m.text||'').includes('<@'+account.userId+'>'),at:seconds(m.ts)*1000,
 version:String(m.edited?.ts||m.ts),body:String(m.text||'').slice(0,12000),url:m.permalink||'',userId:account.userId};}
function larkTime(v){const n=seconds(v);if(n)return n*1000;const d=Date.parse(String(v||'').replace(' ','T'));return Number.isFinite(d)?d:0;}
function larkMessage(m,account,flow){return {provider:'lark',account:account.key,id:m.message_id,channel:m.chat_id,thread:m.thread_id||m.message_id,
 sender:m.sender?.id||m.sender?.open_id||'',senderType:m.sender?.sender_type||m.sender?.type||'user',deleted:!!m.deleted,scope:flow,
 addressed:flow==='dm'||(m.mentions||[]).some(x=>[x.id,x.id?.open_id,x.open_id].includes(account.userId)),at:larkTime(m.create_time),
 version:String(m.update_time||m.create_time)+'|'+String(m.updated||''),body:text(m.content||m.body?.content).slice(0,12000),url:m.url||m.message_app_link||'',userId:account.userId};}
function adapters({env,slackCall=slack.call,larkRun=lark.runCli}={}) {
 const sc=async(method,args)=>check(await slackCall(env().SLACK_USER_TOKEN,method,args));
 const lc=async(args)=>check(await larkRun(args.concat(['--as','user','--format','json']),{timeout:30000}));
 // search:read is the supported existing user grant. Some installations lack
 // conversations.replies scopes; search results retain exact thread permalinks.
 async function slackThreadRead(channel,thread,hint={}){
  try{const r=await sc('conversations.replies',{channel,ts:thread,limit:50});if(!Array.isArray(r.messages))throw Error('Slack 线程返回不完整');return {...r,readNote:''};}
  catch(e){if(!/(?:^|：)missing_scope$/.test(e.message))throw e;}
  // Slack search in: expects a channel name, not a conversation ID. Discover
  // the name from an authenticated, exact-thread result before narrowing.
  const name=v=>/^[a-z0-9_-]{1,100}$/.test(v||'')?v:'';
  let channelName=name(hint.channelName),recent=false,page=1;
  const day=new Date(Number(thread)*1000).toISOString().slice(0,10),since=new Date((Number(thread)-86400)*1000).toISOString().slice(0,10),found=new Map();
  const addressed=hint.scope==='mention'&&/^[a-z0-9]+$/i.test(hint.userId||'')?'<@'+hint.userId+'> ':'';
  for(let request=0;request<3;request++){
   const scope=channelName?'in:'+channelName+' ':recent?'':addressed;
   const r=await sc('search.messages',{query:scope+(recent?'after:'+since:'on:'+day),count:100,page,sort:'timestamp',sort_dir:'desc'}),p=r.messages;
   if(!p||!Array.isArray(p.matches))throw Error('Slack 搜索返回不完整');
   for(const m of p.matches)if((m.channel?.id||m.channel)===channel&&slackThread(m)===thread){found.set(m.ts,m);if(!channelName)channelName=name(m.channel?.name);}
   const pages=Number(p.pagination?.page_count||p.paging?.pages||1);
   if(!recent&&(channelName||found.size)){recent=true;page=1;}
   else if(page>=pages)break;else page++;
  }
  if(!found.size)throw Error('Slack 当前只能搜索，未找到这条线程的可读消息');
  return {messages:[...found.values()].sort((a,b)=>Number(a.ts)-Number(b.ts)),has_more:true,readNote:'Slack 使用当前账号的搜索权限读取；线程可能不完整，请以原消息为准。'};
 }
 function slackSnapshot(r,channel,thread,account,scope){
  const body=r.messages.map(x=>'['+x.ts+'] '+x.user+': '+x.text).join('\n');
  return {body:body.slice(0,18000),partial:!!r.has_more||body.length>18000,readNote:r.readNote||'',snapshot:r.messages.map(x=>({...slackMessage({...x,channel},account,scope),thread}))};
 }

 return {
  slack:{async identity(){const a=await sc('auth.test',{});if(!a.user_id||!a.team_id)throw Error('Slack 用户身份不完整');return {key:a.team_id+':'+a.user_id,userId:a.user_id,name:a.user||''};},
   async page(account,flow,range){const query=(flow==='mention'?'<@'+account.userId+'>':'to:'+account.userId)+' after:'+new Date(range.since).toISOString().slice(0,10);
    const r=await sc('search.messages',{query,count:50,page:range.page||1,sort:'timestamp',sort_dir:'asc'}),p=r.messages;
    if(!p||!Array.isArray(p.matches))throw Error('Slack 搜索返回不完整');
    const messages=p.matches.map(m=>slackMessage(m,account,flow)).filter(m=>m.at>=range.since&&m.at<=range.end&&(flow!=='dm'||String(m.channel).startsWith('D')));
    return {messages,next:(Number(p.pagination?.page_count||p.paging?.pages||1)>Number(range.page||1))?Number(range.page||1)+1:null};},
   async thread(m){const r=await slackThreadRead(m.channel,m.thread,m);return slackSnapshot(r,m.channel,m.thread,{key:m.account,userId:m.userId},m.scope);},
   async seed(account,{channel,thread}){if(!/^[CDG][A-Z0-9]+$/.test(channel)||!/^\d+\.\d+$/.test(thread))throw Error('无效 Slack 线程');const r=await slackThreadRead(channel,thread,{userId:account.userId,scope:'mention'}),root=r.messages.find(x=>x.ts===thread);if(!root)throw Error('未读到原帖，不能核实指派给谁');const m=slackMessage({...root,channel,channelName:root.channel?.name},account,'mention');
    if(!m.url){const p=await sc('chat.getPermalink',{channel,message_ts:thread});m.url=p.permalink;}
    return {...m,...slackSnapshot(r,channel,thread,account,'mention')};}},
  lark:{async identity(){const r=await larkRun(['auth','status','--json'],{timeout:30000});if(!r.ok)throw Error(r.error);const a=r.json?.identities?.user;const id=a?.openId||a?.open_id;if(!id||a.available===false||a.tokenStatus==='expired')throw Error('请登录飞书的当前用户账号');return {key:(r.json?.appId||'lark')+':'+id,userId:id,name:a.userName||a.name||''};},
   async page(account,flow,range){const args=['im','+messages-search',flow==='mention'?'--is-at-me':'--chat-type',...(flow==='dm'?['p2p']:[]),'--exclude-sender-type','bot','--start',localTime(range.since),'--end',localTime(range.end),'--page-size','50','--no-reactions'];if(range.page)args.push('--page-token',String(range.page));const r=await lc(args);if(!Array.isArray(r.messages)||(r.has_more&&!r.page_token))throw Error('飞书搜索返回不完整');return {messages:r.messages.map(m=>({...larkMessage(m,account,flow),addressed:true})).filter(m=>m.at>=range.since&&m.at<=range.end),next:r.has_more?r.page_token:null};},
   async thread(m){if(!m.thread.startsWith('omt_')){
    const r=await lc(['im','+chat-messages-list','--chat-id',m.channel,'--start',localTime(m.at),'--end',localTime(Date.now()),'--page-size','50','--order','desc','--no-reactions']);
    const list=r.messages||r.items;if(!Array.isArray(list))throw Error('飞书消息返回不完整');
    const related=list.filter(x=>x.message_id===m.id||x.parent_id===m.id||x.root_id===m.id||x.thread_id===m.thread);
    const snapshot=related.map(x=>({...larkMessage({...x,chat_id:m.channel},{key:m.account,userId:m.userId},m.scope),thread:m.thread}));
    const body=related.length?related.map(x=>'['+x.message_id+'] '+(x.sender?.id||'')+': '+text(x.content||x.body?.content)).join('\n'):m.body;
    return {body:body.slice(0,18000),partial:true,readNote:'飞书普通消息仅核对最近 50 条中的原消息与明确关联回复；独立后续消息可能未关联，请以原消息为准。',snapshot};
   }const r=await lc(['im','+threads-messages-list','--thread',m.thread,'--page-size','50','--no-reactions']);const list=r.messages||r.items;if(!Array.isArray(list))throw Error('飞书线程返回不完整');const body=list.map(x=>'['+x.create_time+'] '+(x.sender?.name||x.sender?.id||'')+': '+text(x.content||x.body?.content)).join('\n');return {body:body.slice(0,18000),partial:!!r.has_more||body.length>18000,snapshot:list.map(x=>({...larkMessage({...x,chat_id:m.channel},{key:m.account,userId:m.userId},m.scope),thread:m.thread}))};}}
 };
}
module.exports={adapters,slackMessage,larkMessage,text};
