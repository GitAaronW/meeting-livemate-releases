'use strict';
const fs=require('fs'), path=require('path'), {spawn}=require('child_process');
module.exports=function create({dataDir,isLocalReq,localReqReason,active,log,updater=require('./updater'),restart}) {
  function relaunch() {
    setTimeout(()=>{
      if(active()){log('更新完成；正在录音，下次启动生效');return;}
      if(process.env.THT_SUPERVISED==='1'){log('更新完成，退出交给系统守护重启');process.exit(0);}
      try {
        const fd=fs.openSync(path.join(dataDir,'launcher.log'),'a',0o600);
        try {
          const child=spawn(process.execPath,[path.join(__dirname,'../scripts/launch.js')],{env:{...process.env,THT_NO_OPEN:'1'},detached:true,stdio:['ignore',fd,fd]});
          child.on('error',e=>log('自动重启失败 '+e.message));child.unref();
        } finally {fs.closeSync(fd);}
        log('更新完成，已触发自动重启');
      } catch(e){log('自动重启没起来 '+e.message);}
    },800);
  }
  return async function route(req,res,u,authed) {
    const p=u.pathname;
    if(!p.endsWith('/update')&&!p.endsWith('/update-rollback'))return false;
    const send=(code,value)=>{res.writeHead(code,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(value));};
    if(!authed){send(401,{ok:false,error:'unauthorized'});return true;}
    if(req.method==='GET'&&p.endsWith('/update')) {
      try {
        const r=await updater.check();
        send(200,{ok:r.ok,current:r.current,latest:r.latest,hasUpdate:r.hasUpdate,notes:r.notes,released:r.released,error:r.error,code:r.code,prev:updater.prevVersion(),prevInfo:updater.prevInfo()});
      } catch(e){send(200,{ok:false,error:String(e.message||e)});}
      return true;
    }
    if(req.method!=='POST'){send(405,{ok:false,error:'method not allowed'});return true;}
    const rollback=p.endsWith('/update-rollback'),label=rollback?'回退':'更新';
    if(!isLocalReq(req)){send(403,{ok:false,error:label+'只能在这台电脑上操作：'+localReqReason(req)});return true;}
    if(active()){send(409,{ok:false,error:'正在录音，结束本场后再'+label});return true;}
    try {
      const r=rollback?await updater.rollback(m=>log('rollback: '+m),()=>!active()):await updater.apply(m=>log('update: '+m),()=>!active());
      const changed=rollback||r.updated===true;
      log(label+' done '+JSON.stringify(r));send(200,{ok:true,...r,restarting:changed});
      if(changed)(restart||relaunch)();
    } catch(e){log(label+' fail '+e.message);send(200,{ok:false,error:String(e.message||e)});}
    return true;
  };
};
