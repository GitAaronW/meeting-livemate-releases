'use strict';
// Counts only; no message contents. Unknown input must never authorize a reload.
const TERMINAL=new Set(['completed','failed','cancelled','interrupted','preview','planned']);
function status({sessions,boardJobs,threads,hubJobs}={}){
 if(!Array.isArray(sessions)||!Array.isArray(boardJobs)||!Array.isArray(hubJobs)||!Number.isInteger(threads?.running)||threads.running<0||!Number.isInteger(threads?.queued)||threads.queued<0)return {schema:1,idle:false};
 const meetings=sessions.filter(s=>!s.finalized).length,agents=boardJobs.filter(j=>!TERMINAL.has(j?.state)).length,
  cards=threads.running+threads.queued,imports=hubJobs.filter(j=>!['completed','done','failed','error','cancelled'].includes(j?.status||j?.state)).length;
 return {schema:1,idle:meetings===0&&agents===0&&cards===0&&imports===0,meetings,agents,cards,imports};
}
module.exports={status};
