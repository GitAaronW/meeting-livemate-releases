'use strict';
const statuses = ['inbox','proposed','draft','todo','doing','blocked','submitted','done','verified','cancelled','dismissed','parked'];
function validate(current, patch) {
  const next = {...current,...patch};
  if (patch.status && !statuses.includes(patch.status)) throw Error('任务状态不正确');
  if (next.status === 'verified') {
    if (!String(next.acceptanceCriteria || '').trim()) throw Error('请填写验收标准，再标记已验证');
    if (!String(next.completionEvidence || '').trim()) throw Error('请填写完成证据：测试结果、截图或验收链接，再标记已验证');
  }
}
module.exports = {statuses, validate};
