"use strict";
const crypto = require('crypto');
const {Readable} = require('stream');
const packs = require('./context-pack');
const route = require('./meeting-board-routes');
const jobs = require('./meeting-board-jobs');

// Background and browser generation share the durable job journal and Hub CAS.
// The native feed produces small live suggestions; this pass maintains the canvas.
class Coordinator {
 constructor({context, sessions, now=Date.now, gapMs=90000, maxPerHour=30, log=()=>{}}) {
  Object.assign(this, {context, sessions, now, gapMs, maxPerHour, log});
  this.states = new Map(); this.timer = null;
 }
 fingerprint(s, ctx) {
  const source = ctx.hub.data.sources.find(x=>x.key==='session:'+s.id);
  const pack = packs.build(ctx.env?.()||{}, {purpose:'meeting-board', dataDir:ctx.dataDir,
   session:{...s, projectId:source?.projectManual ? source.projectId||'' : s.projectId||source?.projectId||''}, meetingId:s.id});
  return crypto.createHash('sha256').update(JSON.stringify([s.transcript, s.editEpoch||0,
   source?.projectManual ? source.projectId||'' : s.projectId||source?.projectId||'', s.contextSourceIds||[], pack.hash])).digest('hex');
 }
 async tick() {
  const ctx = this.context(); if (!ctx.hub) return;
  const ids = new Set(), store = jobs.get(ctx.dataDir);
  for (const s of this.sessions()) {
   if (s.finalized || s.end || s.boardAuto===false || !s.transcript?.length) continue;
   ids.add(s.id);
   if (String(s.env?.ACTIVE_INTELLIGENCE_MODE||'legacy')!=='rapid') continue;
   const state = this.states.get(s.id)||{hash:'', last:-Infinity, attempts:0};
   this.states.set(s.id, state);
   if (state.pending) continue;
   try {
    const hash = this.fingerprint(s, ctx);
    if (state.hash===hash && state.done) continue;
    const retry = state.hash===hash ? state.attempts : 0;
    if (retry>=3 || this.now()-state.last<this.gapMs*Math.max(1, 2**retry)) continue;
    const recent = store.items.filter(j=>j.meetingId===s.id && j.action==='generate');
    if (recent.some(j=>['queued','running'].includes(j.state))) continue;
    // Persisted job timestamps also enforce the bound after a service restart.
    const hour = recent.filter(j=>this.now()-Date.parse(j.created)<3600000);
    if (hour.length>=this.maxPerHour || recent.some(j=>this.now()-Date.parse(j.created)<this.gapMs)) continue;
    state.hash=hash; state.attempts=retry; state.done=false; state.last=this.now();
    const source = ctx.hub.data.sources.find(x=>x.key==='session:'+s.id);
    const request = {id:s.id, action:'generate', async:true, revision:source?.revision||0, lang:s.uiLang||'zh'};
    const input = Readable.from([JSON.stringify(request)]); input.method='POST'; input.headers={};
    let result, status;
    await route(input, {writeHead(c){status=c;}, end(body){result=JSON.parse(body);}}, new URL('/meeting-board','http://localhost'), ctx);
    if (status>=400 || !result?.job) throw Error(result?.error||'No background job');
    state.attempts=retry+1; state.pending=result.job.id;
   } catch(e) { state.last=this.now(); state.attempts++; this.log('background board '+s.id+' '+e.message); }
  }
  for (const [id, state] of this.states) {
   if (state.pending) {
    const job=store.list(id).find(j=>j.id===state.pending);
    if (job && !['queued','running'].includes(job.state)) {state.pending=''; state.done=job.state==='completed';}
   }
   if (!ids.has(id) && !state.pending) this.states.delete(id);
  }
 }
 start() { if(this.timer)return; this.timer=setInterval(()=>this.tick().catch(e=>this.log(e.message)),5000); this.timer.unref?.(); }
 close() { clearInterval(this.timer); this.timer=null; }
}
module.exports={Coordinator};
