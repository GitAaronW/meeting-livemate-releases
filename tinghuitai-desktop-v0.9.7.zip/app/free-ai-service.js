'use strict';
// Narrow, revocable trial relay. No meeting routes, tools, body logs or arbitrary upstreams.
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const llm=require('./llm');
const CONFIG=path.join(require('os').homedir(),'.claude-maint/tinghuitai-private/free-ai-service.json');
const same=(a,b)=>typeof b==='string'&&b.length>=32&&Buffer.byteLength(a)===Buffer.byteLength(b)&&crypto.timingSafeEqual(Buffer.from(a),Buffer.from(b));
function validate(j){
 if(!j||typeof j!=='object'||Array.isArray(j)||Object.keys(j).some(k=>!['model','messages','max_tokens','temperature','stream','response_format'].includes(k)))throw Error('schema');
 if(j.model!=='deepseek-chat'||(j.stream!==undefined&&j.stream!==false))throw Error('model');
 if(!Array.isArray(j.messages)||j.messages.length<1||j.messages.length>2)throw Error('messages');
 if(j.messages.at(-1)?.role!=='user'||j.messages.some((m,i)=>!m||Object.keys(m).some(k=>!['role','content'].includes(k))||typeof m.content!=='string'||(i<j.messages.length-1&&m.role!=='system')))throw Error('messages');
 if(j.messages.reduce((n,m)=>n+m.content.length,0)>48000)throw Error('length');
 if(j.max_tokens!==undefined&&(!Number.isInteger(j.max_tokens)||j.max_tokens<1||j.max_tokens>8192))throw Error('tokens');
 if(j.temperature!==undefined&&(!Number.isFinite(j.temperature)||j.temperature<0||j.temperature>2))throw Error('temperature');
 if(j.response_format!==undefined&&(Object.keys(j.response_format||{}).length!==1||j.response_format?.type!=='json_object'))throw Error('format');
 return {system:j.messages.length===2?j.messages[0].content:'',user:j.messages.at(-1).content,maxTokens:j.max_tokens||800,temperature:j.temperature??0.2,json:!!j.response_format};
}
function createService({load=()=>JSON.parse(fs.readFileSync(CONFIG,'utf8')),ask=llm.ask,timeoutMs=90000,maxConcurrent=8}={}){
 let busy=0;
 const server=http.createServer(async(req,res)=>{
  const reply=(status,j)=>{if(!res.destroyed&&!res.writableEnded){res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(j));}};
  let c;try{c=load();}catch{return reply(503,{error:{message:'Trial service is unavailable'}});}
  if(req.url==='/health'&&req.method==='GET')return reply(200,{ready:!!(c.DEEPSEEK_API_KEY&&c.FREE_AI_TOKEN),model:'deepseek-chat'});
  if(req.url!=='/chat/completions'||req.method!=='POST')return reply(404,{error:{message:'Not found'}});
  if(!same(String(req.headers.authorization||'').replace(/^Bearer /,''),c.FREE_AI_TOKEN))return reply(401,{error:{message:'Invalid trial token'}});
  if(!/^application\/json(?:;|$)/i.test(String(req.headers['content-type']||'')))return reply(415,{error:{message:'JSON required'}});
  if(busy>=maxConcurrent)return reply(503,{error:{message:'Trial service is busy; retry shortly'}});
  const controller=new AbortController();let reading=true;const timer=setTimeout(()=>{controller.abort();if(reading){reply(408,{error:{message:'Request body timed out'}});req.destroy();}},timeoutMs);
  const closed=()=>controller.abort();req.on('aborted',closed);res.on('close',closed);busy++;
  try{
   let body='',bytes=0;
   for await(const chunk of req){bytes+=Buffer.byteLength(chunk);if(bytes>196608)return reply(413,{error:{message:'Request too large'}});body+=chunk;}
   reading=false;let args;try{args=validate(JSON.parse(body));}catch{return reply(400,{error:{message:'Invalid request'}});}
   const result=await ask({DEEPSEEK_API_KEY:c.DEEPSEEK_API_KEY,LLM_BASE_URL:'https://api.deepseek.com',LLM_MODEL:'deepseek-chat'},{kind:'live',...args,signal:controller.signal,timeoutMs});
   if(controller.signal.aborted)return reply(504,{error:{message:'Trial request timed out'}});
   if(!result?.text)return reply(502,{error:{message:'Trial model unavailable; retry shortly'}});
   reply(200,{id:'trial-'+crypto.randomUUID(),object:'chat.completion',model:result.model||'deepseek-chat',choices:[{index:0,message:{role:'assistant',content:result.text},finish_reason:'stop'}],...(result.usage?{usage:{prompt_tokens:result.usage.in,completion_tokens:result.usage.out}}:{})});
  }catch{return reply(controller.signal.aborted?504:502,{error:{message:controller.signal.aborted?'Trial request timed out':'Trial model unavailable; retry shortly'}});}
  finally{clearTimeout(timer);req.off('aborted',closed);res.off('close',closed);busy--;}
 });
 server.requestTimeout=95000;server.headersTimeout=10000;server.keepAliveTimeout=5000;
 return server;
}
if(require.main===module)createService().listen(47831,'127.0.0.1',()=>console.log('Trial AI relay listening on 127.0.0.1:47831'));
module.exports={createService,validate,CONFIG};
