'use strict';
// Optional enrichments must never discard the core triage result.
function run(session,result,rows,{deliverables,signals,confirmation,log=()=>{}}){
 const safe=(label,fn)=>{try{fn();}catch(e){log('triage '+label+' failed: '+e.message);}};
 if(result.deliverable)safe('deliverable',()=>deliverables(session,result.deliverable,rows));
 safe('signals',()=>signals(session,result,rows));
 for(const event of (Array.isArray(result)?result:[result,...(Array.isArray(result.insights)?result.insights:[])]))safe('confirmation',()=>confirmation(session,event?.confirmation,rows));
}
module.exports={run};
