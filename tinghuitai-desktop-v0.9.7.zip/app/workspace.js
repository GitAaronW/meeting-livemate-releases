'use strict';
const fs=require('fs'),path=require('path');
function create({dataDir,config,isLocal,ask,active}){
 const files=()=>{const c=config();return Object.fromEntries(['briefs','activity'].map(k=>{const f=process.env['THT_'+k.toUpperCase()+'_JSON']||c['WORKSPACE_'+k.toUpperCase()+'_JSON']||path.join(dataDir,k+'.json');return[k,fs.existsSync(f)?f:''];}));};
 return async(req,res,u)=>{
 const p=u.pathname; if(!['/workspace/status','/workspace/ask','/tinghuitai/briefs.json','/tinghuitai/activity.json'].includes(p))return false;
 const reply=(code,j)=>{res.writeHead(code,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(j));return true;};
 if(!isLocal(req))return reply(403,{error:'请在这台Mac上打开工作台'});
 const f=files(),c=config();
 if(p==='/workspace/status')return reply(200,{briefs:!!f.briefs,activity:!!f.activity,handoff:!!c.HUB_UPSTREAM,agentLabel:'MyAgent',provider:'MyAgent'});
 if(p.endsWith('.json')){const key=p.includes('briefs')?'briefs':'activity';if(!f[key])return reply(404,{error:'尚未连接此数据源'});try{return reply(200,JSON.parse(fs.readFileSync(f[key],'utf8')));}catch{return reply(503,{error:'数据暂时无法读取，请稍后刷新'});}}
 return reply(410,{error:'旧问答入口已合并到 MyAgent，请打开 MyAgent 继续',endpoint:'/workspace-assistant'});
 };
}
module.exports={create};
