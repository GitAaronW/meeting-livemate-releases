'use strict';
const fs=require('fs'),path=require('path'),os=require('os'),crypto=require('crypto'),{execFileSync}=require('child_process');
const xml=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
const quote=s=>"'"+String(s).replace(/'/g,"'\\''")+"'";
function create({dataDir,home=os.homedir(),root=path.resolve(__dirname,'..'),node=process.execPath,platform=process.platform,run=execFileSync,uid=process.getuid?.()||0}){
 const label='com.livemate.local.'+crypto.createHash('sha256').update(dataDir).digest('hex').slice(0,12),file=path.join(home,'Library/LaunchAgents',label+'.plist'),shortcut=path.join(home,'Desktop/听会台.command');
 function currentLabel(){try{const l=fs.readFileSync(path.join(dataDir,'supervisor-label'),'utf8').trim();return /^[\w.-]+$/.test(l)?l:label;}catch{return label;}}
 function loaded(l){try{run('/bin/launchctl',['print','gui/'+uid+'/'+l],{stdio:'ignore'});return true;}catch{return false;}}
 function status(){const l=currentLabel();return {supported:platform==='darwin',enabled:platform==='darwin'&&loaded(l),configured:fs.existsSync(path.join(home,'Library/LaunchAgents',l+'.plist')),managed:l===label,desktop:fs.existsSync(shortcut),label:l};}
 function set(enabled){
  if(platform!=='darwin')throw Error('此功能目前支持 macOS');
  if(typeof enabled!=='boolean')throw Error('invalid startup');
  const l=currentLabel();if(l!==label){if(enabled&&loaded(l))return status();throw Error('此安装由已有系统守护管理，请使用原安装程序的自启开关；未改动该守护。');}
  if(!enabled){if(loaded(label))run('/bin/launchctl',['bootout','gui/'+uid+'/'+label],{stdio:'ignore'});if(fs.existsSync(file))fs.unlinkSync(file);return status();}
  if(loaded(label))return status();
  // Refuse replacing an unrelated service or changing an existing installation.
  if(fs.existsSync(file)&&!fs.readFileSync(file,'utf8').includes(xml(root+'/app/server.js')))throw Error('已有同名自启文件，未覆盖');
  fs.mkdirSync(path.dirname(file),{recursive:true});
  const log=path.join(dataDir,'launcher.log');
  fs.writeFileSync(file,'<?xml version="1.0"?><!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd"><plist version="1.0"><dict><key>Label</key><string>'+label+'</string><key>ProgramArguments</key><array><string>'+xml(node)+'</string><string>'+xml(root+'/app/server.js')+'</string></array><key>WorkingDirectory</key><string>'+xml(root)+'</string><key>EnvironmentVariables</key><dict><key>THT_DATA_DIR</key><string>'+xml(dataDir)+'</string><key>THT_SUPERVISED</key><string>1</string></dict><key>RunAtLoad</key><true/><key>KeepAlive</key><dict><key>SuccessfulExit</key><false/></dict><key>ThrottleInterval</key><integer>10</integer><key>StandardOutPath</key><string>'+xml(log)+'</string><key>StandardErrorPath</key><string>'+xml(log)+'</string></dict></plist>',{mode:0o600});
  // Configure the next login without starting a second server alongside this one.
  run('/usr/bin/plutil',['-lint',file],{stdio:'ignore'});
  fs.writeFileSync(path.join(dataDir,'supervisor-label'),label,{mode:0o600});
  return {...status(),configured:true,enabled:false,nextLogin:true};
 }
 function desktop(){
  if(platform!=='darwin')throw Error('此功能目前支持 macOS');
  const text='#!/bin/zsh\n# Meeting LiveMate desktop entry\nexport THT_DATA_DIR='+quote(dataDir)+'\nexec '+quote(node)+' '+quote(root+'/scripts/launch.js')+'\n';
  if(fs.existsSync(shortcut)&&fs.readFileSync(shortcut,'utf8')!==text)throw Error('桌面已有不同的听会台入口，未覆盖');
  fs.mkdirSync(path.dirname(shortcut),{recursive:true});fs.writeFileSync(shortcut,text,{mode:0o700});fs.chmodSync(shortcut,0o700);return status();
 }
 return {status,set,desktop,file,label};
}
module.exports={create};
