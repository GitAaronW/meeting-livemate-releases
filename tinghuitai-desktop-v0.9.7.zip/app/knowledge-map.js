'use strict';
const { loadMeetings, terms } = require('./tools/local');

const clean = s => String(s == null ? '' : s).trim();
const urlFor = id => '/tinghuitai/archive.html?id=' + encodeURIComponent(id);
const dateOf = iso => { const d = new Date(iso); return isNaN(d) ? '' : d.toISOString().slice(0, 10); };
const atOf = at => {
  if (typeof at === 'number') return at > 1e11 ? new Date(at).toTimeString().slice(0, 8) : new Date(at * 1000).toISOString().slice(11, 19);
  const s = clean(at); return /^\d{1,2}:\d{2}/.test(s) ? s : '';
};
const cited = (m, text, at = '', kind = 'evidence') => ({ kind, text: clean(text), meetingId: m.id, meeting: m.title, date: dateOf(m.date), at: atOf(at), url: urlFor(m.id) });
const match = (text, q) => { const hay = clean(text).toLowerCase(); return terms(q).every(t => hay.includes(t)); };

function build(dataDir, query = '') {
  const { meetings, skipped } = loadMeetings(dataDir, { max: 80 });
  const people = new Map(), topics = new Map(), evidence = [];
  const person = name => { name = clean(name); if (!name || /^(S|spk|speaker)[-_ ]?\d+$/i.test(name)) return null; if (!people.has(name)) people.set(name, { name, meetings: [], positions: [], todos: [] }); return people.get(name); };
  const topic = title => { title = clean(title); if (!title) return null; if (!topics.has(title)) topics.set(title, { title, meetings: [], history: [] }); return topics.get(title); };
  for (const m of meetings) {
    const pnames = new Set([...(m.participants || []), ...Object.values(m.names || {}), ...(m.todos || []).map(x => x.owner), ...(m.briefTodos || []).map(x => x.owner)].map(clean).filter(Boolean));
    for (const name of pnames) {
      const p = person(name); if (!p) continue;
      if (!p.meetings.some(x => x.meetingId === m.id)) p.meetings.push(cited(m, m.summary || m.conclusions[0] || '会议记录', '', 'meeting'));
      for (const t of [...(m.todos || []), ...(m.briefTodos || [])]) if (clean(t.owner).toLowerCase() === name.toLowerCase()) p.todos.push(cited(m, t.text || t.what, '', 'todo'));
      for (const s of m.segments || []) if (clean(s.speakerName).toLowerCase() === name.toLowerCase()) p.positions.push(cited(m, s.text, s.at, 'quote'));
      p.positions = p.positions.slice(-12); p.todos = p.todos.slice(-12); p.meetings = p.meetings.slice(0, 12);
    }
    for (const row of m.topics || []) {
      const t = topic(row.title); if (!t) continue;
      if (!t.meetings.some(x => x.meetingId === m.id)) t.meetings.push(cited(m, row.title, '', 'meeting'));
      for (const x of m.conclusions || []) t.history.push(cited(m, x, '', 'conclusion'));
      for (const x of m.openQuestions || []) t.history.push(cited(m, x, '', 'open'));
      for (const x of m.decisions || []) t.history.push(cited(m, (x.status ? x.status + ' · ' : '') + x.title, '', 'decision'));
      t.history = t.history.slice(0, 24); t.meetings = t.meetings.slice(0, 16);
    }
    if (query) {
      for (const x of m.conclusions || []) if (match(x, query)) evidence.push(cited(m, x, '', 'conclusion'));
      for (const x of [...(m.todos || []), ...(m.briefTodos || [])]) if (match((x.text || x.what) + ' ' + x.owner, query)) evidence.push(cited(m, x.text || x.what, '', 'todo'));
      for (const s of m.segments || []) if (match(s.text, query)) evidence.push(cited(m, s.text, s.at, 'quote'));
    }
  }
  let peopleRows = [...people.values()].sort((a, b) => b.meetings.length - a.meetings.length || a.name.localeCompare(b.name, 'zh'));
  let topicRows = [...topics.values()].sort((a, b) => b.meetings.length - a.meetings.length || a.title.localeCompare(b.title, 'zh'));
  if (query) { peopleRows = peopleRows.filter(x => match([x.name, ...x.positions.map(y => y.text), ...x.todos.map(y => y.text)].join(' '), query)); topicRows = topicRows.filter(x => match([x.title, ...x.history.map(y => y.text)].join(' '), query)); }
  return { ok: true, query, people: peopleRows.slice(0, 80), topics: topicRows.slice(0, 80), evidence: evidence.slice(0, 80), scanned: meetings.length, unreadableFiles: skipped };
}

module.exports = { build, __test: { atOf, match } };
