'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const MAX=5*1024*1024;
const types={'.txt':'text/plain','.md':'text/markdown','.csv':'text/csv','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp'};
function directory(dataDir){return path.join(dataDir,'state','assistant-materials');}
function put(dataDir,{name,base64}){
 if(typeof name!=='string'||typeof base64!=='string'||base64.length>Math.ceil(MAX*4/3)+4)throw Error('材料超过 5 MB 或格式无效');
 name=path.basename(name).slice(0,160);const ext=path.extname(name).toLowerCase(),type=types[ext];if(!type)throw Error('暂支持文字、Markdown、CSV、JSON、PNG、JPG 和 WebP');
 if(!/^[A-Za-z0-9+/]*={0,2}$/.test(base64)||base64.length%4)throw Error('材料编码无效');
 const bytes=Buffer.from(base64,'base64');if(!bytes.length||bytes.length>MAX)throw Error('材料为空或超过 5 MB');
 if(type.startsWith('image/')){
  const valid=type==='image/png'?bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])):type==='image/jpeg'?bytes[0]===255&&bytes[1]===216:bytes.subarray(0,4).toString()==='RIFF'&&bytes.subarray(8,12).toString()==='WEBP';
  if(!valid)throw Error('图片格式与文件名不一致');
 }else if(bytes.includes(0))throw Error('材料不是可读取的文字');
 const id=crypto.randomUUID(),dir=directory(dataDir);fs.mkdirSync(dir,{recursive:true,mode:0o700});
 const file=id+ext;fs.writeFileSync(path.join(dir,file),bytes,{mode:0o600,flag:'wx'});
 const record={id,name,type,file,size:bytes.length};fs.writeFileSync(path.join(dir,id+'.json'),JSON.stringify(record),{mode:0o600,flag:'wx'});return {id,name,type,size:record.size};
}
function load(dataDir,ids=[]){
 if(!Array.isArray(ids)||ids.length>5)throw Error('一次最多补充 5 份材料');
 return [...new Set(ids)].map(id=>{
  if(typeof id!=='string'||!/^[a-f0-9-]{36}$/.test(id))throw Error('材料编号无效');
  const dir=directory(dataDir),record=JSON.parse(fs.readFileSync(path.join(dir,id+'.json'),'utf8'));
  if(record.id!==id||path.basename(record.file)!==record.file)throw Error('材料记录无效');
  const file=path.join(dir,record.file);return {id,name:record.name,type:record.type,path:file,...(record.type.startsWith('image/')?{}:{text:fs.readFileSync(file,'utf8').slice(0,16000)})};
 });
}
module.exports={put,load};
