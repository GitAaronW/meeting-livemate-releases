/* Derived salience. No status changes, no deletions, no migration timestamps. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.workAttention=factory();})(typeof globalThis!=='undefined'?globalThis:this,function(){
 const date=v=>{const n=typeof v==='number'?v:Date.parse(v);return Number.isFinite(n)&&n>0?n:0;};
 return function attention(w,db={},asOf=Date.now()){
  const ts=(w.memberIds||[]).map(id=>(db.tasks||[]).find(t=>t.id===id)).filter(Boolean),ss=(w.sourceIds||[]).map(id=>(db.sources||[]).find(s=>s.id===id)).filter(Boolean);
  const times=[w.businessUpdatedAt,w.manual?w.created:null,...ts.flatMap(t=>[t.businessUpdatedAt,t.triagedAt,t.key?.startsWith('manual:')?t.created:null]),...ss.map(s=>s.date)];
  const at=Math.max(0,...times.map(date)),days=at?Math.max(0,(Number(asOf)-at)/86400000):null;
  const result=(state,reason)=>({state,reason,lastBusinessActivityAt:at?new Date(at).toISOString():null,idleDays:days===null?null:Math.floor(days)});
  if(['done','verified','cancelled','parked'].includes(w.status))return result('closed','已结束或主动暂存');
  if(w.attentionPinned)return result('protected','你选择保留在关注中');
  if(w.due||ts.some(t=>t.due))return result('protected','有期限，保留跟进');
  if(w.needsDecision||w.commitment||w.dependencies?.length||ts.some(t=>t.commitment||t.dependencies?.length))return result('protected','有决定、承诺或依赖');
  if(['blocked','doing','submitted'].includes(w.status)||ts.some(t=>['blocked','doing','submitted'].includes(t.status)))return result('protected','仍在推进、阻塞或等待验收');
  if(days===null)return result('focus','时间未核实，暂不隐藏');
  return days>7?result('quiet','超过 7 天无新进展，已降低关注'):result('focus','近期有进展');
 };
});
