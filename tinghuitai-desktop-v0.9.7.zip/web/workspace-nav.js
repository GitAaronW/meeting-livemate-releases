'use strict';
(()=>{
 const params=new URLSearchParams(location.search),inside=parent!==window;
 const forward=message=>parent.postMessage(message,location.origin);
 const back=document.querySelector('.topbar > .back-link');
 if(back)back.href=sessionStorage.getItem('tht-meeting-return')||'./';
 if(inside&&params.has('shell')){
  document.documentElement.classList.add('work-in-shell');
  if(back)back.onclick=e=>{e.preventDefault();forward({type:'tht-work-return'});};
  window.addEventListener('hashchange',()=>forward({type:'tht-work-view',view:location.hash.slice(1)}));
 }
 if(params.has('embedded'))document.documentElement.classList.add('utility-embedded');
 const style=document.createElement('style');style.textContent='.utility-embedded .topbar,.utility-embedded body>header,.utility-embedded .cw-fab{display:none!important}.utility-embedded .shell{max-width:none!important;padding:8px!important}.work-in-shell .wordmark,.work-in-shell #work-lang,.work-in-shell .back-link{display:none!important}.work-in-shell .topbar{padding:14px 0;justify-content:center}';document.head.append(style);
 // Capture before per-page handlers or browser navigation can load an entire
 // app shell into one of its own content frames.
 document.addEventListener('click',e=>{
  const a=e.target.closest('a[href]');if(!a||e.metaKey||e.ctrlKey||e.shiftKey)return;
  let u;try{u=new URL(a.href,location.href);}catch{return;}
  if(u.origin!==location.origin)return;
  if(/\/tinghuitai\/(?:index\.html|meeting-board\.html)?$/.test(u.pathname)&&inside){
   e.preventDefault();e.stopImmediatePropagation();forward({type:'tht-open-meeting',id:u.searchParams.get('id')||sessionStorage.getItem('tht-selected-meeting')||'',atSec:Number((u.hash.match(/t=([\d.]+)/)||[])[1]||0)});
  }else if(u.pathname.endsWith('/work.html')&&inside){e.preventDefault();e.stopImmediatePropagation();if(params.has('shell'))location.hash=u.hash||'#focus';else forward({type:'tht-work-open',view:u.hash.slice(1)});}
 },true);
 window.addEventListener('message',e=>{
  if(e.origin!==location.origin||![...document.querySelectorAll('iframe')].some(f=>f.contentWindow===e.source))return;
  if(['tht-open-meeting','tht-work-open','tht-agent-ask','tht-agent-open','tht-agent-quote'].includes(e.data?.type)&&inside)forward(e.data);
 });
})();
