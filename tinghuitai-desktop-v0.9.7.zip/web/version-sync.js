/* Shared version readback. Never claim the service version is the loaded UI version. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.ThtVersionSync=api;})(typeof window==='object'?window:this,function(){
 'use strict';
 const IDLE_MS=60000,KEY='tht-ui-reloaded-for',baselines=new WeakMap(),warned=new WeakSet();
 function fieldState(e){return e.tagName==='SELECT'?[...e.options].map(o=>!!o.selected):['checkbox','radio'].includes(e.type)?!!e.checked:e.value;}
 function captureBaseline(doc){
  // Snapshot initialized navigation / saved form controls once. Draft text and attachments remain protected.
  for(const e of doc.querySelectorAll('input,select'))if(['INPUT','SELECT'].includes(e.tagName)&&e.getClientRects().length&&!e.disabled&&e.type!=='file')baselines.set(e,fieldState(e));
 }
 function decision({build,health,busy,idleMs,attempted,storageAvailable=true,automatic=true}){
  const target=health?.version;
  if(!health?.ok||typeof target!=='string'||!build||target===build)return {pending:false,reload:false};
  const safe=health.activeSessions===0&&health.uiRefresh?.schema===1&&health.uiRefresh.idle===true&&busy===false;
  const autoAllowed=automatic&&storageAvailable&&attempted!==target;
  return {pending:true,target,safe,autoAllowed,reload:autoAllowed&&safe&&idleMs>=IDLE_MS};
 }
 function documentBusy(doc,seen=new Set()){
  if(!doc)return true;if(seen.has(doc))return false;seen.add(doc);
  try{
   const win=doc.defaultView;
   if(win?.thtAgentBusy?.()||win?.thtRefreshBusy?.())return true;
   if(doc.querySelector('dialog[open]'))return true;
   const visible=e=>e.getClientRects().length>0;
   for(const e of doc.querySelectorAll('input,textarea,select,[contenteditable]:not([contenteditable="false"])')){
    if(!visible(e)||e.disabled)continue;
    if(e.isContentEditable)return true;
    const baseline=baselines.get(e);
    if(e.tagName==='SELECT'){if(baselines.has(e)?JSON.stringify(fieldState(e))!==JSON.stringify(baseline):[...e.options].some(o=>o.selected!==o.defaultSelected))return true;}
    else if(['checkbox','radio'].includes(e.type)){if(e.checked!==(baselines.has(e)?baseline:e.defaultChecked))return true;}
    else if(e.type==='file'){if(e.files?.length)return true;}
    else if(e.value!==(baselines.has(e)?baseline:e.defaultValue))return true;
   }
   for(const frame of doc.querySelectorAll('iframe')){
    // A frame that has not loaded or cannot be inspected is not known to be safe.
    if(!frame.contentDocument||documentBusy(frame.contentDocument,seen))return true;
   }
   return false;
  }catch{if(!warned.has(doc)){warned.add(doc);doc.defaultView?.console?.warn?.('THT: refresh safety check failed; keeping this window open.');}return true;}
 }
 function create({build,readHealth,busy,reload,notify,storage,now=()=>Date.now(),automatic=true}){
  let lastInteraction=now(),health=null,checking=false;
  function interaction(){lastInteraction=now();}
  function apply(manual=false){
   let attempted='',storageAvailable=true;try{if(!storage)throw Error('No storage');attempted=storage.getItem(KEY)||'';}catch{storageAvailable=false;}
   const d=decision({build,health,busy:busy(),idleMs:now()-lastInteraction,attempted,storageAvailable,automatic});
   notify(d);
   if(!d.pending)return d;
   if(d.reload||(manual&&d.safe&&storageAvailable)){
    try{storage.setItem(KEY,d.target);}catch{return {...d,reload:false};}
    reload();return {...d,reload:true};
   }
   return d;
  }
  async function check(manual=false){if(checking)return;checking=true;try{health=await readHealth();return apply(manual);}catch{health=null;return {pending:false,reload:false};}finally{checking=false;}}
  return {check,interaction,apply};
 }
 function wireInteractions(doc,interaction,seen=new Set()){
  if(!doc||seen.has(doc))return;seen.add(doc);
  for(const event of ['pointerdown','keydown','input','wheel'])doc.addEventListener(event,interaction,{capture:true,passive:true});
  for(const frame of doc.querySelectorAll('iframe')){try{if(frame.contentDocument)wireInteractions(frame.contentDocument,interaction,seen);}catch{}frame.addEventListener('load',()=>{try{wireInteractions(frame.contentDocument,interaction,seen);}catch{}});}
 }
 function boot(options={}){
  const doc=options.document||document,win=doc.defaultView;
  const build=doc.querySelector('meta[name="tht-build"]')?.content;
  let storage;try{storage=win.sessionStorage;}catch{}
  const core=create({build,storage,automatic:options.automatic!==false,busy:()=>documentBusy(doc),reload:()=>win.location.reload(),notify:options.notify||(()=>{}),readHealth:async()=>{
   const base=options.base?.()||'';let token='';try{token=JSON.parse(win.localStorage.getItem('tht-settings')||'{}').relayToken||'';}catch{}
   const response=await win.fetch(base+'/health',{headers:{'x-tht-token':token},cache:'no-store',signal:AbortSignal.timeout(2500)});
   if(!response.ok)throw Error('Health unavailable');return response.json();
  }});
  wireInteractions(doc,core.interaction);
  // The assembled app initializes its controls synchronously; defer until that render finishes.
  queueMicrotask(()=>{captureBaseline(doc);core.check();});
  win.setInterval(()=>core.check(),30000);doc.addEventListener('visibilitychange',()=>{if(!doc.hidden)core.check();});
  return core;
 }
 if(typeof document==='object')document.addEventListener('DOMContentLoaded',()=>{
  // index owns its existing updater bar; embedded pages are protected by their parent.
  if(/\/(?:index\.html)?$/.test(location.pathname)||window.parent!==window)return;
  const automatic=/\/work\.html$/.test(location.pathname);
  let notice,button,core;
  core=boot({automatic,notify:d=>{
   if(!d.pending){if(notice)notice.hidden=true;return;}
   if(notice)notice.hidden=false;
   if(!notice){notice=document.createElement('div');notice.setAttribute('role','status');notice.style.cssText='position:fixed;bottom:16px;right:16px;z-index:99999;background:#f7f6f2;color:#252523;border:1px solid #d8d7d0;border-radius:12px;padding:12px;max-width:360px;font:14px system-ui;box-shadow:0 4px 18px #0001';const text=document.createElement('span');text.className='version-note';button=document.createElement('button');button.textContent=document.documentElement.lang==='en'?'Refresh':'刷新';button.style.marginLeft='12px';button.onclick=()=>core.check(true);notice.append(text,button);document.body.append(notice);}
   const en=document.documentElement.lang==='en';notice.querySelector('.version-note').textContent=d.safe?(en?'Updated. Refresh this window when ready.':'已更新，可以刷新这个窗口。'):(en?'Updated. Save your edits or finish the current task first.':'已更新，保存编辑或结束当前任务后可刷新。');button.disabled=!d.safe;
  }});
 });
 return {decision,documentBusy,captureBaseline,create,boot,IDLE_MS};
});
