// Native mini mode shares the existing meeting canvas; it never finalizes on a view switch.
let nativeState={available:false,active:false,sessionId:''},browserCommandPending=false,nativeClockReceivedAt=0;
async function nativeRequest(route,body){
  const response=await fetch(relayBase()+'/native/'+route,{method:body?'POST':'GET',headers:body?{'Content-Type':'application/json'}:undefined,body:body?JSON.stringify(body):undefined,cache:'no-store',signal:AbortSignal.timeout(8000)});
  const result=await response.json();if(!response.ok)throw Error(result.error||'HTTP '+response.status);return result;
}
function nativeStatus(next){
  const previous=nativeState;nativeState=next;nativeClockReceivedAt=Date.now();window.thtNativeStatus=next;paintMeetingClock();
  const join=document.getElementById('native-join');if(join){join.hidden=!next.available;document.getElementById('native-join-go').disabled=!!next.active||nativeJoinPending;}
  const button=document.getElementById('b-native');button.hidden=!next.available;button.textContent=next.active&&next.view==='hidden'?(ui==='en'?'Show mini window':'显示小窗'):next.active&&next.view==='compact'?(ui==='en'?'Expand mini window':'展开小窗'):(ui==='en'?'Mini window':'小窗模式');button.title=ui==='en'?'Show the same meeting. Hiding the mini window keeps listening.':'显示同一场会议；隐藏小窗不会结束听会。';
  if(next.active&&next.captureMode==='browser'){
    if(next.command&&running&&cur?.id===next.sessionId&&!browserCommandPending){
      browserCommandPending=true;
      (async()=>{const command=next.command;try{if(command==='stop'){await stopAll(true);window.thtMiniPaused=false;}else{window.thtMiniPaused=command==='pause';await nativeRequest('browser-state',{sessionId:next.sessionId,paused:window.thtMiniPaused});}await nativeRequest('browser-ack',{sessionId:next.sessionId,command});}catch(e){note(e.message,true);}finally{browserCommandPending=false;}})();
    }
  }else if(next.active){
    if(running){
      if(asrMode)asrStop(false);
      // Retire browser recognition before changing cur: its last result belongs to the old input.
      if(rec){rec.onresult=null;rec.onerror=null;rec.onend=null;try{rec.abort();}catch{}rec=null;}
      running=false;clearInterval(timer);try{wake?.release();}catch{}
    }
    if(previous.sessionId!==next.sessionId||!cur){
      cur=normalizeSession({id:next.sessionId,title:next.title,start:next.startedAt||Date.now(),transcript:[],highlights:[],todos:[],factchecks:[],nativeCapture:true});
      window.thtOpenMeeting?.(next.sessionId);viewerConnect();
    }
    el.start.hidden=true;el.stop.hidden=false;
    el.status.textContent=next.phase==='paused'?(ui==='en'?'Paused':'已暂停'):(ui==='en'?'Listening · on device':'正在听 · 本机转写');el.status.className=next.phase==='paused'?'pill':'pill live';
    if(next.error&&next.error!==previous.error)note(next.error,true);
  }else if(previous.active&&!running){el.start.hidden=false;el.stop.hidden=true;el.status.textContent=ui==='en'?'Ended':'已结束';el.status.className='pill';}
  window.dispatchEvent(new CustomEvent('tht-native-status',{detail:next}));
}
// The header follows the shared session, including browser capture opened in another view.
function paintMeetingClock(){
 if(!nativeState.active)return;
 const started=Number(nativeState.startedAt),elapsed=started>0?(Date.now()-started)/1000:Number(nativeState.audioSeconds)+(Date.now()-nativeClockReceivedAt)/1000;
 if(Number.isFinite(elapsed))el.clock.textContent=fmt(Math.floor(Math.max(0,elapsed)));
}
setInterval(paintMeetingClock,1000);
const nativeButton=document.getElementById('b-native');
nativeButton.onclick=async()=>{try{await nativeRequest('launch',{uiLang:ui,lang:cur?.lang||'zh'});}catch(e){note(e.message,true);}};
let nativeJoinPending=false;
const nativeJoinGo=document.getElementById('native-join-go');
function paintNativeJoin(){
 if(!nativeJoinGo)return;const english=ui==='en';
 document.getElementById('native-join-label').textContent=english?'Join an online meeting':'加入线上会议';
 document.getElementById('native-join-url').placeholder=english?'Paste a Lark, Feishu or Google Meet link':'粘贴飞书 / Lark 或 Google Meet 会议链接';
 nativeJoinGo.textContent=english?'Join & record':'加入并录制';
 document.getElementById('native-join-hint').textContent=nativeState.active?(english?'This meeting is already being recorded.':'当前会议正在录制。'):(english?'Captures system audio and your microphone. Allow system permissions on first use.':'记录系统声音和你的麦克风。首次使用需要允许系统权限。');
}
if(nativeJoinGo){
 document.getElementById('mode-chip').addEventListener('click',paintNativeJoin);
 nativeJoinGo.onclick=async()=>{
  if(nativeJoinPending||nativeState.active)return;
  const url=document.getElementById('native-join-url').value.trim(),message=document.getElementById('native-join-error');
  if(!url){message.textContent=ui==='en'?'Paste a meeting link first.':'请先粘贴会议链接。';message.hidden=false;return;}
  nativeJoinPending=true;nativeJoinGo.disabled=true;message.hidden=true;
  try{await nativeRequest('join',{url,uiLang:ui,lang:cur?.lang||'zh'});closeSheets();note(ui==='en'?'Opening your meeting. Follow the mini window for recording status.':'正在打开会议；录制状态请看小窗。');}
  catch(e){message.textContent=e.message;message.hidden=false;}
  finally{nativeJoinPending=false;nativeJoinGo.disabled=!!nativeState.active;}
 };
}
el.stop.addEventListener('click',async e=>{if(!nativeState.active||nativeState.captureMode==='browser')return;e.preventDefault();e.stopImmediatePropagation();try{await nativeRequest('command',{sessionId:nativeState.sessionId,command:'stop'});note(ui==='en'?'Saving the last sentence…':'正在保存最后一句…');}catch(error){note(error.message,true);}},true);
setInterval(()=>nativeRequest('status').then(nativeStatus).catch(()=>{}),2000);
nativeRequest('status').then(nativeStatus).catch(()=>{});
