async function workspaceShareAction(message){
      const controls={lark:'share-lark',slack:'share-slack',full:'x-full',transcript:'x-verb',pdf:'x-pdf',copy:'copy',workspace:'save-hub'};
      const control=controls[message.action],id=message.sessionId;
      if(!control||!id)return;
      if(running&&cur?.id!==id){note(ui==='en'?'End the current meeting before exporting another.':'请先结束当前会议，再导出其他会议。',true);return;}
      try{
        const r=await fetch(relayBase()+'/export-state?ids='+encodeURIComponent(id)+'&token='+encodeURIComponent(cfg.relayToken||''),{cache:'no-store',signal:AbortSignal.timeout(8000)});
        if(!r.ok)throw Error('HTTP '+r.status);
        const selected=(await r.json()).sessions.find(x=>x.id===id);
        if(!selected)throw Error(ui==='en'?'Meeting not found':'未找到对应会议');
        if(!running){cur=normalizeSession(selected);resetSigs();render();}
        document.getElementById(control).click();
      }catch(error){note(error.message,true);}
}
// Keep the existing recorder and controls as the application shell. Its primary
// content is the same workspace used after the meeting, not a second data store.
{ // The recorder always uses the canonical meeting canvas.
  const frame = document.getElementById('workspace-frame');
  document.getElementById('app').classList.add('workspace-primary');
  frame.hidden = false;
  let previous = '', ready = false, viewedMeetingId = new URLSearchParams(location.search).get('id') || sessionStorage.getItem('tht-selected-meeting') || '', wasRunning=running, requestedModule=new URLSearchParams(location.search).get('module')||'', navigationId='', requestedAt=Number((location.hash.match(/(?:^#|&)t=(\d+(?:\.\d+)?)/)||[])[1]||0);
  const workFrame=document.getElementById('work-frame');
  function workRoute(view,sourceId=''){const raw=String(view||'focus'),p=new URLSearchParams(raw),name=p.get('view')||raw.split('&')[0]||'focus',q=new URLSearchParams();if(p.get('node'))q.set('node',p.get('node'));if(sourceId||p.get('source'))q.set('source',sourceId||p.get('source'));return encodeURIComponent(name)+(q.size?'&'+q:'');}
  function saveRoute(mode,view='',replace=false){
    const q=new URLSearchParams(location.search);if(viewedMeetingId)q.set('id',viewedMeetingId);else q.delete('id');
    if(mode==='work'){q.set('view','work');q.set('tab',workRoute(view||workFrame.contentWindow?.location.hash.slice(1)||'focus'));}else{q.delete('view');q.delete('tab');}
    const next=location.pathname+(q.toString()?'?'+q:'')+location.hash;
    if(next!==location.pathname+location.search+location.hash)history[replace?'replaceState':'pushState'](null,'',next);
    sessionStorage.setItem('tht-selected-meeting',viewedMeetingId);
  }
  window.thtCloseWorkbench=(restore=false)=>{workFrame.hidden=true;frame.hidden=false;if(!restore)saveRoute('meeting');syncWorkspace(true);};
  window.thtOpenWorkbench=(view,restore=false,sourceId='')=>{
    if(!view&&!workFrame.hidden){window.thtCloseWorkbench();return;}
    const target=workRoute(view,sourceId);
    if(!workFrame.getAttribute('src'))workFrame.src='work.html?shell=1#'+target;
    else if(view&&workFrame.contentWindow.location.hash!=='#'+target){
      const child=workFrame.contentWindow;
      child.history.replaceState(null,'','#'+target);
      child.dispatchEvent(new child.HashChangeEvent('hashchange'));
    }
    frame.hidden=true;workFrame.hidden=false;if(!restore)saveRoute('work',view);syncWorkspace(true);
  };
  window.thtOpenMeeting=(nextId,atSec,moduleId)=>{
    if(!nextId)return;
    navigationId=crypto.randomUUID();
    requestedModule=moduleId||'';
    requestedAt=Number(atSec)>0?Number(atSec):0;
    viewedMeetingId=String(nextId||'');
    const hash=Number(atSec)>0?'#t='+Number(atSec):'';
    const q=new URLSearchParams(location.search);q.set('id',viewedMeetingId);q.delete('view');q.delete('tab');if(requestedModule)q.set('module',requestedModule);else q.delete('module');const next=location.pathname+'?'+q+hash;if(next!==location.pathname+location.search+location.hash)history.pushState(null,'',next);
    window.thtCloseWorkbench();
  };
  function restoreRoute(){const q=new URLSearchParams(location.search);viewedMeetingId=q.get('id')||'';requestedModule=q.get('module')||'';navigationId=crypto.randomUUID();requestedAt=Number((location.hash.match(/(?:^#|&)t=(\d+(?:\.\d+)?)/)||[])[1]||0);sessionStorage.setItem('tht-selected-meeting',viewedMeetingId);q.get('view')==='work'?window.thtOpenWorkbench(q.get('tab')||'focus',true):window.thtCloseWorkbench(true);}
  function recoverNestedShell(child){
    try{const u=new URL(child.contentWindow.location.href);if(u.origin!==location.origin)return false;
      if(/\/tinghuitai\/(?:index\.html)?$/.test(u.pathname)){
        if(child===frame){ready=false;frame.src='meeting-board.html?embedded=1'+(viewedMeetingId?'&id='+encodeURIComponent(viewedMeetingId):'');}else workFrame.src='work.html?shell=1';
        window.thtOpenMeeting(u.searchParams.get('id')||viewedMeetingId,Number(u.hash.slice(3)),u.searchParams.get('module')||'');return true;
      }
    }catch{}return false;
  }
  function syncWorkspace(force=false) {
    if (!ready) return;
    document.getElementById('b-assistant').textContent='✦ MyAgent';
    document.getElementById('b-work-top').textContent=workFrame.hidden?(ui==='en'?'Workbench':'工作台'):(ui==='en'?'← Meeting':'← 听会台');
    const active=running||nativeState.active;
    if(active&&!wasRunning){viewedMeetingId=nativeState.sessionId||cur?.id||'';workFrame.hidden=true;frame.hidden=false;}wasRunning=active;
    const context = {type:'tht-context', lang:ui, moduleId:requestedModule,navigationId,
      sessionId:viewedMeetingId || (active&&nativeState.sessionId) || (cur?.id && (active || cur.transcript?.length) ? cur.id : ''), active,nativeCapture:nativeState.active&&nativeState.captureMode==='native',atSec:requestedAt};
    const key = JSON.stringify(context);
    if(force || key!==previous) { previous=key;frame.contentWindow.postMessage(context,location.origin);if(workFrame.getAttribute('src'))workFrame.contentWindow.postMessage({type:'tht-language',lang:ui},location.origin); }
  }
  frame.onload=()=>{if(recoverNestedShell(frame))return;ready=true;syncWorkspace(true);};
  workFrame.onload=()=>{if(!recoverNestedShell(workFrame))syncWorkspace(true);};
  window.addEventListener('popstate',restoreRoute);
  frame.src='meeting-board.html?embedded=1'+(viewedMeetingId?'&id='+encodeURIComponent(viewedMeetingId):'');
  restoreRoute();
  window.addEventListener('hashchange',()=>{previous='';syncWorkspace(true);});
  setInterval(syncWorkspace,1000);
  window.addEventListener('tht-native-status',()=>syncWorkspace(true));
  const button=document.getElementById('b-assistant');
  button.textContent='✦ MyAgent';
  button.setAttribute('aria-controls','myagent-panel');
  button.addEventListener('click',e=>{
    e.preventDefault();e.stopImmediatePropagation();
    window.myAgentOpen?.();
  },true);
  document.getElementById('b-this').addEventListener('click',e=>{
    e.preventDefault();e.stopImmediatePropagation();
    window.thtCloseWorkbench();frame.contentWindow.postMessage({type:'tht-export'},location.origin);
  },true);
  window.addEventListener('message',async e=>{
    if(e.origin!==location.origin)return;
    if(![frame.contentWindow,workFrame.contentWindow].includes(e.source))return;
    if(e.data?.type==='tht-work-open')window.thtOpenWorkbench(e.data.view);
    if(e.data?.type==='tht-agent-open'){window.myAgentOpen?.();return;}
    if(e.data?.type==='tht-agent-ask'){window.myAgentAsk?.(e.data.quote,e.data.question||'',e.data.meta||{});return;}
    if(e.data?.type==='tht-open-meeting'){window.thtOpenMeeting(e.data.id,e.data.atSec,e.data.moduleId);return;}
    if(e.data?.type==='tht-work-view'){if(e.source===workFrame.contentWindow&&!workFrame.hidden)saveRoute('work',e.data.view);return;}
    if(e.source===workFrame.contentWindow){
      if(e.data?.type==='tht-work-return')window.thtCloseWorkbench();
      if(e.data?.type==='tht-open-meeting')window.thtOpenMeeting(e.data.id,e.data.atSec,e.data.moduleId);
      if(e.data?.type==='tht-language'&&['zh','en'].includes(e.data.lang))document.querySelector('[data-ui="'+e.data.lang+'"]')?.click();
      return;
    }
    if(e.source!==frame.contentWindow)return;
    if(e.data?.type==='tht-navigation-opened'&&e.data.navigationId===navigationId){navigationId='';requestedModule='';requestedAt=0;return;}
    if(e.data?.type==='tht-result-opened'&&e.data.moduleId===requestedModule){requestedModule='';return;}
    if(e.data?.type==='tht-selected-meeting'){if(e.data.reason==='context'&&viewedMeetingId&&e.data.id!==viewedMeetingId)return;viewedMeetingId=e.data.id;sessionStorage.setItem('tht-selected-meeting',viewedMeetingId);const q=new URLSearchParams(location.search);q.set('id',viewedMeetingId);history.replaceState(null,'',location.pathname+(q.toString()?'?'+q:'')+location.hash);}
    if(e.data?.type==='tht-share-action'){
      await workspaceShareAction(e.data);
    }
    if(e.data?.type==='tht-assistant-state')button.setAttribute('aria-expanded',String(e.data.open));
    if(e.data?.type==='tht-language' && ['zh','en'].includes(e.data.lang))document.querySelector('[data-ui="'+e.data.lang+'"]')?.click();
    if(e.data?.type==='tht-app-panel'&&e.data.mode==='material'){document.getElementById('b-this').onclick();document.getElementById('more-title').textContent=ui==='en'?'Add meeting material':'补充会议资料';return;}
    if(e.data?.type==='tht-app-panel')document.getElementById(({settings:'gear2',history:'b-hist',update:'m-update'})[e.data.mode])?.click();
  });
}
