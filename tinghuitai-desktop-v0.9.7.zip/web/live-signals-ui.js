'use strict';
// Evidence, background and AI judgement are separate views of the Session journal.
window.THTLiveSignals = {
  attach(items, modules) {
    const groups = new Map(), loose = [];
    for (const item of items.filter(x => ['background','verification'].includes(x.channel))) {
      const ids = (item.sourceRefs || []).map(r => typeof r === 'string' ? r : r.segId);
      const candidates = modules.filter(m => m.kind !== 'summary');
      const module = candidates.find(m => m.topic === item.topic) || candidates.find(m => (m.sourceRefs || []).some(r => ids.includes(typeof r === 'string' ? r : r.segId)));
      if (!module) { loose.push(item); continue; }
      if (!groups.has(module.id)) groups.set(module.id, []);
      groups.get(module.id).push(item);
    }
    return {groups, loose};
  },
  render(item, {el, tr, refs, globalAct}) {
    const card = el('section', '', 'signal signal-' + item.channel);
    card.dataset.signalId = item.id;
    card.append(el('small', item.channel === 'judgment' ? tr('当前判断 · AI 推断，尚未确认','Current judgement · AI inference, unconfirmed') : item.channel === 'verification' ? tr('事实核查 · 公开检索','Fact check · Public search') : tr('背景补充 · 公开检索','Background · Public search'), 'signal-label'));
    card.append(el('h3', item.channel === 'judgment' ? item.point : item.entity || item.topic));
    if (item.channel === 'judgment') {
      card.append(el('p', item.whyChanged, 'signal-reason'));
      if(item.speechDraft){const speech=el('aside','','speech-draft');speech.append(el('small',tr('此刻可以这样说 · AI 草稿','Something you could say · AI draft')),el('p',item.speechDraft));card.append(speech);}
      const correct = el('button', tr('纠正或继续问','Correct or ask'));
      correct.onclick = () => globalAct({comment:'',quote:item.point}); card.append(correct);
    } else {
      if (item.channel === 'verification') card.append(el('p', tr('待核查说法：','Claim to check: ') + item.claim));
      if (item.lookupState === 'ready') {
        for (const source of item.evidence || []) {
          if (!/^https?:\/\//.test(source.url || '')) continue;
          card.append(el('blockquote', source.excerpt));
          const a = el('a', source.title || source.url); a.href=source.url; a.target='_blank'; a.rel='noopener noreferrer'; card.append(a);
          const date=new Date(source.retrievedAt); if (!Number.isNaN(date.getTime())) card.append(el('small', tr('检索于 ','Retrieved ') + date.toLocaleString(), 'signal-date'));
        }
        card.append(el('small', tr('检索片段供核对，不代表整条说法已经验证。','Search excerpts for review; the full claim has not been verified.'), 'signal-caveat'));
      } else {
        const state = ({pending:tr('已识别，准备检索','Identified, preparing search'),searching:tr('正在检索公开来源…','Searching public sources…'),no_evidence:tr('未找到可用证据；不能据此判定真伪','No usable evidence; this does not establish truth or falsity'),unavailable:tr('检索暂不可用','Search unavailable')})[item.lookupState] || '';
        card.append(el('small',state,'signal-status'));
      }
    }
    if (item.sourceRefs?.length) { const d=refs(item); d.dataset.key=item.id+':source';card.append(d); }
    return card;
  }
};
