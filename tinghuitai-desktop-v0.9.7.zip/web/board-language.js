/* Display translations share the original board; they are never a second editable document. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.THTBoardLanguage=api;})(typeof window==='object'?window:globalThis,()=>{
 'use strict';
 function fields(value){
  const out={};const add=(key,text)=>{if(typeof text==='string'&&text.trim())out[key]=text;};
  for(const key of ['title','body','context','topic','goal','summary','text','point','whyChanged','speechDraft','entity','claim','md','question','statement','whyNow'])add(key,value?.[key]);
  for(const key of ['verdict','note'])add('verify.'+key,value?.verify?.[key]);
  for(const [list,keys] of [['nodes',['label','detail']],['evidence',['excerpt','title']],['verify.sources',['title']]]){
   const rows=list.split('.').reduce((v,k)=>v?.[k],value);for(const [i,row] of (Array.isArray(rows)?rows:[]).entries())for(const key of keys)add(list+'.'+i+'.'+key,row?.[key]);
  }return out;
 }
 function apply(value,text){const copy=JSON.parse(JSON.stringify(value));for(const [key,v] of Object.entries(text)){const parts=key.split('.'),last=parts.pop();let target=copy;for(const p of parts)target=target?.[p];if(target&&typeof target[last]==='string')target[last]=v;}return copy;}
 function units(data){
  const out=new Map(),source=data.source,session=data.session||{};
  out.set('overview',{title:source?.title||session.title||'',goal:source?.board?.goal||''});
  for(const m of source?.board?.modules||[])out.set('module:'+m.id,m);
  if(session.summary)out.set('recap',{summary:session.summary});
  if(session.liveConfirmation)out.set('confirmation:'+session.liveConfirmation.id,session.liveConfirmation);
  for(const s of session.factchecks||[])if(!s.stale)out.set('signal:'+s.id,s);
  const live=session.nativeInsights;[live?.suggestion,...(live?.insights||[])].filter(Boolean).forEach((s,i)=>out.set('native:'+i,s));return out;
 }
 function create({request,onChange,storage}){
  const cache=new Map(),queue=[];let active=0,meeting='',global='zh',overrides={};
  function configure(id,lang){if(meeting!==id){meeting=id;try{overrides=JSON.parse(storage?.getItem('tht-content-lang:'+id)||'{}');}catch{overrides={};}}else if(global!==lang){overrides={};save();}global=lang;}
  function save(){try{storage?.setItem('tht-content-lang:'+meeting,JSON.stringify(overrides));}catch{}}
  function desired(key){return overrides[key]||global;}
  function toggle(key){overrides[key]=desired(key)==='en'?'zh':'en';save();onChange();}
  function cacheKey(key,value,lang){return JSON.stringify([meeting,key,lang,fields(value)]);}
  function originalLanguage(text){return /[\u3400-\u9fff]/.test(Object.values(text).join(''))?'zh':'en';}
  function pump(){while(active<2&&queue.length){const task=queue.shift();active++;request(task.body).then(reply=>{if(!reply.text||typeof reply.text!=='object')throw Error('Invalid translation');task.entry.text=reply.text;task.entry.state='ready';}).catch(e=>{task.entry.state='failed';task.entry.error=e.message;}).finally(()=>{active--;onChange();pump();});}}
  function view(key,value){const lang=desired(key),text=fields(value);if(!Object.keys(text).length||originalLanguage(text)===lang)return {value,state:'original',lang};const k=cacheKey(key,value,lang);let entry=cache.get(k);if(!entry){entry={state:'loading'};cache.set(k,entry);queue.push({entry,body:{id:meeting,action:'translate-display',unit:key,lang,text}});pump();if(cache.size>160)for(const [old,item]of cache){if(item.state!=='loading'){cache.delete(old);break;}}}return {value:entry.state==='ready'?apply(value,entry.text):value,state:entry.state,lang,error:entry.error};}
  function retry(key,value){cache.delete(cacheKey(key,value,desired(key)));onChange();}
  return {configure,desired,toggle,view,retry};
 }
 return {fields,apply,units,create};
});
