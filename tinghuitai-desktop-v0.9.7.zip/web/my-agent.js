'use strict';
(()=>{
 if(window.__thtMyAgent)return;window.__thtMyAgent=true;
 const nested=parent!==window,params=new URLSearchParams(location.search);
 if(nested){
  window.myAgentAsk=(quote,question='',meta={})=>parent.postMessage({type:'tht-agent-ask',quote,question,meta},location.origin);
  window.claudeAssistantAsk=window.myAgentAsk;
  const button=document.createElement('button');button.className='ma-selection';button.hidden=true;document.body.append(button);let quote='';
  document.addEventListener('mouseup',()=>{const selection=getSelection();quote=String(selection||'').trim().slice(0,4000);button.hidden=!quote;if(!quote)return;const r=selection.getRangeAt(0).getBoundingClientRect();button.textContent=localStorage.getItem('tht-board-lang')==='en'?'Ask MyAgent':'跟 MyAgent 说';button.style.top=Math.max(8,r.top-40)+'px';button.style.left=Math.min(r.left,innerWidth-150)+'px';});
  button.onpointerdown=e=>e.preventDefault();button.onclick=()=>{button.hidden=true;window.myAgentAsk(quote,'',{view:location.hash,page:location.pathname});};document.addEventListener('keydown',e=>{if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();parent.postMessage({type:'tht-agent-open'},location.origin);}});return;
 }
 const en=()=>localStorage.getItem('tht-board-lang')==='en',tr=(z,e)=>en()?e:z;
 const make=(tag,text='',cls='')=>{const n=document.createElement(tag);n.textContent=text;if(cls)n.className=cls;return n;};
 const auth=()=>{if(window.THT_BOOT?.relayToken)return window.THT_BOOT.relayToken;try{return JSON.parse(localStorage.getItem('tht-settings')||'{}').relayToken||'';}catch{return '';}};
 const address=p=>p+'?token='+encodeURIComponent(auth());
 function openMeeting(id,atSec=0,moduleId=''){if(!id)return false;const at=Number(atSec)>0?Number(atSec):0;if(typeof window.thtOpenMeeting==='function')window.thtOpenMeeting(id,at,moduleId);else{const url=new URL('/tinghuitai/',location.href);url.searchParams.set('id',id);if(moduleId)url.searchParams.set('module',moduleId);if(at)url.hash='t='+at;location.assign(url.href);}return true;}
 function errorText(error,canRetry=false){
  const message=String(error?.message||error||'');
  if(/Failed to fetch|Load failed|NetworkError|fetch failed|disconnected|retrying|timeout|timed out|aborted|连接暂时中断|Connection interrupted/i.test(message))return canRetry?tr('连接暂时中断；消息已保留，可以重试。','Connection interrupted. Your message is kept; you can retry.'):tr('连接暂时中断，正在重新连接。','Connection interrupted. Reconnecting.');
  return message;
 }
 async function api(body,path='/workspace-assistant'){
  const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),20000);
  try{
   let r;try{r=await fetch(address(path),{signal:controller.signal,cache:'no-store',...(body?{method:'POST',headers:{'Content-Type':'application/json','x-tht-token':auth()},body:JSON.stringify(body)}:{})});}
   catch(error){throw Object.assign(Error(errorText(error)),{transport:true});}
   const j=await r.json();if(!r.ok)throw Error(j.error||'HTTP '+r.status);return j;
  }finally{clearTimeout(timeout);}
 }
 const panel=make('aside','','ma-panel'),fab=make('button','✦ MyAgent','ma-fab'),dock=make('div','','ma-dock');
 panel.id='myagent-panel';panel.hidden=true;panel.setAttribute('aria-label','MyAgent');
 panel.innerHTML='<header class="ma-head"><div><strong>MyAgent</strong><small class="ma-connection"></small></div><div><details class="ma-options"><summary aria-label="More">···</summary><label><input type="checkbox" class="ma-develop"> 开发反馈</label><label><input type="checkbox" class="ma-intake"> 接收 Slack / 飞书任务</label><small class="ma-intake-status"></small><small class="ma-intake-status">Slack 使用 search:read；完整线程需对应的 channels:history / groups:history / im:history。只接一对一私聊。</small><button type="button" class="ma-intake-scan">检查新任务</button></details><button type="button" class="ma-close" aria-label="Close">×</button></div></header><div class="ma-conversation" aria-live="polite" aria-relevant="additions text"></div><form class="ma-form"><div class="ma-quote-wrap" hidden><blockquote class="ma-quote"></blockquote><button type="button" class="ma-clear-quote" aria-label="Clear quote">×</button></div><textarea maxlength="4000" rows="2"></textarea><div class="ma-materials"></div><input class="ma-file" type="file" accept=".txt,.md,.csv,.json,.png,.jpg,.jpeg,.webp" multiple hidden><div class="ma-controls"><div class="ma-tools"><button type="button" class="ma-add" aria-label="补充材料">＋</button><select class="ma-model" aria-label="模型"><option value="">默认模型</option></select><button type="button" class="ma-voice" aria-label="语音输入"></button></div><button type="submit" class="ma-send" aria-label="Send">↑</button></div><div class="ma-help-row"><small class="ma-hint"></small><details class="ma-model-info"><summary></summary><p></p></details></div><small class="ma-status" role="status"></small></form>';
 const ownerCard=make('section','','ma-owner-card');ownerCard.hidden=true;panel.querySelector('.ma-conversation').before(ownerCard);
 document.body.append(panel,dock);if(!document.getElementById('b-assistant'))document.body.append(fab);
 const $=s=>panel.querySelector(s),input=$('textarea');let quote='',object={},jobs=[],localJobs=[],developAllowed=false,streamController,retryTimer,connected=false,materials=[],uploading=false,recognition=null,connectionError=false;
 const modelSelect=$('.ma-model');let modelCatalog=[],modelError=false;const rememberedModel=localStorage.getItem('tht-agent-model')||'';if(rememberedModel){const option=make('option',rememberedModel);option.value=rememberedModel;modelSelect.append(option);}modelSelect.value=rememberedModel;
 try{
  const saved=JSON.parse(sessionStorage.getItem('tht-agent-composer')||'{}');input.value=saved.text||'';quote=saved.quote||'';object=saved.object||{};materials=Array.isArray(saved.materials)?saved.materials.slice(0,5):[];
  localJobs=(saved.pending||[]).filter(j=>j.payload?.requestId&&j.composer).map(j=>({...j,id:'local-'+j.payload.requestId,state:'failed',error:tr('上次发送的结果尚未确认；可以重试查询。','Previous delivery is unconfirmed; retry to check.'),events:[]}));
 }catch{}
 let ownerLoaded=false;
 async function greetOwner(){
  if(ownerLoaded)return;
  try {const state=await api(null,'/setup');ownerLoaded=true;if(!state.ownerProfile?.needsName)return;
   ownerCard.replaceChildren();ownerCard.hidden=false;const label=make('strong',tr('怎么称呼你？','What should I call you?')),name=make('input'),row=make('div');name.maxLength=80;name.placeholder=tr('你的称呼','Your name');name.setAttribute('aria-label',tr('你的称呼','Your name'));
   const save=make('button',tr('记住这个称呼','Remember my name')),skip=make('button',tr('先跳过','Skip for now')),status=make('small','','ma-owner-status');save.type=skip.type='button';status.setAttribute('role','status');status.setAttribute('aria-live','polite');row.append(save,skip);ownerCard.append(label,name,row,status);
   let saving=false;
   async function submit(value){
    if(saving)return;saving=true;name.disabled=save.disabled=skip.disabled=true;ownerCard.setAttribute('aria-busy','true');status.classList.remove('ma-owner-error');status.textContent=tr('正在保存…','Saving…');
    try{const result=await api(value,'/setup/owner');if(result.ownerProfile?.needsName!==false)throw Error(result.ownerProfile?.needsName===true?tr('请换一个称呼，或选择先跳过。','Choose another name, or Skip for now.'):tr('称呼未保存，请重试。','Your name was not saved. Please retry.'));
     status.textContent=value.skip?tr('已跳过，不影响使用。','Skipped. You can continue.'):tr('已记住，','Got it, ')+result.ownerProfile.displayName;
     ownerCard.replaceChildren(status);setTimeout(()=>{ownerCard.hidden=true;},2500);
    }catch(e){name.disabled=save.disabled=skip.disabled=false;status.classList.add('ma-owner-error');status.textContent=errorText(e);}
    finally{saving=false;ownerCard.setAttribute('aria-busy','false');}
   }
   save.onclick=()=>{if(name.value.trim())submit({displayName:name.value.trim()});else{status.classList.add('ma-owner-error');status.textContent=tr('请填写称呼，或选择先跳过。','Enter a name, or choose Skip for now.');name.focus();}};skip.onclick=()=>submit({skip:true});name.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();save.click();}};
  }catch{} // A local profile is optional; connector login is independent.
 }
 function composer(){return {text:input.value.trim(),quote,object,materials,model:modelSelect.value,develop:$('.ma-develop').checked};}
 function sameDraft(entry){return JSON.stringify(composer())===JSON.stringify(entry.composer);}
 function persist(){sessionStorage.setItem('tht-agent-composer',JSON.stringify({text:input.value,quote,object,materials,pending:localJobs.map(({comment,quote,payload,composer})=>({comment,quote,payload,composer}))}));}
 function resizeComposer(){input.style.height='auto';input.style.height=Math.max(48,Math.min(144,input.scrollHeight))+'px';$('.ma-send').disabled=uploading||!input.value.trim();}
 function clearComposer(){input.value='';quote='';object={};materials=[];showMaterials();showQuote();resizeComposer();persist();}
 function voiceIcon(listening=false){
  const button=$('.ma-voice');button.innerHTML=listening?'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="7" y="7" width="10" height="10" rx="2" fill="currentColor"/></svg>':'<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><rect x="9" y="3" width="6" height="12" rx="3"/><path d="M6 10v2a6 6 0 0 0 12 0v-2M12 18v3M9 21h6"/></svg>';
  button.setAttribute('aria-pressed',String(listening));button.setAttribute('aria-label',listening?tr('结束听写','Stop dictation'):tr('语音输入','Voice input'));button.title=listening?tr('结束听写，检查后发送','Stop dictation, review then send'):tr('语音输入','Voice input');
 }
 const effortName=e=>({none:tr('无','none'),low:tr('低','low'),medium:tr('中度','medium'),high:tr('高','high'),xhigh:tr('更高','extra high'),max:tr('最高','maximum'),ultra:tr('超高','ultra')})[e]||e||tr('模型默认','model default');
 function modelName(m){return String(m?.name||m?.id||'').replace(/(GPT-[\d.]+)-/,'$1 ');}
 function modelDescription(m){const descriptions={
  'Latest workhorse model for coding and everyday work.':'适合代码开发与日常工作。',
  'Frontier intelligence for the most demanding work.':'用于要求较高的复杂工作。',
  'Previous generation workhorse model.':'上一代通用工作模型。',
  'Fast and affordable model for easier tasks.':'适合较简单的任务，侧重速度与较低用量。',
  'Older generation workhorse model.':'较早一代的通用工作模型。',
  'Older balanced model for straightforward work.':'较早一代的均衡模型，适合直接明确的任务。',
  'Older fast and efficient model.':'较早一代的快速模型。'
 };return en()?m.description||'':descriptions[m.description]||m.description||'';}
 function sizeModel(){
  const current=modelCatalog.find(m=>modelSelect.value?m.id===modelSelect.value:m.isDefault),first=modelSelect.options[0];
  first.textContent=current&& !modelSelect.value?modelName(current)+' · '+tr('默认','default'):modelCatalog.find(m=>m.isDefault)?modelName(modelCatalog.find(m=>m.isDefault))+' · '+tr('默认','default'):tr(modelError?'默认模型（待确认）':'读取默认模型…',modelError?'Default (unconfirmed)':'Loading default…');
  const detail=$('.ma-model-info'),fullText=current?[!modelSelect.value?(current.provider==='api'?tr('默认使用已配置的模型 API。','Default uses your configured model API.'):tr('默认跟随本机 Codex 配置。','Default follows your local Codex configuration.')):'',modelName(current)+(current.provider==='api'?'':' · '+effortName(current.reasoningEffort)+tr('推理。',' reasoning.')),modelDescription(current),tr('切换用于后续消息；正在执行的任务保持原模型。','Changes apply to future messages; running tasks keep their model.'),tr('手选模型启动失败时会报错，不会悄悄换模型；默认模式的备用调用会显示在过程里。','A selected model failure is reported without substitution. Default-mode fallback is shown in Activity.')].filter(Boolean).join(' '):modelSelect.value?tr('所选模型的信息暂未确认；发送时仍使用你的选择，启动失败会报错，不会换成默认模型。','Selected model information is unconfirmed. Your selection is kept; startup failure is reported without substitution.'):tr(modelError?'模型信息暂不可用；发送时会重新读取本机配置，不猜测模型。':'正在读取本机 Codex 的模型与推理配置。',modelError?'Model information unavailable. Configuration is read again when sending.':'Reading your local Codex model and reasoning settings.');
  const text=current?[modelDescription(current),tr('切换仅用于后续消息。','Changes apply to future messages.')].filter(Boolean).join(' '):tr('模型信息待确认；保留当前选择。','Model info pending; your selection is kept.');
  detail.querySelector('summary').textContent=current?(current.provider==='api'?'API · '+tr('说明','Info'):effortName(current.reasoningEffort)+tr('推理 · 说明',' reasoning · Info')):tr('模型说明','Model info');detail.querySelector('p').textContent=text;
  const selected=modelSelect.selectedOptions[0];modelSelect.style.width=Math.min(164,Math.max(84,(selected?.textContent.length||4)*7+27))+'px';modelSelect.title=fullText;modelSelect.setAttribute('aria-label',tr('选择模型：','Select model: ')+(selected?.textContent||''));
 }

 function showQuote(){$('.ma-quote-wrap').hidden=!quote;$('.ma-quote').textContent=quote;}
 function language(){input.setAttribute('aria-label',tr('给 MyAgent 发消息','Message MyAgent'));input.placeholder=tr('问点什么，或者交给我做…','Ask anything, or give me a task…');$('.ma-hint').textContent=tr('↵ 发送 · Shift ↵ 换行','↵ Send · Shift ↵ New line');$('.ma-send').setAttribute('aria-label',tr('发送','Send'));$('.ma-close').setAttribute('aria-label',tr('收起','Close'));$('.ma-clear-quote').setAttribute('aria-label',tr('取消引用','Clear quote'));voiceIcon(!!recognition);sizeModel();$('.ma-connection').textContent=connected?tr('实时连接已就绪','Live connection ready'):tr('连接中…','Reconnecting…');}
 const seen=new Map();try{const entries=JSON.parse(localStorage.getItem('tht-intake-seen')||'[]');if(Array.isArray(entries))for(const e of entries)if(Array.isArray(e)&&e.length===2)seen.set(e[0],e[1]);}catch{}
 const unseen=j=>j.origin&&j.finished&&seen.get(j.id)!==j.finished;
 function markSeen(){for(const j of jobs)if(j.origin)seen.set(j.id,j.finished);localStorage.setItem('tht-intake-seen',JSON.stringify([...seen].slice(-100)));}
 function open(){greetOwner();markSeen();panel.hidden=false;document.body.classList.add('myagent-open');fab.hidden=true;dock.hidden=true;sessionStorage.setItem('tht-agent-open','1');document.getElementById('b-assistant')?.setAttribute('aria-expanded','true');language();showQuote();resizeComposer();input.focus();refresh();}
 function close(){panel.hidden=true;document.body.classList.remove('myagent-open');fab.hidden=false;dock.hidden=false;sessionStorage.setItem('tht-agent-open','0');document.getElementById('b-assistant')?.setAttribute('aria-expanded','false');}
 window.myAgentOpen=open;
 window.myAgentAsk=(selected,question='',meta={})=>{quote=String(selected||'').slice(0,4000);object=meta;persist();open();if(question){input.value=question;send();}};
 window.claudeAssistantAsk=window.myAgentAsk;
 input.oninput=()=>{resizeComposer();persist();};
 $('.ma-close').onclick=close;fab.onclick=open;
 $('.ma-clear-quote').onclick=()=>{quote='';object={};showQuote();persist();};
 const active=j=>['queued','running','retrieving','syncing','thinking','planning','stopping','executing'].includes(j.state);
 window.thtAgentBusy=()=>!!(uploading||recognition||input.value.trim()||quote||materials.length||localJobs.length||jobs.some(j=>active(j)||['awaiting_confirmation','uncertain'].includes(j.state)));
 const status=j=>j.state==='queued'?tr(j.id.startsWith('local-')?'提交中…':'已收到',j.id.startsWith('local-')?'Sending…':'Received'):j.state==='stopping'?tr('正在停止…','Stopping…'):j.events?.at(-1)?.message||tr('正在处理…','Working…');
 // Old transport envelopes remain readable without changing saved history.
 function answerBody(text){
  const raw=String(text||''),json=raw.trim().replace(/^```(?:json)?\s*\n([\s\S]*?)\n```$/,'$1');
  try{const value=JSON.parse(json);if(value&&typeof value.reply==='string'&&Object.keys(value).every(k=>['reply','action'].includes(k)))return value.reply;}catch{}
  return raw;
 }
 function rich(text){
  const box=make('div','','ma-answer'),lines=answerBody(text).split('\n');let list=null;
  function inline(n,line){
   let at=0;
   for(const m of line.matchAll(/\[([^\]]+)\]\(([^\s)]+)\)|\*\*([^*]+)\*\*|`([^`]+)`/g)){
    n.append(document.createTextNode(line.slice(at,m.index)));
    if(m[1]){let url;try{url=new URL(m[2],location.href);}catch{}if(url&&['http:','https:','codex:'].includes(url.protocol)&&!url.username&&!url.password){const a=make('a',m[1]);a.href=url.href;a.rel='noopener noreferrer';a.onclick=e=>{if(url.origin===location.origin&&url.searchParams.has('id')&&/\/tinghuitai\/(?:index\.html|meeting-board\.html)?$/.test(url.pathname)&&openMeeting(url.searchParams.get('id'),Number((url.hash.match(/t=([\d.]+)/)||[])[1]||0),url.searchParams.get('module')||'')){e.preventDefault();}};n.append(a);}else n.append(document.createTextNode(m[0]));}
    else n.append(make(m[3]?'strong':'code',m[3]||m[4]));at=m.index+m[0].length;
   }n.append(document.createTextNode(line.slice(at)));
  }
  const cells=line=>line.trim().replace(/^\||(?<!\\)\|$/g,'').split(/(?<!\\)\|/).map(x=>x.trim().replace(/\\\|/g,'|'));
  for(let i=0;i<lines.length;i++){
   const raw=lines[i];if(!raw.trim()){list=null;continue;}
   const fence=/^\s*(`{3,}|~{3,})([\w+-]*)\s*$/.exec(raw);
   if(fence){list=null;const code=[];while(++i<lines.length&&!new RegExp('^\\s*'+fence[1][0]+'{'+fence[1].length+',}\\s*$').test(lines[i]))code.push(lines[i]);const pre=make('pre');pre.append(make('code',code.join('\n')));box.append(pre);continue;}
   const header=cells(raw),divider=cells(lines[i+1]||'');
   if(raw.includes('|')&&header.length>1&&divider.length===header.length&&divider.every(x=>/^:?-{3,}:?$/.test(x))){
    list=null;const wrap=make('div','','ma-table'),table=make('table'),head=make('thead'),row=make('tr'),body=make('tbody');
    for(const value of header){const cell=make('th');inline(cell,value);row.append(cell);}head.append(row);table.append(head,body);i++;
    while(i+1<lines.length&&lines[i+1].trim()&&lines[i+1].includes('|')){const row=make('tr'),values=cells(lines[++i]);for(let c=0;c<header.length;c++){const cell=make('td');inline(cell,values[c]||'');row.append(cell);}body.append(row);}wrap.append(table);box.append(wrap);continue;
   }
   const bullet=/^\s*[-*+] (.*)$/.exec(raw),ordered=/^\s*(\d+)[.)] (.*)$/.exec(raw),heading=/^(#{1,6}) (.*)$/.exec(raw),quoted=/^>\s?(.*)$/.exec(raw);
   if(bullet||ordered){const type=ordered?'ol':'ul';if(!list||list.tagName.toLowerCase()!==type){list=make(type);if(ordered)list.start=Number(ordered[1]);box.append(list);}const n=make('li');inline(n,ordered?ordered[2]:bullet[1]);list.append(n);}
   else{list=null;const n=make(heading?'h'+Math.min(heading[1].length+1,4):quoted?'blockquote':'p');inline(n,heading?heading[2]:quoted?quoted[1]:raw);box.append(n);}
  }return box;
 }
 async function command(job,action){try{const body={action,jobId:job.id,...(action==='confirm'?{confirmed:true}:{})};const path=job.meetingId&&job.meetingId!=='assistant:global'?'/meeting-board':'/workspace-assistant';if(path==='/meeting-board')body.id=job.meetingId;const result=await api(body,path);upsert(result.job);}catch(e){$('.ma-status').textContent=e.message;}}
 function codexThreadLink(id){if(typeof id!=='string'||!id.trim())return null;const a=make('a',tr('在 Codex 中打开 ↗','Open in Codex ↗'));a.href='codex://threads/'+encodeURIComponent(id.trim());a.rel='noopener noreferrer';return a;}
 function row(job){
  const article=make('article','','ma-job');article.dataset.job=job.id;
  if(job.origin){const label=make('small',(job.error?tr('任务来源 · ','Assignment · '):tr('已准备 · ','Prepared · '))+(job.origin.provider==='lark'?tr('飞书','Lark'):'Slack'),'ma-muted');article.append(label);if(job.origin.url){const a=make('a',tr('任务原消息 ↗','Original assignment ↗'),'ma-result');let url;try{url=new URL(job.origin.url);}catch{}if(url&&url.protocol==='https:'&&!url.username&&!url.password){a.href=url.href;a.target='_blank';a.rel='noopener noreferrer';article.append(a);}}}
  if(job.assignmentSourceId){const b=make('button',tr('打开草稿','Open draft'),'ma-result');b.onclick=()=>{if(window.thtOpenWorkbench)window.thtOpenWorkbench('sources',false,job.assignmentSourceId);else location.href='./work.html#sources&source='+encodeURIComponent(job.assignmentSourceId);close();};article.append(b);if(job.error){const retry=make('button',tr('重新准备','Retry draft'),'ma-result');retry.onclick=()=>api({action:'retry',sourceId:job.assignmentSourceId},'/assigned-work').then(()=>refresh()).catch(e=>{$('.ma-status').textContent=e.message;});article.append(retry);}}
  if(job.comment)article.append(make('p',job.comment,'ma-user'));
  if(job.quote){const reference=make('details','','ma-reference');reference.append(make('summary',tr('引用的内容','Quoted context')),make('blockquote',job.quote));article.append(reference);}
  if(job.reply)article.append(rich(job.reply));
  if(active(job)){const progress=make('div','','ma-progress');progress.append(make('span',status(job)));if(job.id&&!job.id.startsWith('local-')&&!['executing','stopping'].includes(job.state)){const stop=make('button',tr('停止','Stop'));stop.onclick=()=>command(job,'cancel');progress.append(stop);}article.append(progress);}
  if(job.state==='cancelled')article.append(make('small',tr('已停止','Stopped'),'ma-muted'));
  if(job.state==='preview')article.append(make('small',tr('预览已生成，等待测试与审核','Preview ready, awaiting tests and review'),'ma-muted'));
  if(job.action==='project-draft'&&['failed','interrupted'].includes(job.state)){const b=make('button',tr('重试成果','Retry draft'),'ma-result');b.onclick=()=>api({id:job.meetingId,action:'artifact-retry',jobId:job.id},'/meeting-board').then(()=>refresh()).catch(e=>{$('.ma-status').textContent=e.message;});article.append(b);}
  if(job.error){const error=make('div','','ma-error');error.append(make('span',errorText(job.error,!!job.payload)));if(job.payload&&job.state==='failed'){const retry=make('button',tr('重试发送','Retry'),'ma-retry');retry.type='button';retry.onclick=()=>submit(job);error.append(retry);}article.append(error);}
  if(job.codexSyncError)article.append(make('small',errorText(job.codexSyncError),'ma-muted'));
  if(job.events?.length||job.codexThreadId){const details=make('details','','ma-activity');details.append(make('summary',tr('过程与来源','Activity & source')));for(const e of job.events||[])details.append(make('p',e.message));if(job.model)details.append(make('p',tr('Codex 会话模型：','Codex conversation model: ')+job.model+' · '+effortName(job.effort)));if(job.codexThreadId){details.append(codexThreadLink(job.codexThreadId));}article.append(details);}
  if(job.resultIds?.length&&(job.contextId||job.meetingId)){const b=make('button',tr('查看成果 ↗','Open result ↗'),'ma-result');b.onclick=()=>openMeeting(job.resultContextId||job.contextId||job.meetingId,0,job.resultIds[0]);article.append(b);}
  if(job.state==='awaiting_confirmation'){
   article.append(make('p',String(job.proposal?.args?.text||job.proposal?.args?.body||job.proposal?.description||job.proposal?.name||''),'ma-proposal'));
   for(const [action,label]of [['confirm',tr('确认执行','Confirm')],['cancel',tr('取消','Cancel')]]){const b=make('button',label);b.onclick=()=>command(job,action);article.append(b);}
  }return article;
 }
 function render(){
  const conv=$('.ma-conversation'),bottom=conv.scrollHeight-conv.scrollTop-conv.clientHeight<70,top=conv.scrollTop,all=[...jobs,...localJobs];
  const previous=new Map([...conv.querySelectorAll('.ma-job')].map(n=>[n.dataset.job,n]));
  if(!all.length){conv.replaceChildren(make('div',tr('查找资料，把想法做出来。','Find what you need. Make an idea real.'),'ma-empty'));}
  else{conv.querySelector('.ma-empty')?.remove();for(const j of all){const old=previous.get(j.id),signature=JSON.stringify({...j,payload:undefined,composer:undefined});if(old?.dataset.signature===signature){previous.delete(j.id);continue;}const fresh=row(j);fresh.dataset.signature=signature;for(const cls of ['.ma-activity','.ma-reference'])if(old?.querySelector(cls)?.open&&fresh.querySelector(cls))fresh.querySelector(cls).open=true;if(old)old.replaceWith(fresh);else conv.append(fresh);previous.delete(j.id);}for(const n of previous.values())n.remove();}
  conv.scrollTop=bottom?conv.scrollHeight:top;
  dock.replaceChildren();for(const j of all.filter(j=>active(j)||unseen(j)).slice(-3)){const b=make('button','','ma-task');b.append(make('span','◌','ma-orbit'),make('span',(j.comment||j.reply||tr('正在准备成果','Preparing a draft')).slice(0,24)));b.title=status(j);b.onclick=()=>{open();panel.querySelector('[data-job="'+CSS.escape(j.id)+'"]')?.scrollIntoView({block:'center'});};dock.append(b);}dock.hidden=!panel.hidden;
  const count=all.filter(j=>active(j)||unseen(j)).length;fab.textContent='✦ MyAgent'+(count?' · '+count:'');
 }
 function reconcile(job){
  if(!job?.requestId)return;
  const entry=localJobs.find(j=>j.payload?.requestId===job.requestId);if(!entry)return;
  localJobs=localJobs.filter(j=>j!==entry);if(sameDraft(entry))clearComposer();else persist();
 }
 function upsert(job){if(!job)return;reconcile(job);const index=jobs.findIndex(j=>j.id===job.id);if(index<0)jobs.push(job);else jobs[index]=job;if(!panel.hidden)markSeen();render();}
 function recovered(){if(connectionError){$('.ma-status').textContent='';connectionError=false;}}
 async function intakeStatus(){try{const s=await api(null,'/assigned-work');$('.ma-intake').checked=s.enabled;$('.ma-intake-status').textContent=s.enabled?(s.channels.length?s.channels.map(c=>(c.provider==='lark'?'飞书':'Slack')+(c.status==='ready'?(Object.values(c.flows||{}).some(f=>f.emptyRuns>=3&&f.lastHits===0)?'已连接；暂无新消息':'已连接'):'：'+c.error)).join(' · '):tr('等待连接检查','Awaiting connection check')):tr('未启用；从启用时开始接收','Disabled; starts with new messages');}catch(e){$('.ma-intake-status').textContent=errorText(e);}}
 $('.ma-intake').onchange=async e=>{try{await api({action:'enable',enabled:e.target.checked},'/assigned-work');if(e.target.checked)await api({action:'scan'},'/assigned-work');await intakeStatus();}catch(err){$('.ma-intake-status').textContent=errorText(err);}};
 $('.ma-intake-scan').onclick=async e=>{e.target.disabled=true;try{await api({action:'scan'},'/assigned-work');$('.ma-intake-status').textContent=tr('正在检查；草稿准备好会显示在这里。','Checking; drafts will appear here.');}catch(err){$('.ma-intake-status').textContent=errorText(err);}finally{e.target.disabled=false;}};
 $('.ma-options').ontoggle=()=>{if($('.ma-options').open)intakeStatus();};
 async function refresh(){try{jobs=(await api()).jobs||[];jobs.forEach(reconcile);if(!panel.hidden)markSeen();recovered();render();}catch(error){if(!$('.ma-status').textContent||connectionError){connectionError=true;$('.ma-status').textContent=errorText(error);}}}
 async function submit(entry){
  if(entry.submitting)return;entry.submitting=true;entry.state='queued';delete entry.error;
  if(sameDraft(entry))clearComposer();persist();render();$('.ma-status').textContent='';
  try{const result=await api(entry.payload);localJobs=localJobs.filter(j=>j!==entry);persist();upsert(result.job);}
  catch(error){
   // The stream may have delivered the receipt before the POST response was lost.
   if(jobs.some(j=>j.requestId===entry.payload.requestId))return;
   entry.state='failed';entry.error=errorText(error,true);
   if(!input.value.trim()&&!quote&&!materials.length){const saved=entry.composer;input.value=saved.text;quote=saved.quote;object=saved.object;materials=saved.materials;modelSelect.value=saved.model;showMaterials();showQuote();sizeModel();resizeComposer();}
   persist();render();
  }finally{entry.submitting=false;}
 }
 async function send(){
  const text=input.value.trim();if(!text||uploading)return;
  const previous=localJobs.find(j=>j.state==='failed'&&sameDraft(j));if(previous){await submit(previous);return;}
  const requestId=crypto.randomUUID(),contextId=object.contextId||sessionStorage.getItem('tht-selected-meeting')||'';
  const pageContext={page:object.page||location.pathname,view:object.view||location.hash,projectId:object.projectId||'',objectId:object.objectId||'',sourceIds:object.sourceIds||[],quote};
  const snapshot=JSON.parse(JSON.stringify(composer()));
  const payload={action:snapshot.develop?'develop':'auto',comment:text,requestId,contextId,pageContext,lang:en()?'en':'zh',model:snapshot.model,materialIds:snapshot.materials.map(m=>m.id)};
  const entry={id:'local-'+requestId,comment:text,quote,state:'queued',events:[],payload,composer:snapshot};localJobs.push(entry);await submit(entry);
 }
 function showMaterials(){const host=$('.ma-materials');host.replaceChildren();for(const item of materials){const b=make('button',item.name+' ×');b.type='button';b.onclick=()=>{materials=materials.filter(m=>m!==item);showMaterials();persist();};host.append(b);}}
 $('.ma-add').onclick=()=>$('.ma-file').click();
 $('.ma-file').onchange=async()=>{const files=[...$('.ma-file').files];$('.ma-file').value='';if(materials.length+files.length>5){$('.ma-status').textContent=tr('一次最多 5 份材料','Up to 5 attachments');return;}uploading=true;$('.ma-send').disabled=true;$('.ma-status').textContent=tr('正在补充材料…','Adding attachments…');try{for(const file of files){if(file.size>5*1024*1024)throw Error(tr('材料超过 5 MB','Attachment exceeds 5 MB'));const base64=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result).split(',')[1]);reader.onerror=()=>reject(Error('读取失败'));reader.readAsDataURL(file);});const result=await api({name:file.name,base64},'/workspace-assistant/materials');materials.push(result.material);showMaterials();persist();}$('.ma-status').textContent='';}catch(e){$('.ma-status').textContent=e.message;}finally{uploading=false;resizeComposer();}};
 modelSelect.onchange=()=>{localStorage.setItem('tht-agent-model',modelSelect.value);sizeModel();persist();};
 api(null,'/workspace-assistant/models').then(j=>{const selected=localStorage.getItem('tht-agent-model')||'';modelCatalog=j.models||[];while(modelSelect.options.length>1)modelSelect.remove(1);for(const m of modelCatalog){if(!m.id)continue;const option=make('option',modelName(m));option.value=m.id;option.title=modelDescription(m);modelSelect.append(option);}if(selected&&!modelCatalog.some(m=>m.id===selected)){const option=make('option',selected+' · '+tr('待确认','unconfirmed'));option.value=selected;modelSelect.append(option);}modelSelect.value=selected;sizeModel();}).catch(()=>{modelError=true;sizeModel();});
 const Speech=window.SpeechRecognition||window.webkitSpeechRecognition;
 $('.ma-voice').onclick=()=>{if(recognition){recognition.stop();return;}if(!Speech){$('.ma-status').textContent=tr('此浏览器不支持语音输入，可用 macOS 听写输入。','Use macOS Dictation in this browser.');input.focus();return;}
  const r=new Speech();recognition=r;r.lang=en()?'en-US':'zh-CN';r.interimResults=true;const original=input.value;
  r.onresult=e=>{input.value=original+Array.from(e.results).map(x=>x[0].transcript).join('');resizeComposer();persist();};r.onerror=e=>{$('.ma-status').textContent=tr('语音输入未成功：','Voice input failed: ')+e.error;};r.onend=()=>{recognition=null;voiceIcon();if(!$('.ma-status').textContent.includes(tr('未成功','failed')))$('.ma-status').textContent=input.value.trim()?tr('听写结束，检查后发送。','Dictation finished. Review, then send.'):'';};
  try{r.start();voiceIcon(true);$('.ma-status').textContent=tr('正在听写 · 由浏览器语音服务识别，结束后发送','Dictating via browser speech service; send when ready');}catch(e){recognition=null;$('.ma-status').textContent=e.message;}
 };
 $('.ma-form').onsubmit=e=>{e.preventDefault();send();};
 input.onkeydown=e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing&&e.keyCode!==229){e.preventDefault();send();}};
 $('.ma-develop').onchange=async()=>{try{await api({developerPreviewEnabled:$('.ma-develop').checked},'/workspace-assistant/preferences');developAllowed=$('.ma-develop').checked;$('.ma-status').textContent=tr(developAllowed?'开发预览已开启，测试与审核后才安装。':'开发预览已关闭。',developAllowed?'Preview changes enabled. Installation follows tests and review.':'Development preview off.');}catch(e){$('.ma-develop').checked=false;$('.ma-status').textContent=e.message;}};
 api(null,'/workspace-assistant/preferences').then(j=>{developAllowed=j.developerPreviewEnabled;$('.ma-develop').checked=developAllowed;}).catch(()=>{});
 async function connect(){
  clearTimeout(retryTimer);streamController?.abort();const controller=new AbortController();streamController=controller;
  try{const response=await fetch(address('/workspace-assistant/events'),{signal:controller.signal,cache:'no-store'});if(!response.ok)throw Error('HTTP '+response.status);
   connected=true;recovered();language();
   const reader=response.body.getReader(),decoder=new TextDecoder();let buffer='';
   while(true){const {value,done}=await reader.read();if(done)break;buffer+=decoder.decode(value,{stream:true});let end;
    while((end=buffer.indexOf('\n\n'))>=0){const packet=buffer.slice(0,end);buffer=buffer.slice(end+2);if(!packet.startsWith('data: '))continue;const data=JSON.parse(packet.slice(6));if(data.jobs){jobs=data.jobs;jobs.forEach(reconcile);if(!panel.hidden)markSeen();render();}if(data.job)upsert(data.job);}
   }throw Error('disconnected');
  }catch(e){if(controller.signal.aborted)return;connected=false;language();refresh();retryTimer=setTimeout(connect,3000);}
 }
 document.addEventListener('keydown',e=>{if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();panel.hidden?open():close();}if(e.key==='Escape'&&!panel.hidden)close();});
 window.addEventListener('beforeunload',()=>{persist();streamController?.abort();clearTimeout(retryTimer);});
 window.addEventListener('tht-language-change',()=>{language();for(const n of panel.querySelectorAll('[data-signature]'))delete n.dataset.signature;render();});
 language();showMaterials();showQuote();resizeComposer();render();connect();if(sessionStorage.getItem('tht-agent-open')==='1')open();
})();
