'use strict';
const $=s=>document.querySelector(s), esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const token=()=>window.THT_BOOT?.relayToken||'';
const meta=x=>[x.meeting,x.date,x.at].filter(Boolean).join(' · ');
const citation=x=>`<a class="cite" href="${esc(x.url)}"><span>${esc(x.text)}</span><small>${esc(meta(x))}</small></a>`;
let data={people:[],topics:[],evidence:[]}, tab='people';
function render(){
  const people=data.people.map(p=>`<article class="card"><h2>${esc(p.name)}</h2>${p.positions.length?`<h3>原话与立场</h3>${p.positions.slice(0,4).map(citation).join('')}`:''}${p.todos.length?`<h3>待办</h3>${p.todos.slice(0,4).map(citation).join('')}`:''}<h3>最近会议</h3>${p.meetings.slice(0,5).map(citation).join('')}</article>`).join('');
  const topics=data.topics.map(t=>`<article class="card"><h2>${esc(t.title)}</h2>${t.history.slice(0,8).map(citation).join('')}${!t.history.length?t.meetings.slice(0,6).map(citation).join(''):''}</article>`).join('');
  $('#people').innerHTML=people?`<div class="grid">${people}</div>`:'<p class="empty">没有匹配的人物。</p>';
  $('#topics').innerHTML=topics?`<div class="grid">${topics}</div>`:'<p class="empty">没有匹配的议题。</p>';
  $('#evidence').innerHTML=data.evidence.length?data.evidence.map(x=>`<article class="card">${citation(x)}</article>`).join(''):'<p class="empty">输入关键词后，这里会列出带会议、日期和时间点的跨会证据。</p>';
  for(const id of ['people','topics','evidence']) $('#'+id).hidden=id!==tab;
}
async function load(){const q=$('#q').value.trim();$('#status').textContent='正在读取本机会议…';try{const r=await fetch('/knowledge-map?token='+encodeURIComponent(token())+'&q='+encodeURIComponent(q),{cache:'no-store'});data=await r.json();if(!r.ok||!data.ok)throw Error(data.error||'读取失败');$('#status').textContent=`已核对 ${data.scanned} 场本机会议${data.unreadableFiles?'，跳过 '+data.unreadableFiles+' 个损坏文件':''}`;render();}catch(e){$('#status').textContent=e.message;}}
$('#search').onsubmit=e=>{e.preventDefault();load()};
document.querySelector('.tabs').onclick=e=>{const b=e.target.closest('[data-tab]');if(!b)return;tab=b.dataset.tab;document.querySelectorAll('.tabs button').forEach(x=>x.classList.toggle('active',x===b));render()};
load();
