'use strict';
function trimUrl(value){
 let s=value.replace(/[.,;，。；]+$/,'');
 for(const [open,close] of [['(',')'],['（','）'],['[',']']])while(s.endsWith(close)&&s.split(close).length>s.split(open).length)s=s.slice(0,-close.length);
 return s;
}
function links(description){
 const rows=[];const pattern=/https:\/\/[^\s<>"']+/g;let match;
 while((match=pattern.exec(description))){
  const raw=trimUrl(match[0]);let url;try{const u=new URL(raw);if(u.protocol!=='https:'||u.username||u.password)continue;url=u.href;}catch{continue;}
  const before=description.slice(0,match.index).split('\n').pop();
  const markdown=before.match(/\[([^\]]+)\]\($/);
  const label=markdown?.[1]||before.replace(/[（(]\s*$/,'').trim().replace(/[：:]\s*$/,'').replace(/^[-*•]\s*/,'');
  rows.push({url,title:label.slice(-100)||new URL(url).hostname});
 }
 return rows;
}
module.exports={links,trimUrl};
