'use strict';
const crypto=require('crypto'),brief=require('./premeeting-brief'),calendar=require('./calendar-preparation');
const key=e=>String(e.calendarId||'')+'\0'+String(e.eventId||'');
const fingerprint=raw=>{const e=brief.normalizeEvent(raw);return crypto.createHash('sha256').update(JSON.stringify([e.title,e.start,e.end,e.description,e.meetingUrl,e.status,e.cancelled])).digest('hex');};
function materialBinding(hub,event,now=Date.now()){
 const current=hub.data.sources.find(s=>s.calendarEvent&&key(s.calendarEvent)===key(event))||{};
 const rows=brief.materials(hub.data,current,event,{purpose:'current-work',asOf:new Date(now).toISOString()});
 return crypto.createHash('sha256').update(JSON.stringify(rows.map(r=>{const s=hub.data.sources.find(x=>x.id===r.sourceId);return {sourceId:r.sourceId,url:r.url,title:r.title,revision:r.revision,role:r.role,date:r.date,readReceipt:s?.readReceipt||null,bodyCoverage:s?.bodyCoverage||null,bodyContinuation:s?.bodyContinuation||null,bodyState:s?.bodyState||null,bodyHash:s?crypto.createHash('sha256').update(String(s.body||'')).digest('hex'):null};}))).digest('hex');
}
// Calendar attachments are explicit user-scoped inputs, not a web crawl.
function registerCalendarMaterials(hub,source,event,now){
 const {canonical}=require('./work-hub');let added=false;
 for(const row of brief.materials(hub.data,source,event,{purpose:'current-work',asOf:new Date(now).toISOString()})){
  if(row.sourceId)continue;let u;try{u=new URL(row.url);}catch{continue;}
  const lark=/(^|\.)(feishu\.cn|larksuite\.com|doubao\.com)$/.test(u.hostname)&&/^\/(docx|wiki|sheets|slides|minutes)\/[a-zA-Z0-9]+/.test(u.pathname);
  const notion=/(^|\.)(notion\.so|notion\.site|notion\.com)$/.test(u.hostname)&&/^https:\/\/www\.notion\.so\/[a-f0-9]{32}$/.test(canonical(row.url));
  const google=['docs.google.com','drive.google.com'].includes(u.hostname)&&/^\/(document|presentation|spreadsheets|file)\/d\/[a-zA-Z0-9_-]+/.test(u.pathname);
  if(u.protocol!=='https:'||u.username||u.password||u.port||!(lark||notion||google))continue;
  // Include archived records in dedup: a calendar link cannot undo a user's archive.
  if(hub.data.sources.some(s=>canonical(s.url||s.key)===canonical(row.url)))continue;
  hub.source({url:row.url,title:row.title,body:'',origin:'calendar-material',knowledgeRole:'reference',discoveredFrom:{calendarId:event.calendarId,eventId:event.eventId},bodyState:'link-only'});added=true;
 }
 if(added)hub.save();
}
class Preparation{
 constructor(){this.busy=false;}
 async tick(ctx,{now=Date.now()}={}){
  if(this.busy)return;this.busy=true;
  try{
   const agenda=await ctx.calendarAgenda();if(agenda.error||!Array.isArray(agenda.events))return;
   const receipts=ctx.hub.data.sync.preparation||{},seen=new Set(agenda.events.map(key));
   for(const [id,r]of Object.entries(receipts))if(!seen.has(id)&&r.status!=='not-listed'){r.status='not-listed';ctx.hub.save();}
   let processed=0;
   for(const rawEvent of agenda.events){
    const event=brief.normalizeEvent(rawEvent);
    const id=key(event),binding=fingerprint(event),previous=receipts[id];
    if(!event.eventId)continue;
    if(event.status==='cancelled'||event.cancelled===true){if(previous?.binding===binding&&previous.status==='cancelled')continue;receipts[id]={...previous,binding,status:'cancelled',checkedAt:now};ctx.hub.data.sync.preparation=receipts;ctx.hub.save();continue;}
    const start=Date.parse(event.start);if(!event.eventId||!Number.isFinite(start)||start<now||start>now+86400000)continue;
    const materialsBinding=materialBinding(ctx.hub,event,now),sameMaterials=previous?.materialsBinding===materialsBinding;
    if(sameMaterials&&previous?.binding===binding&&previous.status==='prepared'&&now-previous.checkedAt<3600000)continue;
    if(sameMaterials&&previous?.binding===binding&&previous.status==='partial'&&now-previous.checkedAt<900000)continue;
    if(processed>=2)continue;processed++;
    let prepared;try{prepared=await calendar.prepare(ctx,event);}catch(e){if(e.status===409)continue;receipts[id]={binding,materialsBinding,status:'partial',checkedAt:now,errors:[{error:String(e.message).slice(0,200)}]};ctx.hub.data.sync.preparation=receipts;ctx.hub.save();continue;}const {source,id:noteId}=prepared,errors=[];
    registerCalendarMaterials(ctx.hub,source,event,now);
    // Read supported calendar attachments through existing authorized adapters.
    for(const row of brief.materials(ctx.hub.data,source,event,{purpose:'current-work',asOf:new Date(Math.max(now,Date.now())).toISOString()})){
     if(!row.sourceId||row.eligible===false)continue;
     const s=ctx.hub.data.sources.find(x=>x.id===row.sourceId);let url;try{url=new URL(s.url);}catch{continue;}
     if(!/(^|\.)(feishu\.cn|larksuite\.com|doubao\.com|notion\.so|notion\.site|notion\.com)$/.test(url.hostname))continue;
     if(row.read&&row.readReceipt&&now-Date.parse(row.readReceipt.fetchedAt)<3600000)continue;
     try{await ctx.hub.fetchSource(s.id,{env:ctx.env,fetchImpl:ctx.fetchImpl});}catch(e){errors.push({sourceId:s.id,error:String(e.message).slice(0,200)});}
    }
    // A calendar edit during IO invalidates this preparation; the next tick uses its new identity.
    const latest=await ctx.calendarAgenda();if(latest.error||!latest.events?.some(e=>key(e)===id&&fingerprint(e)===binding))continue;
    const current=ctx.hub.data.sources.find(s=>s.id===source.id);if(!current||!calendar.isCurrent(ctx,event,prepared.generation))continue;
    const completedAt=Math.max(now,Date.now()),options={purpose:'current-work',asOf:new Date(completedAt).toISOString()};
    const modules=current.board?.modules||[],prior=modules.find(m=>m.id==='premeeting-materials');
    if(!prior?.edited){const next=brief.preparationModule(ctx.hub.data,current,event,options),all=modules.filter(m=>m.id!=='premeeting-materials');if(next)all.unshift(next);if(JSON.stringify(all)!==JSON.stringify(modules))ctx.hub.update('sources',current.id,{board:{...current.board,modules:all}},current.revision);}
    const rows=brief.materials(ctx.hub.data,current,event,options),onlineReadCount=rows.filter(r=>r.read&&r.readReceipt&&completedAt-Date.parse(r.readReceipt.fetchedAt)<3600000).length,cacheCount=rows.filter(r=>r.read).length-onlineReadCount,linkCount=rows.filter(r=>!r.read).length;
    receipts[id]={binding,materialsBinding:materialBinding(ctx.hub,event,completedAt),noteId,status:!rows.length||errors.length||cacheCount||linkCount?'partial':'prepared',checkedAt:now,materialCount:rows.length,readCount:onlineReadCount,onlineReadCount,cacheCount,linkCount,errors};ctx.hub.data.sync.preparation=receipts;ctx.hub.save();
   }
  }finally{this.busy=false;}
 }
}
function visible(hub,event){const r=hub.data.sync.preparation?.[key(event)];return r&&r.binding===fingerprint(event)&&r.materialsBinding===materialBinding(hub,event)&&['prepared','partial'].includes(r.status)?{status:r.status,noteId:r.noteId,materialCount:r.materialCount,readCount:r.readCount,onlineReadCount:r.onlineReadCount,cacheCount:r.cacheCount,linkCount:r.linkCount}:null;}
module.exports={Preparation,key,fingerprint,visible,registerCalendarMaterials};
