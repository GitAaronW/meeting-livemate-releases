'use strict';
// Only reusable instructions and bounded usage counts are stored; never meeting text.
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.ThtPrompts=api;})(typeof window==='object'?window:globalThis,()=>{
 const defaults=[
 ['relevant','与我相关','Relevant to me','总结与我明确相关的事项，保留来源与未确认之处。','Summarize items explicitly relevant to me. Include sources and flag uncertainty.'],
 ['todos','最近待办','Recent to-dos','列出最近明确交给我的待办，保留来源，不推测负责人或期限。','List recent tasks explicitly assigned to me. Include sources; do not guess owners or deadlines.'],
 ['continue','继续上次讨论','Continue discussion','根据最近一次讨论总结进展，并建议下一步。','Summarize progress from the most recent discussion and suggest next steps.'],
 ['shawn','解释 Shawn 的意思','Explain Shawn','解释 Shawn 刚才的意思，并保留不确定之处。','Explain what Shawn just meant and flag uncertainty.'],
 ['plan','起草方案','Draft a plan','根据当前讨论，在当前文档起草一个具体方案。','Draft a concrete plan in the current document based on this discussion.'],
 ['check','核查说法','Check a claim','核查这个说法，给出来源和日期。','Check this claim with sources and dates.']
 ].map(([id,zh,en,promptZh,promptEn])=>({id,zh,en,promptZh,promptEn}));
 function create(storage,key='tht-prompt-library:v1'){
  let state={items:defaults.map(x=>({...x})),usage:{}};
  try{const saved=JSON.parse(storage.getItem(key)||'null');if(saved?.version===1&&Array.isArray(saved.items)){state.items=saved.items.slice(0,30).filter(valid).map(clean);state.usage=Object.fromEntries(state.items.map(x=>[x.id,Math.min(100000,Math.max(0,Number(saved.usage?.[x.id])||0))]));}}catch{}
  function valid(x){return x&&typeof x.id==='string'&&x.id.trim()&&['zh','en'].some(k=>typeof x[k]==='string'&&x[k].trim())&&['promptZh','promptEn'].some(k=>typeof x[k]==='string'&&x[k].trim());}
  function clean(x){return Object.fromEntries(['id','zh','en','promptZh','promptEn'].map(k=>[k,String(x[k]||'').trim().slice(0,k.startsWith('prompt')?4000:80)]));}
  function save(){storage.setItem(key,JSON.stringify({version:1,...state}));}
  return {list:()=>state.items.map(x=>({...x})),recommended:()=>state.items.map((x,i)=>({...x,order:i})).sort((a,b)=>(state.usage[b.id]||0)-(state.usage[a.id]||0)||a.order-b.order).slice(0,3),
   put(item){if(!valid(item))throw Error('Enter a label and complete instruction.');const next=clean(item);next.zh=next.zh||next.en;next.en=next.en||next.zh;next.promptZh=next.promptZh||next.promptEn;next.promptEn=next.promptEn||next.promptZh;const at=state.items.findIndex(x=>x.id===next.id);if(at<0&&state.items.length>=30)throw Error('Maximum 30 prompts.');const before=state.items.slice();at<0?state.items.push(next):state.items.splice(at,1,next);try{save();}catch(e){state.items=before;throw e;}},
   use(id){if(!state.items.some(x=>x.id===id))return;state.usage[id]=Math.min(100000,(state.usage[id]||0)+1);try{save();}catch{}},
   instruction:(id,lang)=>{const x=state.items.find(x=>x.id===id);return x?.[lang==='en'?'promptEn':'promptZh']||'';}};
 }
 return {create};
});
