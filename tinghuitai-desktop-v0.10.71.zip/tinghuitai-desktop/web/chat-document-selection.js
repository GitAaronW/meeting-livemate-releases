'use strict';
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.ChatDocumentSelection=factory();})(typeof window==='object'?window:globalThis,()=>{
 const normalize=text=>String(text||'').replace(/\s+/g,' ').trim();
 async function selection(job,quote='',crypto=globalThis.crypto){
  const text=normalize(quote),reply=String(job.reply||'');
  const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(job.id+'\n'+reply+'\n'+text));
  return {moduleId:'chat-'+Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,'0')).join('').slice(0,40),chatSelection:{jobId:job.id,reply,quote:text}};
 }
 return {normalize,selection};
});
