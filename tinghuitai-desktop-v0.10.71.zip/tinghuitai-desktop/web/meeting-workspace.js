'use strict';
// Layout owns visibility and panel sizes only. Capture, conversation and document keep their owners.
(()=>{
 if(parent!==window)return;
 const frame=document.getElementById('workspace-frame'),panel=document.getElementById('myagent-panel');
 if(!frame||!panel)return;
 // One stylesheet in each existing document; never replace the frame or its editor.
 function referenceStyle(doc){
  if(!doc?.head||doc.getElementById('mw-reference-style'))return;
  const link=doc.createElement('link');link.id='mw-reference-style';link.rel='stylesheet';link.href='meeting-reference.css?v=1';doc.head.append(link);
  // meeting-surface attaches the base stylesheet after its first parent message.
  // Keep this view-only layer last without changing that message/data protocol.
  new MutationObserver(()=>{if(doc.head.lastElementChild!==link)doc.head.append(link);}).observe(doc.head,{childList:true});
 }
 referenceStyle(document);
 // New workspaces start with the conversation and its working document. The
 // fixed transcript control remains available; explicit prior choices win.
 const state={left:false,right:true};
 const narrow=()=>window.innerWidth<1100;
 const compact=()=>window.innerWidth<760;
 try{const saved=JSON.parse(localStorage.getItem('tht-meeting-workspace-panels')||'{}');for(const key of ['left','right'])if(typeof saved[key]==='boolean')state[key]=saved[key];}catch{}
 const maximum={left:640,right:960};
 const widths={left:Math.round(Math.min(420,Math.max(230,window.innerWidth*.245))),right:Math.round(Math.min(maximum.right,Math.max(420,window.innerWidth*.58)))};
 try{const saved=JSON.parse(localStorage.getItem('tht-meeting-workspace-widths')||'{}');for(const key of ['left','right'])if(Number.isFinite(saved[key]))widths[key]=Math.max(key==='left'?220:260,Math.min(maximum[key],saved[key]));}catch{}
 const preferred={...state};
 const sizeMode=()=>compact()?'compact':narrow()?'narrow':'wide';
 let currentSize=sizeMode();
 function adaptSize(){Object.assign(state,preferred);if(compact()){state.left=false;state.right=false;}else if(narrow()&&state.left&&state.right)state.right=false;}
 adaptSize();
 const bar=document.createElement('nav');bar.className='mw-bar';bar.setAttribute('aria-label','会议工作区 / Meeting workspace');
 const title=document.createElement('strong');title.textContent='会议 / Meeting';
 const buttons={};
 for(const [key,label] of [['left','实时转写 / Live transcript'],['right','方案文档 / Solution document']]){
  const button=document.createElement('button');button.type='button';const icon=document.createElementNS('http://www.w3.org/2000/svg','svg');icon.setAttribute('viewBox','0 0 24 24');icon.setAttribute('width','18');icon.setAttribute('height','18');icon.setAttribute('fill','none');icon.setAttribute('stroke','currentColor');icon.setAttribute('stroke-width','1.6');icon.setAttribute('aria-hidden','true');const outline=document.createElementNS(icon.namespaceURI,'rect');outline.setAttribute('x','3');outline.setAttribute('y','4');outline.setAttribute('width','18');outline.setAttribute('height','16');outline.setAttribute('rx','3');const pane=document.createElementNS(icon.namespaceURI,'rect');pane.setAttribute('class','mw-pane');pane.setAttribute('x',key==='left'?'4.2':'12.8');pane.setAttribute('y','5.2');pane.setAttribute('width','7');pane.setAttribute('height','13.6');pane.setAttribute('rx','1.2');const divider=document.createElementNS(icon.namespaceURI,'path');divider.setAttribute('d',key==='left'?'M9 4v16':'M15 4v16');icon.append(outline,pane,divider);button.append(icon);button.setAttribute('aria-label',label);button.title=label;
  button.className='mw-toggle-'+key;
  button.onclick=()=>{stopDrag();state[key]=!state[key];preferred[key]=state[key];if(state[key]&&narrow()){const other=key==='left'?'right':'left';state[other]=preferred[other]=false;}localStorage.setItem('tht-meeting-workspace-panels',JSON.stringify(preferred));layout();};buttons[key]=button;
 }
 const live=document.createElement('span');live.className='mw-live-status';live.hidden=true;const end=document.createElement('button');end.type='button';end.className='mw-end';end.hidden=true;end.onclick=()=>document.getElementById('stop')?.click();const menu=document.createElement('details');menu.className='mw-app-menu';const more=document.createElement('summary');more.textContent='···';more.setAttribute('aria-label','应用菜单 / App menu');menu.append(more);const actions=document.createElement('div');actions.setAttribute('role','group');menu.append(actions);
 for(const [id,zh,en]of [['ui-language','界面语言 · English','Language · 中文'],['mw-summary','要点总结','Summary'],['mw-notice','最近通知','Recent notification'],['m-update','检查更新','Check updates'],['gear2','设置','Settings']]){const action=document.createElement('button');action.type='button';const label=()=>{const text=document.documentElement.lang==='en'?en:zh;action.textContent=text;action.setAttribute('aria-label',text);if(id==='mw-notice')action.hidden=!window.thtHasNotice?.();};label();menu.addEventListener('toggle',label);action.onclick=()=>{menu.open=false;if(id==='ui-language'){document.querySelector('#ui-lang [data-ui="'+(document.documentElement.lang==='en'?'zh':'en')+'"]')?.click();return;}if(id==='mw-summary'){if(!state.left)buttons.left.click();frame.contentWindow?.postMessage({type:'tht-summary-toggle'},location.origin);return;}if(id==='mw-notice'){window.thtRestoreNotice?.();return;}document.getElementById(id)?.click();};actions.append(action);}
 menu.addEventListener('keydown',e=>{if(e.key==='Escape'){menu.open=false;more.focus();}});document.addEventListener('pointerdown',e=>{if(!menu.contains(e.target))menu.open=false;});bar.append(buttons.left,title,live,end,buttons.right,menu);document.body.append(bar);
 // Reuse the real status node and recorder handlers; no cloned controls or capture commands.
 document.querySelector?.('.meeting-recorder')?.append(live);
 function active(){return !document.body.classList.contains('document-home-open')&&frame.hidden===false;}
 const handles={};let stopDrag=()=>{};
 const minimum={left:220,right:260};
 function measured(){
  const budget=Math.max(0,window.innerWidth-(compact()?280:420));
  const result={left:state.left?widths.left:0,right:state.right?widths.right:0};
  if(result.left+result.right>budget){
   const floor=(state.left?minimum.left:0)+(state.right?minimum.right:0);
   if(budget<floor){for(const key of ['left','right'])result[key]=state[key]?budget*minimum[key]/floor:0;}
   else{const extra=budget-floor,total=result.left+result.right-floor;for(const key of ['left','right'])if(state[key])result[key]=Math.floor(minimum[key]+(total?(result[key]-minimum[key])*extra/total:0));}
  }
  return result;
 }
 function changeWidth(key,delta){const sizes=measured(),other=key==='left'?'right':'left';widths[key]=Math.max(minimum[key],Math.min(maximum[key],window.innerWidth-420-sizes[other],sizes[key]+delta));layout();}
 function saveWidths(){try{localStorage.setItem('tht-meeting-workspace-widths',JSON.stringify(widths));}catch{}}
 for(const key of ['left','right']){
  const handle=document.createElement('div');handle.className='mw-splitter mw-splitter-'+key;handle.setAttribute('role','separator');handle.setAttribute('aria-orientation','vertical');handle.setAttribute('aria-label',key==='left'?'调整实时转写宽度 / Resize live transcript':'调整方案文档宽度 / Resize solution document');
  handle.onpointerdown=e=>{
   if(handle.hidden||e.button!==0)return;e.preventDefault();stopDrag();let x=e.clientX,id=e.pointerId;
   const stop=()=>{handle.onpointermove=handle.onpointerup=handle.onpointercancel=handle.onlostpointercapture=null;document.body.classList.remove('mw-resizing');try{handle.releasePointerCapture(id);}catch{}saveWidths();stopDrag=()=>{};};
   stopDrag=stop;document.body.classList.add('mw-resizing');
   try{handle.setPointerCapture(id);}catch{stop();return;}
   handle.onpointermove=next=>{const delta=(next.clientX-x)*(key==='right'?-1:1);x=next.clientX;changeWidth(key,delta);};
   handle.onpointerup=handle.onpointercancel=handle.onlostpointercapture=stop;
  };
  handle.onkeydown=e=>{if(handle.hidden||!['ArrowLeft','ArrowRight'].includes(e.key))return;e.preventDefault();changeWidth(key,(e.key==='ArrowRight'?20:-20)*(key==='right'?-1:1));saveWidths();};
  handles[key]=handle;document.body.append(handle);
 }
 window.addEventListener('blur',()=>stopDrag());
 const notice=document.getElementById('notice');
 function noticeSpace(){if(notice?.getBoundingClientRect)document.body.style.setProperty('--mw-notice-height',(!notice.hidden?Math.ceil(notice.getBoundingClientRect().height)+16:0)+'px');}
 window.addEventListener('tht-notice-change',noticeSpace);
 window.addEventListener('resize',noticeSpace);
 if(notice?.getBoundingClientRect&&typeof ResizeObserver!=='undefined')new ResizeObserver(noticeSpace).observe(notice);
 noticeSpace();
 let lastLayout='';
 function layout(force=false){
  const on=active(),sizes=measured(),key=JSON.stringify([on,state.left,state.right,sizes.left,sizes.right,window.innerWidth]);if(!force&&lastLayout===key)return;lastLayout=key;document.body.classList.toggle('meeting-workspace',on);bar.hidden=!on;
  if(!on||compact())stopDrag();
  for(const side of ['left','right']){
   document.body.style.setProperty('--mw-'+side,sizes[side]+'px');
   const handle=handles[side];handle.hidden=!on||compact()||!state[side];handle.tabIndex=handle.hidden?-1:0;
   handle.setAttribute('aria-valuemin',String(minimum[side]));handle.setAttribute('aria-valuemax',String(Math.min(maximum[side],window.innerWidth-420-sizes[side==='left'?'right':'left'])));handle.setAttribute('aria-valuenow',String(Math.round(sizes[side])));
  }
  const en=document.documentElement?.lang==='en';
  for(const key of ['left','right']){document.body.classList.toggle('mw-'+key+'-closed',!state[key]);const open=state[key];buttons[key].setAttribute('aria-expanded',String(open));const text=key==='left'?(open?(en?'Hide live transcript':'收起实时转写'):(en?'Show live transcript':'展开实时转写')):(open?(en?'Hide solution document':'收起方案文档'):(en?'Show solution document':'展开方案文档'));buttons[key].setAttribute('aria-label',text);buttons[key].title=text;}
  if(on){panel.hidden=false;panel.classList.remove('ma-collapsed');document.body.classList.add('myagent-open');}
  referenceStyle(frame.contentDocument);
  frame.contentWindow?.postMessage({type:'tht-workspace-layout',enabled:on,left:state.left,right:state.right,widths:sizes},location.origin);
 }
 window.addEventListener('resize',()=>{stopDrag();const next=sizeMode();if(next!==currentSize){currentSize=next;adaptSize();}layout();});
 frame.addEventListener('load',()=>{referenceStyle(frame.contentDocument);layout(true);});
 // A title copied verbatim into the first paragraph is displayed once. Nothing is
 // removed from the candidate or stored document; changed wording remains visible.
 function presentInsights(){
  for(const card of panel.querySelectorAll('.ma-insight')){
   const heading=card.querySelector(':scope > strong'),lead=card.querySelector(':scope > div .ma-answer > p:first-child');
   if(!heading)continue;
   const title=[...heading.childNodes].filter(n=>n.nodeType===3).map(n=>n.textContent).join('').trim();
   if(lead)lead.classList.toggle('mw-duplicate-lead',!!title&&lead.textContent.trim()===title);
   const source=card.querySelector(':scope > div .ma-insight-sources > p'),stamp=source?.textContent.match(/^(\d+:\d{2}) · /)?.[1];
   let time=card.querySelector('.mw-insight-time');
   if(stamp&&!time){time=document.createElement('span');time.className='mw-insight-time';card.append(time);}
   if(time){if(time.textContent!==stamp)time.textContent=stamp||'';time.hidden=!stamp;time.setAttribute('aria-label','依据时间 / Source time '+(stamp||''));}
   card.classList.toggle('mw-has-time',!!stamp);
  }
 }
 if(panel.querySelectorAll){presentInsights();new MutationObserver(presentInsights).observe(panel,{childList:true,subtree:true});}
 new MutationObserver(()=>layout()).observe(document.body,{attributes:true,attributeFilter:['class']});
 new MutationObserver(()=>layout()).observe(frame,{attributes:true,attributeFilter:['hidden']});
 // Do not move or recreate the composer, editor or conversation when panels fold.
 window.addEventListener('tht-proactive-data',e=>{const data=e.detail;title.textContent=data.meetingTitle||data.session?.topicTitle||data.session?.title||data.source?.title||'会议 / Meeting';});
 setInterval(()=>{const el=frame.contentDocument?.querySelector('.surface-elapsed'),status=frame.contentDocument?.querySelector('.surface-audio-status');const showing=!!el&&(!!el.classList.contains('recording')||['starting','sound','quiet','paused','waiting','disconnected'].includes(status?.dataset?.state));live.hidden=end.hidden=!showing;live.textContent=showing?((status?.textContent||'')+(status?.dataset?.state==='starting'?'':' · '+el.textContent)):'';live.setAttribute('role','status');live.setAttribute('aria-busy',String(status?.dataset?.state==='starting'));const en=document.documentElement?.lang==='en';end.textContent=en?'End':'结束';end.disabled=!!document.getElementById('stop')?.disabled;window.dispatchEvent(new Event('tht-workspace-status'));},1000);
 layout();
})();
