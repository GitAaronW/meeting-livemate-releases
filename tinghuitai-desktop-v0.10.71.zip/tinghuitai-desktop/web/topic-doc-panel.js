'use strict';
// 会后「主题文档更新」预览（Aaron 2026-09-25）：每主题一份飞书真源文档，这场会带来的增量先在这里给差异预览，
// 只有点「接受」才带 confirmed:true 调 /topic-diff/apply 写飞书；不点不写。独立文件、独立区块 #topic-doc，不碰 archive-v2.js。
(function(){
  const mid=new URLSearchParams(location.search).get('id')||'';
  const box=document.getElementById('topic-doc');
  if(!mid||!box)return;
  const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const tok=()=>{let s={};try{s=JSON.parse(localStorage.getItem('tht-settings')||'{}');}catch{}return encodeURIComponent(s.relayToken||(window.THT_BOOT&&window.THT_BOOT.relayToken)||'');};
  const api=(path,opt)=>fetch('/asr-relay/'+path+(path.includes('?')?'&':'?')+'token='+tok(),Object.assign({cache:'no-store',signal:AbortSignal.timeout(opt&&opt.method==='POST'?180000:8000)},opt||{})).then(r=>r.json().then(j=>({status:r.status,j})));
  const post=(path,body)=>api(path,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});
  function show(html){box.innerHTML='<h2>主题文档更新</h2>'+html;box.hidden=false;}
  let previewId = '';
  function renderDiff(d){
    previewId=d.previewId||'';
    const groups=(d.sections||[]).filter(g=>g.items&&g.items.length);
    const head='<div class="td-meta">主题 <b>'+esc(d.topic)+'</b>'+(d.owner?' · 负责人 '+esc(d.owner):'')+' · '+esc(d.date||'')+'</div>';
    if(!groups.length){show(head+'<p class="td-empty">这场会对该主题没有新增。</p>');return;}
    const body=groups.map(g=>'<div class="td-sec"><div class="td-h">'+esc(g.section)+'</div>'+g.items.map(it=>
      '<div class="td-item"><label><input type="checkbox" data-id="'+esc(it.id)+'" '+(['applied','retained'].includes(it.status)?'disabled':'checked')+'> <span class="td-add">'+(it.status==='applied'?'已写入 · ':it.status==='retained'?'保留两版 · ':'+ ')+esc(it.text)+'</span></label>'+(it.replaceBlockId?'<details class="td-change"><summary>'+(it.restoredVersion?'恢复历史版本':'修订现有 AI 段落')+'</summary><div><small>原文</small><pre style="white-space:pre-wrap">'+esc(it.before)+'</pre><small>建议</small><pre style="white-space:pre-wrap">'+esc(it.rendered)+'</pre></div></details>':'')+' <span class="td-ev">'+esc((it.evidence||[]).join(' '))+'</span></div>').join('')+'</div>').join('');
    if(d.hasDocument===false){show(head+body+'<p class="td-empty">该主题尚未关联文档，目前可预览。</p>');return;}
    show(head+body+'<div class="td-bar"><button type="button" class="btn sm" id="td-accept">接受，写进主题文档</button><span id="td-msg" class="td-msg"></span></div>');
    box.querySelector('#td-accept').onclick=accept;
    history();
    const message=box.querySelector('#td-msg'),button=box.querySelector('#td-accept');
    message.setAttribute('role','status');
    if(d.sync?.status==='needs_verification'){
      message.textContent='写入结果尚未确认，请先到目标文档核对；不会自动重发。';
      button.textContent='等待核对写入结果';button.disabled=true;
    }else if(d.sync?.status==='conflict_retained'){
      message.textContent='人工原文与建议均保留，请在目标文档合并后重新生成。';button.disabled=true;
    }else if(d.sync?.status==='pending'){
      message.textContent='尚未保存到远端，恢复连接或权限后可重试。';button.textContent='重试写入';
    }else if(!box.querySelector('input[data-id]:checked')){
      message.textContent='所选内容已写入并核对。';button.disabled=true;
    }
  }
  async function history(){
    const requestedPreview=previewId;
    try {
      const {j}=await api('topic-diff/history?id='+encodeURIComponent(mid));
      if(!j.ok||!j.history||requestedPreview!==previewId)return;
      const h=j.history, wrap=document.createElement('div');wrap.className='td-history';
      const groups=Object.values(h.blocks||{}).filter(b=>b.versions?.length>1);
      wrap.innerHTML=(h.journal?'<details open><summary>有一项修订需要核对</summary><p>新旧版本已保留。核对结果不会再次发送正文；如原文有并发修改，将恢复其可见性。</p><small>原版</small><pre style="white-space:pre-wrap">'+esc(h.journal.before?.text)+'</pre><small>建议</small><pre style="white-space:pre-wrap">'+esc(h.journal.proposed)+'</pre><button type="button" class="btn sm" data-recover>核对远端并恢复原文可见性</button><button type="button" class="btn sm" data-keep>保留两版，结束本次核对</button><p role="status" data-recover-msg></p></details>':'')+
        (groups.length?'<details><summary>历史版本 · 可预览后恢复</summary>'+groups.map(b=>'<div>'+b.versions.map(v=>'<p>'+esc(v.text)+' <button type="button" class="btn sm" data-block="'+esc(b.id)+'" data-version="'+esc(v.id)+'">预览恢复</button></p>').join('')+'</div>').join('')+'</details>':'');
      box.appendChild(wrap);
      wrap.querySelectorAll('[data-version]').forEach(btn=>btn.onclick=async()=>{
        btn.disabled=true;
        try{const {j}=await post('topic-diff/restore-preview',{id:mid,blockId:btn.dataset.block,versionId:btn.dataset.version});if(!j.ok)throw Error(j.error);renderDiff(j.diff);}
        catch(e){btn.disabled=false;const msg=document.createElement('p');msg.textContent=e.message;btn.parentElement.appendChild(msg);}
      });
      const keep=wrap.querySelector('[data-keep]');
      if(keep)keep.onclick=async()=>{
        keep.disabled=true;
        try{const {j}=await post('topic-diff/recover',{id:mid,confirmed:true,keepBoth:true});if(!j.ok)throw Error(j.error);renderDiff(j.diff);}
        catch(e){keep.disabled=false;wrap.querySelector('[data-recover-msg]').textContent=e.message;}
      };
      const recover=wrap.querySelector('[data-recover]');
      if(recover)recover.onclick=async()=>{
        recover.disabled=true;
        try{const {j}=await post('topic-diff/recover',{id:mid,confirmed:true});if(!j.ok)throw Error(j.error);renderDiff(j.diff);}
        catch(e){recover.disabled=false;wrap.querySelector('[data-recover-msg]').textContent=e.message;}
      };
    }catch(e){}
  }
  async function accept(){
    const ids=[...box.querySelectorAll('input[data-id]:checked')].map(i=>i.dataset.id);
    const msg=box.querySelector('#td-msg'),btn=box.querySelector('#td-accept');
    if(!ids.length){msg.textContent='没有勾选条目';return;}
    btn.disabled=true;msg.textContent='写入中…';
    try{const {status,j}=await post('topic-diff/apply',{id:mid,ids,previewId,confirmed:true});
      if(!j.ok){
        if(j.uncertain){box.querySelector('.td-history')?.remove();history();msg.textContent='写入结果尚未确认，请先到目标文档核对；不会自动重发。';return;}
        if(status===409){msg.textContent=j.error||'预览已过期';btn.textContent='重新生成预览';btn.disabled=false;btn.onclick=compute;return;}
        throw new Error(j.error||'写入失败');
      }
      await load();
    }catch(e){btn.disabled=false;msg.textContent='失败：'+e.message;}
  }
  async function compute(){
    show('<p class="td-empty">正在生成差异…</p>');
    try{const r=await api('meeting-result?id='+encodeURIComponent(mid));
      const {j}=await post('topic-diff/compute',{enhanced:Object.assign({},r.j,{id:mid})});
      if(!j.ok)throw new Error(j.error||'生成失败');
      if(!j.matched){show('<p class="td-empty">这场会没有对上任何主题。</p>');return;}
      renderDiff(j.diff);
    }catch(e){show('<p class="td-empty">生成失败：'+esc(e.message)+'</p>');}
  }
  async function load(){
    try{const {status,j}=await api('topic-diff?id='+encodeURIComponent(mid));
      if(j.ok&&j.diff)return renderDiff(j.diff);
      if(status===404||(j.ok&&!j.diff)){show('<p class="td-empty">还没有这场会的主题差异。</p><button type="button" class="btn sm" id="td-gen">生成差异预览</button>');box.querySelector('#td-gen').onclick=compute;}
    }catch(e){}
  }
  load();
  window.THT_TOPIC_DOC={reload:load};
})();
