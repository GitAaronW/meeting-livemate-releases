'use strict';
// Evidence, background and AI judgement are separate views of the Session journal.
window.THTLiveSignals = {
  attach(items, modules) {
    const groups = new Map(), loose = [];
    for (const item of items.filter(x => ['background','verification'].includes(x.channel))) {
      const ids = (item.sourceRefs || []).map(r => typeof r === 'string' ? r : r.segId);
      const candidates = modules.filter(m => m.kind !== 'summary');
      const module = candidates.find(m => m.topic === item.topic) || candidates.find(m => (m.sourceRefs || []).some(r => ids.includes(typeof r === 'string' ? r : r.segId)));
      if (!module) { loose.push(item); continue; }
      if (!groups.has(module.id)) groups.set(module.id, []);
      groups.get(module.id).push(item);
    }
    return {groups, loose};
  },
  render(item, {el, tr, refs, globalAct, openArtifact}) {
    const card = el('section', '', 'signal signal-' + item.channel);
    card.dataset.signalId = item.id;
    card.append(el('small', item.channel === 'judgment' ? tr('当前判断 · AI 推断，尚未确认','Current judgement · AI inference, unconfirmed') : item.channel === 'verification' ? tr('事实核查 · 公开检索','Fact check · Public search') : tr('背景补充 · 公开检索','Background · Public search'), 'signal-label'));
    card.append(el('h3', item.channel === 'judgment' ? item.point : item.entity || item.topic));
    if (item.channel === 'judgment') {
      const change = item.decisionChange;
      if (change && [change.previous, change.reason, change.current].every(x => typeof x === 'string' && x.trim())) {
        const figure = el('figure', '', 'decision-change');
        figure.append(el('figcaption', tr('判断如何改变 · AI 推断','How the judgement changed · AI inference')));
        const flow = el('ol', '', 'decision-change-flow');
        for (const [label, text] of [[tr('原判断','Previous'),change.previous],[tr('新依据','New basis'),change.reason],[tr('当前判断','Current'),change.current]]) {
          const step = el('li'); step.append(el('small',label),el('p',text)); flow.append(step);
        }
        figure.append(flow); card.append(figure);
      } else card.append(el('p', item.whyChanged, 'signal-reason'));
      if(String(item.openGap||'').trim()){const gap=el('p','','signal-gap');gap.append(el('small',tr('还没关上的缺口','Still open')),el('span',String(item.openGap).trim()));card.append(gap);}
      if(item.speechDraft){const speech=el('aside','','speech-draft');speech.append(el('small',tr('此刻可以这样说 · AI 草稿','Something you could say · AI draft')),el('p',item.speechDraft));card.append(speech);}
      if (item.artifactId && typeof openArtifact === 'function') {
        const open = el('button', tr('查看并修改图稿','View and edit diagram'));
        open.type='button'; open.onclick=()=>openArtifact(item.artifactId); card.append(open);
      }
      const correct = el('button', tr('纠正或继续问','Correct or ask'));
      correct.onclick = () => globalAct({comment:'',quote:item.point}); card.append(correct);
    } else {
      if (item.channel === 'verification') card.append(el('p', tr('待核查说法：','Claim to check: ') + item.claim));
      if (item.lookupState === 'ready') {
        if (item.point) card.append(el('p', item.point, 'signal-message'));
        if (item.whyUseful) card.append(el('p', item.whyUseful, 'signal-reason'));
        const evidence = el('details', '', 'signal-evidence');
        evidence.append(el('summary', tr('查看来源', 'Sources')));
        for (const source of item.evidence || []) {
          if (!/^https?:\/\//.test(source.url || '')) continue;
          evidence.append(el('blockquote', source.excerpt));
          const a = el('a', source.title || source.url); a.href=source.url; a.target='_blank'; a.rel='noopener noreferrer'; evidence.append(a);
          const date=new Date(source.retrievedAt); if (!Number.isNaN(date.getTime())) evidence.append(el('small', tr('检索于 ','Retrieved ') + date.toLocaleString(), 'signal-date'));
        }
        evidence.append(el('small', tr('检索片段供核对，不代表整条说法已经验证。','Search excerpts for review; the full claim has not been verified.'), 'signal-caveat'));
        card.append(evidence);
      } else {
        const state = ({pending:tr('已识别，准备检索','Identified, preparing search'),searching:tr('正在检索公开来源…','Searching public sources…'),no_evidence:tr('未找到可用证据；不能据此判定真伪','No usable evidence; this does not establish truth or falsity'),unavailable:tr('检索暂不可用','Search unavailable')})[item.lookupState] || '';
        card.append(el('small',state,'signal-status'));
      }
    }
    if (item.sourceRefs?.length) { const d=refs(item); d.dataset.key=item.id+':source';card.append(d); }
    return card;
  }
};
