/* Follow live speech until the reader scrolls or selects text. Never replace a selection. */
(function(root){
 'use strict';
 function create(host, options={}){
  const doc=host.ownerDocument, win=doc.defaultView, states=new Map();
  let meeting='', state=null, pending=null, restoring=false, restoredTop=null, unresolvedAnchor=false;
  const rows=()=>[...host.querySelectorAll('[data-transcript-key]')];
  const selected=()=>{const s=win.getSelection();return !!s&&!s.isCollapsed&&(host.contains(s.anchorNode)||host.contains(s.focusNode));};
  const nearBottom=()=>host.scrollHeight-host.clientHeight-host.scrollTop<40;
  const storageKey=id=>'tht-transcript-position:'+host.id+':'+id;
  function save(){if(!state||!meeting)return;try{win.sessionStorage.setItem(storageKey(meeting),JSON.stringify(state));}catch{}}
  function anchor(){if(!state||!host.clientHeight||unresolvedAnchor)return;const top=host.getBoundingClientRect().top;const row=rows().find(r=>r.getBoundingClientRect().bottom>top);state.top=host.scrollTop;state.key=row?.dataset.transcriptKey||'';state.offset=row?row.getBoundingClientRect().top-top:0;save();}
  function restore(){if(!state||!host.clientHeight)return;restoring=true;if(state.follow&&!selected())host.scrollTop=host.scrollHeight;else{const row=rows().find(r=>r.dataset.transcriptKey===state.key);unresolvedAnchor=!!state.key&&!row;host.scrollTop=row?host.scrollTop+row.getBoundingClientRect().top-host.getBoundingClientRect().top-state.offset:state.top||0;}restoredTop=host.scrollTop;options.onFollow?.(state.follow);restoring=false;}
  function bind(id){if(meeting===String(id)&&state)return false;anchor();if(selected())win.getSelection().removeAllRanges();meeting=String(id);pending=null;unresolvedAnchor=false;let stored;try{stored=JSON.parse(win.sessionStorage.getItem(storageKey(meeting)));}catch{}state=states.get(meeting)||stored||{follow:true,top:0,key:'',offset:0};states.set(meeting,state);return true;}
  function render(id,fn){const changed=bind(id);if(selected()){state.follow=false;anchor();pending=fn;options.onFollow?.(false);return;}if(!changed&&!state.follow)anchor();pending=null;fn();restore();}
  function latest(){if(!state)return;const s=win.getSelection();if(selected())s.removeAllRanges();state.follow=true;if(pending){const fn=pending;pending=null;fn();}restore();anchor();}
  host.addEventListener('scroll',()=>{if(!state||restoring||!host.clientHeight)return;if(restoredTop!==null&&Math.abs(host.scrollTop-restoredTop)<1)return;restoredTop=null;unresolvedAnchor=false;state.follow=!selected()&&nearBottom();anchor();options.onFollow?.(state.follow);},{passive:true});
  doc.addEventListener('selectionchange',()=>{if(!state)return;if(selected()){state.follow=false;anchor();options.onFollow?.(false);}else if(pending){const fn=pending;pending=null;fn();restore();}});
  const resume=()=>{if(!doc.hidden)restore();};
  win.addEventListener('focus',resume);doc.addEventListener('visibilitychange',resume);
  if(win.ResizeObserver)new win.ResizeObserver(restore).observe(host);
  return {render,latest,restore,pause(){if(state){state.follow=false;anchor();options.onFollow?.(false);}},get following(){return state?.follow!==false;}};
 }
 root.ThtTranscriptScroll={create};
 if(typeof module==='object'&&module.exports)module.exports={create};
})(typeof window==='object'?window:globalThis);
