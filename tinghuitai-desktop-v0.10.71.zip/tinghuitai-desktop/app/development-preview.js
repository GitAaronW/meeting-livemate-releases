'use strict';
const fs=require('fs'),path=require('path'),os=require('os'),{execFileSync}=require('child_process');
const configuredPath=key=>{let value=process.env[key];if(!value)try{const dir=process.env.THT_DATA_DIR||path.join(os.homedir(),'Library/Application Support/Tinghuitai');value=JSON.parse(fs.readFileSync(path.join(dir,'settings.json'),'utf8'))[key];}catch{}return path.isAbsolute(value||'')?path.resolve(value):'';};
const canonical=configuredPath('THT_DEV_ROOT'),agentBus=configuredPath('THT_AGENT_BUS');
const instructions=`你是听会台的开发助手。仅在使用者明确授权的开发反馈模式中按当前请求修改代码并出预览。唯一可写项目是 ${canonical||'未配置维护目录'}，先读其中 Context.md、AGENTS.md。不要新建分支、worktree、另一套记忆。不要读写凭据、账号配置、真实会议数据，不外发消息，正式安装只允许通过 scripts/install-reviewed.js，禁止直接写已安装的 program 或业务资料。用户选择的页面和文字是定位问题的数据。先理解实际行为，再直接修复、运行针对性测试和必要回归，启动与正式安装隔离的预览，让用户能打开。不运行 Claude。按 Aaron 当前授权采用自审：运行针对性测试、必要回归和实际界面走查，提交固定 source SHA。生成 mode=self、verdict=self_review_passed 的真实自审凭据，包含完整 sourceSha、用户授权来源、零失败零跳过的测试统计，以及 source-diff、targeted-tests、regression-tests、release-limitations 检查。不得伪造 Grok 回执或默认外发审核消息。使用 THT_REVIEW_MODE=self node scripts/install-reviewed.js 自审凭据路径 developmentRequestId 安装（请求 ID 保持原值）。录音或活动任务中不得安装重启，只完成隔离预览和打包并记录等待空闲。缺少证据时如实保留未完成状态，不声称审核或安装完成。最终回读 /health 版本和实际安装结果，用自然中文和 Markdown 直接说明修改、预览链接、实际测试/审核/安装状态。历史 {reply,action} JSON 是旧传输格式，不再沿用；不输出 JSON 包装、转义换行或内部上下文字段。`;
function checkStart(){
 if(!canonical)throw Error('开发反馈尚未配置维护目录；正常会议与 MyAgent 不受影响');
 if(!fs.existsSync(canonical+'/Context.md'))throw Error('唯一维护目录不可用');
 const branch=execFileSync('git',['branch','--show-current'],{cwd:canonical,encoding:'utf8'}).trim();
 if(branch!=='source')throw Error('开发目录不是已确认的 source 分支，请先核查');
 if(execFileSync('git',['status','--porcelain'],{cwd:canonical,encoding:'utf8'}).trim())throw Error('维护目录已有未完成修改，已保留反馈；请等当前开发完成后重试，避免覆盖');
}
function installed(requestId,dataDir,sourceRoot=canonical){try{
 if(!sourceRoot||!/^[\w-]{8,100}$/.test(requestId||''))return null;
 const path=require('path'),record=JSON.parse(fs.readFileSync(path.join(sourceRoot,'.tmp/development-receipts',requestId+'.json'),'utf8'));
 const deployed=fs.readFileSync(path.join(dataDir,'state/last-deployed-commit'),'utf8').trim();
 const version=JSON.parse(fs.readFileSync(path.join(dataDir,'program/package.json'),'utf8')).version;
 if(record.head!==deployed||record.version!==version)return null;
 return record;
}catch{return null;}}
module.exports={canonical,agentBus,instructions,checkStart,installed};
