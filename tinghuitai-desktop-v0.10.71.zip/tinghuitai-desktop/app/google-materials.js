'use strict';
// Full native Slides text plus original element identities and image references.
// Image references are not a claim that the image pixels were understood.
function textOf(container){return (container?.textElements||[]).map(e=>e.textRun?.content||'').join('');}
function elements(rows,lines,images){for(const e of rows||[]){
 if(e.shape)lines.push(textOf(e.shape.text));
 if(e.table)for(const row of e.table.tableRows||[])lines.push((row.tableCells||[]).map(c=>textOf(c.text)).join(' | '));
 if(e.image)images.push({objectId:e.objectId,contentUrl:e.image.contentUrl||'',sourceUrl:e.image.sourceUrl||'',title:e.title||'',description:e.description||'',contentRead:false});
 if(e.elementGroup)elements(e.elementGroup.children,lines,images);
}}
async function readCompletePresentation(dataDir,id,{read=require('./codex-app-bridge').readPresentation}={}){
 const body=await read(dataDir,id);
 if(body.presentationId!==id||!Array.isArray(body.slides)||!body.revisionId||body.truncated===true)throw Error('Google Slides 正文或版本不完整');
 const check=await read(dataDir,id,'presentationId,revisionId');
 if(check.revisionId!==body.revisionId)throw Error('Google Slides 在读取期间已更新，请重试');
 const pages=body.slides.map((slide,index)=>{const lines=[],images=[];elements(slide.pageElements,lines,images);const notes=[];elements(slide.slideProperties?.notesPage?.pageElements,notes,images);return {objectId:slide.objectId,pageIndex:index+1,text:lines.join('\n'),notes:notes.join('\n'),images};});
 return {text:pages.map(p=>'## Slide '+p.pageIndex+' · '+p.objectId+'\n'+p.text+(p.notes?'\n### Speaker notes\n'+p.notes:'')).join('\n\n'),version:body.revisionId,title:body.title||'',pages,coverage:{kind:'presentation_text',complete:true,pageCount:pages.length,imagesRead:false},nativeBody:body};
}
module.exports={readCompletePresentation,textOf};
