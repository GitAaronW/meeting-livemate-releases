'use strict';
// Wait for the provider's terminal receipt before archiving the final sentence.
function drain(socket,send,isFinal,{timeoutMs=8000}={}){
  return new Promise(resolve=>{
    let timer,done=false;
    const finish=(ok,reason='')=>{if(done)return;done=true;clearTimeout(timer);socket.removeListener('message',message);socket.removeListener('close',closed);resolve({ok,reason});};
    const message=d=>{try{if(isFinal(d))finish(true);}catch{}};
    const closed=()=>finish(false,'provider_closed_before_final');
    socket.on('message',message);socket.on('close',closed);
    timer=setTimeout(()=>finish(false,'provider_final_timeout'),timeoutMs);
    try{send();}catch{finish(false,'provider_end_send_failed');}
  });
}
module.exports={drain};
