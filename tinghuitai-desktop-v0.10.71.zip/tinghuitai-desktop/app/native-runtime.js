'use strict';
// Read the executable mapped by the process, not its argv path: updater rename
// can leave a live process mapped to an already deleted .originals inode.
const fs=require('fs'),{execFile}=require('child_process');
const run=(file,args)=>new Promise((resolve,reject)=>execFile(file,args,{encoding:'utf8',timeout:3000,maxBuffer:4*1024*1024},(e,out)=>e?reject(e):resolve(out)));
function create({binary,port,platform=process.platform,uid=process.getuid?.(),execute=run,stat=fs.statSync}={}){
 async function current(pid){
  if(platform!=='darwin')return true;
  if(!Number.isSafeInteger(pid)||pid<2)return false;
  try{
   const output=await execute('/usr/sbin/lsof',['-a','-p',String(pid),'-d','txt','-Fin']);
   const expected=stat(binary);let inode='',name='';
   const matches=()=>name===binary&&inode===String(expected.ino);
   for(const line of output.split('\n')){if(line.startsWith('f')){if(matches())return true;inode='';name='';}else if(line.startsWith('i'))inode=line.slice(1);else if(line.startsWith('n'))name=line.slice(1);}
   return matches();
  }catch{return false;}
 }
 async function helpers(){
  if(platform!=='darwin')return [];
  const output=await execute('/bin/ps',['-ww','-axo','pid=,uid=,command=']);
  const endpoint='http://127.0.0.1:'+port;
  return output.split('\n').flatMap(line=>{
   const m=line.match(/^\s*(\d+)\s+(\d+)\s+(.+)$/);if(!m||Number(m[2])!==uid)return [];
   const command=m[3];
   const executableEnd=command.indexOf('/Contents/MacOS/TinghuitaiCapture');
   if(executableEnd<0)return [];
   const args=command.slice(executableEnd+'/Contents/MacOS/TinghuitaiCapture'.length);
   if(args&&!/^\s/.test(args))return [];
   const server=args.match(/(?:^|\s)--server\s+(\S+)/);
   const target=server?server[1]:'http://127.0.0.1:47823';
   return target===endpoint?[{pid:Number(m[1])}]:[];
  });
 }
 return {current,helpers};
}
module.exports={create};
if(require.main===module){
 const port=Number(process.argv[2]);
 if(!Number.isSafeInteger(port)||port<1||port>65535){console.error('无效服务端口');process.exitCode=1;}
 else create({port}).helpers().then(helpers=>{
  if(helpers.length)throw Error('录音小窗仍在运行（'+helpers.map(h=>h.pid).join(', ')+'）；请正常退出听会台后再更新，未覆盖程序');
 }).catch(error=>{console.error(error.message);process.exitCode=1;});
}
