'use strict';
function rawUrl(value,markdown=false){
 let s=value.replace(/[.,;，。；]+$/,'');
 // Markdown's closing delimiter can be followed immediately by more prose.
 // Keep balanced parentheses in real URL paths, stop at the first unmatched one.
 let depth=0;for(let i=0;markdown&&i<s.length;i++){if(s[i]==='(')depth++;else if(s[i]===')'){if(!depth){s=s.slice(0,i);break;}depth--;}}

 for(const [open,close] of [['(',')'],['（','）'],['[',']']])while(s.endsWith(close)&&s.split(close).length>s.split(open).length)s=s.slice(0,-close.length);
 return s;
}
function trimUrl(value,markdown=false){return rawUrl(value,markdown).replace(/\\([_~*])/g,'$1');}
function scan(description){
 const rows=[];const pattern=/https:\/\/[^\s<>"']+/g;let match;
 while((match=pattern.exec(description))){
  const before=description.slice(0,match.index).split('\n').pop();
  const markdown=before.match(/\[([^\]]+)\]\($/);
  const raw=rawUrl(match[0],!!markdown);let url;try{const u=new URL(trimUrl(raw));if(u.protocol!=='https:'||u.username||u.password)continue;url=u.href;}catch{continue;}
  const label=markdown?.[1]||before.replace(/[（(]\s*$/,'').trim().replace(/[：:]\s*$/,'').replace(/^[-*•]\s*/,'');
  const end=match.index+raw.length;
  rows.push({url,title:label.slice(-100)||new URL(url).hostname,start:markdown?match.index-markdown[0].length:match.index,end:markdown&&description[end]===')'?end+1:end});
  pattern.lastIndex=end;
 }
 return rows;
}
function links(description){return scan(description).map(({url,title})=>({url,title}));}
function removeLinks(description,predicate){
 let result=description;
 for(const row of scan(description).reverse())if(predicate(row.url))result=result.slice(0,row.start)+result.slice(row.end);
 return result;
}
module.exports={links,trimUrl,removeLinks};
