'use strict';
const crypto=require('crypto');
const fail=(message,status=409)=>Object.assign(Error(message),{status});
// Collect the saved result, never markdown or a path supplied by the browser.
module.exports=function artifactSelection(ctx,source,moduleId,selection){
 if(!selection||typeof selection.jobId!=='string'||selection.jobId.length>300||typeof selection.artifactId!=='string'||!/^[a-f0-9]{64}$/.test(selection.artifactId))throw fail('Invalid saved result reference',400);
 if(moduleId!=='artifact-'+selection.artifactId)throw fail('Saved result identity changed');
 const job=require('./meeting-board-jobs').get(ctx.dataDir).items.find(j=>j.id===selection.jobId);
 if(!job||job.state!=='completed'||job.meetingId!=='assistant:global'||!job.request?.candidateId||![source.id,source.sessionId].filter(Boolean).includes(job.request.contextId))throw fail('Open the meeting containing this completed result');
 if(job.artifact?.id!==selection.artifactId||job.artifact.candidateId!==job.request.candidateId||job.artifact.candidateHash!==job.request.candidateHash)throw fail('Saved result does not match this task');
 const {body}=require('./task-artifacts').read(ctx.dataDir,selection.artifactId,'md');
 if(crypto.createHash('sha256').update(body).digest('hex')!==job.artifact.sha256)throw fail('Saved result integrity check failed');
 return {id:moduleId,kind:'plan',title:job.artifact.title||'AI draft',body,sourceRefs:['artifact:'+selection.artifactId,'candidate:'+job.request.candidateId]};
};
