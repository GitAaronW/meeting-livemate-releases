'use strict';
const LIMIT=12;
const termsOf=text=>{const words=String(text||'').toLowerCase().match(/[a-z0-9]{2,}|[\u4e00-\u9fff]{2,}/g)||[];return [...new Set(words.flatMap(w=>/[\u4e00-\u9fff]/.test(w)&&w.length>4?[w,...Array.from({length:w.length-1},(_,i)=>w.slice(i,i+2))]:[w]))].slice(0,40);};
function sanitizePageContext(j={}) {
 if(!j||typeof j!=='object'||Array.isArray(j))return {};
 const text=(k,n)=>typeof j[k]==='string'?j[k].slice(0,n):'';
 return {motherDocumentId:text('motherDocumentId',60),blockIds:Array.isArray(j.blockIds)?j.blockIds.filter(x=>typeof x==='string'&&x.length<=100).slice(0,12):[],page:text('page',240),view:text('view',240),projectId:text('projectId',100),objectId:text('objectId',100),quote:text('quote',4000),targetSourceIds:Array.isArray(j.targetSourceIds)?j.targetSourceIds.filter(x=>typeof x==='string'&&x.length<=100).slice(0,8):[],sourceIds:Array.isArray(j.sourceIds)?j.sourceIds.filter(x=>typeof x==='string').slice(0,8).map(x=>x.slice(0,100)):[]};
}
function executionKind(action,text){
 if(action!=='auto')return action;
 // Independent deliverables receive independent Codex threads. Conversation
 // and read questions retain the ongoing master thread; no extra send button.
 return /(帮我做|帮我写|生成|制作|起草|整理成|画出|对比|调查|研究|执行|准备一|create|generate|draft|make|prepare|compare|research|build)/i.test(text)?'run':'chat';
}
function scopeContext(ctx,request,meetings){
 const d=ctx.hub.data,p=request.pageContext||{},selected=d.sources.find(x=>x.sessionId===request.contextId||x.id===request.contextId);
 const projectId=p.projectId||selected?.projectId||'';
 const terms=termsOf(request.comment);
 const score=x=>terms.reduce((n,t)=>n+(String(x.title||'').toLowerCase().includes(t)?1:0),0);
 const pool=projectId?meetings.filter(x=>x.projectId===projectId):meetings.filter(x=>score(x)>0);
 // With no scope or match, return titles only for recent meetings; do not load unrelated project bodies.
 if(!projectId&&!pool.length)pool.push(...meetings.slice(0,4));
 const relevant=pool.map(x=>({...x,_score:score(x)+(x.id===request.contextId?100:0)})).sort((a,b)=>b._score-a._score).slice(0,LIMIT).map(({_score,...x})=>x);
 const ids=new Set([projectId,...relevant.map(x=>x.projectId)].filter(Boolean));
 const tasks=(d.workItems||[]).filter(w=>(!projectId||w.projectId===projectId)&&score(w)>0).sort((a,b)=>score(b)-score(a)).slice(0,8).map(w=>({id:w.id,title:w.title,status:w.status,due:w.due||'',owner:w.owner||'',sourceIds:w.sourceIds||[],verification:w.verification||null}));
 return {projectScope:projectId||'Relevant results only; keep different projects separate. Ask before linking projects.',meetings:relevant,projects:(d.projects||[]).filter(x=>ids.has(x.id)).map(x=>({id:x.id,title:x.title})),relevantTasks:tasks};
}
function bindModuleTask(ctx,source,request){
 const module=source?.board?.modules?.find(m=>m.id===request.pageContext?.objectId&&m.kind==='task');
 if(!module||(source.projectId||'')!==(request.pageContext?.projectId||source.projectId||''))return;
 const tasks=ctx.hub.data.tasks||[];
 if(module.taskId){
  const bound=tasks.find(t=>t.id===module.taskId&&(t.sourceIds||[]).includes(source.id)&&(t.projectId||'')===(source.projectId||''));
  if(!bound)throw Error('画布任务关联不可用，请核对来源 / Task binding unavailable');
  return;
 }
 // An explicit user action creates a draft task for this exact module. It
 // does not infer that another task with a similar title is the same work.
 const current=ctx.hub.data.sources.find(s=>s.id===source.id);
 if(!current||current.revision!==source.revision){const error=Error('来源已更新，请刷新后重试 / Source changed');error.status=409;throw error;}
 require('./meeting-board').validate(source.board);
 const task=ctx.hub.task({key:'board-module:'+source.id+':'+module.id,text:module.title,notes:module.body,status:'draft',acceptanceCriteria:module.acceptanceCriteria||'',sourceRefs:module.sourceRefs||[]},source.id);
 task.projectId=source.projectId||'';
 const board=JSON.parse(JSON.stringify(source.board));board.modules.find(m=>m.id===module.id).taskId=task.id;
 const saved=ctx.hub.update('sources',source.id,{board:require('./meeting-board').validate(board)},source.revision);
 Object.assign(source,saved);ctx.hub.save();
}
function bindDocumentTasks(ctx,record,selected){
 const links=selected.map(n=>String(n.attrs?.sourceRef||''));
 const sources=(ctx.hub?.data?.sources||[]).filter(s=>(s.projectId||'')===(record.projectId||'')&&(record.meetings||[]).includes(s.sessionId));
 const matches=sources.flatMap(s=>(s.board?.modules||[]).filter(m=>links.includes(s.sessionId+':'+m.id)).map(m=>({s,m})));
 if(matches.length!==1||matches[0].m.kind!=='task')return;
 const {s,m}=matches[0];bindModuleTask(ctx,s,{pageContext:{objectId:m.id,projectId:record.projectId||''}});
}
function selectedBoard(board,request){
 if(!board)return null;
 const terms=termsOf(request.comment),id=request.pageContext?.objectId;
 const modules=(board.modules||[]).map(m=>({m,score:(id===m.id?100:0)+terms.reduce((n,t)=>n+(String(m.title+' '+m.body).toLowerCase().includes(t)?1:0),0)})).sort((a,b)=>b.score-a.score).slice(0,6).map(({m})=>({id:m.id,...(m.taskId?{taskId:m.taskId}:{}),kind:m.kind,title:m.title,body:String(m.body||'').slice(0,3000),sourceRefs:m.sourceRefs||[],...(m.view?{view:m.view}:{}),...(m.nodes?{nodes:m.nodes,edges:m.edges||[]}: {})}));
 return {goal:board.goal||'',modules};
}
function saveDraft(ctx,request,reply,draft){
 if(request.action!=='run'||!request.contextId||!reply.trim())return {};
 // Append to the latest board: parallel jobs cannot overwrite each other or
 // the user's edits. This is an AI draft, never a confirmed task/decision.
 const source=ctx.hub.data.sources.find(s=>s.sessionId===request.contextId);
 if(!source||!ctx.hub.update)return {};
 const board=JSON.parse(JSON.stringify(source.board||{modules:[]}));
 const moduleId='agent-'+require('crypto').createHash('sha256').update(request.requestId).digest('hex').slice(0,24);
 if(board.modules.some(m=>m.id===moduleId))return {resultIds:[moduleId]};
 const selected=board.modules.find(m=>m.id===request.pageContext.objectId);
 let graph=null,refs=selected?.sourceRefs||[];
 if(draft){
  try{
   graph=require('../web/meeting-graph').normalize(draft.nodes,draft.edges);
   if(!graph.nodes.length)throw Error('empty graph');
   const session=ctx.session?.(request.contextId),known=new Set((session?.transcript||[]).flatMap((t,i)=>{const id=String(t.segId||t.id||'segment-'+i);return [id,request.contextId+':'+id];}));
   for(const ref of selected?.sourceRefs||[])known.add(ref);
   if(!Array.isArray(draft.sourceRefs)||!draft.sourceRefs.length||draft.sourceRefs.some(r=>!known.has(r)))throw Error('unknown source');
   refs=[...new Set(draft.sourceRefs)];
  }catch{throw Object.assign(Error('图表或来源格式有误，原文未修改；请重试 / Invalid diagram or sources; original preserved'),{status:502,draft:reply});}
 }
 board.modules.push({id:moduleId,kind:graph?'map':'note',title:typeof draft?.title==='string'?draft.title.slice(0,200):request.comment.slice(0,120),body:reply.slice(0,40000),edited:true,view:graph?'diagram':'document',...(graph||{}),topic:selected?.topic||selected?.title||'MyAgent',context:request.lang==='en'?'AI draft · review before using':'AI 草稿 · 使用前核对',sourceRefs:refs});
 if(board.cloud)board.cloud.verified=false;
 const saved=ctx.hub.update('sources',source.id,{board:require('./meeting-board').validate(board)},source.revision);
 return {source:saved,resultIds:[moduleId]};
}
module.exports={bindDocumentTasks,bindModuleTask,saveDraft,sanitizePageContext,executionKind,scopeContext,selectedBoard,termsOf};
