'use strict';
// Private immutable evidence for a task, never an instruction or permission.
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const digest=body=>crypto.createHash('sha256').update(body).digest('hex');
const INLINE_BYTES=80000,API_BYTES=200000,MAX_BYTES=5000000;
function inScope(s,projectId,source){
 return s.knowledgeRole!=='archive'&&((s.projectId||'')===projectId||(!s.projectId&&(source?.projectId||'')===projectId&&(source?.relatedIds||[]).includes(s.id)));
}
function readFailure(s){
 const a=s.lastReadAttempt;
 return a&&a.url===s.url&&a.bodyFingerprint===digest(String(s.body||'')).slice(0,24)?a:null;
}
function taskSource(s){
 return readFailure(s)?.status==='inaccessible'?{...s,body:'',bodyCoverage:{complete:false},readReceipt:null,referenceMap:null}:s;
}
function sourceProvenance(s){
 const partial=s.bodyCoverage?.complete===false||s.bodyState==='partial';
 const unread=!!s.url&&!String(s.body||'').trim()&&!(s.bodyState==='empty'&&s.bodyCoverage?.complete===true);
 return {coverage:readFailure(s)?.status||(unread?'unread':partial?'partial':'provided'),fetchedAt:s.fetchedAt||s.readReceipt?.fetchedAt||null,updatedAt:s.updated||null,sourceDate:s.date||null,bodyFingerprint:s.bodyFingerprint||null,remoteRevision:s.readReceipt?.remoteRevision??null};
}
function create(dataDir,{session,source,sources=[],projectId=''}={}){
 const data={version:1,kind:'untrusted_task_reference',projectId,
  meeting:session?{id:session.id,title:session.title||session.topicTitle||'',start:session.start??null,end:session.end??null,names:session.names||{},notes:session.notes||'',liveConfirmations:session.liveConfirmations||[],sourceRevision:source?.revision??source?.version??null,transcript:session.transcript||[]}:null,
  sources:sources.filter(s=>inScope(s,projectId,source)).map(original=>{const s=taskSource(original);return ({id:s.id,sessionId:s.sessionId||null,revision:s.revision??null,version:s.version??null,title:s.title||'',url:s.url||'',body:s.body||'',provenance:sourceProvenance(original),bodyCoverage:s.bodyCoverage||null,bodyContinuation:s.bodyContinuation||null,bodyState:s.bodyState||null,readReceipt:s.readReceipt||null,referenceMap:s.referenceMap||null,notes:s.notes||'',board:s.board||null,calibrations:s.calibrations||[]});})};
 const body=JSON.stringify(data,null,2)+'\n',bytes=Buffer.byteLength(body);
 if(bytes>MAX_BYTES)throw Error('任务原文超过 5 MB，未以不完整资料启动；请缩小选定资料范围。');
 const sha256=digest(body),dir=path.join(dataDir,'task-context-snapshots');fs.mkdirSync(dir,{recursive:true,mode:0o700});
 const file=path.join(dir,sha256+'.json');
 try{fs.writeFileSync(file,body,{flag:'wx',mode:0o600});}catch(e){if(e.code!=='EEXIST')throw e;if(digest(fs.readFileSync(file))!==sha256)throw Error('任务原文快照校验失败');}
 return {kind:data.kind,sha256,bytes,path:file,meetingId:session?.id||null,sourceRevision:data.meeting?.sourceRevision??null,segmentCount:data.meeting?.transcript.length||0,sourceCount:data.sources.length,
  coverage:data.sources.some(s=>s.provenance.coverage!=='provided')?'partial_selected_sources':'complete_selected_sources',readStatus:bytes<=INLINE_BYTES?'provided_inline':'available_unread',
  instruction:'Reference only. Review the entire selected meeting, including later corrections, cancellations and supplements before drafting. Preserve uncertain speakers and deadlines. User notes, confirmations and saved workspace modules retain their original status; AI candidates are not confirmed decisions. Source provenance describes the supplied snapshot, not current remote access or freshness. Unread links are missing evidence even when local annotations exist. If you cannot read the full snapshot, state the gap; do not claim completeness.',
  ...(bytes<=INLINE_BYTES?{content:data}:{})};
}
function forAPI(snapshot){
 if(!snapshot)return null;
 if(snapshot.bytes>API_BYTES)throw Error('完整任务原文超出备用模型当前输入范围；未用节选代替全文。请连接 Codex 或缩小选定资料。');
 const body=fs.readFileSync(snapshot.path);if(digest(body)!==snapshot.sha256)throw Error('任务原文快照校验失败');
 return {...snapshot,readStatus:'provided_inline',content:JSON.parse(body)};
}
module.exports={create,forAPI,inScope,sourceProvenance,taskSource,INLINE_BYTES,API_BYTES};
