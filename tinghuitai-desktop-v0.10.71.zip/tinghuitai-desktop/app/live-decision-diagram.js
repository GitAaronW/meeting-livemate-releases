'use strict';
// A grounded change uses the existing board and candidate revision history.
// No second artifact store, model call, or automatic edit of the user's document.
const crypto=require('crypto'),boards=require('./meeting-board'),candidates=require('./meeting-candidates');
const fingerprint=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
function create({hub,log=()=>{}}){
 return function save(session,item){
  const change=item?.decisionChange;
  if(!session||session.finalized||session.end||item?.stale||item?.channel!=='judgment'||!change||
   !['previous','reason','current'].every(k=>typeof change[k]==='string'&&change[k].trim())||!item.topic)return null;
  const previous=(session.factchecks||[]).find(x=>x.id===change.previousId&&x.channel==='judgment'&&!x.stale&&x.topic===item.topic);
  // Both ends must be journaled in this meeting, with matching snapshots and references.
  const journaled=(session.factchecks||[]).includes(item);
  const supported=x=>{
   if(!Array.isArray(x?.sourceRefs)||!x.sourceRefs.length||typeof x.quote!=='string'||x.quote.length<4)return false;
   const rows=x.sourceRefs.map(r=>(session.transcript||[]).find(t=>typeof r.segId==='string'&&t.id===r.segId&&!t.stale));
   return rows.every(Boolean)&&rows.some(t=>String(t.text||'').includes(x.quote));
  };
  if(!journaled||!previous||previous.point!==change.previous||item.point!==change.current||item.whyChanged!==change.reason||!supported(previous)||!supported(item))return null;
  try{
   const source=hub.data.sources.find(s=>s.key==='session:'+session.id)||hub.ingestSession(session);
   if(!source||source.projectId&&(source.projectId!==session.projectId))return null;
   const id='decision-'+fingerprint([session.id,item.topic]).slice(0,32),module=source.board?.modules?.find(m=>m.id===id);
   const en=session.uiLang==='en',labels=en?['Previous interpretation','New evidence','Current interpretation']:['原判断','新依据','当前判断'];
   const values=[change.previous,change.reason,change.current];
   const body=(en?'AI inference · not a confirmed decision':'AI 推断 · 尚非确认决定')+'\n\n'+values.map((v,i)=>labels[i]+'：'+v).join('\n\n');
   const nodes=values.map((v,i)=>({id:['previous','evidence','current'][i],label:v.length>230?Array.from(v).slice(0,110).join('')+'…':v,detail:labels[i]+'：'+v}));
   const edges=[{from:'previous',to:'evidence',label:en?'reconsidered with':'结合新依据'},{from:'evidence',to:'current',label:en?'updated interpretation':'更新解读'}];
   const sourceRefs=[...new Set([...previous.sourceRefs,...item.sourceRefs].map(r=>r.segId))];
   if(!module){
    const board=boards.validate({...source.board,modules:[...(source.board?.modules||[]),{id,kind:'map',view:'diagram',title:(en?'Judgement change · ':'判断变化 · ')+item.topic,topic:item.topic,body,nodes,edges,edited:false,context:en?'AI draft · editable':'AI 草稿 · 可直接修改',sourceRefs}]});
    hub.update('sources',source.id,{board},source.revision);return id;
   }
   // Manual edits/comments freeze automatic replacement; the new signal remains visible.
   if(module.edited||module.kind!=='map'||module.topic!==item.topic)return null;
   const before=candidates.snapshot(source,session,id),saved=source.candidateRevisions?.[id];
   if(before.comments.length||before.protectedParagraphs.length||(saved&&saved.baseFingerprint!==before.fingerprint))return null;
   if(before.body===body&&fingerprint(before.nodes)===fingerprint(nodes)&&fingerprint(before.edges)===fingerprint(edges)&&fingerprint(before.sourceRefs)===fingerprint(sourceRefs))return id;
   const at=new Date().toISOString(),revision={id,body,nodes,edges,sourceRefs,revision:before.revision+1,baseFingerprint:before.fingerprint,comments:before.comments,protectedParagraphs:[],versions:[...before.versions,{revision:before.revision,body:before.body,nodes:before.nodes,edges:before.edges,sourceRefs:before.sourceRefs,at}],updated:at};
   hub.update('sources',source.id,{candidateRevisions:{...source.candidateRevisions,[id]:revision}},source.revision);return id;
  }catch(e){log('decision diagram '+e.message);return null;}
 };
}
module.exports={create};
