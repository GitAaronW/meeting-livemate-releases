'use strict';
const crypto=require('crypto');
const KINDS=['summary','plan','task','action','map','note','insight'];
function imageRefs(images){
 if(images===undefined)return undefined;
 if(!Array.isArray(images)||images.length>40)throw Error('invalid images');
 const seen=new Set();return images.map(i=>{
 if(!i||typeof i.id!=='string'||!/^[\w-]{1,120}$/.test(i.id)||seen.has(i.id))throw Error('invalid image identity');seen.add(i.id);
 let url;try{url=new URL(i.url);}catch{throw Error('invalid image URL');}if(url.protocol!=='https:'||url.username||url.password)throw Error('invalid image URL');
 for(const k of ['sourceId','version','quote'])if(typeof i[k]!=='string'||i[k].length>(k==='quote'?4000:200)||(k!=='quote'&&!i[k].trim()))throw Error('invalid image source');
 return {id:i.id,url:url.href,sourceId:i.sourceId,version:i.version,quote:i.quote,contentRead:false};
 });
}
function validate(board){
 if(!board||typeof board!=='object'||!Array.isArray(board.modules)||board.modules.length>120)throw Error('invalid board');
 const seen=new Set();const modules=board.modules.map(m=>{
  if(!m||typeof m.id!=='string'||!/^[\w-]{1,80}$/.test(m.id)||seen.has(m.id))throw Error('invalid module id');seen.add(m.id);
  for(const [field,valid] of [['kind',KINDS.includes(m.kind)],['title',typeof m.title==='string'&&m.title.length<=200],['body',typeof m.body==='string'&&m.body.length<=40000],['edited',typeof m.edited==='boolean']])if(!valid)throw Object.assign(Error('invalid module: '+field),{field});
  if(!Array.isArray(m.sourceRefs)||m.sourceRefs.length>100||m.sourceRefs.some(x=>typeof x!=='string'||x.length>160))throw Error('invalid references');
  if(m.taskId!==undefined&&(typeof m.taskId!=='string'||!/^t-[\w-]{1,100}$/.test(m.taskId)))throw Error('invalid task binding');
  if(m.acceptanceCriteria!==undefined&&(typeof m.acceptanceCriteria!=='string'||m.acceptanceCriteria.length>20000))throw Error('invalid acceptance criteria');
  if(m.actionText!==undefined&&(typeof m.actionText!=='string'||m.actionText.length>500))throw Error('invalid action text');
  const views=['document','timeline','checklist','diagram','comparison'];
  const view=views.includes(m.view)?m.view:undefined;
  const graph=m.edges!==undefined?require('../web/meeting-graph').normalize(m.nodes,m.edges):null;
  return {...(m.images!==undefined?{images:imageRefs(m.images)}:{}),...(m.artifact?{artifact:require('./project-deliverables').validate(m.artifact)}:{}),id:m.id,...(m.actionText!==undefined?{actionText:m.actionText.trim()}:{}),...(m.taskId?{taskId:m.taskId}:{}),...(m.acceptanceCriteria!==undefined?{acceptanceCriteria:m.acceptanceCriteria}:{}),kind:m.kind,title:m.title,body:m.body,edited:m.edited,sourceRefs:m.sourceRefs.slice(),...(m.origin&&['sourceId','moduleId','sessionId','title'].every(k=>typeof m.origin[k]==='string'&&m.origin[k].length<=200)?{origin:{sourceId:m.origin.sourceId,moduleId:m.origin.moduleId,sessionId:m.origin.sessionId,title:m.origin.title}}:{}),...(view?{view}:{}),...(typeof m.topic==='string'&&m.topic.length<=120?{topic:m.topic}:{}),...(typeof m.context==='string'&&m.context.length<=1000?{context:m.context}:{}),...(graph?{nodes:graph.nodes,edges:graph.edges}:Array.isArray(m.nodes)&&m.nodes.length<=30&&m.nodes.every(n=>n&&typeof n.label==='string'&&n.label.length<=240&&(!n.detail||typeof n.detail==='string'&&n.detail.length<=1000))?{nodes:m.nodes.map(n=>({label:n.label,detail:n.detail||''}))}:{})};
 });return {version:1,modules,...(Array.isArray(board.contextManifest)?{contextManifest:board.contextManifest.slice(0,40).map(p=>({key:String(p.key||'').slice(0,160),title:String(p.title||'').slice(0,200),version:String(p.version||'').slice(0,80),missing:p.missing===true,truncated:p.truncated===true}))}:{}),...(typeof board.contextHash==='string'?{contextHash:board.contextHash.slice(0,64)}:{}),...(typeof board.goal==='string'&&board.goal.length<=600?{goal:board.goal}:{}),cursor:Math.max(0,Number.isSafeInteger(board.cursor)?board.cursor:0),updated:new Date().toISOString(),...(board.cloud&&typeof board.cloud.url==='string'&&(()=>{try{const u=new URL(board.cloud.url);return u.protocol==='https:'&&/(^|\.)(larksuite\.com|feishu\.cn)$/.test(u.hostname);}catch{return false;}})()?{cloud:{url:board.cloud.url,verified:board.cloud.verified===true}}:{})};
}
function merge(board, incoming, refs){
 const old=validate(board||{modules:[]}),known=new Set(refs),seen=new Set();
 if(!Array.isArray(incoming)||incoming.length>50)throw Error('invalid model output');
 for(const raw of incoming){
  const prior=old.modules.find(m=>m.id===raw.id);if(prior?.edited)continue;
  const m={...prior,...raw,id:prior?prior.id:crypto.randomUUID(),edited:false,sourceRefs:raw.sourceRefs===undefined&&prior?prior.sourceRefs.slice():(Array.isArray(raw.sourceRefs)?raw.sourceRefs.filter(x=>known.has(x)):[])};
  // Models cannot introduce or change a host task binding.
  if(prior?.taskId)m.taskId=prior.taskId;else delete m.taskId;
  if(prior?.acceptanceCriteria!==undefined)m.acceptanceCriteria=prior.acceptanceCriteria;else delete m.acceptanceCriteria;
  if(prior?.artifact)m.artifact=prior.artifact;else delete m.artifact;
  if(prior?.images)m.images=prior.images;else delete m.images;
  if(prior?.origin)m.origin=prior.origin;else delete m.origin;
  if(prior){if(seen.has(prior.id))throw Error('duplicate patch');seen.add(prior.id);Object.assign(prior,m);}else old.modules.push(m);
 }return validate(old);
}
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
function inline(s){return esc(s).replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>').replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g,(_,label,url)=>'<a rel="noreferrer" href="'+url+'">'+label+'</a>');}
function documentBody(body){
 const out=[];let list=false,table=false;
 const close=()=>{if(list){out.push('</ul>');list=false;}if(table){out.push('</tbody></table></div>');table=false;}};
 for(const line of String(body).split('\n')){
  if(!line.trim()){close();continue;}
  if(/^\s*\|/.test(line)){if(list){out.push('</ul>');list=false;}const cells=line.trim().replace(/^\||\|$/g,'').split('|');if(cells.every(c=>/^\s*:?-+:?\s*$/.test(c)))continue;if(!table){out.push('<div class="table-scroll"><table><tbody>');table=true;}out.push('<tr>'+cells.map(c=>'<td>'+inline(c.trim())+'</td>').join('')+'</tr>');continue;}
  if(table){out.push('</tbody></table></div>');table=false;}
  const bullet=line.match(/^\s*(?:[-*]|\d+[.)])\s+(.+)/);if(bullet){if(!list){out.push('<ul>');list=true;}out.push('<li>'+inline(bullet[1])+'</li>');continue;}
  if(list){out.push('</ul>');list=false;}
  const heading=line.match(/^#{1,6}\s+(.+)/);out.push(heading?'<h3>'+inline(heading[1])+'</h3>':'<p>'+inline(line)+'</p>');
 }close();return out.join('');
}
function diagramText(m){
 if((m.view||({plan:'timeline',task:'checklist',map:'diagram'})[m.kind]||'document')!=='diagram'||!m.nodes?.length)return '';const labels=new Map(m.nodes.map((n,i)=>[n.id||'node-'+i,n.label]));
 return '\n\n'+m.nodes.map(n=>'- '+n.label+(n.detail?' — '+n.detail:'')).join('\n')+((m.edges||[]).length?'\n\n'+m.edges.map(e=>'- '+labels.get(e.from)+' → '+labels.get(e.to)+(e.label?' — '+e.label:'')).join('\n'):'');
}
function diagramHTML(m){
 if((m.view||({plan:'timeline',task:'checklist',map:'diagram'})[m.kind]||'document')!=='diagram'||!m.nodes?.length)return '';if(!Array.isArray(m.edges))return '<ul>'+m.nodes.map(n=>'<li>'+esc(n.label)+(n.detail?' — '+esc(n.detail):'')+'</li>').join('')+'</ul>';
 const g=require('../web/meeting-graph').layout(m.nodes,m.edges);
 const lines=g.connections.map(e=>'<path d="'+e.path+'"/><path d="'+e.arrow+'"/>'+(e.label?'<text x="'+e.labelX+'" y="'+e.labelY+'" text-anchor="middle">'+esc(e.label.length>20?e.label.slice(0,19)+'…':e.label)+'</text>':'')).join('');
 const cards=g.nodes.map(n=>'<div class="graph-node" style="left:'+n.x+'px;top:'+n.y+'px;height:'+n.height+'px" title="'+esc(n.label+' — '+n.detail)+'"><strong>'+esc(n.label)+'</strong></div>').join('');
 return '<div class="graph-scroll"><div class="graph" style="width:'+g.width+'px;height:'+g.height+'px"><svg aria-hidden="true" width="'+g.width+'" height="'+g.height+'" viewBox="0 0 '+g.width+' '+g.height+'">'+lines+'</svg>'+cards+'</div></div><details><summary>关系 / Relationships</summary>'+documentBody(diagramText(m))+'</details>';
}
function imagesHTML(m){return (m.images||[]).map(i=>'<figure><a href="'+esc(i.url)+'" rel="noreferrer"><img loading="lazy" referrerpolicy="no-referrer" src="'+esc(i.url)+'" alt="Source image" style="max-width:100%;max-height:600px;object-fit:contain"></a><figcaption>'+esc(i.sourceId+' · '+i.version)+'</figcaption><blockquote>'+esc(i.quote)+'</blockquote></figure>').join('');}
function exportBoard(board,title,format){
 board=validate(board);const md='# '+title+'\n\n'+(board.goal?board.goal+'\n\n':'')+board.modules.map(m=>'## '+m.title+'\n\n'+m.body+diagramText(m)).join('\n\n');
 if(format==='html')return '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+esc(title)+'</title><style>body{margin:0;background:#f7f7f8;color:#222;font:16px/1.8 system-ui,"PingFang SC",sans-serif}main{max-width:920px;margin:40px auto;padding:0 24px}h1{font-size:32px;line-height:1.4}h2{font-size:23px;margin:0 0 20px}h3{font-size:18px;margin:24px 0 10px}section{background:white;border:1px solid #e5e5e7;border-radius:20px;padding:32px;margin:24px 0}.goal{color:#666}li{margin:8px 0}a{color:#C8102E}figure{margin:20px 0;min-width:0}figcaption,blockquote{overflow-wrap:anywhere}figure img{display:block}.table-scroll{overflow:auto}table{width:100%;border-collapse:collapse}td{border-bottom:1px solid #eee;padding:12px;vertical-align:top}code{background:#f4f4f5;padding:2px 4px;border-radius:4px}.graph-scroll{overflow:auto}.graph{position:relative}.graph svg{position:absolute;inset:0}.graph path{fill:none;stroke:#8c9690;stroke-width:1.7}.graph text{fill:#58625b;font:12px system-ui;paint-order:stroke;stroke:#fff;stroke-width:5px}.graph-node{position:absolute;box-sizing:border-box;width:210px;height:120px;padding:14px 16px;border:1px solid #d9e0db;border-radius:12px;background:#f6f8f6;overflow:hidden}.graph-node strong,.graph-node small{display:-webkit-box;-webkit-box-orient:vertical;overflow:hidden;line-height:1.4}.graph-node strong{-webkit-line-clamp:2;font-size:14px}.graph-node small{-webkit-line-clamp:3;font-size:12px;color:#68716b;margin-top:8px}@media(max-width:600px){main{padding:0 16px}section{padding:16px}.graph{zoom:.72}}@media print{body{background:white}main{margin:0;max-width:none}section{border:0;padding:12px 0;break-inside:avoid}}</style></head><body><main><h1>'+esc(title)+'</h1>'+(board.goal?'<p class="goal">'+esc(board.goal)+'</p>':'')+board.modules.map(m=>'<section><h2>'+esc(m.title)+'</h2>'+diagramHTML(m)+documentBody(m.body)+imagesHTML(m)+'</section>').join('')+'</main></body></html>';
 if(format==='opml')return '<?xml version="1.0" encoding="UTF-8"?><opml version="2.0"><head><title>'+esc(title)+'</title></head><body><outline text="'+esc(title)+'">'+board.modules.map(m=>'<outline text="'+esc(m.title)+'">'+(m.body+diagramText(m)).split('\n').filter(Boolean).map(t=>'<outline text="'+esc(t)+'"/>').join('')+'</outline>').join('')+'</outline></body></opml>';
 return md;
}
module.exports={validate,merge,exportBoard,KINDS};
