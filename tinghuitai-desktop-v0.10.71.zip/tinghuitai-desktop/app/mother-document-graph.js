'use strict';
const {Node}=require('./mother-document-runtime'),graph=require('../web/meeting-graph');
// A diagram remains structured data in the same document, not an external screenshot.
module.exports=Node.create({
 name:'meetingGraph',group:'block',atom:true,selectable:true,
 addAttributes(){return {graph:{default:{nodes:[],edges:[]},renderHTML:()=>({})}};},
 parseHTML(){return [{tag:'figure[data-meeting-graph]'}];},
 renderHTML(){return ['figure',{'data-meeting-graph':'true'},'Meeting diagram'];},
 addNodeView(){return ({node,editor,getPos})=>{
  let current=node;const dom=document.createElement('figure');dom.className='mother-graph';dom.contentEditable='false';
  function replace(next){const normalized=graph.normalize(next.nodes,next.edges),pos=getPos();if(typeof pos!=='number')return;editor.view.dispatch(editor.state.tr.setNodeMarkup(pos,undefined,{...current.attrs,graph:normalized}));}
  function paint(){
   dom.replaceChildren(graph.render(current.attrs.graph,document));
   if(!editor.isEditable)return;
   const details=document.createElement('details'),summary=document.createElement('summary');summary.textContent=(document.documentElement?.lang||'zh').startsWith('en')?'Edit diagram':'编辑图示';details.append(summary);
   const data=graph.normalize(current.attrs.graph.nodes,current.attrs.graph.edges);
   for(const n of data.nodes){const row=document.createElement('label'),label=document.createElement('input'),detail=document.createElement('textarea');label.value=n.label;label.setAttribute('aria-label','Node label '+n.id);detail.value=n.detail;detail.setAttribute('aria-label','Node detail '+n.id);label.maxLength=240;detail.maxLength=1000;row.append(label,detail);details.append(row);
    label.onchange=()=>replace({...data,nodes:data.nodes.map(x=>x.id===n.id?{...x,label:label.value}:x)});
    detail.onchange=()=>replace({...data,nodes:data.nodes.map(x=>x.id===n.id?{...x,detail:detail.value}:x)});
   }
   data.edges.forEach((edge,i)=>{const row=document.createElement('label'),from=document.createElement('select'),to=document.createElement('select'),label=document.createElement('input');for(const select of [from,to])for(const n of data.nodes){const option=document.createElement('option');option.value=n.id;option.textContent=n.label;select.append(option);}from.value=edge.from;to.value=edge.to;from.setAttribute('aria-label','Relationship source');to.setAttribute('aria-label','Relationship target');label.value=edge.label;label.maxLength=160;label.setAttribute('aria-label','Relationship label');row.append(from,to,label);details.append(row);const change=()=>{try{replace({...data,edges:data.edges.map((x,j)=>j===i?{from:from.value,to:to.value,label:label.value}:x)});}catch(e){label.setCustomValidity(e.message);label.reportValidity();}};from.onchange=to.onchange=label.onchange=change;});
   dom.append(details);
  }
  paint();return {dom,update(next){if(next.type!==current.type)return false;current=next;const open=dom.querySelector('details')?.open;paint();if(open&&dom.querySelector('details'))dom.querySelector('details').open=true;return true;},stopEvent(event){return !!event.target.closest('input,textarea,select,details');},ignoreMutation(){return true;}};
 };
 }
});
