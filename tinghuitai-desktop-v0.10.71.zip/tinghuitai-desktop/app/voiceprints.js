'use strict';
// Local, optional registry. Registration is not evidence that ASR has matched a voice.
// Never infer identity from diarization order, participants, or a preceding sentence.
const fs = require('fs');
const own = (o, k) => Object.prototype.hasOwnProperty.call(o || {}, k);
const idOf = value => typeof value === 'string' && /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(value.trim()) ? value.trim().toLowerCase() : '';
function aliases(row) {
  const ids = ['SpeakID', 'SpeakId'].filter(k => own(row, k)).map(k => idOf(row[k]));
  return ids.length && ids.every(Boolean) && new Set(ids).size === 1 ? ids[0] : '';
}
function registry(rows) {
  const result = new Map(), rejected = new Set();
  if (!Array.isArray(rows)) return result;
  for (const row of rows) {
    if (!row || typeof row !== 'object') continue;
    const id = aliases(row), name = typeof row.name === 'string' ? row.name.trim() : '';
    if (!id) {
      for (const key of ['SpeakID', 'SpeakId']) {
        const conflict = idOf(row[key]);
        if (conflict) { rejected.add(conflict); result.delete(conflict); }
      }
      continue;
    }
    if (!name || name.length > 80 || /[\x00-\x1f\x7f]/.test(name) || (own(row, 'Status') && row.Status !== 1) || result.has(id)) {
      rejected.add(id); result.delete(id); continue;
    }
    if (!rejected.has(id)) result.set(id, name);
  }
  return result;
}
function load(file) { try { return registry(JSON.parse(fs.readFileSync(file, 'utf8'))); } catch { return new Map(); } }
function resolve(utterance, registered) {
  // These are explicit identity fields only. speaker_id=1 is a local diarization
  // label, not the first registered person. No stream-wide propagation is safe.
  const values = [];
  for (const row of [utterance, utterance?.additions]) {
    if (!row || typeof row !== 'object') continue;
    for (const key of ['SpeakID', 'SpeakId']) if (own(row, key)) values.push(idOf(row[key]));
  }
  if (!values.length || values.some(v => !v) || new Set(values).size !== 1) return null;
  const id = values[0], name = registered?.get(id);
  return name ? { id, name, source: 'provider-reported' } : null;
}
function apply(session, utterance, row) {
  const identity = resolve(utterance, session.voiceprintRegistry);
  if (!identity) return false;
  row.speakerIdentity = identity;
  // A human label on the original speaker always wins. The stable identity key
  // otherwise keeps numeric speaker labels from transferring names on reconnect.
  if (own(session.names, row.speaker)) return false;
  row.diarizationSpeaker = row.speaker;
  row.speaker = 'vp-' + identity.id;
  if (own(session.names, row.speaker)) return false;
  session.names = { ...session.names, [row.speaker]: identity.name };
  return true;
}
module.exports = { registry, load, resolve, apply };
