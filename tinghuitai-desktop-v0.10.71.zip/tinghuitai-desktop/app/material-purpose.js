'use strict';
// Explicit metadata only. Retrieved business documents are not retrieval artifacts.
const values=new Set(['unknown','business','engineering','retrieval']);
function validate(value){if(!values.has(value))throw Error('Invalid material purpose');return value;}
function internal(value){return value==='engineering'||value==='retrieval';}
module.exports={validate,internal};
