'use strict';
// Natural-language entry over the existing Hub work items. No second task store.
const crypto=require('crypto');
const {hash}=require('./send-gate');
const fail=(message,status=400)=>Object.assign(Error(message),{status});
// Keep case-sensitive URLs and decimal numbers distinct while ignoring prose punctuation.
function normalize(s){const tokens=[];const text=String(s||'').normalize('NFKC').replace(/https:\/\/[^\s<>"，。；）)]+|\d+(?:\.\d+)+/g,value=>{tokens.push(value);return '\u0001'+(tokens.length-1)+'\u0002';});return [text.toLowerCase().replace(/[\s，。！？、；：,.!?;:]+/g,''),tokens];}
function modeOf(input){return /^(?:\s*)(?:帮我|替我|请\s*AI|让\s*AI|AI\s*帮|help me|research|draft|write me)/i.test(input)?'ai':'self';}
function fingerprint(item){return hash([item.id,item.revision,item.title,item.notes,item.owner,item.status,item.projectId,item.sourceIds,item.acceptanceCriteria,item.intake]);}
function create(ctx,j){
 const input=typeof j.comment==='string'?j.comment.trim():'';
 if(!input||input.length>4000)throw fail('请用一句话描述任务（最多4000字） / Describe your task (up to 4000 characters)');
 if(j.mode!==undefined&&!['self','ai'].includes(j.mode))throw fail('Invalid task mode');
 if(typeof j.requestId!=='string'||!j.requestId||j.requestId.length>100)throw fail('Invalid request ID');
 const hub=ctx.hub;require('./knowledge').prepare(hub);const d=hub.data;
 const projectId=j.projectId||'';if(typeof projectId!=='string'||(projectId&&!d.projects.some(p=>p.id===projectId)))throw fail('项目不存在 / Project not found');
 const mode=j.mode||modeOf(input),urls=[...new Set((input.match(/https:\/\/[^\s<>"，。；）)]+/g)||[]).filter(raw=>{try{const u=new URL(raw);return !u.username&&!u.password;}catch{return false;}}))];
 const key=hash([normalize(input),mode,projectId]),existing=d.workItems.find(w=>w.intake?.requestId===j.requestId||w.intake?.key===key);
 if(existing){if(existing.intake.requestId===j.requestId&&existing.intake.key!==key)throw fail('这次请求内容已改变，请重新创建 / Request changed; start a new request',409);return {task:existing,duplicate:true};}
 const stamp=new Date().toISOString(),id=crypto.randomUUID(),sourceIds=d.sources.filter(s=>(s.projectId||'')===projectId&&urls.includes(s.url)).map(s=>s.id);
 const item={id,key:'manual:'+id,title:input.slice(0,200),notes:'',nodeId:'',projectId,parentId:'',kind:'action',status:'todo',owner:mode==='self'?'我':'AI',due:'',memberIds:[],sourceIds,bucket:'mine',manual:true,revision:1,created:stamp,intake:{schema:1,input,mode,urls,key,requestId:j.requestId}};
 const prior=d.workItems.slice();d.workItems.push(item);
 try{hub.event('task-intake',id,input);hub.save();}catch(e){d.workItems=prior;throw e;}
 return {task:item,duplicate:false};
}
function current(ctx,binding){const item=ctx.hub.data.workItems?.find(w=>w.id===binding?.id);if(!item||item.revision!==binding.revision||fingerprint(item)!==binding.fingerprint)throw fail('任务或关联资料已修改，旧结果不会覆盖；请按当前内容重试 / Task changed; retry with the current content',409);return item;}
function prepare(ctx,j,store){
 const item=ctx.hub.data.workItems?.find(w=>w.id===j.taskId);
 if(!item?.intake)throw fail('任务不存在 / Task not found',404);
 if(item.revision!==j.revision)throw fail('任务已修改，请刷新 / Task changed; refresh',409);
 if(['done','verified','cancelled','parked'].includes(item.status))throw fail('请先恢复任务再执行 / Restore the task before running',409);
 const binding={id:item.id,revision:item.revision,fingerprint:fingerprint(item)};
 const base=hash([binding,j.model||'',j.effort||'']);
 const prior=store.items.filter(job=>job.request?.taskEntry?.id===item.id&&job.request?.taskRunKey===base).at(-1);
 if(j.retry!==undefined&&typeof j.retry!=='boolean')throw fail('Invalid retry');
 if(prior&&(!j.retry||!['failed','cancelled','interrupted','planned'].includes(prior.state)))return {existing:prior.id};
 const comment=item.intake.input;
 return {binding:{taskEntry:binding,taskRunKey:base},input:{action:'run',comment,requestId:'task:'+base.slice(0,40)+':'+(prior?crypto.randomUUID():'first'),model:j.model,effort:j.effort,lang:j.lang,pageContext:{page:'tasks',view:'tasks',objectId:item.id,projectId:item.projectId||'',sourceIds:item.sourceIds||[]}}};
}
module.exports={create,prepare,current,fingerprint,modeOf};
