'use strict';
// Local device adapter. It never owns capture, invents a meeting, or finalizes one.
const fs=require('fs'),path=require('path'),crypto=require('crypto');
function create({dataDir,port,status,ownerValid,prepare,launch,stop,canControl=()=>true,finalized=()=>false,now=Date.now}){
 const dir=path.join(dataDir,'state'),file=path.join(dir,'meeting-trigger.json'),clientFile=path.join(dir,'meeting-trigger-client.json');
 let state;try{state=JSON.parse(fs.readFileSync(file,'utf8'));}catch(e){if(e.code!=='ENOENT')throw e;state={};}
 let queue=Promise.resolve(),busy=false;
 const write=(target,value)=>{fs.mkdirSync(dir,{recursive:true,mode:0o700});const tmp=target+'.'+crypto.randomUUID()+'.tmp';try{fs.writeFileSync(tmp,JSON.stringify(value),{mode:0o600});fs.renameSync(tmp,target);}finally{try{fs.unlinkSync(tmp);}catch{}}};
 const save=()=>write(file,state);
 const valid=()=>{if(!state.binding||!ownerValid(state.binding.owner))throw Error('trigger_rebind_required');return state.binding;};
 const publicStatus=()=>{const b=valid(),s=status();const matching=s.sessionId===b.sessionId,ownError=matching||s.errorSessionId===b.sessionId;return {sessionId:b.sessionId,generation:b.generation,state:matching&&s.active?(s.command==='stop'?'stopping':s.phase==='paused'?'paused':s.captureReady?'recording':'starting'):s.starting&&s.pendingSessionId===b.sessionId?'starting':finalized(b.sessionId)?'ended':state.started?(ownError&&s.error?'failed':'unknown'):'bound',audioEvidence:matching?s.audioEvidence||null:null,error:ownError?s.error||'':''};};
 function bind(j,owner){if(busy)throw Error('trigger_command_pending');if(!ownerValid(owner))throw Error('native_owner_unknown');if(!j.sessionId||!j.deviceId||!/^[-\w]{1,80}$/.test(j.deviceId))throw Error('trigger_explicit_binding_required');
  const s=status();if(!canControl(j.sessionId,owner)||s.active&&s.captureMode==='browser')throw Error('trigger_capture_owner_changed');if(s.active&&s.sessionId!==j.sessionId||s.starting&&s.pendingSessionId!==j.sessionId)throw Error('trigger_other_meeting_active');
  const intent=s.active&&s.sessionId===j.sessionId?{sessionId:j.sessionId}:prepare({sessionId:j.sessionId,continuationToken:j.continuationToken,lang:j.lang,uiLang:j.uiLang});
  if(intent.sessionId!==j.sessionId)throw Error('trigger_target_invalid');
  const token=crypto.randomBytes(32).toString('hex'),generation=crypto.randomUUID();
  state={binding:{owner,deviceId:j.deviceId,sessionId:j.sessionId,generation,intent},tokenHash:crypto.createHash('sha256').update(token).digest('hex'),sequence:0,receipts:[],started:!!s.active};save();
  write(clientFile,{endpoint:'http://127.0.0.1:'+port+'/asr-relay/native/trigger-command',capability:token,deviceId:j.deviceId,sessionId:j.sessionId,bindingGeneration:generation,sequence:0});
  return {ok:true,...publicStatus()};
 }
 function revoke(owner){if(busy)throw Error('trigger_command_pending');if(state.binding?.owner!==owner||!ownerValid(owner))throw Error('native_owner_unknown');state={};save();try{fs.unlinkSync(clientFile);}catch(e){if(e.code!=='ENOENT')throw e;}return {ok:true};}
 async function execute(j,token){const b=valid();const hash=crypto.createHash('sha256').update(token).digest('hex');if(!state.tokenHash||!crypto.timingSafeEqual(Buffer.from(hash),Buffer.from(state.tokenHash)))throw Error('trigger_unauthorized');
  if(j.deviceId!==b.deviceId||j.sessionId!==b.sessionId||j.bindingGeneration!==b.generation)throw Error('trigger_binding_changed');
  if(!['start','end','status'].includes(j.action)||!/^[-\w]{1,100}$/.test(j.requestId||'')||!Number.isSafeInteger(j.sequence)||j.sequence<1||!Number.isFinite(j.issuedAt))throw Error('trigger_invalid_or_expired_request');
  const fingerprint=crypto.createHash('sha256').update(JSON.stringify([j.deviceId,j.sessionId,j.bindingGeneration,j.action,j.sequence,j.issuedAt])).digest('hex');
  const prior=state.receipts.find(r=>r.id===j.requestId);if(prior){if(prior.fingerprint!==fingerprint)throw Error('trigger_request_conflict');if(prior.state==='failed')throw Error(prior.error||'trigger_failed');return {ok:true,replayed:true,requestState:prior.state,...publicStatus()};}
  if(Math.abs(now()-j.issuedAt)>30000)throw Error('trigger_invalid_or_expired_request');
  if(j.sequence<=state.sequence)throw Error('trigger_replay_rejected');
  const receipt={id:j.requestId,fingerprint,state:'accepted'};state.sequence=j.sequence;state.receipts.push(receipt);state.receipts=state.receipts.slice(-100);save();
  try{const s=status();if(!canControl(b.sessionId,b.owner)||s.active&&s.captureMode==='browser')throw Error('trigger_capture_owner_changed');if(s.active&&s.sessionId!==b.sessionId||s.starting&&s.pendingSessionId!==b.sessionId)throw Error('trigger_other_meeting_active');
   if(j.action==='start'&&!s.active&&!s.starting){const result=await launch({...b.intent,autoStart:true},b.owner);if(result.code!==200)throw Error(result.body.error||'trigger_launch_failed');state.started=true;}
   if(j.action==='end'){if(s.starting&&!s.active)throw Error('trigger_start_pending');if(s.active&&!stop(b.sessionId))throw Error('trigger_meeting_changed');}
   receipt.state='dispatched';save();return {ok:true,requestState:receipt.state,...publicStatus()};
  }catch(e){receipt.state='failed';receipt.error=e.message;save();throw e;}
 }
 return {bind,revoke,inspect(owner){if(!ownerValid(owner))throw Error('native_owner_unknown');if(!state.binding)return {ok:true,bound:false};if(state.binding.owner!==owner)throw Error('trigger_rebind_required');return {ok:true,bound:true,deviceId:state.binding.deviceId,title:String(state.binding.intent.title||''),...publicStatus()};},command(j,token){const p=queue.then(async()=>{busy=true;try{return await execute(j,token);}finally{busy=false;}});queue=p.catch(()=>{});return p;}};
}
module.exports={create};
