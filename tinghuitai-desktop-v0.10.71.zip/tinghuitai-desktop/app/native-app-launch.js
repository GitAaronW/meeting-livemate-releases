'use strict';
const path=require('path');
const REGISTER='/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister';
// Register the verified installed copy before dispatching through LaunchServices.
// Registration changes neither the signed bundle nor its recording permissions.
function create({app,execute=require('child_process').execFile}) {
  if(!path.isAbsolute(app)||!app.endsWith('.app'))throw Error('native_app_absolute_path_required');
  return (args,done)=>{
    const options={timeout:6000,maxBuffer:256*1024};
    execute('/usr/bin/codesign',['--verify','--deep','--strict',app],options,error=>{
      if(error)return done(Error('native_app_signature_invalid'));
      execute(REGISTER,['-f',app],options,error=>{
        if(error)return done(Error('native_app_registration_failed'));
        execute('/usr/bin/open',['-g','-n','-a',app,'--args',...args],options,done);
      });
    });
  };
}
module.exports={create,REGISTER};
