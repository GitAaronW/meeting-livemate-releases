'use strict';
// 会议记忆真源：SQLite。有事务、能并发、坏不了。
// 另有一份只读 md 投影（见 memory-ops.js），给人在 Claude 里看；投影改了不生效。
const path = require('path'), fs = require('fs');
let DatabaseSync = null;
try { ({ DatabaseSync } = require('node:sqlite')); } catch (e) { /* 旧 node：整层降级为不可用 */ }

// L-18：'rule' = 你在 MyAgent 里点「以后也记住」留下的会中规矩（译名、口径、别改哪些字）。
// 以前它只写进浏览器的 localStorage，底栏「它记住的」根本看不到，换个浏览器或清一次站点数据就没了。
// 它不是模型从会上抽出来的，是你亲口定的，所以默认 human_edited=1、不进待复核。
const KINDS = new Set(['decision', 'question', 'promise', 'term', 'rule']);
// 四类记忆的生命周期不同，不能共用一套状态
const STATES = {
  decision: ['active', 'superseded', 'revoked'],
  term:     ['active', 'superseded', 'revoked'],
  question: ['open', 'resolved'],
  promise:  ['pending', 'done', 'cancelled'],
  rule:     ['active', 'revoked'],
};
const DEFAULT_STATE = { decision: 'active', term: 'active', question: 'open', promise: 'pending', rule: 'active' };
const TERMINAL = new Set(['revoked', 'superseded', 'resolved', 'done', 'cancelled']);
const DROP_STATE = { decision: 'revoked', term: 'revoked', question: 'resolved', promise: 'cancelled' };

// 老库补列。加列失败分两种：列已经在（正常，什么都不用做）和真出事了（库被锁、只读、文件坏）。
// 后者必须抛出来 —— 吞掉的话，后面按新列名写入会一路失败，表面上是「记忆莫名其妙存不下」，
// 日志里一个字都没有。判据是「报的是 duplicate column」且「这一列现在确实在表上」，两条都成立才算正常。
function addColumn(db, table, column, ddl, log) {
  try { db.exec('ALTER TABLE ' + table + ' ADD COLUMN ' + ddl); return; }
  catch (e) {
    const dup = /duplicate column/i.test(String(e.message || ''));
    let has = false;
    try { has = db.prepare('PRAGMA table_info(' + table + ')').all().some(c => c.name === column); } catch (e2) {}
    if (dup && has) return;
    if (log) { try { log('记忆库升级失败（' + table + '.' + column + ' 列）：' + e.message); } catch (e3) {} }
    throw new Error('记忆库升级失败（' + table + '.' + column + ' 列）：' + e.message);
  }
}

// 每次调用都新建连接会把 fd 和内存吃光（retrieve 是高频路径）。按数据目录做单例。
const POOL = new Map();
function open(dataDir) {
  if (!DatabaseSync) return null;
  const key = path.resolve(dataDir);
  const hit = POOL.get(key);
  if (hit) { try { hit.prepare('SELECT 1').get(); return hit; } catch (e) { POOL.delete(key); } }
  const dir = path.join(key, 'state');
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  const db = new DatabaseSync(path.join(dir, 'memory.db'));
  db.exec('PRAGMA journal_mode=WAL');
  db.exec('PRAGMA busy_timeout=4000');
  db.exec('PRAGMA synchronous=NORMAL');
  db.exec(`CREATE TABLE IF NOT EXISTS cards(
    id TEXT PRIMARY KEY, revision INTEGER NOT NULL DEFAULT 1,
    project TEXT NOT NULL DEFAULT '', scope TEXT NOT NULL DEFAULT 'project', kind TEXT NOT NULL, topic TEXT NOT NULL DEFAULT '',
    text TEXT NOT NULL, state TEXT NOT NULL, owner TEXT NOT NULL DEFAULT '', due TEXT NOT NULL DEFAULT '',
    aliases TEXT NOT NULL DEFAULT '', meeting_id TEXT NOT NULL DEFAULT '', meeting_title TEXT NOT NULL DEFAULT '',
    source_refs TEXT NOT NULL DEFAULT '[]', recorded_at TEXT NOT NULL, effective_at TEXT,
    supersedes_id TEXT, change_reason TEXT NOT NULL DEFAULT '', human_edited INTEGER NOT NULL DEFAULT 0, needs_review INTEGER NOT NULL DEFAULT 0,
    review_note TEXT NOT NULL DEFAULT '')`);
  // 老库没有这一列：被替代的旧决定要留下「是哪句话把它推翻的」。
  addColumn(db, 'cards', 'change_reason', "change_reason TEXT NOT NULL DEFAULT ''");
  // 可跨项目的记忆必须显式标成 global；旧卡保持 project 范围，避免升级后突然泄到别的项目。
  addColumn(db, 'cards', 'scope', "scope TEXT NOT NULL DEFAULT 'project'");
  // Evidence and review metadata are additive so existing memory cards remain readable.
  addColumn(db, 'cards', 'confidence', 'confidence REAL NOT NULL DEFAULT 1.0');
  addColumn(db, 'cards', 'confirmed', 'confirmed INTEGER NOT NULL DEFAULT 0');
  addColumn(db, 'cards', 'source_type', "source_type TEXT NOT NULL DEFAULT 'meeting'");
  addColumn(db, 'cards', 'speaker', "speaker TEXT NOT NULL DEFAULT ''");
  addColumn(db, 'cards', 'conflict_key', "conflict_key TEXT NOT NULL DEFAULT ''");
  addColumn(db, 'cards', 'memory_tier', "memory_tier TEXT NOT NULL DEFAULT 'meeting'");
  db.exec(`CREATE TABLE IF NOT EXISTS card_history(
    id TEXT NOT NULL, revision INTEGER NOT NULL, snapshot TEXT NOT NULL, changed_at TEXT NOT NULL,
    PRIMARY KEY(id, revision))`);
  // status 区分「正在抽」和「抽完了」：进程中途死掉时，claiming 会过期，不会让这场永远抽不了
  db.exec(`CREATE TABLE IF NOT EXISTS ingested(
    meeting_id TEXT PRIMARY KEY, input_hash TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'done', at TEXT NOT NULL)`);
  // D9：这两处原来是裸 catch。库被锁或只读时「加列失败」被当成「列已经有了」吞掉，
  // 接着 claiming / attempts 全写不进去，表现就是这台机器永远抽不出记忆，而且没有任何日志。
  addColumn(db, 'ingested', 'status', "status TEXT NOT NULL DEFAULT 'done'");
  // P-11：失败的抽卡要能自动重来，得记住重来过几次，免得坏数据无限重跑
  addColumn(db, 'ingested', 'attempts', 'attempts INTEGER NOT NULL DEFAULT 0');
  db.exec('CREATE INDEX IF NOT EXISTS idx_cards_kind_state ON cards(kind,state)');
  db.exec('CREATE INDEX IF NOT EXISTS idx_cards_project_live ON cards(project,scope,state,kind)');
  db.exec('CREATE INDEX IF NOT EXISTS idx_cards_meeting ON cards(meeting_id)');
  db.exec('CREATE INDEX IF NOT EXISTS idx_cards_live ON cards(state,needs_review,recorded_at)');
  POOL.set(key, db);
  return db;
}
function closeAll() { for (const [k, db] of POOL) { try { db.close(); } catch (e) {} POOL.delete(k); } }

const now = () => new Date().toISOString();
const uid = () => 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
// 模型可能把 owner 返回成对象、把 due 返回成数字。数字照抄，对象/数组一律当没填，
// 不要 String() 成 [object Object] 存进去。
const str = (v, n) => {
  if (typeof v === 'string') return v.slice(0, n);
  if (typeof v === 'number' && isFinite(v)) return String(v).slice(0, n);
  return '';
};
// 上游给的时间可能是毫秒数或任意串，不归一化会让衰减算成 NaN、投影里打印出一串数字
function iso(v) {
  if (typeof v === 'number' && isFinite(v)) { const d = new Date(v); return isNaN(d) ? now() : d.toISOString(); }
  if (typeof v === 'string' && v) { const d = new Date(/^\d{10,}$/.test(v) ? Number(v) : v); return isNaN(d) ? now() : d.toISOString(); }
  return now();
}
// 事务嵌套会让内层的 ROLLBACK 把外层一起回滚。统一用 SAVEPOINT。
let spSeq = 0;
function inTx(db, fn) {
  const sp = 'sp' + (++spSeq);
  db.exec('SAVEPOINT ' + sp);
  let r;
  try { r = fn(); }
  catch (e) { try { db.exec('ROLLBACK TO ' + sp); db.exec('RELEASE ' + sp); } catch (e2) {} throw e; }
  // RELEASE 自己也可能失败（磁盘满、I/O 错）。连接是长生命周期池化的，
  // 这里不收拾就会留下一个永不提交的事务，之后所有写入都不落盘。
  try { db.exec('RELEASE ' + sp); }
  catch (e) { try { db.exec('ROLLBACK TO ' + sp); db.exec('RELEASE ' + sp); } catch (e2) { try { db.exec('ROLLBACK'); } catch (e3) {} } throw e; }
  return r;
}

const COLS = ['project','scope','kind','topic','text','state','owner','due','aliases','meeting_id','meeting_title',
              'memory_tier','confidence','confirmed','source_type','speaker','conflict_key',
              'source_refs','recorded_at','effective_at','supersedes_id','change_reason','human_edited','needs_review','review_note'];

function putCard(db, c) {
  const kind = KINDS.has(c.kind) ? c.kind : 'decision';
  const allowed = STATES[kind];
  const state = allowed.includes(c.state) ? c.state : DEFAULT_STATE[kind];
  const row = {
    id: str(c.id, 64) || uid(), revision: 1, project: str(c.project, 80), scope: c.scope === 'global' ? 'global' : 'project', kind, topic: str(c.topic, 120),
    text: str(c.text, 2000), state, owner: str(c.owner, 80), due: str(c.due, 40),
    aliases: Array.isArray(c.aliases) ? c.aliases.map(x => str(x, 60)).join(',').slice(0, 300) : str(c.aliases, 300),
    meeting_id: str(c.meeting_id, 100), meeting_title: str(c.meeting_title, 200),
    source_refs: JSON.stringify(Array.isArray(c.source_refs) ? c.source_refs.slice(0, 20) : []),
    confidence: typeof c.confidence === 'number' && isFinite(c.confidence) ? Math.max(0, Math.min(1, c.confidence)) : 1,
    memory_tier: c.memory_tier === 'candidate' ? 'candidate' : 'meeting',
    confirmed: c.confirmed ? 1 : 0,
    source_type: str(c.source_type, 40) || 'meeting', speaker: str(c.speaker, 100), conflict_key: str(c.conflict_key, 160),
    recorded_at: iso(c.recorded_at), effective_at: c.effective_at ? iso(c.effective_at) : null,
    supersedes_id: str(c.supersedes_id, 64) || null, change_reason: str(c.change_reason, 400), human_edited: c.human_edited ? 1 : 0,
    needs_review: c.needs_review ? 1 : 0, review_note: str(c.review_note, 300),
  };
  if (!row.text.trim()) return null;
  return inTx(db, () => {
    db.prepare(`INSERT INTO cards(id,revision,${COLS.join(',')}) VALUES(?,?,${COLS.map(() => '?').join(',')})`)
      .run(row.id, row.revision, ...COLS.map(k => row[k]));
    db.prepare('INSERT INTO card_history(id,revision,snapshot,changed_at) VALUES(?,?,?,?)')
      .run(row.id, row.revision, JSON.stringify(row), row.recorded_at);
    return row;
  });
}

// 终态不可复活：撤销过的决定不能被改回 active
function transitionOk(kind, from, to) {
  if (from === to) return true;
  if (TERMINAL.has(from) && !TERMINAL.has(to)) return false;
  return (STATES[kind] || STATES.decision).includes(to);
}

function updateCard(db, id, patch, reason) {
  const cur = db.prepare('SELECT * FROM cards WHERE id=?').get(id);
  if (!cur) return null;
  const next = { ...cur, ...patch };
  if (patch.text !== undefined && patch.text !== cur.text) { next.confirmed = 0; next.needs_review = 1; if (cur.memory_tier === 'stable') next.memory_tier = 'candidate'; }
  next.revision = cur.revision + 1;
  if (!transitionOk(next.kind, cur.state, next.state)) next.state = cur.state;
  next.text = str(next.text, 2000) || cur.text;
  next.topic = str(next.topic, 120); next.owner = str(next.owner, 80); next.due = str(next.due, 40);
  next.review_note = str(reason || next.review_note, 300);
  next.human_edited = next.human_edited ? 1 : 0; next.needs_review = next.needs_review ? 1 : 0;
  if (Array.isArray(next.source_refs)) next.source_refs = JSON.stringify(next.source_refs.slice(0, 20));
  return inTx(db, () => {
    // 乐观锁：两处同时改同一条时，后到的那次读到的 revision 已经过期，这里会拦下来
    const r = db.prepare(`UPDATE cards SET revision=?,${COLS.map(k => k + '=?').join(',')} WHERE id=? AND revision=?`)
      .run(next.revision, ...COLS.map(k => next[k]), id, cur.revision);
    if (!r.changes) throw new Error('这条记忆刚被别处改过，请重新打开再改');
    // 历史用 INSERT 而不是 REPLACE：同版本号冲突说明并发写，宁可报错也不要把上一次的来历覆盖掉
    db.prepare('INSERT INTO card_history(id,revision,snapshot,changed_at) VALUES(?,?,?,?)')
      .run(id, next.revision, JSON.stringify(next), now());
    return next;
  });
}

function flagPossiblyChanged(db, id, note) {
  const cur = db.prepare('SELECT state,human_edited FROM cards WHERE id=?').get(id);
  if (!cur) return null;
  if (TERMINAL.has(cur.state)) return null;      // 已经作废的别再翻出来
  if (cur.human_edited) return null;             // 用户处理过的，别覆盖他的判断
  return updateCard(db, id, { needs_review: 1 }, note || '可能已变更，等你核对');
}

// Human review is explicit: suggestions stay unconfirmed until Aaron accepts them.
function reviewCard(db, id, decision, note) {
  const cur = db.prepare('SELECT * FROM cards WHERE id=?').get(id);
  if (!cur) return null;
  if (!['confirm','reject','unresolved','candidate','promote'].includes(decision)) throw new Error('不支持的审核动作');
  if (TERMINAL.has(cur.state) && decision !== 'reject') throw new Error('已结束的记忆不能确认或升级，请先恢复');
  if (decision === 'promote' && cur.memory_tier !== 'candidate') throw new Error('请先保存为候选长期记忆，再审核升级');
  const patch = decision === 'promote'
    ? { memory_tier: 'stable', confirmed: 1, needs_review: 0, human_edited: 1 }
    : decision === 'candidate'
      ? { memory_tier: 'candidate', confirmed: 0, needs_review: 1, human_edited: 1 }
    : decision === 'confirm'
    ? { confirmed: 1, needs_review: 0, human_edited: 1 }
    : decision === 'reject'
      ? { state: cur.kind === 'question' ? 'resolved' : (cur.kind === 'promise' ? 'cancelled' : 'revoked'), confirmed: 0, needs_review: 0, human_edited: 1 }
      : { needs_review: 1, confirmed: 0 };
  return updateCard(db, id, patch, note || ('human-review:' + decision));
}
function conflicts(db, project, conflictKey) {
  if (!conflictKey) return [];
  return db.prepare("SELECT * FROM cards WHERE project=? AND conflict_key=? AND state NOT IN ('revoked','superseded','resolved','cancelled') ORDER BY recorded_at DESC").all(str(project,80), str(conflictKey,160));
}

function dropCard(db, id, note) {
  const cur = db.prepare('SELECT kind,state,human_edited,review_note FROM cards WHERE id=?').get(id);
  if (!cur) return null;
  // 记下作废之前是什么状态，才撤得回来。不留这个，撤销只能瞎猜。
  // human_edited 也要记：作废会把它置 1，不还原，撤销后这条会留在「已确认」那一组里。
  const r = updateCard(db, id, { state: DROP_STATE[cur.kind] || 'revoked', human_edited: 1, needs_review: 0 }, note || '你标为作废');
  return r ? { ...r, prevState: cur.state, prevEdited: cur.human_edited ? 1 : 0, prevNote: cur.review_note || '' } : null;
}

// 撤销作废：放回作废前的状态。终态不可复活那条规则在这里要让路——
// 是用户自己刚点的作废，5 秒内反悔属于正常操作，不是模型在复活旧决定。
function undropCard(db, id, prevState, prevEdited, prevNote) {
  const cur = db.prepare('SELECT kind,state FROM cards WHERE id=?').get(id);
  if (!cur) return null;
  const allowed = STATES[cur.kind] || [];
  const back = allowed.includes(prevState) ? prevState : DEFAULT_STATE[cur.kind];
  const edited = prevEdited ? 1 : 0;
  const note = typeof prevNote === 'string' ? prevNote.slice(0, 300) : '';
  return inTx(db, () => {
    db.prepare('UPDATE cards SET state=?, human_edited=?, review_note=?, revision=revision+1 WHERE id=?').run(back, edited, note, id);
    const row = db.prepare('SELECT * FROM cards WHERE id=?').get(id);
    db.prepare('INSERT INTO card_history(id,revision,snapshot,changed_at) VALUES(?,?,?,?)').run(id, row.revision, JSON.stringify(row), now());
    return row;
  });
}

module.exports = { open, closeAll, inTx, putCard, updateCard, dropCard, undropCard, flagPossiblyChanged, reviewCard, conflicts,
                   KINDS, STATES, DEFAULT_STATE, DROP_STATE, TERMINAL, uid, now, iso };

// ===== 词表（lexicon）：用户纠正过的词，回流到转写之前 =====
// 跟记忆卡分开存：卡片是会议内容，词表是识别层的纠正，生命周期和用途都不同。
// 存服务端而不是浏览器，因为它必须在下一场会开始之前、由服务端注入热词。
function ensureLexicon(db) {
  db.exec(`CREATE TABLE IF NOT EXISTS lexicon(
    wrong TEXT PRIMARY KEY, right TEXT NOT NULL, scope TEXT NOT NULL DEFAULT '',
    confidence REAL NOT NULL DEFAULT 1.0, hit_count INTEGER NOT NULL DEFAULT 0,
    harm_count INTEGER NOT NULL DEFAULT 0, miss_count INTEGER NOT NULL DEFAULT 0,
    last_hit_at TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
    source_meeting TEXT NOT NULL DEFAULT '', state TEXT NOT NULL DEFAULT 'active')`);
  db.exec('CREATE INDEX IF NOT EXISTS idx_lex_live ON lexicon(state,last_hit_at)');
}
// 太短或太常见的词进热词会污染整场识别（把「方案」加成热词，满屏都是方案）。
// 这里只拦明显有害的：单字、纯数字、纯标点、超长。其余交给用户判断。
const LEX_BAD = /^[\s\p{P}]*$|^\d+$/u;
function lexOk(wrong, right) {
  const w = String(wrong || '').trim(), r = String(right || '').trim();
  if (!w || !r) return { ok: false, why: '两个都要填' };
  if (w === r) return { ok: false, why: '两个词一样' };
  if (w.length > 40 || r.length > 40) return { ok: false, why: '词太长' };
  if (/[\r\n]/.test(w + r)) return { ok: false, why: '不能有换行' };
  if (LEX_BAD.test(w) || LEX_BAD.test(r)) return { ok: false, why: '不是一个词' };
  if ([...w].length < 2 && !/^[A-Za-z]{2,}$/.test(w)) return { ok: false, why: '单字不能做热词，会污染整场识别' };
  return { ok: true, w, r };
}
function putLex(db, wrong, right, meetingId) {
  ensureLexicon(db);
  const v = lexOk(wrong, right);
  if (!v.ok) return { ok: false, why: v.why };
  return inTx(db, () => {
    const cur = db.prepare('SELECT * FROM lexicon WHERE wrong=?').get(v.w);
    const t = now();
    if (cur) {
      // 同一个错词改到了另一个正确写法：以最新为准，但不清空统计
      db.prepare('UPDATE lexicon SET right=?,updated_at=?,state=?,confidence=1.0 WHERE wrong=?').run(v.r, t, 'active', v.w);
      return { ok: true, updated: true, wrong: v.w, right: v.r };
    }
    db.prepare('INSERT INTO lexicon(wrong,right,created_at,updated_at,source_meeting) VALUES(?,?,?,?,?)')
      .run(v.w, v.r, t, t, str(meetingId, 100));
    return { ok: true, created: true, wrong: v.w, right: v.r };
  });
}
// M3（09-25）：回看页把人名 A 改成 B（本场已有的名字被人手改掉）= 一条用户纠正的别名。
// 落两处：规则卡（kind=rule，topic=alias，全局生效，human_edited=1，底栏「它记住的」看得到、能撤）+ 词表（热词和纠名表都读它）。
// 只收「原来有名字、改成另一个名字」这一种；从「未认人 / S2」认出名字是本场映射，不当全局别名。
const ALIAS_PLACEHOLDER = /^(S?\d{1,3}|说话人\s*\d+|Speaker\s*\d+|未认人|未知|对方|我|me|them)$/i;
function putAliasRule(db, wrong, right, meetingId) {
  const w = String(wrong || '').trim(), r = String(right || '').trim();
  if (!w || !r || w === r || ALIAS_PLACEHOLDER.test(w) || ALIAS_PLACEHOLDER.test(r)) return { ok: false, why: 'not_alias' };
  const lex = putLex(db, w, r, meetingId);
  if (!lex.ok) return lex;
  const old = db.prepare("SELECT id FROM cards WHERE kind='rule' AND topic='alias' AND aliases=? AND state='active'").all(w);
  for (const o of old) updateCard(db, o.id, { state: 'revoked' }, '同一个错名改到了新写法');
  const card = putCard(db, { kind: 'rule', topic: 'alias', text: w + ' → ' + r, aliases: w, owner: r, meeting_id: meetingId,
    human_edited: true, change_reason: 'source=user-correction; scope=global' });
  return { ok: true, wrong: w, right: r, cardId: card && card.id };
}
function aliasRules(db) {
  try { return db.prepare("SELECT aliases AS wrong, owner AS right FROM cards WHERE kind='rule' AND topic='alias' AND state='active'").all().filter(x => x.wrong && x.right).map(x => ({ wrong: x.wrong, right: x.right })); } catch (e) { return []; }
}
// 注入热词：取正确写法，按最近命中和置信度排序。limit 由调用方按 ASR 能力给。
function lexHotwords(db, limit = 15) {
  ensureLexicon(db);
  try {
    return db.prepare(`SELECT right FROM lexicon WHERE state='active' AND harm_count < 3
      ORDER BY (last_hit_at IS NULL) ASC, last_hit_at DESC, confidence DESC, updated_at DESC LIMIT ?`)
      .all(Math.max(0, Math.min(200, limit | 0))).map(r => r.right);
  } catch (e) { return []; }
}
function lexAll(db) { ensureLexicon(db); try { return db.prepare('SELECT * FROM lexicon ORDER BY updated_at DESC').all(); } catch (e) { return []; } }
// 一场会结束后数一次：错词还出现 = 这次没救回来（复发）；正确写法出现 = 命中。
function lexScore(db, text, meetingId) {
  ensureLexicon(db);
  const rows = lexAll(db).filter(r => r.state === 'active');
  const out = [];
  const t = now();
  for (const r of rows) {
    const miss = (String(text).split(r.wrong).length - 1);
    const hit = (String(text).split(r.right).length - 1);
    if (!miss && !hit) continue;
    try {
      inTx(db, () => {
        db.prepare('UPDATE lexicon SET hit_count=hit_count+?, miss_count=miss_count+?, last_hit_at=CASE WHEN ?>0 THEN ? ELSE last_hit_at END, updated_at=? WHERE wrong=?')
          .run(hit, miss, hit, t, t, r.wrong);
      });
    } catch (e) {}
    out.push({ wrong: r.wrong, right: r.right, hit, miss, meeting: meetingId || '' });
  }
  return out;
}
module.exports.ensureLexicon = ensureLexicon;
module.exports.lexOk = lexOk;
module.exports.putLex = putLex;
module.exports.lexHotwords = lexHotwords;
module.exports.lexAll = lexAll;
module.exports.lexScore = lexScore;
// D9 单测要能直接驱动「加列失败」这条路（真把库锁住太脆），所以把判别函数导出来。
module.exports.addColumn = addColumn;
module.exports.putAliasRule = putAliasRule;
module.exports.aliasRules = aliasRules;
