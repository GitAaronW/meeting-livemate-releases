'use strict';
// Operational read receipts, not another meeting database. Originals remain in the Hub.
const fs=require('fs'),path=require('path'),crypto=require('crypto'),cal=require('./meeting-calibration');
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
const instances=new Map(),normalize=x=>String(x||'').replace(/\s+/g,'').toLowerCase();
function identity(source,session){const e=calendarEvent(source,session);return {title:source.title||session.title||'',eventId:e.eventId||'',calendarId:e.calendarId||'',provider:e.provider||'',start:typeof (e.start||session.start||source.date)==='number'?new Date(e.start||session.start||source.date).toISOString():e.start||session.start||source.date||''};}
function fingerprint(source,session){return hash(JSON.stringify(identity(source,session)));}
function calendarEvent(source,session){return session.calendar?.chosen==='none'?{}:session.calendar?.event||((session.calendar?.eventId)?session.calendar:null)||source.calendarEvent||{};}
function identityClaim(source,session,text){
 const i=identity(source,session),date=String(i.start).slice(0,10),header=text.slice(0,2000);
 if(!i.title||typeof i.eventId!=='string'||i.eventId.length<12||!/^\d{4}-\d{2}-\d{2}$/.test(date)||!normalize(header).includes(normalize(i.title)))return false;
 const escaped=i.eventId.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
 return new RegExp('(?:Event ID|event_id|日程 ID|日程ID|会议日程ID)\\s*[:：]\\s*'+escaped+'(?=\\s|$)','i').test(header)&&header.includes(date);
}
class Discovery{
 constructor(dataDir){this.file=path.join(dataDir,'meeting-notes-discovery.json');this.busy=false;this.pending=new Set();try{const v=JSON.parse(fs.readFileSync(this.file,'utf8'));this.items=Array.isArray(v.items)?v.items.filter(x=>x&&typeof x.meetingId==='string'&&typeof x.binding==='string'&&Number.isFinite(x.checkedAt)&&Array.isArray(x.candidates)&&x.candidates.every(c=>c&&c.reader==='lark.docs.fetch'&&typeof c.id==='string'&&/^notes-[a-f0-9]{24}$/.test(c.id)&&(()=>{try{return cal.link(c.url)===c.url;}catch{return false;}})()&&typeof c.text==='string'&&c.text.length<=100000&&c.hash===hash(c.text))).slice(-200):[];}catch{this.items=[];}}
 save(){fs.mkdirSync(path.dirname(this.file),{recursive:true,mode:0o700});const tmp=this.file+'.'+crypto.randomBytes(6).toString('hex')+'.tmp';try{fs.writeFileSync(tmp,JSON.stringify({schema:1,items:this.items.slice(-200)}),{mode:0o600});fs.renameSync(tmp,this.file);}finally{try{fs.unlinkSync(tmp);}catch{}}}
 entry(source,session){return this.items.find(x=>x.meetingId===session.id&&x.binding===fingerprint(source,session));}
 visible(source,session){const e=this.entry(source,session);if(!e)return null;return {checkedAt:e.checkedAt,error:e.error||'',attempts:e.attempts||1,stopped:(e.attempts||1)>=6,candidates:e.candidates.map(({text,...c})=>c)};}
 snapshot(source,session,id){const c=this.entry(source,session)?.candidates.find(c=>c.id===id);if(!c||c.hash!==hash(c.text))throw Error('纪要来源已变化，请重新检索 / Notes source changed; search again');return c;}
 async scan(ctx,source,session,options={}){
  if(!session||this.pending.has(session.id))return null;this.pending.add(session.id);try{return await this.scanOnce(ctx,source,session,options);}finally{this.pending.delete(session.id);}
 }
 async scanOnce(ctx,source,session,{force=false,now=Date.now()}={}){
  if(!session?.end&&!session?.finalized)return null;
  if(!source||source.kind!=='meeting'||normalize(source.title).length<4)return null;
  const previous=this.entry(source,session),delay=[5,15,30,60,120][Math.min(4,(previous?.attempts||1)-1)]*60000;
  if(previous&&(force?now-previous.checkedAt<60000:(previous.attempts||1)>=6||now-previous.checkedAt<delay))return this.visible(source,session);
  const binding=fingerprint(source,session),record={meetingId:session.id,binding,checkedAt:now,candidates:[],attempts:force?1:(previous?.attempts||0)+1,error:''};
  const call=(name,args)=>require('./tools').call(name,args,{dataDir:ctx.dataDir,caller:'ui',sessionId:session.id,timeoutMs:name.endsWith('fetch')?65000:35000,execImpl:ctx.execImpl});
  try{
   const event=calendarEvent(source,session);
   // All persisted calendar associations currently come from the Lark agenda reader.
   // Google/other integrations must identify their provider before using this path.
   if(event.eventId&&event.calendarId&&(!event.provider||['lark','feishu'].includes(event.provider))){
    const requireRead=async(name,args)=>{const r=await call(name,args);if(!r.ok)throw Error(r.error||'Platform read failed');return r.data;};
    const mapped=await requireRead('lark.calendar.meeting',{eventId:event.eventId,calendarId:event.calendarId});
    if(mapped.identity!=='user'||mapped.event_id!==event.eventId||!/^\d{10,30}$/.test(mapped.meeting_id))throw Error('Calendar association cannot be verified');
    const meeting=await requireRead('lark.meetings.detail',{meetingId:mapped.meeting_id});
    if(meeting.identity!=='user'||meeting.meeting_id!==mapped.meeting_id||!meeting.end_time||!/^\d{10,30}$/.test(meeting.note_id))throw Error('Ended meeting notes are not ready');
    const note=await requireRead('lark.notes.detail',{noteId:meeting.note_id});
    if(note.identity!=='user'||note.note_id!==meeting.note_id)throw Error('Note association cannot be verified');
    const docs=[['transcript',note.verbatim_doc_token],['notes',note.note_doc_token]].filter(([,id])=>typeof id==='string'&&/^[A-Za-z0-9]{8,64}$/.test(id));
    if(!docs.length)throw Error('Complete note documents are not ready');
    const seen=new Set();for(const [kind,docId] of docs){
     if(seen.has(docId))continue;seen.add(docId);
     const fetched=await call('lark.docs.fetch',{doc:docId,scope:'full'});
     if(!fetched.ok||fetched.data?.docId!==docId||typeof fetched.data.text!=='string'||!fetched.data.text.trim()||fetched.data.text.length>100000)throw Error(fetched.error||'Full document identity or content cannot be verified');
     if(fingerprint(source,session)!==binding)throw Error('Meeting association changed');
     const text=fetched.data.text,digest=hash(text),url='https://feishu.cn/docx/'+docId;
     const c={id:'notes-'+hash(url+digest).slice(0,24),url,title:source.title,hash:digest,text,reader:'lark.docs.fetch',remoteRevision:fetched.data.revision??null,sameMeeting:true,state:'platform-linked',at:new Date(now).toISOString(),platformBinding:{identity:'user',eventId:event.eventId,calendarId:event.calendarId,meetingId:meeting.meeting_id,noteId:note.note_id,docId,kind,bindingFingerprint:binding}};
     record.candidates.push(c);
     // Reuse fresh full-read receipts; never grant automatic authority to a saved candidate.
     if(ctx.ask){await cal.calibrate(ctx,source,session,{url,confirmSameMeeting:true,lang:ctx.settings?.load?.().UI_LANG==='en'?'en':'zh'},c);c.state='calibrated';}
    }
   }else{
   const r=await call('lark.docs.search',{query:source.title.slice(0,200),limit:8});if(!r.ok)throw Error(r.error||'Notes search failed');
   const seen=new Set();let reads=0;for(const item of r.items||[]){
    if(reads>=3)break;
    let url;try{url=cal.link(item.url);if(!/(^|\.)(feishu\.cn|larksuite\.com)$/.test(new URL(url).hostname))continue;}catch{continue;}
    if(seen.has(url)||!normalize(item.title).includes(normalize(source.title)))continue;seen.add(url);reads++;
    const fetched=await call('lark.docs.fetch',{doc:url,scope:'full'});if(!fetched.ok||typeof fetched.data?.text!=='string'){record.error=String(fetched.error||'Notes read failed').slice(0,200);continue;}
    const text=fetched.data.text;if(!text.trim()||text.length>100000){record.error='纪要超出完整读取范围；未截断导入 / Notes exceed the full-read limit; not imported';continue;}
    const digest=hash(text),matched=identityClaim(source,session,text);
    record.candidates.push({id:'notes-'+hash(url+digest).slice(0,24),url,title:String(item.title).slice(0,200),hash:digest,text,reader:'lark.docs.fetch',remoteRevision:fetched.data.revision??null,identityClaim:matched,sameMeeting:false,state:'candidate',at:new Date(now).toISOString()});
   }
   }
   // A calendar change during network IO invalidates all candidates.
   if(fingerprint(source,session)!==binding)throw Error('会议关联已变化 / Meeting association changed');
   // Search/fetch supplies document identity, not calendar-event identity. Body claims
   // remain untrusted. Only the human confirmation path may reconcile these candidates.
  }catch(e){record.error=String(e.message).slice(0,200);}
  if(fingerprint(source,session)!==binding)return null;
  for(const old of previous?.candidates||[])if(!record.candidates.some(c=>c.id===old.id))record.candidates.push(old);record.candidates=record.candidates.slice(0,6);
  this.items=this.items.filter(x=>x.meetingId!==session.id);this.items.push(record);this.items=this.items.slice(-200);this.save();return this.visible(source,session);
 }
 async tick(ctx){if(this.busy)return;this.busy=true;try{
  const now=Date.now(),rows=ctx.hub.data.sources.filter(s=>s.kind==='meeting'&&s.sessionId).sort((a,b)=>Date.parse(b.date)-Date.parse(a.date)).slice(0,100).map(source=>({source,session:ctx.session(source.sessionId)})).filter(x=>x.session&&(x.session.end||x.session.finalized)&&normalize(x.source.title).length>=4&&now-Date.parse(x.source.date)>=0&&now-Date.parse(x.source.date)<7*86400000&&(!this.entry(x.source,x.session)||((this.entry(x.source,x.session).attempts||1)<6&&now-this.entry(x.source,x.session).checkedAt>=[5,15,30,60,120][Math.min(4,(this.entry(x.source,x.session).attempts||1)-1)]*60000))).sort((a,b)=>(this.entry(a.source,a.session)?.checkedAt||0)-(this.entry(b.source,b.session)?.checkedAt||0));
  for(const x of rows.slice(0,2))await this.scan(ctx,x.source,x.session,{now});
 }finally{this.busy=false;}}
}
module.exports={get(dir){if(!instances.has(dir))instances.set(dir,new Discovery(dir));return instances.get(dir);},Discovery,identityClaim,fingerprint};
