'use strict';
// Explicit, source-backed copies. Linking meetings/topics never invokes this path.
const {format,digest}=require('./mother-documents');
const {yDocToProsemirrorJSON}=require('./mother-document-runtime');
const fail=(message,status=400)=>Object.assign(Error(message),{status});
const text=n=>String(n.text||'')+(n.content||[]).map(text).join(' ');
const project=s=>s.projectManual?s.projectId||'':'';
function choices(ctx,store,target,{fromDocumentId='',fromMeetingId=''}){
 const result={blocks:[],segments:[],meetings:ctx.hub.data.sources.filter(s=>s.sessionId&&s.sessionId!==target.sessionId&&project(s)===project(target)).map(s=>({id:s.sessionId,title:s.title||s.sessionId}))};
 if(fromDocumentId){const entry=store.read(fromDocumentId);if(entry.record.projectId!==project(target))throw fail('This document belongs to another project',409);result.documentRevision=entry.record.revision;result.documentTitle=entry.record.title;result.blocks=yDocToProsemirrorJSON(entry.doc,'default').content.map(b=>({id:b.attrs?.blockId,label:text(b).trim().slice(0,400)||b.type})).filter(b=>b.id);}
 if(fromMeetingId){const source=ctx.hub.data.sources.find(s=>s.sessionId===fromMeetingId||s.key==='session:'+fromMeetingId);if(!source||project(source)!==project(target))throw fail('Choose a meeting in this project',409);const session=ctx.session?.(fromMeetingId);if(!session)throw fail('Original meeting is unavailable',404);result.meetingTitle=source.title;result.segments=(session.transcript||[]).map((s,index)=>({index,hash:digest(s),text:String(s.text||''),at:s.t??s.at??'',id:s.segId||s.id||'',speaker:String(s.speaker||s.spk||s.who||'').slice(0,120)}));}
 return result;
}
function fork(ctx,store,target,j){
 if(typeof j.requestId!=='string'||!/^fork-[a-f0-9-]{36}$/.test(j.requestId))throw fail('Invalid fork request');
 const signature=digest({meetingId:j.meetingId,title:j.title,fromDocumentId:j.fromDocumentId||'',documentRevision:j.documentRevision,blockIds:j.blockIds||[],fromMeetingId:j.fromMeetingId||'',segments:j.segments||[]});
 const prior=store.list().find(d=>d.fork?.requestId===j.requestId);
 if(prior){if(prior.projectId!==project(target)||prior.fork.signature!==signature)throw fail('Fork request changed; try again',409);return store.state(prior.id);}
 if(target.revision!==Number(j.sourceRevision))throw fail('Meeting changed; refresh and retry',409);
 const ids=j.blockIds||[],segments=j.segments||[];
 if(!Array.isArray(ids)||ids.length>50||new Set(ids).size!==ids.length||!Array.isArray(segments)||segments.length>100||new Set(segments.map(s=>s.index)).size!==segments.length||!ids.length&&!segments.length)throw fail('Select the blocks or original speech to carry over');
 const available=choices(ctx,store,target,j),content=[];
 if(ids.length){const entry=store.read(j.fromDocumentId);if(entry.record.revision!==Number(j.documentRevision))throw fail('Original document changed; review your selection again',409);const blocks=yDocToProsemirrorJSON(entry.doc,'default').content;if(ids.some(id=>!blocks.some(b=>b.attrs?.blockId===id)))throw fail('Selected block no longer exists',409);content.push(...blocks.filter(b=>ids.includes(b.attrs?.blockId)));}
 if(segments.length){for(const selected of segments){const original=available.segments.find(s=>s.index===selected.index);if(!original||original.hash!==selected.hash)throw fail('Original speech changed; review your selection again',409);const label=[available.meetingTitle||j.fromMeetingId,String(original.at),original.speaker].filter(v=>v!=='').join(' · ');const link={type:'paragraph',content:[{type:'text',text:label,marks:[{type:'link',attrs:{href:'/tinghuitai/?id='+encodeURIComponent(j.fromMeetingId)}}]}]};content.push({type:'blockquote',attrs:{sourceRef:j.fromMeetingId+':fork',sourceRefs:original.id?[original.id]:[],draft:'working-draft'},content:[link,format.paragraph(original.text)]});}}
 if(Buffer.byteLength(JSON.stringify(content))>8000000)throw fail('Selected content is too large',413);
 const provenance={requestId:j.requestId,signature,fromDocumentId:j.fromDocumentId||'',documentRevision:j.documentRevision||null,blockIds:ids,fromMeetingId:j.fromMeetingId||'',segments:segments.map(s=>({index:s.index,hash:s.hash})),at:new Date().toISOString()};
 return store.create({title:j.title,projectId:project(target),meetingId:j.meetingId,content:{type:'doc',content},fork:provenance});
}
module.exports={choices,fork};
