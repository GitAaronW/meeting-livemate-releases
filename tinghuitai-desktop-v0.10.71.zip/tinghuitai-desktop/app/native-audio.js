'use strict';
const crypto=require('crypto');
// The capture process retains each packet until ACK. A lost response may retry
// an accepted packet, but must never duplicate audio at the ASR provider.
function createIngress(){
  let next=1;const receipts=new Map();
  return {accept(j,write){
    if(!Number.isSafeInteger(j.seq)||j.seq<1)throw Error('invalid_audio_sequence');
    if(typeof j.pcm!=='string'||j.pcm.length>42668||!j.pcm.length)throw Error('invalid_audio_payload');
    const pcm=Buffer.from(j.pcm,'base64');
    if(pcm.toString('base64')!==j.pcm||pcm.length%2||pcm.length>32000)throw Error('invalid_audio_payload');
    const hash=crypto.createHash('sha256').update(pcm).digest('hex');
    if(j.seq<next){if(receipts.get(j.seq)!==hash)throw Error('audio_retry_conflict');return {seq:j.seq,duplicate:true};}
    if(j.seq!==next)throw Error('audio_sequence_gap');
    write(pcm);receipts.set(next,hash);next++;if(receipts.size>128)receipts.delete(next-129);
    return {seq:j.seq,duplicate:false};
  }};
}
module.exports={createIngress};
