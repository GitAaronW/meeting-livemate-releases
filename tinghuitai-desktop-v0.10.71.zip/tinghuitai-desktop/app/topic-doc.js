'use strict';

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const llm = require('./llm');
const localTime = require('./local-time');
const defaultSendGate = require('./send-gate');
const defaultLark = require('./tools/lark');
// 主题 → 远端文档与负责人：个人版放 <THT_DATA_DIR>/topics.json（含文档 token 与同事名字，不随包公开），包里是空表
function loadTopics() {
  const mine = process.env.THT_DATA_DIR ? path.join(process.env.THT_DATA_DIR, 'topics.json') : '';
  for (const f of [mine, path.join(__dirname, 'topics.json')].filter(Boolean)) {
    try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) {}
  }
  return {};
}

const topicDocRoutes = require('./topic-doc-routes');
const SECTIONS = ['未决问题', '讨论中', '最新进展', '下一步最重要的事'];
const MAX_TEXT = 60;
const operations = new Set();
const digest = value => crypto.createHash('sha256').update(JSON.stringify(stable(value)) || 'null').digest('hex');
const canonicalMarkdown = value => String(value || '').replace(/\r\n?/g, '\n').trim();

// Compare user-visible content only; archive/version metadata is intentionally
// excluded so formatting, links and newly added children remain conflict signals.
function blockContent(block) {
  const type = block?.type;
  const richText = block?.richText || block?.[type]?.rich_text || [];
  return digest({ type, hasChildren: !!(block?.hasChildren || block?.has_children),
    color: block?.color || block?.[type]?.color || 'default',
    richText: richText.map(r => ({ type: r.type || 'text',
      text: r.plain_text ?? r.text?.content ?? '',
      link: r.href || r.text?.link?.url || null,
      annotations: { bold: false, italic: false, strikethrough: false, underline: false, code: false, color: 'default', ...r.annotations },
      mention: r.mention || null, equation: r.equation || null })) });
}

function bad(message, code = 400) {
  const error = Error(message);
  error.code = code;
  return error;
}

function stable(value) {
  if (Array.isArray(value)) return value.map(stable);
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(Object.keys(value).sort().map(key => [key, stable(value[key])]));
}

function searchable(value) {
  const parts = [];
  const visit = current => {
    if (Array.isArray(current)) return current.forEach(visit);
    if (current && typeof current === 'object') return Object.keys(current).sort().forEach(key => visit(current[key]));
    if (current != null) parts.push(String(current));
  };
  visit(stable(value));
  return parts.join('\n').normalize('NFKC').toLocaleLowerCase();
}

function classifyWith(topics, enhanced) {
  if (!enhanced || typeof enhanced !== 'object') return null;
  const haystack = searchable(enhanced);
  if (!haystack) return null;
  for (const [name, config] of Object.entries(topics || {})) {
    if (!config || !Array.isArray(config.keywords)) continue;
    for (const keyword of config.keywords) {
      const needle = String(keyword || '').normalize('NFKC').toLocaleLowerCase();
      if (needle && haystack.includes(needle)) return name;
    }
  }
  return null;
}

function extractJson(raw) {
  const text = String(raw || '').trim();
  if (!text) throw bad('模型没有返回主题差异', 502);
  try { return JSON.parse(text); } catch (error) {}
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fenced) {
    try { return JSON.parse(fenced[1]); } catch (error) {}
  }
  const start = text.indexOf('{'), end = text.lastIndexOf('}');
  if (start >= 0 && end > start) {
    try { return JSON.parse(text.slice(start, end + 1)); } catch (error) {}
  }
  throw bad('模型返回的主题差异不是合法 JSON', 502);
}

function evidenceIds(enhanced) {
  const ids = new Set();
  const visit = current => {
    if (Array.isArray(current)) return current.forEach(visit);
    if (!current || typeof current !== 'object') return;
    if (typeof current.seg === 'string' && current.seg.trim()) ids.add(current.seg.trim());
    for (const value of Object.values(current)) visit(value);
  };
  visit(enhanced);
  return ids;
}

function rawItems(parsed) {
  if (Array.isArray(parsed && parsed.items)) return parsed.items;
  if (!Array.isArray(parsed && parsed.sections)) return [];
  const out = [];
  for (const group of parsed.sections) {
    if (!group || typeof group !== 'object' || !Array.isArray(group.items)) continue;
    for (const item of group.items) out.push({ ...item, section: item.section || group.section });
  }
  return out;
}

function itemId(meetingId, topic, item) {
  const source = [meetingId, topic, item.section, item.text, item.replaceBlockId || '', ...item.evidence].join('\u001f');
  return 'td-' + crypto.createHash('sha256').update(source).digest('hex').slice(0, 16);
}

function validateDiff(parsed, enhanced, meetingId, topic, managed = []) {
  if (!Array.isArray(parsed && parsed.sections) || parsed.sections.length !== SECTIONS.length) throw bad('主题差异必须完整包含四个章节', 502);
  const names = parsed.sections.map(group => String(group && group.section || '').trim());
  if (new Set(names).size !== SECTIONS.length || SECTIONS.some(section => !names.includes(section))) throw bad('主题差异必须完整包含四个章节', 502);
  const allowedEvidence = evidenceIds(enhanced);
  const items = rawItems(parsed).map((raw, index) => {
    if (!raw || typeof raw !== 'object') throw bad('主题差异第 ' + (index + 1) + ' 条不是对象', 502);
    const section = String(raw.section || '').trim();
    if (!SECTIONS.includes(section)) throw bad('主题差异包含未知章节：' + section, 502);
    const text = String(raw.text || '').trim();
    if (!text) throw bad('主题差异第 ' + (index + 1) + ' 条没有内容', 502);
    if ([...text].length > MAX_TEXT) throw bad('主题差异第 ' + (index + 1) + ' 条超过 60 字', 502);
    if (!Array.isArray(raw.evidence) || !raw.evidence.length) throw bad('主题差异第 ' + (index + 1) + ' 条没有证据段', 502);
    const evidence = [...new Set(raw.evidence.map(value => String(value || '').trim()).filter(Boolean))];
    if (!evidence.length || evidence.some(id => !allowedEvidence.has(id))) throw bad('主题差异第 ' + (index + 1) + ' 条引用了不存在的证据段', 502);
    const replaceBlockId = String(raw.replaceBlockId || '').trim();
    if (replaceBlockId && !managed.some(b => b.id === replaceBlockId && b.current.section === section)) throw bad('不能修订未受管理的段落', 502);
    const item = { section, text, evidence, status: 'pending', ...(replaceBlockId ? { replaceBlockId } : {}) };
    return { id: itemId(meetingId, topic, item), ...item };
  });
  const replacements = items.filter(i => i.replaceBlockId).map(i => i.replaceBlockId);
  if (new Set(replacements).size !== replacements.length) throw bad('同一段落不能重复修订', 502);
  return SECTIONS.map(section => ({ section, items: items.filter(item => item.section === section) }));
}

function meetingDate(enhanced) {
  const raw = Number(enhanced && (enhanced.start || enhanced.startedAt || enhanced.at));
  if (!Number.isFinite(raw) || raw <= 0) return localTime.localDay();
  return localTime.localDay(raw);
}

function promptFor(enhanced, docMarkdown, topic, managed = []) {
  const system = [
    '你只输出 JSON，不写解释。',
    '从会议内容提取相对于主题文档的增量，固定分成四节：' + SECTIONS.join(' / ') + '。',
    '格式：{"sections":[{"section":"未决问题","items":[{"text":"不超过60字","evidence":["逐字稿seg"]}]}]}。',
    '四个 section 都必须出现；没有内容时 items 为空。每条必须引用真实 seg，不能推测决定。',
    '新结论更新已有 AI 段落时设置 replaceBlockId，必须来自下方可修订列表且保持原章节；无需重复追加。人工原文不可替换。所有修订都展示前后差异并经用户确认。',
  ].join('\n');
  const user = [
    '主题：' + topic,
    '可修订 AI 段落：\n' + JSON.stringify(managed.map(b => ({ id: b.id, section: b.current.section, text: b.current.text }))),
    '现有主题文档：\n' + (String(docMarkdown || '').trim() || '（空）'),
    '会议增强结果：\n' + JSON.stringify(stable(enhanced)),
  ].join('\n\n');
  return { system, user };
}

function atomicWrite(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = file + '.' + process.pid + '.' + Date.now() + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(value, null, 2) + '\n', { mode: 0o600 });
  fs.renameSync(tmp, file);
}

function escapeXml(value) {
  return String(value == null ? '' : value)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function itemXml(item, record) {
  const source = '来源：会议 ' + record.meetingId + ' ' + record.date;
  return '<h2>' + escapeXml(item.section) + '</h2><p>' + escapeXml(item.text) + '<br/>' + escapeXml(source) + '</p>';
}

function create(options = {}) {
  const dataDir = options.dataDir || process.env.THT_DATA_DIR || process.cwd();
  const currentTopics = () => options.topics || loadTopics();
  const log = typeof options.log === 'function' ? options.log : () => {};
  const ask = options.ask || (request => llm.ask(typeof options.env === 'function' ? options.env() : options.env || process.env, request));
  const lark = options.lark || defaultLark;
  const larkOptions = { log, ...(options.larkOptions || {}) };
  const documents = require('./topic-doc-provider').create({ lark, larkOptions, env: options.env, notionOptions: options.notionOptions });
  const sendGate = options.sendGate || defaultSendGate;
  const revisions = require('./topic-doc-revisions').create(dataDir);

  const diffFile = meetingId => path.join(dataDir, 'state', 'topic-diff', meetingId + '.json');
  const classify = enhanced => classifyWith(currentTopics(), enhanced);
  const currentSource = async id => {
    if (typeof options.getEnhanced !== 'function') throw bad('缺少当前会议核对能力，请重新生成预览后再试', 409);
    const source = await options.getEnhanced(id);
    if (!source || typeof source !== 'object') throw bad('当前会议结果不可用，未写入', 409);
    if (source.id && source.id !== id || source.meetingId && source.meetingId !== id) throw bad('会议目标不一致，未写入', 409);
    return JSON.parse(JSON.stringify({ ...source, id }));
  };
  async function locked(id, run) {
    const key = diffFile(id);
    if (operations.has(key)) throw bad('这场会的文档更新正在处理中，请稍后再试', 409);
    operations.add(key);
    try { return await run(); } finally { operations.delete(key); }
  }
  async function fetchDocument(config) {
    const fetched = await documents.read(config);
    const verifiedEmptyPage = config.provider === 'notion' && fetched?.coverage?.complete === true;
    if (!fetched || !fetched.ok || !canonicalMarkdown(fetched.markdown) && !verifiedEmptyPage) throw bad('读不到主题文档正文：' + String(fetched && fetched.error || '正文为空'), 502);
    return canonicalMarkdown(fetched.markdown);
  }
  async function checkBinding(record) {
    const config = currentTopics()[record.topic];
    if (!record.binding || digest(config) !== record.binding.configHash) throw bad('主题目标或负责人已改变，请重新生成差异预览；未写入', 409);
    if (digest(await currentSource(record.meetingId)) !== record.binding.sourceHash) throw bad('会议内容或人工决定已改变，请重新生成差异预览；未写入', 409);
    if (read(record.meetingId).previewId !== record.previewId) throw bad('预览已更新，请重新打开；未写入', 409);
    return config;
  }

  async function computeDiff(enhanced, docMarkdown = '') {
    if (!enhanced || typeof enhanced !== 'object') throw bad('缺会议增强结果');
    const meetingId = String(enhanced.id || enhanced.meetingId || '').trim();
    if (!/^[A-Za-z0-9_.:-]{1,120}$/.test(meetingId)) throw bad('会议编号不对');
    return locked(meetingId, async () => {
    enhanced = typeof options.getEnhanced === 'function' ? await currentSource(meetingId) : JSON.parse(JSON.stringify({ ...enhanced, id: meetingId }));
    const topic = classify(enhanced);
    if (!topic) return null;
    // 调用方没给正文就自己读目标文档当基线；读不到就不生成，免得拿空基线写出重复内容
    const config = JSON.parse(JSON.stringify(currentTopics()[topic]));
    const docToken = config && config.doc;
    if (!String(docMarkdown || '').trim() && docToken) {
      docMarkdown = await fetchDocument(config);
    }
    docMarkdown = canonicalMarkdown(docMarkdown);
    const targetHash = digest(config.provider === 'notion' ? require('./topic-doc-provider').target(config) : docToken || '');
    const managed = config.provider === 'notion' ? Object.values(revisions.read(targetHash).blocks) : [];
    const prompts = promptFor(enhanced, docMarkdown, topic, managed);
    // 真实模型偶尔回坏 JSON 或编出不存在的证据段（09-25 实测 3 次败 2 次）：最多试 3 次，把上次的错带回去
    let sections = null, lastError = null;
    for (let attempt = 0; attempt < 3 && !sections; attempt++) {
      const req = { kind: 'post', json: true, tools: false, maxTokens: 4000, dataDir, log, ...prompts };   // 四节差异要 2–3 千字，接口默认 800 token 会截断
      if (lastError) req.user = String(req.user || '') + '\n\n上一次输出不合格：' + lastError.message + '。只输出合法 JSON，evidence 只能用上面出现过的段编号。';
      const response = await ask(req);
      if (!response || !response.text) throw bad('主题差异生成失败：' + String(response && response.errorCode || '模型无响应'), 502);
      try { sections = validateDiff(extractJson(response.text), enhanced, meetingId, topic, managed); }
      catch (error) { if (error.code !== 502) throw error; lastError = error; log('主题差异第 ' + (attempt + 1) + ' 次不合格：' + error.message); }
    }
    if (!sections) throw lastError;
    for (const item of sections.flatMap(g => g.items)) {
      if (!item.replaceBlockId) continue;
      const block = managed.find(b => b.id === item.replaceBlockId);
      item.before = block.current.rendered;
      item.sources = [...block.current.sources, { meetingId, date: meetingDate(enhanced), evidence: item.evidence }];
      item.rendered = item.text + '\n' + item.sources.map(src => '来源：会议 ' + src.meetingId + ' ' + src.date + ' [' + src.evidence.join(', ') + ']').join('\n');
      item.previousVersions = block.versions.map(v => ({ id: v.id, text: v.text, at: v.at }));
    }
    const record = {
      meetingId,
      meetingTitle: String(enhanced.title || '').trim().slice(0, 200),
      date: meetingDate(enhanced),
      topic,
      owner: config.owner || '',
      previewId: crypto.randomUUID(),
      binding: { configHash: digest(config), targetHash: digest(config.provider === 'notion' ? require('./topic-doc-provider').target(config) : docToken || ''), sourceHash: digest(enhanced), baselineHash: digest(docMarkdown) },
      hasDocument: !!String(docToken || '').trim(),   // 没配目标文档的主题只给预览，界面不出「接受」
      status: 'pending',
      sections,
    };
    if (digest(currentTopics()[topic]) !== record.binding.configHash || typeof options.getEnhanced === 'function' && digest(await currentSource(meetingId)) !== record.binding.sourceHash) throw bad('生成期间目标或会议内容已改变，请重新生成', 409);
    atomicWrite(diffFile(meetingId), record);
    return record;
    });
  }

  function read(meetingId) {
    const id = String(meetingId || '').trim();
    if (!/^[A-Za-z0-9_.:-]{1,120}$/.test(id)) throw bad('会议编号不对');
    try { return JSON.parse(fs.readFileSync(diffFile(id), 'utf8')); }
    catch (error) { if (error.code === 'ENOENT') throw bad('还没有主题差异', 404); throw error; }
  }

  // This is a pre-read/write/readback guard, not an atomic remote CAS.
  async function replaceManaged(config, item, record) {
    const target = record.binding.targetHash;
    const history = revisions.read(target);
    const managed = history.blocks[item.replaceBlockId];
    if (history.journal) throw Object.assign(bad('上一次段落修订待核对，请先核对恢复记录', 409), { definite: true });
    if (!managed || managed.current.rendered !== item.before) throw Object.assign(bad('段落版本已改变，请重新生成预览', 409), { definite: true });
    const before = await documents.read(config);
    const block = before.snapshots?.find(b => b.id === (managed.current.remoteId || item.replaceBlockId));
    if (!before.ok || digest(canonicalMarkdown(before.markdown)) !== (record.verifiedBaselineHash || record.binding.baselineHash) || !block || block.type !== 'paragraph' || block.hasChildren || block.text !== item.before || block.parentId.replace(/-/g, '') !== require('./topic-doc-provider').target(config).id) throw Object.assign(bad('段落已被人工修改或移动，请重新生成并核对差异；未写入', 409), { definite: true });
    // Styled/linked human edits must not be flattened by a plain text revision.
    if (block.color && block.color !== 'default' || (block.richText || []).some(r => r.type && r.type !== 'text' || r.href || r.text?.link || Object.entries(r.annotations || {}).some(([k,v]) => k === 'color' ? v !== 'default' : v === true))) throw Object.assign(bad('段落含人工格式或链接，请保留原文并新增建议', 409), { definite: true });
    await checkBinding(record);
    revisions.begin(target, { blockId: block.id, meetingId: record.meetingId, itemId: item.id, before: block, proposed: item.rendered, sources: item.sources, baseline: before.snapshots });
    // Never PATCH paragraph text: without CAS an unseen human edit could be
    // overwritten. Insert the new revision at this location, then archive the old
    // block without changing its text. The old remote block remains recoverable.
    const result = await documents.insertRevision(config, block.id, item.rendered);
    if (!result?.ok) {
      if (!result?.uncertain) revisions.settle(target, 'rejected');
      throw Object.assign(bad('段落修订失败：' + (result?.error || '未知错误'), 502), { definite: !result?.uncertain });
    }
    const newId = result.json?.results?.[0]?.id;
    if (!newId) throw bad('新段落编号未确认，请先核对恢复记录', 502);
    revisions.settle(target, 'inserted', null, { newBlockId: newId });
    const currentOld = await documents.readBlock(config, block.id);
    if (!currentOld.ok || blockContent(currentOld.json) !== blockContent(block)) {
      revisions.settle(target, 'conflict', currentOld.json || {});
      throw bad('原段落发生并发修改，新旧两版均已保留，请核对恢复记录', 502);
    }
    const archived = await documents.archive(config, block.id);
    if (!archived?.ok) throw bad('新段落已保存，旧段落状态待核对；不会自动重发', 502);
    const savedOld = await documents.readBlock(config, block.id);
    revisions.settle(target, 'archived', savedOld.json || {});
    if (!savedOld.ok || blockContent(savedOld.json) !== blockContent(block)) {
      // Retain the late human version in its original remote block. Do not claim
      // successful replacement: explicit recovery can restore its visibility.
      revisions.settle(target, 'conflict', savedOld.json || {});
      throw bad('原段落出现并发人工修改，原远端版本仍可恢复；请核对恢复记录', 502);
    }
    const after = await documents.read(config);
    const observed = after.snapshots?.find(b => b.id === newId);
    const comparable = rows => (rows || []).map(({ id, type, text, parentId, hasChildren, richText, color }) => ({ id, type, text, parentId, hasChildren, richText, color }));
    const untouchedBefore = comparable(before.snapshots.filter(b => b.id !== block.id));
    const untouchedAfter = comparable((after.snapshots || []).filter(b => b.id !== newId));
    if (!after.ok || !observed || observed.type !== 'paragraph' || observed.hasChildren || observed.text !== item.rendered || observed.parentId !== block.parentId || digest(untouchedBefore) !== digest(untouchedAfter)) {
      revisions.settle(target, 'conflict', after.snapshots || []);
      throw bad('修订后发现并发变化，原版与建议已保留；请核对恢复记录，不会自动重发', 502);
    }
    item.remoteId = newId;
    revisions.remember(target, item.replaceBlockId, item, record, item.rendered);
    return { after: canonicalMarkdown(after.markdown), blockId: newId };
  }

  async function apply(meetingId, ids, body = {}) {
    // 确认门在服务层也守一道：任何调用路径不带 confirmed:true 都不写远端文档
    if (!body || body.confirmed !== true) throw bad('写回文档需要你在界面上点确认', 403);
    if (!Array.isArray(ids) || !ids.length) throw bad('没有选择要写入的条目');
    return locked(meetingId, async () => {
    const record = read(meetingId);
    const config = currentTopics()[record.topic];
    if (!config) throw bad('主题配置不存在', 500);
    const all = (record.sections || []).flatMap(group => Array.isArray(group.items) ? group.items : []);
    const wanted = [...new Set(ids.map(value => String(value || '').trim()).filter(Boolean))];
    const selected = wanted.map(id => all.find(item => item.id === id));
    if (selected.some(item => !item)) throw bad('选择里有不存在的条目');
    if (!String(config.doc || '').trim()) return { ok: true, skipped: 'no_document', topic: record.topic, applied: [] };
    if (!record.previewId || body.previewId !== record.previewId) throw bad('预览已过期，请重新生成差异预览；未写入', 409);
    await checkBinding(record);
    // Different meetings may share one canonical document. Serialize their writes
    // so the second preview is rechecked against the first meeting's readback.
    const targetKey = path.resolve(dataDir) + '/topic-target/' + record.binding.targetHash;
    if (operations.has(targetKey)) throw bad('这份文档正在更新，请稍后重试；未写入', 409);
    operations.add(targetKey);
    try {
    const applied = [];
    for (const item of selected) {
      const xml = itemXml(item, record);
      let receipt;
      try { receipt = await sendGate.send({
        dataDir,
        kind: 'topic-doc',
        key: record.meetingId + ':' + item.id,
        body: { confirmed: true, retryConfirmed: body.retryConfirmed === true },
        meta: { meetingId: record.meetingId, itemId: item.id, topic: record.topic, targetHash: record.binding.targetHash },
        run: async () => {
          // All failures before append are definite. After append, a failed readback
          // stays uncertain in the durable gate and must never auto-retry.
          if (item.status === 'applied' && item.writeback) return item.writeback;
          let before;
          try {
            await checkBinding(record);
            before = await fetchDocument(config);
            if (digest(before) !== (record.verifiedBaselineHash || record.binding.baselineHash)) throw bad('主题文档已被修改，请重新生成差异预览；未写入', 409);
            await checkBinding(record);
          } catch (error) { error.definite = body.retryConfirmed !== true; throw error; }
          if (item.replaceBlockId) {
            const revised = await replaceManaged(config, item, record);
            record.verifiedBaselineHash = digest(revised.after);
            item.status = 'applied';
            item.writeback = { verified: true, blockId: revised.blockId, readbackHash: digest(revised.after) };
            atomicWrite(diffFile(record.meetingId), record);
            return item.writeback;
          }
          if (config.provider === 'notion' && revisions.read(record.binding.targetHash).journal) throw Object.assign(bad('上一次段落修订待核对，暂不写入这份文档', 409), { definite: true });
          const result = await documents.append(config, item, record, xml);
          if (!result || result.ok === false) {
            const error = bad('主题文档写入失败：' + String(result && result.error || '未知错误'), 502);
            error.definite = !(result && result.uncertain);
            throw error;
          }
          const after = await fetchDocument(config);
          const suffix = after.slice(before.length);
          const source = '来源：会议 ' + record.meetingId + ' ' + record.date;
          if (!after.startsWith(before) || !suffix.includes(item.text) || !suffix.includes(source)) throw bad('写入后的正文未能核实，请先到目标文档核对；不会自动重发', 502);
          if (config.provider === 'notion') revisions.remember(record.binding.targetHash, result.blockId, item, record);
          record.verifiedBaselineHash = digest(after);
          item.status = 'applied';
          item.writeback = { revision: String(result.revision || ''), verified: true, readbackHash: digest(after) };
          atomicWrite(diffFile(record.meetingId), record);
          return item.writeback;
        },
      }); } catch (error) {
        record.sync = { status: error.uncertain ? 'needs_verification' : 'pending', at: Date.now(), itemId: item.id, error: error.uncertain ? '写入结果待核对，不会自动重发' : '尚未保存远端，请恢复连接或权限后重试' };
        try { atomicWrite(diffFile(record.meetingId), record); }
        catch (saveError) { error.stateSaveFailed = true; }
        throw error;
      }
      if (receipt.alreadySent && receipt.targetHash !== record.binding.targetHash) throw bad('条目已有其他目标或旧版写入记录，请先核对原文档；不会重复写入', 409);
      log('topic-doc ' + record.topic + ' ' + record.meetingId + ' ' + item.id + ' ' + (receipt.alreadySent ? 'already-sent' : 'sent'));
      applied.push({ id: item.id, alreadySent: !!receipt.alreadySent });
    }
    record.sync = { status: 'verified', at: Date.now() };
    atomicWrite(diffFile(record.meetingId), record);
    return { ok: true, topic: record.topic, applied };
    } finally { operations.delete(targetKey); }
    });
  }

  function history(meetingId) {
    const record = read(meetingId);
    return revisions.read(record.binding.targetHash);
  }
  async function restorePreview(meetingId, blockId, versionId) {
    return locked(meetingId, async () => {
      const record = read(meetingId), config = await checkBinding(record);
      const saved = revisions.read(record.binding.targetHash);
      if (saved.journal) throw bad('请先核对尚未确认的修订', 409);
      const block = saved.blocks[blockId], version = block?.versions.find(v => v.id === versionId);
      if (!version) throw bad('历史版本不存在', 404);
      const markdown = await fetchDocument(config);
      const item = { id: 'restore-' + crypto.randomUUID(), section: version.section, text: version.text,
        evidence: [], status: 'pending', replaceBlockId: blockId, before: block.current.rendered,
        rendered: version.rendered, sources: version.sources, restoredVersion: version.id };
      const preview = { ...record, previewId: crypto.randomUUID(), verifiedBaselineHash: undefined,
        binding: { ...record.binding, baselineHash: digest(markdown) }, sync: undefined,
        sections: SECTIONS.map(section => ({ section, items: section === item.section ? [item] : [] })) };
      await checkBinding(record);
      atomicWrite(diffFile(meetingId), preview);
      return preview;
    });
  }
  async function recover(meetingId, body) {
    if (body?.confirmed !== true) throw bad('核对恢复需要明确确认', 403);
    return locked(meetingId, async () => {
      const record = read(meetingId), config = await checkBinding(record), target = record.binding.targetHash;
      const s = revisions.read(target), journal = s.journal;
      if (!journal) return { ok: true, diff: record };
      if (journal.meetingId !== meetingId) throw bad('请在原会议中核对这次修订', 409);
      const current = await documents.read(config);
      const old = await documents.readBlock(config, journal.blockId);
      if (!current.ok || !old.ok) throw bad('无法读取新旧段落，恢复记录已保留', 409);
      const item = record.sections.flatMap(g => g.items).find(i => i.id === journal.itemId);
      const block = current.snapshots?.find(b => b.id === journal.newBlockId);
      if (blockContent(old.json) !== blockContent(journal.before)) {
        // Changes during the last pre-read/archive interval were never overwritten.
        // Make the original block visible again, preserving the candidate as well.
        if (old.json.archived || old.json.in_trash) {
          const restored = await documents.archive(config, journal.blockId, false);
          if (!restored.ok) throw bad('原段落恢复可见性失败，原远端编号已保留', 502);
        }
        revisions.settle(target, 'conflict', old.json);
        if (body.keepBoth === true && block?.text === journal.proposed && item) {
          revisions.settle(target, 'rejected');
          item.status = 'retained';
          record.sync = { status: 'conflict_retained', at: Date.now() };
          atomicWrite(diffFile(meetingId), record);
          return { ok: true, diff: record };
        }
        throw bad('人工原文和建议均已保留，请在远端合并后重新生成；不会覆盖正文', 409);
      }
      if (block?.text === journal.proposed && (old.json.archived || old.json.in_trash) && item) {
        item.remoteId = block.id;
        revisions.remember(target, item.replaceBlockId, item, record, journal.proposed);
        item.status = 'applied'; item.writeback = { verified: true, recovered: true, blockId: block.id, readbackHash: digest(canonicalMarkdown(current.markdown)) };
        record.verifiedBaselineHash = item.writeback.readbackHash;
        record.sync = { status: 'verified', at: Date.now() };
      } else throw bad('新旧段落状态尚未一致，恢复记录已保留，请先人工核对', 409);
      atomicWrite(diffFile(meetingId), record);
      return { ok: true, diff: record };
    });
  }
  const service = { classify, computeDiff, read, apply, history, restorePreview, recover };
  service.routes = router => topicDocRoutes.mount(router, service);
  return service;
}

module.exports = { create, SECTIONS, MAX_TEXT, __test: { stable, searchable, classifyWith, extractJson, validateDiff, promptFor, itemXml } };
