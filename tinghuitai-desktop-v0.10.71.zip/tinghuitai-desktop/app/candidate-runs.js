'use strict';
const crypto=require('crypto'),candidates=require('./meeting-candidates');
const digest=value=>crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');
const fail=(message,status=409)=>Object.assign(Error(message),{status});
// The card is a reference, never a client-supplied prompt or write destination.
function current(ctx,input){
 if(typeof input.contextId!=='string'||!input.contextId||input.contextId.length>300||typeof input.candidateId!=='string'||!input.candidateId||input.candidateId.length>300)throw fail('Invalid action card',400);
 const source=ctx.hub.data.sources.find(s=>s.sessionId===input.contextId||s.id===input.contextId);
 const contextId=source?.sessionId||source?.id;
 const module=source?.board?.modules?.find(m=>m.id===input.candidateId);
 if(!module||!['action','task'].includes(module.kind))throw fail('Action card unavailable');
 const session=ctx.session(contextId),snapshot=candidates.snapshot(source,session,module.id);
 const candidateHash=digest([source.id,module.id,snapshot.base.title,snapshot.body,snapshot.sourceRefs]);
 return {source,contextId,module,snapshot,candidateHash};
}
function prepare(ctx,input,store){
 const {source,contextId,module,snapshot,candidateHash}=current(ctx,input);
 if(input.candidateHash!==undefined&&input.candidateHash!==candidateHash)throw fail('Action card changed; refresh before running');
 const matching=store.items.filter(j=>j.meetingId==='assistant:global'&&j.request?.candidateId===module.id&&j.request?.candidateHash===candidateHash&&[source.id,contextId].includes(j.request?.contextId));
 const previous=matching.at(-1);
 // A retry is explicit and cannot supersede an uncertain or still running job.
 if(previous&&(!['failed','cancelled','interrupted'].includes(previous.state)||input.retry!==true))return {existing:previous.id};
 const comment=[snapshot.base.title,snapshot.body].filter(Boolean).join('\n\n');
 if(!comment.trim()||comment.length>4000)throw fail('Action card is empty or too large',400);
 return {input:{...input,contextId,action:'run',comment,materialIds:[],requestId:'candidate:'+digest([contextId,module.id,candidateHash,matching.length]),
  pageContext:{objectId:module.id,projectId:source.projectId||'',sourceIds:[source.id]}},binding:{candidateId:module.id,candidateHash}};
}
module.exports={prepare,current};
