'use strict';
// Upgrade only identified automatic preparation, during the existing POST import.
// MotherDocuments preserves revision history and rejects changed/deleted user blocks.
module.exports=function(hub,source,module){
 if(module.kind==='note'&&module.edited===false&&/^AI[ ·草]/.test(module.context||'')&&source.candidateRevisions?.[module.id]){
  const saved=require('./meeting-candidates').visible(source,null)[module.id];
  if(saved&&!saved.stale)return {...module,body:saved.body,sourceRefs:saved.sourceRefs,...(saved.nodes?{nodes:saved.nodes,edges:saved.edges||[]}:{} )};
 }

 if(module.id==='premeeting-candidates'&&module.edited===false&&source.calendarEvent){
  const receipt=hub.sync?.preparation?.[require('./premeeting-preparation').key(source.calendarEvent)]?.discovery;
  if(!receipt)return module;
  const visible={...receipt,items:(receipt.items||[]).filter(r=>!/\.(?:md|json|jsonl)(?:$|[?#])/i.test(r.title||''))};
  const rebuilt=require('./premeeting-discovery').moduleFor(visible);
  return {...module,...(rebuilt||{title:'可能相关的资料',body:'尚未找到可展示的相关资料。可以添加本场需要的资料链接。'}),sourceRefs:module.sourceRefs||[]};
 }
 if(module.id!=='premeeting-materials'||module.edited!==false||!source.calendarEvent)return module;
 const rebuilt=require('./premeeting-brief').preparationModule(hub,source,source.calendarEvent,{purpose:'current-work'});
 if(!rebuilt)return module;
 return {...module,...rebuilt,sourceRefs:[...new Set([...(module.sourceRefs||[]),...(rebuilt.sourceRefs||[])])]};
};

// An automatic suggestion can outlive its board module after discovery refresh.
// Only refresh a previously imported block; never invent or touch a human block.
module.exports.orphanCandidate=function(hub,source,record,meetingId){
 if(!source.calendarEvent||source.board?.modules?.some(m=>m.id==='premeeting-candidates')||!record.imports?.[meetingId+':premeeting-candidates'])return null;
 const original={id:'premeeting-candidates',kind:'note',edited:false,body:''};
 const rebuilt=module.exports(hub,source,original);return rebuilt===original?null:rebuilt;
};
