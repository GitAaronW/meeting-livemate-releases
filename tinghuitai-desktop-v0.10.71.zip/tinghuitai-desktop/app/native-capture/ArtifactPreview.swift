import AppKit
import WebKit
import PDFKit

// Host-owned escaped HTML only. No browser profile, remote URLs, or recording permissions.
final class Renderer: NSObject, WKNavigationDelegate {
    var web: WKWebView!
    let output: URL
    init(input: URL, output: URL) throws {
        self.output = output
        super.init()
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .nonPersistent()
        config.defaultWebpagePreferences.allowsContentJavaScript = false
        web = WKWebView(frame: NSRect(x: 0, y: 0, width: 900, height: 800), configuration: config)
        web.navigationDelegate = self
        web.loadHTMLString(try String(contentsOf: input, encoding: .utf8), baseURL: nil)
    }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        decisionHandler(navigationAction.request.url?.absoluteString == "about:blank" ? .allow : .cancel)
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        webView.evaluateJavaScript("Math.max(document.body.scrollHeight,document.documentElement.scrollHeight)") { height, error in
            guard error == nil, let total = height as? Double, total > 0 else { exit(2) }
            guard total <= 230400 else { exit(9) }
            self.renderPage(webView, total: total, index: 0, pages: [])

        }
    }
    func renderPage(_ webView: WKWebView, total: Double, index: Int, pages: [[String: Any]]) {
        let y = Double(index) * 1800
        let h = min(1800, total - y)
        let config = WKPDFConfiguration()
        config.rect = CGRect(x: 0, y: y, width: 900, height: h)
        webView.createPDF(configuration: config) { result in
            do {
                let data = try result.get()
                guard let page = PDFDocument(data: data)?.page(at: 0) else { exit(3) }
                let image = page.thumbnail(of: NSSize(width: 900, height: h), for: .mediaBox)
                guard let tiff = image.tiffRepresentation, let bitmap = NSBitmapImageRep(data: tiff), let png = bitmap.representation(using: .png, properties: [:]) else { exit(4) }
                let name = index == 0 ? self.output.lastPathComponent : "page-\(index).png"
                try png.write(to: self.output.deletingLastPathComponent().appendingPathComponent(name), options: .atomic)
                var next = pages
                next.append(["file": name, "width": bitmap.pixelsWide, "height": bitmap.pixelsHigh, "offset": y, "text": page.string ?? ""])
                if y + h < total { self.renderPage(webView, total: total, index: index + 1, pages: next); return }
                let info: [String: Any] = ["width": 900, "height": min(total, 1800), "documentHeight": total, "truncated": false, "pages": next]
                FileHandle.standardOutput.write(try JSONSerialization.data(withJSONObject: info))
                exit(0)
            } catch { exit(5) }
        }
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { exit(6) }
}
let args = CommandLine.arguments
if args.count != 3 { exit(1) }
let app = NSApplication.shared
app.setActivationPolicy(.prohibited)
let renderer: Renderer
 do { renderer = try Renderer(input: URL(fileURLWithPath: args[1]), output: URL(fileURLWithPath: args[2])) } catch { exit(7) }
DispatchQueue.main.asyncAfter(deadline: .now() + 90) { exit(8) }
app.run()
