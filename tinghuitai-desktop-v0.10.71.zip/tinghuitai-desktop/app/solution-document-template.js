'use strict';
// Empty structure only: no generated recommendation, owner or commitment.
module.exports=function solutionDocument(lang='zh'){
 const headings=lang==='en'?['What are we solving?','Current recommendation','Options and trade-offs','Validation and next steps','Evidence and revisions']:['我们要解决什么','当前建议','方案与取舍','验证与下一步','依据与修订记录'];
 return {type:'doc',content:headings.flatMap((text,index)=>[
  {type:'heading',attrs:{level:2,sourceRef:'solution-section:'+index},content:[{type:'text',text}]},
  {type:'paragraph'}
 ])};
};
