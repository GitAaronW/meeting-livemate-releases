'use strict';
// Ownership comes from saved organization receipts, never model-provided attrs.
const crypto=require('crypto');
const hash=node=>crypto.createHash('sha256').update(JSON.stringify(node)).digest('hex');
const fail=message=>Object.assign(Error(message),{status:409});
function chapterOf(content,id){let chapter='';for(const node of content.content){if(node.type==='heading')chapter=node.attrs.blockId;if(node.attrs?.blockId===id)return chapter;}return null;}
function owners(record){const result=new Map();for(const selection of Object.values(record.collections||{})){if(selection.undone)continue;const org=selection.organization;for(const item of org?.inserted||[]){if(item.kind!=='increment')continue;const previous=result.get(item.id);if(!previous||(item.revision||org.revision||0)>=(previous.revision||0))result.set(item.id,{...item,revision:item.revision||org.revision||0});}}return result;}
function targets(record,content){return [...owners(record)].map(([id,owner])=>{const node=content.content.find(n=>n.attrs?.blockId===id);return {id,hash:owner.hash,chapterId:owner.chapterId||chapterOf(content,id),currentHash:node?hash(node):null,changed:!node||hash(node)!==owner.hash};});}
function replacement(content,section,key,sourceRefs,base){
 const node=content.content.find(n=>n.attrs?.blockId===section.replaceBlockId);
 if(!base)throw fail('Only recorded AI increments can be updated');
 if(base.chapterId!==section.chapterId)throw fail('Update must stay in its original chapter');
 const next={type:'blockquote',attrs:{...node?.attrs,blockId:base.id,draft:'AI draft',sourceRef:key,sourceRefs:[...new Set([...(node?.attrs?.sourceRefs||[]),...sourceRefs])]},content:section.blocks};
 const hasMedia=n=>['image','meetingGraph'].includes(n.type)||(n.content||[]).some(hasMedia);
 if(node)for(const [index,child] of node.content.entries())if(hasMedia(child))next.content.splice(Math.min(index,next.content.length),0,child);
 const unchanged=node&&hash(node)===base.hash&&base.currentHash===base.hash&&chapterOf(content,base.id)===base.chapterId;
 if(!unchanged)return {proposal:{id:'revision-'+crypto.randomBytes(8).toString('hex'),targetId:base.id,chapterId:base.chapterId,expectedHash:node?hash(node):null,before:node||null,after:next,state:'pending'}};
 const index=content.content.indexOf(node);content.content[index]=next;
 return {inserted:{id:base.id,kind:'increment',chapterId:base.chapterId,previous:node}};
}
function resolve(content,organization,proposalId,decision){
 if(!['accept','reject','undo'].includes(decision))throw fail('Choose accept or reject');
 const proposal=organization?.proposals?.find(p=>p.id===proposalId);if(!proposal)throw fail('This revision suggestion is no longer available');
 if(decision==='undo'){
  if(proposal.state!=='accepted')return;
  const item=organization.inserted.findLast(i=>i.id===proposal.targetId&&i.previous),index=content.content.findIndex(n=>n.attrs?.blockId===proposal.targetId),node=content.content[index];
  if(!item||!node||hash(node)!==item.hash||chapterOf(content,proposal.targetId)!==proposal.chapterId)throw fail('This content has later edits. Your changes are preserved; undo was not applied.');
  content.content[index]=item.previous;organization.inserted.splice(organization.inserted.indexOf(item),1);proposal.state='undone';return;
 }
 if(proposal.state!=='pending')return;
 if(decision==='reject'){proposal.state='rejected';return;}
 const index=content.content.findIndex(n=>n.attrs?.blockId===proposal.targetId),node=content.content[index];
 if(!node||proposal.expectedHash!==hash(node)||chapterOf(content,proposal.targetId)!==proposal.chapterId)throw fail('This content changed or was removed. Your edits are preserved; request a new suggestion.');
 content.content[index]=proposal.after;organization.inserted.push({id:proposal.targetId,kind:'increment',chapterId:proposal.chapterId,previous:node,...(proposal.thinkingMethod?{thinkingMethod:proposal.thinkingMethod}:{})});proposal.state='accepted';
}
module.exports={hash,chapterOf,targets,replacement,resolve};
