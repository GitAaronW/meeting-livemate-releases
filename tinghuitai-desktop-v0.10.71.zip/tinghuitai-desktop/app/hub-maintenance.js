'use strict';
// Meeting preparation can continue while recording; disk indexing stays idle-only.
function create({upstream,skipHeavy,context,prepare,heavy,log=()=>{}}){
 let busy=false;
 return async function tick(withIndex=false){
  if(busy||upstream())return;
  busy=true;
  try{
   try{await prepare(context());}catch(e){log('meeting preparation '+e.message);}
   if(skipHeavy())return;
   await heavy(withIndex);
  }catch(e){log('hub sync '+e.message);}finally{busy=false;}
 };
}
module.exports={create};
