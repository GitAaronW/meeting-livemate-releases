'use strict';
// Resolve an explicit prepared page on the server; never move or replace its board.
function prepare(hub,msg={}) {
 const id=String(msg.sessionId||'');
 const base={lang:msg.lang==='en'?'en':'zh',uiLang:msg.uiLang==='en'?'en':'zh',brief:String(msg.brief||'').slice(0,20000)};
 if(!id)return base;
 if(!/^[A-Za-z0-9][A-Za-z0-9._-]{0,100}$/.test(id))throw Error('invalid meeting ID');
 const source=hub.data.sources.find(s=>s.sessionId===id&&s.key==='session:'+id);
 if(!source)throw Error('会议页面未找到，请重新打开后开始');
 if(source.kind!=='note')throw Error('这场会议已录制，请新建笔记或恢复正在录制的会议');
 return {...base,sessionId:id,title:source.title||'',notes:source.body||'',projectId:source.projectId||'',contextSourceIds:[source.id],calendarEvent:source.calendarEvent||null};
}
// A prepared page owns its calendar identity. Copy it so later session updates
// cannot mutate the Hub's source through an object alias.
function calendarBinding(hub,id) {
 const source=hub?.data?.sources?.find(s=>s.sessionId===id&&s.key==='session:'+id&&s.kind==='note');
 const event=source?.calendarEvent;
 if(!event||typeof event.eventId!=='string'||!event.eventId.trim())return null;
 return {chosen:event.eventId,event:JSON.parse(JSON.stringify(event))};
}
module.exports={prepare,calendarBinding};
