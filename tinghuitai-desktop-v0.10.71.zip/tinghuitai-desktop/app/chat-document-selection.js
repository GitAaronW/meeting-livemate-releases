'use strict';
const crypto=require('crypto'),format=require('./mother-document-schema');
const {normalize}=require('../web/chat-document-selection');
const fail=(message,status=409)=>Object.assign(Error(message),{status});
function plain(node){if(node.type==='text')return node.text||'';const separator=['paragraph','heading'].includes(node.type)?'':' ';return (node.content||[]).map(plain).join(separator);}
module.exports=function chatSelection(ctx,meetingId,moduleId,selection){
 if(!selection||typeof selection.jobId!=='string'||typeof selection.reply!=='string'||typeof selection.quote!=='string'||selection.reply.length>24000||selection.quote.length>12000)throw fail('Select a saved reply of at most 24000 characters',400);
 const job=require('./meeting-board-jobs').get(ctx.dataDir).items.find(j=>j.id===selection.jobId);
 if(!job||job.contextId!==meetingId||!['completed','planned'].includes(job.state)||!job.reply)throw fail('Open the meeting containing this completed reply');
 if(job.reply!==selection.reply)throw fail('Reply changed; select the current text again');
 const quote=normalize(selection.quote),expected='chat-'+crypto.createHash('sha256').update(job.id+'\n'+job.reply+'\n'+quote).digest('hex').slice(0,40);
 if(expected!==moduleId)throw fail('Selection identity changed; select the text again');
 if(quote&&!normalize(plain(format.fromMarkdown(job.reply))).includes(quote))throw fail('Selected text is not in the saved reply');
 return {id:moduleId,kind:'note',title:job.lang==='en'?'Collected conversation':'收录的对话',body:quote||job.reply,sourceRefs:['chat:'+job.id]};
};
