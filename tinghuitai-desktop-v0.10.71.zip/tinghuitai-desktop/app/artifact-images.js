'use strict';
// Render private immutable drafts with the packaged macOS WebKit helper.
const fs=require('fs'),path=require('path'),crypto=require('crypto'),{execFile}=require('child_process');
const artifacts=require('./task-artifacts');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const BIN=path.join(__dirname,'native-capture','TinghuitaiCapture.app','Contents','MacOS','ArtifactPreview');
const pending=new Map();let queue=Promise.resolve();
function cached(dir,sourceSHA,page=0){try{
 const receipt=JSON.parse(fs.readFileSync(path.join(dir,'image-receipt.json'),'utf8'));
 if(receipt.sourceSHA!==sourceSHA)return null;
 const pages=receipt.schema===2?receipt.pages:[{file:'preview.png',sha256:receipt.sha256}];
 if(!Array.isArray(pages)||!pages.length||pages.length>128)return null;
 const bodies=pages.map(p=>{if(!/^preview\.png$|^pages-[a-f0-9]+\/page-\d+\.png$/.test(p.file))throw Error('Invalid image path');const body=fs.readFileSync(path.join(dir,p.file));if(hash(body)!==p.sha256)throw Error('Invalid image hash');return body;});
 if(!Number.isInteger(page)||page<0||page>=pages.length)throw Object.assign(Error('Invalid image page'),{status:400});
 return {body:bodies[page],receipt,pageSHA:pages[page].sha256};
 }catch(e){if(e.status===400)throw e;return null;}}
function read(dataDir,id,page=0){
 const draft=artifacts.read(dataDir,id,'md').body,dir=path.join(dataDir,'task-artifacts',id),result=cached(dir,hash(draft),page);
 if(!result)throw Object.assign(Error('Image preview not prepared; request rendering first'),{status:404});
 return result;
}
async function render(dataDir,id,options={}){
 const draft=artifacts.read(dataDir,id,'md').body,sourceSHA=hash(draft),dir=path.join(dataDir,'task-artifacts',id);
 const existing=cached(dir,sourceSHA);if(existing&&existing.receipt.schema===2)return existing;
 const key=dir+':'+sourceSHA;if(pending.has(key))return pending.get(key);
 if(pending.size>=8)throw Object.assign(Error('Preview renderer busy; retry shortly'),{status:429});
 const job=queue.catch(()=>{}).then(async()=>{
  const again=cached(dir,sourceSHA);if(again&&again.receipt.schema===2)return again;
  const bin=options.bin||BIN;
  if(process.platform!=='darwin'||!fs.existsSync(bin))throw Object.assign(Error('Image preview unavailable; the editable draft is still available'),{status:503});
  const stage=fs.mkdtempSync(path.join(dir,'.image-'));
  try{
   fs.writeFileSync(path.join(stage,'input.html'),artifacts.read(dataDir,id,'html').body,{mode:0o600});
   const output=path.join(stage,'preview.png');
   const metadata=await new Promise((resolve,reject)=>execFile(bin,[path.join(stage,'input.html'),output],{timeout:95000,maxBuffer:2000000},(error,stdout)=>{if(error)return reject(Object.assign(Error('Image preview failed; the editable draft is still available'),{status:503}));try{resolve(JSON.parse(stdout));}catch{reject(Object.assign(Error('Invalid image receipt'),{status:502}));}}));
   if(metadata.truncated!==false||!Array.isArray(metadata.pages)||!metadata.pages.length||metadata.pages.length>128)throw Error('Incomplete image preview');
   const batch='pages-'+crypto.randomBytes(8).toString('hex');
   const pages=metadata.pages.map((p,index)=>{
    const expected=index===0?'preview.png':'page-'+index+'.png';if(p.file!==expected||!Number.isFinite(p.width)||!Number.isFinite(p.height)||p.width<=0||p.height<=0)throw Error('Invalid image page');
    const file=path.join(stage,p.file),body=fs.readFileSync(file);
    if(body.length>40000000||!body.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))throw Error('Invalid preview image');
    fs.chmodSync(file,0o600);fs.renameSync(file,path.join(stage,'render-'+index+'.png'));
    return {file:batch+'/page-'+index+'.png',sha256:hash(body),width:p.width,height:p.height,offset:p.offset};
   });
   // Integrity read is required again after asynchronous rendering.
   const latest=artifacts.read(dataDir,id,'md').body;if(hash(latest)!==sourceSHA)throw Object.assign(Error('Draft changed during rendering'),{status:409});
   const source=JSON.parse(fs.readFileSync(path.join(dir,'receipt.json'),'utf8'));
   const receipt={schema:2,artifactId:id,revision:source.revision,threadId:source.threadId,turnId:source.turnId,sourceSHA,sha256:pages[0].sha256,renderer:'macOS WebKit',width:pages[0].width,height:pages[0].height,documentHeight:metadata.documentHeight,truncated:false,pages,created:new Date().toISOString()};
   const folder=path.join(stage,batch);fs.mkdirSync(folder,{mode:0o700});pages.forEach((p,i)=>fs.renameSync(path.join(stage,'render-'+i+'.png'),path.join(folder,'page-'+i+'.png')));
   fs.renameSync(folder,path.join(dir,batch));
   // Publish the manifest last. Existing readers keep their immutable batch.
   const manifest=path.join(stage,'image-receipt.json');fs.writeFileSync(manifest,JSON.stringify(receipt,null,2),{mode:0o600});fs.renameSync(manifest,path.join(dir,'image-receipt.json'));
   return cached(dir,sourceSHA);

  }finally{fs.rmSync(stage,{recursive:true,force:true});}
 });pending.set(key,job);queue=job;try{return await job;}finally{pending.delete(key);}
}
module.exports={render,read};
