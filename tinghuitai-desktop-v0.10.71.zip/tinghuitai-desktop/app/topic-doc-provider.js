'use strict';
const notion = require('./tools/notion');

// Explicit provider only. Existing token-only configurations remain Lark.
function target(config) {
  const provider = config.provider || 'lark';
  if (!['lark', 'notion'].includes(provider)) throw Error('不支持的主题文档来源');
  let id = String(config.doc || '').trim();
  if (provider === 'notion' && id) {
    if (/^https:\/\//.test(id)) {
      const url = new URL(id);
      if (!/(^|\.)(notion\.so|notion\.site|notion\.com)$/.test(url.hostname) || url.username || url.password || url.port) throw Error('Notion 目标链接无效');
      id = (url.pathname.match(/([a-f0-9]{32}|[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12})\/?$/i) || [])[1] || '';
    }
    if (!/^(?:[a-f0-9]{32}|[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12})$/i.test(id)) throw Error('需要明确的 Notion 页面编号');
    id = id.replace(/-/g, '').toLowerCase();
  }
  return { provider, id };
}
function create({ lark, larkOptions, env, notionOptions = {} }) {
  const context = () => ({ ...notionOptions, env: typeof env === 'function' ? env() : env || process.env });
  return {
    async read(config) {
      const t = target(config);
      if (t.provider === 'lark') return typeof lark.docFetchMarkdown === 'function' ? lark.docFetchMarkdown(t.id, larkOptions) : null;
      const r = await notion.readCompletePage(context(), t.id);
      return { ...r, markdown: r.text };
    },
    async readBlock(config, id) {
      if (target(config).provider !== 'notion') throw Error('该来源尚不支持段落修订');
      return notion.api(context(), 'GET', 'blocks/' + encodeURIComponent(id));
    },
    async insertRevision(config, after, text) {
      const t = target(config);
      if (t.provider !== 'notion') throw Error('该来源尚不支持段落修订');
      const rich_text = Array.from({ length: Math.ceil(text.length / 1800) }, (_, i) => ({ type: 'text', text: { content: text.slice(i * 1800, (i + 1) * 1800) } }));
      return notion.api(context(), 'PATCH', 'blocks/' + t.id + '/children', { after, children: [{ object: 'block', type: 'paragraph', paragraph: { rich_text } }] });
    },
    async archive(config, id, archived = true) {
      if (target(config).provider !== 'notion') throw Error('该来源尚不支持段落修订');
      return notion.api(context(), 'PATCH', 'blocks/' + encodeURIComponent(id), { archived });
    },
    async append(config, item, record, xml) {
      const t = target(config);
      if (t.provider === 'lark') return lark.docValidateAppend({ token: t.id, content: xml }, larkOptions);
      const block = (type, text) => ({ object: 'block', type, [type]: { rich_text: [{ type: 'text', text: { content: text } }] } });
      // New increments append; replacements require a separately journaled managed block.
      const r = await notion.api(context(), 'PATCH', 'blocks/' + t.id + '/children', { children: [
        block('heading_2', item.section), block('paragraph', item.text),
        block('paragraph', '来源：会议 ' + record.meetingId + ' ' + record.date),
      ] });
      return { ...r, blockId: r.json?.results?.[1]?.id || '', revision: '', provider: 'notion' };
    },
  };
}
module.exports = { target, create };
