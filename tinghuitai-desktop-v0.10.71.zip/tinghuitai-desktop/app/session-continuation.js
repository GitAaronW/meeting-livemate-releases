'use strict';
const crypto=require('crypto');
const copy=x=>structuredClone(x);
const hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
// A user action grants one start, not permission for old tabs to revive a meeting.
function create({read,active,now=Date.now}){
 const grants=new Map();
 function ended(id){
  if(!/^[a-zA-Z0-9_-]{1,100}$/.test(id))throw Error('Invalid meeting ID');
  if(active())throw Error('已有会议正在录制或收尾，请稍后继续');
  const saved=read(id);if(!saved||!saved.end)throw Error('已结束的会议记录未找到');
  return saved;
 }
 function prepare(id){
  const saved=ended(id),token=crypto.randomUUID();
  for(const [key,value] of grants)if(value.expires<=now()||value.id===id)grants.delete(key);
  grants.set(token,{id,fingerprint:hash(saved),expires:now()+120000});
  const start=Number(saved.start)||Date.parse(saved.start);
  return {sessionId:id,continuationToken:token,title:saved.title||'',notes:saved.notes||'',lang:saved.lang||'',uiLang:saved.uiLang||'zh',brief:saved.brief||'',snapshot:{...copy(saved),start,transcript:(saved.transcript||[]).map(row=>({...row,at:start+Number(row.at||0)*1000,spk:row.speaker||row.who||row.spk||''}))}};
 }
 function validate(id,token){
  const grant=grants.get(token);if(!grant||grant.id!==id||grant.expires<=now())throw Error('继续听会已过期，请重新点击');
  const saved=ended(id);if(hash(saved)!==grant.fingerprint)throw Error('会议记录已更新，请重新点击继续听会');
  return copy(saved);
 }
 function consume(id,token){const saved=validate(id,token);grants.delete(token);return saved;}
 return {prepare,validate,consume};
}
function sameGeneration(original,current){return !current||(original?.continuationEpoch||'')===(current.continuationEpoch||'');}
module.exports={create,sameGeneration};
