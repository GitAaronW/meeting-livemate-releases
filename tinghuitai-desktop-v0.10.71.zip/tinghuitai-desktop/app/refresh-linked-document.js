'use strict';
// Refresh only content already admitted to this document. New suggestions still
// require explicit collection; human edits and selective forks stay protected.
module.exports=function(ctx,source,meetingId){
 if(!source.motherDocumentId)return null;
 const store=require('./mother-documents').get(ctx.dataDir),id=source.motherDocumentId;
 const record=store.read(id).record;
 if(record.fork)return null;
 const upgraded=require('./generated-preparation-module'),conflicts=[];let updated=0;
 for(const module of source.board?.modules||[]){
  const key=meetingId+':'+module.id;
  if(!record.imports?.[key]||record.collections?.[key]?.undone||!['note','plan','map','task','action'].includes(module.kind))continue;
  const result=store.importModule(id,upgraded(ctx.hub.data,source,module),meetingId);
  if(result?.conflict)conflicts.push(module.id);else if(result?.revision)updated++;
 }
 return {id,updated,conflicts};
};
