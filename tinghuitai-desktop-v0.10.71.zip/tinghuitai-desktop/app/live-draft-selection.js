'use strict';
const crypto=require('crypto');
const hash=value=>crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');
const prompt=`
Draft selection protocol (shared by native and web): return draftSelection and deliverable in the same JSON object.
draftSelection = {"choice":"new|hold|blocked|one supplied artifact choice","reason":"specific basis","triggerRefs":["one supplied recent ref"],"missingInputs":[]}.
Choose one supplied artifact choice to revise that exact draft. Choose new only for a different objective with no existing artifact; added alternatives or coverage for the same question revise its existing artifact. A new title is not a new objective. Never guess a target from a title. If its identity is unavailable, choose blocked. hold means no useful draft change and deliverable:null; blocked also requires deliverable:null and 1-4 indispensable missing inputs. hold may have no triggerRefs; other choices require 1-6 refs from draftContext.recent only. Background is reference, never a recent trigger.
For new or a supplied artifact choice, deliverable = {"title":"short draft title","goal":"concrete objective or bounded correction","form":"timeline|diagram|document|comparison","quote":"exact phrase from a cited recent row","requestedDocument":false}. A persistent roadmap with linked validation checklist may also use kind:"project-plan".
Do not output draftDecision, update, updateOnly, target, sourceId, moduleId or sourceIds in these draft fields. The host owns routing and identities. Every interpretation remains an unconfirmed AI draft; a routing choice is never approval. Preserve the original speaker and uncertainty. Distinguish a proposal, an inference and an explicitly accepted decision. A feasibility estimate must not become an exclusion policy. Do not claim consensus from a possible approach.
Before selecting a draft, apply draftContext.evidencePolicy to every claim in title and goal. A matching quote only identifies a source; it does not prove the whole goal. Consult the complete cited row, retain its speaker and modal qualifiers, and verify each alternative separately. Choose hold or a narrower grounded goal when evidence is insufficient.
Compare alternatives at the same architectural layer, already in deliverable.goal: tasks/workloads, execution locations, and input sensors are separate dimensions. VPS/cloud describe deployment; processors may exist in multiple deployments. Preserve relationships and unknown measurements rather than invent exclusive columns or agreed deadlines.
`;
function background(value){
 if(Array.isArray(value))return value.map(background);
 if(!value||typeof value!=='object')return value;
 return Object.fromEntries(Object.entries(value).filter(([k])=>!['id','sourceId','moduleId','contextId','target','sourceIds','sourceRefs','evidenceRefs'].includes(k)).map(([k,v])=>[k,background(v)]));
}
function create(sessionId,rows,pack){
 let data={};try{data=JSON.parse(pack?.text||'{}')||{};}catch{}
 rows=JSON.parse(JSON.stringify(rows));
 const artifacts=(Array.isArray(data.existingArtifacts)?data.existingArtifacts:[]).filter(a=>typeof a.sourceId==='string'&&typeof a.moduleId==='string');
 // Includes content and protection state, not merely a title or array position.
 const snapshot=hash([sessionId,rows,artifacts]);
 const recent=rows.map((r,i)=>({ref:'t:'+hash([snapshot,i,r]).slice(0,24),text:String(r.text||''),speaker:r.speaker||r.spk||r.who||''}));
 const entries=artifacts.map((a,i)=>({choice:'a:'+hash([snapshot,i,a.sourceId,a.moduleId,a.revision]).slice(0,24),artifact:a}));
 return {snapshot,rows,entries,input:{evidencePolicy:{...require('./live-draft-input').evidencePolicy},recent,artifacts:entries.map(({choice,artifact:a})=>({choice,title:a.title,form:a.form,revision:a.revision,scope:a.scope,manualEdits:a.manualEdits,status:a.status,body:a.body})),background:background(data)}};
}
function assess(parsed,binding,current=binding,rows=binding?.rows){
 const fail=code=>({state:'invalid',code,sourceIds:[],deliverable:null});
 if(!binding||binding.snapshot!==current?.snapshot||hash(rows)!==hash(binding.rows))return fail('stale_draft_snapshot');
 const d=parsed?.draftSelection;
 if(!d||typeof d!=='object'||Array.isArray(d))return fail('missing_draft_selection');
 if(Object.hasOwn(parsed,'draftDecision')||['state','update','target','sourceIds'].some(k=>Object.hasOwn(d,k))||parsed.deliverable&&['target','sourceId','moduleId','sourceIds','update','updateOnly'].some(k=>Object.hasOwn(parsed.deliverable,k)))return fail('conflicting_draft_protocol');
 const entry=binding.entries.find(e=>e.choice===d.choice);
 if(!entry&&!['new','hold','blocked'].includes(d.choice))return fail('unknown_draft_choice');
 if(!Array.isArray(d.triggerRefs)||d.triggerRefs.length>6)return fail('invalid_trigger_refs');
 const ids=[];
 for(const ref of d.triggerRefs){const i=binding.input.recent.findIndex(r=>r.ref===ref);if(i<0)return fail('invalid_trigger_refs');ids.push(binding.rows[i].id);}
 const state=d.choice==='new'?'create':entry?'existing':d.choice==='hold'?'none':'blocked';
 const target=entry?{sourceId:entry.artifact.sourceId,moduleId:entry.artifact.moduleId}:null;
 const deliverable=parsed.deliverable==null?null:{...parsed.deliverable,...(target?{target}:{} )};
 // Only host-created state/update/target enters the legacy internal validator.
 const result=require('./native-work-decision').assess({draftDecision:{state,update:!!entry,reason:d.reason,sourceIds:ids,missingInputs:d.missingInputs},deliverable},binding.rows);
 if(result.deliverable)result.deliverable={...result.deliverable,selectionBound:true,interpretationStatus:'unconfirmed',triggerEvidence:binding.rows.filter(r=>ids.includes(r.id)).map(r=>({id:r.id,speaker:r.speaker||r.spk||r.who||'',text:r.text}))};
 return {...result,snapshot:binding.snapshot};
}
module.exports={prompt,create,assess};
