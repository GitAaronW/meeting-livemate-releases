'use strict';
// Only classify provider responses, never local process errors or document text.
function classify(value){
 const parts=[];let httpStatus=null;
 function visit(v,depth=0){
  if(depth>5||v==null)return;
  if(typeof v==='string'){parts.push(v);try{visit(JSON.parse(v),depth+1);}catch{}return;}
  if(typeof v!=='object')return;
  for(const key of ['status','statusCode','code']){
   const n=Number(v[key]);if([401,403,404].includes(n))httpStatus=n;
   if(v[key]!=null)parts.push(String(v[key]));
  }
  for(const key of ['message','error','text','structuredContent','content'])visit(v[key],depth+1);
  if(Array.isArray(v))for(const item of v)visit(item,depth+1);
 }
 visit(value);const text=parts.join(' ').toLowerCase();
 if(httpStatus!==null)return {sourceReadStatus:'inaccessible',sourceReadHttpStatus:httpStatus};
 if(/econnreset|econnrefused|etimedout|socket\s*hang\s*up|network\s*error|timed?\s*out|timeout/.test(text))return {sourceReadStatus:'refresh_failed'};
 const denied=httpStatus!==null||/permission[ _-]denied|access[ _-]denied|forbidden|unauthori[sz]ed|not[ _-]found|无权限|没有权限|无权访问|未授权|不存在/.test(text);
 return {sourceReadStatus:denied?'inaccessible':'refresh_failed',...(httpStatus?{sourceReadHttpStatus:httpStatus}:{})};
}
module.exports={classify};
