'use strict';
// Compare source-backed meanings, never presentation labels. Both texts must
// cover enough of each other so a short, different action is not swallowed.
function repeated(a,b){
 if(!(a.sourceIds||[]).some(id=>(b.sourceIds||[]).includes(id)))return false;
 const pairs=text=>{const s=String(text||'').toLowerCase().replace(/[^\p{L}\p{N}]/gu,'');return new Set(Array.from({length:Math.max(0,s.length-1)},(_,i)=>s.slice(i,i+2)));};
 const x=pairs(a.text),y=pairs(b.text);if(!x.size||!y.size)return false;
 const common=[...x].filter(v=>y.has(v)).length;
 return common>=8&&common/Math.min(x.size,y.size)>=.35&&common/Math.max(x.size,y.size)>=.35;
}
function repeatsJudgment(text,sourceIds,judgments=[]){
 return judgments.some(x=>x.channel==='judgment'&&!x.stale&&!x.supersededBy&&repeated({text,sourceIds},{text:x.point,sourceIds:(x.sourceRefs||[]).map(r=>r.segId)}));
}
module.exports={repeated,repeatsJudgment};
