'use strict';
const {execFile}=require('child_process');
function normalize(data){return (Array.isArray(data)?data:data?.items||[]).filter(p=>p.type!=='resource').map(p=>({name:String(p.display_name||p.user_id||'').slice(0,80),open_id:String(p.user_id||'').slice(0,200),declined:p.rsvp_status==='decline'})).filter(p=>p.name).slice(0,100);}
async function read(event,run){
 if(!event?.eventId||!event.calendarId)return null;
 const args=['calendar','event.attendees','list','--as','user','--params',JSON.stringify({calendar_id:event.calendarId,event_id:event.eventId,page_size:100})];
 try{const raw=await (run||((args)=>new Promise(resolve=>execFile(process.env.THT_LARK_CLI||'lark-cli',args,{timeout:2500,maxBuffer:4e6,env:{...process.env,LARKSUITE_CLI_NO_UPDATE_NOTIFIER:'1',LARKSUITE_CLI_NO_SKILLS_NOTIFIER:'1'}},(error,out)=>resolve(error?'':String(out||''))))))(args);const first=String(raw).indexOf('{');if(first<0)return null;const result=JSON.parse(String(raw).slice(first));return result.ok?normalize(result.data):null;}catch{return null;}
}
module.exports={read,normalize};
