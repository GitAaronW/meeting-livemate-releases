'use strict';

// Provider timestamps describe a recognition stream, not the saved PCM file.
// Reconnect backfill, dropped packets and continued recordings need a separate
// byte-range mapping before these values can be used for automatic cropping.
function fromUtterance(utterance, streamId, continuationEpoch) {
  const start = utterance?.start_time, end = utterance?.end_time;
  if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start < 0 || end <= start) return null;
  if (typeof streamId !== 'string' || !streamId.trim()) return null;
  return {
    provider: 'volc', unit: 'ms', start, end, streamId,
    continuationEpoch: typeof continuationEpoch === 'string' ? continuationEpoch : '',
    audioAligned: false,
  };
}

module.exports = {fromUtterance};
