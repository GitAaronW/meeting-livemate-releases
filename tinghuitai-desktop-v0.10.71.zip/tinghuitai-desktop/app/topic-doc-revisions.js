'use strict';
// A local recovery journal, not a remote CAS. Only blocks created by this service
// may be revised. An unresolved write blocks all subsequent writes to its target.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const durable = require('./durable-json');
function create(dataDir) {
  const file = target => {
    if (!/^[a-f0-9]{64}$/.test(target)) throw Error('主题目标编号无效');
    return path.join(dataDir, 'state', 'topic-revisions', target + '.json');
  };
  const read = target => {
    try { return JSON.parse(fs.readFileSync(file(target), 'utf8')); }
    catch (e) { if (e.code === 'ENOENT') return { blocks: {}, journal: null }; throw e; }
  };
  const save = (target, state) => { const f = file(target); fs.mkdirSync(path.dirname(f), { recursive: true }); durable.write(f, state); };
  function remember(target, id, item, record, rendered = item.text) {
    if (!id) return;
    const s = read(target);
    const version = { id: crypto.randomUUID(), text: item.text, rendered, remoteId: item.remoteId || id, section: item.section,
      sources: item.sources || [{ meetingId: record.meetingId, date: record.date, evidence: item.evidence }], at: Date.now() };
    const old = s.blocks[id];
    s.blocks[id] = { id, current: version, versions: [...(old?.versions || []), version] };
    if (s.journal) s.recoveries = [...(s.recoveries || []), { ...s.journal, status: 'verified', resolvedAt: Date.now() }];
    s.journal = null;
    save(target, s);
  }
  function begin(target, journal) {
    const s = read(target);
    if (s.journal) { const e = Error('上一次段落修订待核对，请先核对目标文档和恢复记录'); e.code = 409; throw e; }
    s.journal = { ...journal, status: 'pending', at: Date.now() }; save(target, s);
  }
  function settle(target, status, observed, extra = {}) {
    const s = read(target);
    if (!s.journal) return;
    if (status === 'rejected') { s.recoveries = [...(s.recoveries || []), { ...s.journal, status, resolvedAt: Date.now() }]; s.journal = null; }
    else s.journal = { ...s.journal, ...extra, status, ...(observed ? { observed } : {}) };
    save(target, s);
  }
  return { read, remember, begin, settle };
}
module.exports = { create };
