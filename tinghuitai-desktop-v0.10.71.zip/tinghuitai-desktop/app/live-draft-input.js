'use strict';
// Host originals and detector interpretations travel separately. This is input
// provenance, not an entailment check or a second evidence store.
function original(row,id=row.id){
 return {id,speaker:row.speaker||row.spk||row.who||'',text:String(row.text||'')};
}
const evidencePolicy={
 status:'unconfirmed',
 attribution:'Each statement belongs to its original speaker. Alternatives from different speakers are separate proposals unless an explicit acceptance connects them.',
 modality:'Read the complete original row, including qualifiers outside a quoted substring. Preserve possibility, estimates, reservations and conditions; none is a confirmed conclusion.',
 coverage:'Check every proposed claim and alternative against supplied originals. An unconfirmed workIntent is not evidence. Omit unsupported alternatives, or label them explicitly as new AI suggestions, never meeting statements. If the objective cannot be grounded, hold instead of generating it as a meeting result.'
};
function workIntent(text){return {text,status:'unconfirmed-ai-interpretation',isEvidence:false};}
function build(text,rows,sourceIds,{prefix=''}={}){
 const ids=new Set(sourceIds||[]);
 return {evidencePolicy:{...evidencePolicy},workIntent:workIntent(text),triggerEvidence:rows.filter(r=>ids.has(r.id)).map(r=>original(r,prefix+r.id)),surroundingEvidence:rows.slice(-6).filter(r=>!ids.has(r.id)).map(r=>original(r,prefix+r.id))};
}
module.exports={original,workIntent,build,evidencePolicy};
