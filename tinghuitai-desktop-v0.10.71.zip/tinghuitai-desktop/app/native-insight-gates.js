'use strict';
// Proactive detection only. Recording and explicit user jobs never enter here.
const {create:createRouter}=require('./proactive-gate-router');
function create({env=()=>({}),dataDir,sessionId,fetchImpl=globalThis.fetch,log=()=>{},askImpl,now}){
 const stats={inputCalls:0,inputHits:0,publicationCalls:0,published:0,suppressed:0,lastError:''};
 const router=createRouter({env,dataDir,sessionId,fetchImpl,log,askImpl,now});
 return {
  snapshot(){return {enabled:true,...stats,...router.snapshot()};},
  pending(){return router.pending();},
  acknowledge(ids){router.acknowledge(ids);},
  async input(rows,context){
   if(!rows.length)return false;
   stats.inputCalls++;
   const result=await router.input(rows,context);
   stats.lastError=result.error||'';if(result.hit)stats.inputHits++;
   return !!result.hit&&!result.error;
  },
  async publication(parsed,context){
   const paths=[];
   const add=(key,value,index)=>{if(value&&typeof value==='object')paths.push({key,index,value});};
   add('suggestion',parsed.suggestion);
   (Array.isArray(parsed.insights)?parsed.insights:[]).slice(0,2).forEach((x,i)=>add('insights',x,i));
   for(const key of ['currentJudgment','confirmation','deliverable'])add(key,parsed[key]);
   // Retrieval requests are not presented as verified facts; their existing
   // grounded retrieval pipeline still owns citation and result validation.
   if(!paths.length)return parsed;
   stats.publicationCalls++;
   const result=await router.publication(paths.map(p=>({kind:p.key,...p.value})),context);
   stats.lastError=result.error||'';
   const clean={...parsed,insights:[]};
   paths.forEach((p,i)=>{const pass=result.decisions[i]?.pass===true;
    if(pass)stats.published++;else stats.suppressed++;
    if(p.key==='insights'){if(pass)clean.insights.push(p.value);}
    else clean[p.key]=pass?p.value:null;
   });
   return clean;
  }
 };
}
module.exports={create};
