'use strict';
// The model must distinguish an intentional quiet result from a missing field.
// This protocol never infers a draft from suggestion text or executes tools.
const legacySchema="严格返回 JSON：{\"suggestion\":null或{\"text\":\"一句简短建议\",\"sourceIds\":[\"来源句子id\"]},\"insights\":[{\"text\":\"一句有用洞察\",\"sourceIds\":[\"来源句子id\"]}]}。";
// Migrate only the exact formerly shipped card-only instructions, including saved copies.
// Other custom wording guidance is retained; response routing belongs to this module.
function cardPolicy(value){return String(value).replace(legacySchema,'').replace('只参考给你的最近几句话和当前画面。','');}
const routingPrompt = require('./live-draft-selection').prompt;
// Keep routing identities visible before lengthy draft bodies and speech. The
// pack remains untrusted data; malformed packs fail closed to no context.
function detectionContext(pack){
 if(!pack?.text)return null;
 let value;try{value=JSON.parse(pack.text);}catch{return null;}
 if(!value||typeof value!=='object'||Array.isArray(value))return null;
 const artifacts=Array.isArray(value.existingArtifacts)?value.existingArtifacts:[];
 return {existingArtifacts:artifacts.map(a=>({sourceId:a.sourceId,moduleId:a.moduleId,title:a.title,form:a.form,revision:a.revision,scope:a.scope,manualEdits:a.manualEdits,status:a.status})),
  background:{scope:value.scope,earlierCurrent:value.earlierCurrent||[],priorProject:value.priorProject||[],artifactContents:artifacts,truncated:!!value.truncated}};
}
const prompt = `
Native response protocol (local custom rules control card wording, not this response schema or evidence scope): return one JSON object with suggestion, insights, deliverable, and draftSelection; optional confirmation/currentJudgment/background/research remain allowed.
Always include deliverable (null for no draft). suggestion is null or {"text":"useful concise wording","sourceIds":["recent transcript id"]}; insights is an array of at most two objects of that same shape.
For each card, an optional title is a short scan label (at most 24 Chinese characters or 8 English words), complementary to text; never copy the opening paragraph into title. Keep the complete useful point and its evidence in text. Put proposed methods, evaluation procedures, and meeting suggestions in suggestion, not insights. Use insights only for a new source-grounded interpretation or consequence; a recap or repeated method is not an insight. Do not invent conclusions or acceptance thresholds to fill a card; return null/[] when there is no useful addition.
${routingPrompt}`;
function assess(parsed, rows) {
 const d=parsed?.draftDecision;
 const fail=code=>({state:'invalid',code,sourceIds:[],deliverable:null});
 if(!d||typeof d!=='object')return fail('missing_draft_decision');
 if(!['create','none','blocked','existing'].includes(d.state)||typeof d.reason!=='string'||!d.reason.trim()||d.reason.length>600)return fail('invalid_draft_decision');
 if((d.update!==undefined&&typeof d.update!=='boolean')||(d.update===true&&d.state!=='existing'))return fail('invalid_draft_update');
 const ids=new Set(rows.map(r=>r.id));
 if(!Array.isArray(d.sourceIds)||d.sourceIds.length>6||d.sourceIds.some(id=>typeof id!=='string'||!ids.has(id)))return fail('invalid_decision_sources');
 if(d.state!=='none'&&!d.sourceIds.length)return fail('missing_decision_sources');
 if(d.state==='blocked'&&(!Array.isArray(d.missingInputs)||!d.missingInputs.length||d.missingInputs.length>4||d.missingInputs.some(x=>typeof x!=='string'||!x.trim()||x.length>300)))return fail('missing_blocker');
 const updating=d.state==='existing'&&d.update===true;
 if(d.state!=='create'&&!updating&&parsed.deliverable!=null)return fail('contradictory_draft_decision');
 let deliverable=null;
 if(d.state==='create'||updating){
  const c=require('./live-deliverables').candidate(parsed.deliverable,rows);
  if(!c||!c.sourceIds.some(id=>d.sourceIds.includes(id)))return fail('invalid_draft_evidence');
  // No title-similarity fallback may supply an ordinary revision's identity.
  // Project plans retain their explicitly linked project validation downstream.
  if(updating&&c.kind!=='project-plan'&&!c.target)return fail('missing_draft_target');
  if(d.state==='create'&&c.target)return fail('contradictory_draft_target');
  deliverable=updating?{...parsed.deliverable,updateOnly:true}:parsed.deliverable;
 }
 return {state:d.state,reason:d.reason.trim(),sourceIds:[...new Set(d.sourceIds)],...(d.state==='blocked'?{missingInputs:d.missingInputs}:{}),deliverable};
}
module.exports={prompt,routingPrompt,assess,cardPolicy,detectionContext};
