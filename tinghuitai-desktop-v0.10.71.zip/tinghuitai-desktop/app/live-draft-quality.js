"use strict";
// Bounded checks for observable table defects, not a technical taxonomy or
// a substitute for semantic review. Never rewrite the user's prose here.
function tables(body){
 const result=[];let block=[];let fenced=false;
 const flush=()=>{if(block.length>=3&&block[1].every(x=>/^:?-{3,}:?$/.test(x))){result.push({headers:block[0],rows:block.slice(2)});}block=[];};
 for(const line of String(body||'').split(/\r?\n/)){
  if(/^\s*(```|~~~)/.test(line)){flush();fenced=!fenced;continue;}
  if(fenced||!/^\s*\|.*\|\s*$/.test(line)){flush();continue;}
  block.push(line.trim().slice(1,-1).split(/(?<!\\)\|/).map(x=>x.trim().replace(/[*_`]/g,'')));
 }flush();return result;
}
function inspect(body,{form='comparison'}={}){
 const issues=[];
 for(const table of tables(body)){
  for(let i=0;i<table.headers.length;i++){
   if(!/^(?:输入(?:图像|数据|图片)?尺寸|input (?:data |image )?(?:size|dimensions))$/i.test(table.headers[i]))continue;
   if(table.rows.some(row=>/(?:运行|内存|memory|runtime|RAM)/i.test(row[i]||'')&&/\b\d+(?:\.\d+)?\s*(?:[KMG]i?B|兆|吉)/i.test(row[i]||''))){issues.push('input_dimension_contains_runtime_memory');}
  }
  // A matrix of repeated placeholders provides no comparison. This does not
  // reject unknown measurements next to concrete conditions or evidence.
  const candidateColumns=table.headers.map((_,i)=>i).filter(i=>i>0&&table.rows.length>=2&&table.rows.every(row=>/^(?:候选|candidate|待定|待测|unknown|unmeasured|tbd|[-—])$/i.test(row[i]||'')));
  const explicitCandidateColumns=candidateColumns.filter(i=>table.rows.some(row=>/^(?:候选|candidate)$/i.test(row[i]||'')));
  if(form==='comparison'&&candidateColumns.length>=2&&((candidateColumns.length===table.headers.length-1&&explicitCandidateColumns.length>=1)||explicitCandidateColumns.length>=2))issues.push('comparison_only_placeholders');
 }
 return [...new Set(issues)];
}
function assertQuality(body,en=false,form='document'){const issues=inspect(body,{form});if(issues.length){const error=Error(en?'Draft has an input-dimension mismatch or an empty comparison; original retained.':'草稿存在输入尺寸混类或空比较表，未写入；原稿已保留。');error.code='DRAFT_QUALITY_REJECTED';error.qualityIssues=issues;throw error;}}
module.exports={tables,inspect,assertQuality};
