'use strict';
// Optional enrichments must never discard the core triage result.
function run(session,result,rows,{deliverables,signals,confirmation,binding,currentBinding,log=()=>{}}){
 const safe=(label,fn)=>{try{fn();}catch(e){log('triage '+label+' failed: '+e.message);}};
 safe('draft decision',()=>{
  const decision=require('./live-draft-selection').assess(result,binding,currentBinding?currentBinding():binding,rows);
  const {deliverable,...record}=decision;session.webDraftDecision={...record,at:Date.now()};
  if(decision.state==='invalid')log('triage draft decision invalid: '+decision.code);
  if(deliverable)deliverables(session,deliverable,rows);
 });
 safe('signals',()=>signals(session,result,rows));
 for(const event of (Array.isArray(result)?result:[result,...(Array.isArray(result.insights)?result.insights:[])]))safe('confirmation',()=>confirmation(session,event?.confirmation,rows));
}
module.exports={run};
