'use strict';
const registry=require('./thinking-methods.json');
const text=(value,max)=>typeof value==='string'?value.trim().slice(0,max):'';
// Validates the trace, not semantic usefulness. Review real outputs against the
// proposition, history and evidence before claiming the method improved it.
function trace(raw,rows){
 if(!raw||raw.tool!=='six-hats')return null;
 const tool=registry[raw.tool],angle=Object.hasOwn(tool.angles,raw.angle)?tool.angles[raw.angle]:null;
 const object=text(raw.object,160),contribution=text(raw.contribution,500),quote=text(raw.quote,500);
 if(!angle||object.length<2||contribution.length<8||quote.length<4||!Array.isArray(raw.sourceIds))return null;
 const refs=rows.filter(r=>raw.sourceIds.includes(r.id)&&!r.stale&&String(r.text||'').includes(quote));
 if(!refs.length)return null;
 if(raw.angle==='red'&&!['expressed','hypothesis'].includes(raw.basis))return null;
 return {tool:raw.tool,angle:raw.angle,object,contribution,quote,sourceIds:refs.map(r=>r.id),...(raw.angle==='red'?{basis:raw.basis}:{}),label:tool.name+' · '+angle.label,labelEn:tool.nameEn+' · '+angle.labelEn};
}
const prompt=' Optional thinking tools: '+JSON.stringify(registry)+'. First identify the actual thinking object and the current decisionThread, its history and new evidence. Choose a useful angle only if it contributes to the judgement or a concrete next action. Never force all six hats, six stages or extra agents. Ordinary tasks need no method; no useful increment means silence. Other suitable thinking methods remain allowed without a six-hats label. Method is separate from event type and thinking object. Only when Six Thinking Hats actually contributes, add currentJudgment.thinkingMethod:{tool:"six-hats",angle:"white|red|black|yellow|green|blue",object:"actual proposition",contribution:"what this angle specifically changes in the emitted point/openGap; not a label or generic description",quote:"exact supplied transcript wording supporting the constraint or feeling",sourceIds:["id"],basis:"red only: expressed or hypothesis"}. Put the useful conclusion in point itself. Do not emit a new judgement merely to add a method marker. Red hypotheses must be explicitly hypothetical in point/contribution, never observed feelings; expressed red requires the quoted person to have expressed that feeling. Labels do not establish correctness, research completion or user agreement.';
// Document organization shares the optional tool contract, with its own output target.
const documentPrompt=prompt.replaceAll('currentJudgment.thinkingMethod','sections[].thinkingMethod').replaceAll('point/openGap','section prose').replaceAll('point itself','section prose itself')+' For document sections, contribution must be an exact excerpt from the emitted blocks showing the useful addition; sourceIds use meetingId:segId and must match this section evidence. Omit the trace when no method actually contributed. A saved trace is model-reported provenance, not independent validation.';
module.exports={registry,trace,prompt,documentPrompt};
