#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${1:-$ROOT/app/native-capture/TinghuitaiCapture.app/Contents/MacOS/ArtifactPreview}"
SDK="${THT_SWIFT_SDK:-$(xcrun --show-sdk-path)}"
if [ -d /Library/Developer/CommandLineTools/SDKs/MacOSX15.5.sdk ]; then SDK="${THT_SWIFT_SDK:-/Library/Developer/CommandLineTools/SDKs/MacOSX15.5.sdk}"; fi
TMP="$(mktemp -d /tmp/lm-preview-build.XXXXXX)"
trap 'rm -rf "$TMP"' EXIT
for ARCH in arm64 x86_64; do
 swiftc -O -sdk "$SDK" -target "$ARCH-apple-macos13.0" -framework AppKit -framework WebKit -framework PDFKit "$ROOT/app/native-capture/ArtifactPreview.swift" -o "$TMP/$ARCH"
done
mkdir -p "$(dirname "$OUT")"
lipo -create "$TMP/arm64" "$TMP/x86_64" -output "$OUT"
codesign --force --sign - --identifier com.aaron.tinghuitai.artifact-preview "$OUT"
