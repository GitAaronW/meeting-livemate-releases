'use strict';
const fs=require('fs'),path=require('path'),{execFileSync}=require('child_process');

function real(file){try{return fs.realpathSync(file);}catch{return path.resolve(file||'');}}
function read(command,args){return execFileSync(command,args,{encoding:'utf8'}).trim();}

function ownsServer(pid,{serverPath,rootDir,nodePaths=[],trustedNodeFiles=[],run=read,realpath=real,hash=file=>require('crypto').createHash('sha256').update(fs.readFileSync(file)).digest('hex')}={}){
  if(!Number.isInteger(pid)||pid<=1)return false;
  try{
    const command=run('/bin/ps',['-ww','-p',String(pid),'-o','command=']);
    const cwdLines=run('/usr/sbin/lsof',['-a','-p',String(pid),'-d','cwd','-Fn']).split('\n');
    const textLines=run('/usr/sbin/lsof',['-a','-p',String(pid),'-d','txt','-Fn']).split('\n');
    const cwd=cwdLines.find(x=>x.startsWith('n'))?.slice(1)||'';
    const executable=textLines.find(x=>x.startsWith('n'))?.slice(1)||'';
    const allowedNodes=new Set(nodePaths.filter(Boolean).map(realpath));
    if(!allowedNodes.has(realpath(executable))){
      // Recover a lost cached runtime only from an identical bundled binary,
      // with the exact installation working directory and server command.
      if(realpath(cwd)!==realpath(rootDir)||!command.endsWith(' '+serverPath))return false;
      const digest=hash(executable);
      if(!trustedNodeFiles.some(file=>{try{return hash(file)===digest;}catch{return false;}}))return false;
    }
    const absolute=' '+serverPath;
    if(command.endsWith(absolute))return true;
    return command.endsWith(' app/server.js')&&realpath(cwd)===realpath(rootDir);
  }catch{return false;}
}

module.exports={ownsServer};
