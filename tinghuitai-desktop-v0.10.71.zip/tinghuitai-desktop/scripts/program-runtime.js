'use strict';
// Source-only bootstrap for a bridge package. No application module may load
// before this check, because compiled modules require the exact Node/V8 pair.
const fs=require('node:fs'),path=require('node:path'),{execFileSync}=require('node:child_process');
const fields=['node','v8','platform','arch'];
const current=()=>({node:process.version,v8:process.versions.v8,platform:process.platform,arch:process.arch});
function expectedRuntime(root,actual=current()){
 const compiled=path.join(root,'compiled-modules.json'),policy=path.join(root,'runtime-policy.json');
 const file=fs.existsSync(compiled)?compiled:fs.existsSync(policy)?policy:null;if(!file)return null;
 const m=JSON.parse(fs.readFileSync(file,'utf8'));
 const expected=m.schema===2?m.runtimes?.[actual.arch]:m.schema===1?m.runtime:null;
 if(!expected||!fields.every(k=>typeof expected[k]==='string')||expected.arch!==actual.arch||expected.platform!==actual.platform)throw Error('Invalid program runtime policy');
 return expected;
}
function selectRuntime(root,{actual=current(),force=false,probe=binary=>JSON.parse(execFileSync(binary,['-e','console.log(JSON.stringify({node:process.version,v8:process.versions.v8,platform:process.platform,arch:process.arch}))'],{encoding:'utf8',timeout:60000}))}={}){
 const expected=expectedRuntime(root,actual);if(!expected||(!force&&fields.every(k=>expected[k]===actual[k])))return null;
 // Only binaries shipped as part of this verified program package. Do not use
 // arbitrary PATH or settings paths to satisfy an executable policy.
 const runtime=path.join(root,'runtime');
 if(fs.existsSync(runtime)&&!fs.lstatSync(runtime).isSymbolicLink()){
  for(const name of fs.readdirSync(runtime).sort()){
   if(!/^node-.+-darwin-(arm64|x64)$/.test(name)||!name.endsWith('-'+actual.arch))continue;
   const base=path.join(runtime,name),bin=path.join(base,'bin'),binary=path.join(bin,'node');
   if([base,bin,binary].some(p=>!fs.existsSync(p)||fs.lstatSync(p).isSymbolicLink()))continue;
   if(!fs.statSync(binary).isFile())continue;
   try{const found=probe(binary);if(fields.every(k=>found[k]===expected[k]))return binary;}catch{}
  }
 }
 throw Error('Matching packaged Node runtime missing; program was not started');
}
function handoffRuntime(entry,{root=path.resolve(path.dirname(entry),'..'),dataDir=process.env.THT_DATA_DIR||path.join(require('node:os').homedir(),'Library/Application Support/Tinghuitai')}={}){
 const binary=selectRuntime(root);if(!binary)return false;
 // A source bridge may be invoked by the old in-app updater. The child starts
 // the same entry under the selected runtime and must succeed before pinning.
 execFileSync(binary,[entry,...process.argv.slice(2)],{env:process.env,stdio:'inherit'});
 fs.mkdirSync(dataDir,{recursive:true});const file=path.join(dataDir,'node-path'),tmp=file+'.bridge-'+process.pid;
 try{fs.writeFileSync(tmp,binary+'\n',{mode:0o600,flag:'wx'});fs.renameSync(tmp,file);}finally{fs.rmSync(tmp,{force:true});}
 return true;
}
module.exports={expectedRuntime,selectRuntime,handoffRuntime};
