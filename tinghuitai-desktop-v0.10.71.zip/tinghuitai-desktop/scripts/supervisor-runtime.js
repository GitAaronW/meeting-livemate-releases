'use strict';
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),{execFileSync}=require('node:child_process');
const {selectRuntime}=require('./program-runtime'),{ownsServer}=require('./process-owner');
const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
// Only a verified bridge can migrate an exact, idle service for this data dir.
// This deliberately does not repair unknown or unavailable launchd services.
async function migrateSupervisorRuntime({root,dataDir,label,health,home=os.homedir(),uid=process.getuid(),
 run=execFileSync,select=()=>selectRuntime(root,{force:true}),owns=ownsServer,sleep=pause,
 dataId=require('../app/server-state').dataDirectoryId(dataDir)}){
 const binary=select();if(!binary||!label)return false;
 if(!/^[\w.-]+$/.test(label))throw Error('Invalid supervisor label');
 const file=path.join(home,'Library/LaunchAgents',label+'.plist'),serverPath=path.join(root,'app/server.js');
 if(!fs.existsSync(file)||fs.lstatSync(file).isSymbolicLink())throw Error('Runtime migration requires the original local service file');
 const original=fs.readFileSync(file);
 const spec=JSON.parse(run('/usr/bin/plutil',['-convert','json','-o','-',file],{encoding:'utf8'}));
 const args=spec.ProgramArguments;
 if(spec.Label!==label||spec.WorkingDirectory!==root||spec.EnvironmentVariables?.THT_DATA_DIR!==dataDir||
   !Array.isArray(args)||args.length!==2||typeof args[0]!=='string'||args[1]!==serverPath||spec.Program)
   throw Error('Runtime migration refused a different service');
 const initial=await health();
 if(args[0]===binary){
  if(!initial||initial.dataDirectoryId!==dataId||!owns(initial.pid,{serverPath,rootDir:root,nodePaths:[binary]}))
   throw Error('Configured runtime does not match the running service');
  return false;
 }
 const idle=h=>h&&h.dataDirectoryId===dataId&&h.activeSessions===0&&h.uiRefresh?.idle===true&&Number.isInteger(h.pid)&&h.pid>1;
 if(!idle(initial)||!owns(initial.pid,{serverPath,rootDir:root,nodePaths:[args[0]]}))
   throw Error('Runtime migration requires this installation to be idle');
 const next={...spec,ProgramArguments:[binary,serverPath]};let replacement;
 const tmp=file+'.runtime-'+process.pid,domain='gui/'+uid,target=domain+'/'+label;
 let unloaded=false,changed=false;
 try{
  fs.writeFileSync(tmp,JSON.stringify(next),{mode:0o600,flag:'wx'});
  run('/usr/bin/plutil',['-convert','xml1',tmp],{stdio:'ignore'});
  replacement=fs.readFileSync(tmp);
  run('/usr/bin/plutil',['-lint',tmp],{stdio:'ignore'});
  const latest=await health();
  if(!idle(latest)||latest.pid!==initial.pid||!fs.readFileSync(file).equals(original)||
    !owns(latest.pid,{serverPath,rootDir:root,nodePaths:[args[0]]}))throw Error('Service changed before runtime migration');
  run('/bin/launchctl',['bootout',target],{stdio:'ignore'});unloaded=true;
  if(!fs.readFileSync(file).equals(original))throw Error('Service file changed during runtime migration');
  fs.renameSync(tmp,file);changed=true;
  run('/bin/launchctl',['bootstrap',domain,file],{stdio:'ignore'});
  const version=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8')).version;
  for(let i=0;i<60;i++){
   const h=await health();
   if(h&&h.pid!==initial.pid&&h.dataDirectoryId===dataId&&h.version===version&&
      owns(h.pid,{serverPath,rootDir:root,nodePaths:[binary]}))return true;
   await sleep(200);
  }
  throw Error('Migrated service did not start with the packaged runtime');
 }catch(error){
  if(unloaded){
   try{
    if(changed){
     if(!fs.readFileSync(file).equals(replacement))throw Error('Service file changed; rollback did not overwrite it');
     try{run('/bin/launchctl',['bootout',target],{stdio:'ignore'});}catch{}
     fs.writeFileSync(tmp,original,{mode:0o600,flag:'wx'});fs.renameSync(tmp,file);
    }else if(!fs.readFileSync(file).equals(original))throw Error('Service file changed; rollback did not restart it');
    run('/bin/launchctl',['bootstrap',domain,file],{stdio:'ignore'});
   }catch(rollback){throw Error(error.message+'; runtime rollback failed: '+rollback.message);}
  }
  throw error;
 }finally{fs.rmSync(tmp,{force:true});}
}
module.exports={migrateSupervisorRuntime};
