import AppKit
import ScreenCaptureKit
import Speech
import AVFoundation
import CoreMedia
import CoreImage

// Local capture, local recognition, two views of the existing meeting Session.
// No raw audio leaves this process except the local PCM recording on disk.
struct PageGate {
    var anchor: [UInt8]?; var candidate: [UInt8]?; var stable = 0
    var lastSent: Double = -100
    static func distance(_ a: [UInt8], _ b: [UInt8]) -> Double {
        guard a.count == b.count, !a.isEmpty else { return 1 }
        let changed = zip(a,b).filter { abs(Int($0.0)-Int($0.1)) > 22 }.count
        return Double(changed)/Double(a.count)
    }
    mutating func accepts(_ sample: [UInt8], now: Double) -> Bool {
        if let a = anchor, Self.distance(a,sample) < 0.14 { candidate=nil; stable=0; return false }
        if let c=candidate, Self.distance(c,sample) < 0.055 { stable += 1 }
        else { candidate=sample; stable=1 }
        guard stable >= 3, now-lastSent >= 4 else { return false }
        anchor=sample; candidate=nil; stable=0; lastSent=now; return true
    }
}
struct MeetingTarget {
    let window: SCWindow
    var json: [String:Any] { ["windowId":Int(window.windowID), "bundleId":window.owningApplication?.bundleIdentifier ?? "", "title":window.title ?? "会议"] }
}
func recognizedMeeting(bundle: String, title: String) -> Bool {
    let b=bundle.lowercased(), t=title.lowercased()
    if b.contains("lark") || b.contains("feishu") { return ["会议","meeting","视频通话","video call"].contains { t.contains($0) } }
    let browser=["chrome","safari","edgemac","arc","firefox"].contains { b.contains($0) }
    return browser && (t.contains("google meet") || t.hasPrefix("meet -") || t.hasPrefix("meet –") || t.contains("meet.google.com"))
}
enum CaptureError: LocalizedError {
    // A pinned browser window must still show the same meeting tab.
    case message(String)
    var errorDescription: String? { if case .message(let s)=self { return s }; return nil }
}
final class LocalAPI {
    let base: URL
    init(_ server: String) {
        guard let u=URL(string:server),u.scheme=="http",u.host=="127.0.0.1",u.port != nil else { fatalError("Invalid local server") }
        base=u
    }
    func request(_ route: String, _ body: [String:Any]?=nil) async throws -> [String:Any] {
        var req=URLRequest(url:base.appendingPathComponent("native/"+route));req.timeoutInterval=7
        if let body=body { req.httpMethod="POST";req.setValue("application/json",forHTTPHeaderField:"Content-Type");req.httpBody=try JSONSerialization.data(withJSONObject:body) }
        let (data,response)=try await URLSession.shared.data(for:req)
        let j=(try? JSONSerialization.jsonObject(with:data)) as? [String:Any] ?? [:]
        guard (response as? HTTPURLResponse)?.statusCode == 200 else { throw CaptureError.message(j["error"] as? String ?? "本机连接失败") }
        return j
    }
}
// Recognizer partials can revise earlier words. Timestamp boundaries ensure
// a correction to old text does not suppress the following new sentence.
struct SpeechPiece { let start:Double;let end:Double;let range:NSRange }
struct SpeechDelta {
    var through:Double = -1
    mutating func take(_ text:String,pieces:[SpeechPiece],limit:Int?=nil) -> String? {
        let source=text as NSString;let end=min(limit ?? source.length,source.length)
        let fresh=pieces.filter { $0.start >= through-0.05 && $0.end > through+0.02 && NSMaxRange($0.range)<=end }
        guard let first=fresh.first,let last=fresh.last,first.range.location<end else { return nil }
        let value=source.substring(with:NSRange(location:first.range.location,length:end-first.range.location)).trimmingCharacters(in:.whitespacesAndNewlines)
        guard !value.isEmpty else { return nil };through=last.end;return value
    }
}
final class SpeechStream {
    let queue: DispatchQueue; let recognizer: SFSpeechRecognizer
    let emit: (String,String)->Void; let failure:(String)->Void
    var request: SFSpeechAudioBufferRecognitionRequest?; var task:SFSpeechRecognitionTask?
    var epoch=0;var delta=SpeechDelta();var latest="";var pieces:[SpeechPiece]=[];var lastUpdate=Date.distantPast
    var rotate: DispatchSourceTimer?;var silence:DispatchSourceTimer?;var running=false;var errors=0
    init(locale:String, queue:DispatchQueue, emit:@escaping(String,String)->Void, failure:@escaping(String)->Void) throws {
        guard let r=SFSpeechRecognizer(locale:Locale(identifier:locale)),r.supportsOnDeviceRecognition else { throw CaptureError.message("这门语言的本机转写不可用；请在 macOS 下载语音识别语言后重试") }
        self.queue=queue;self.recognizer=r;self.emit=emit;self.failure=failure
    }
    func start() {
        guard !running else { return };running=true;errors=0;open()
        let r=DispatchSource.makeTimerSource(queue:queue);r.schedule(deadline:.now()+20,repeating:20);r.setEventHandler { [weak self] in self?.rotateRequest() };r.resume();rotate=r
        let s=DispatchSource.makeTimerSource(queue:queue);s.schedule(deadline:.now()+1,repeating:0.5);s.setEventHandler { [weak self] in
            guard let self=self,self.running,Date().timeIntervalSince(self.lastUpdate)>1.1 else { return };self.commit(self.latest)
        };s.resume();silence=s
    }
    func open() {
        epoch += 1;let token=epoch;delta=SpeechDelta();latest="";pieces=[]
        let r=SFSpeechAudioBufferRecognitionRequest();r.requiresOnDeviceRecognition=true;r.shouldReportPartialResults=true;r.taskHint = .dictation
        request=r
        task=recognizer.recognitionTask(with:r) { [weak self] result,error in
            guard let self=self else { return };self.queue.async {
                guard self.running,self.epoch==token else { return }
                if let result=result {
                    self.errors=0
                    let transcription=result.bestTranscription;let text=transcription.formattedString
                    self.pieces=transcription.segments.map { SpeechPiece(start:$0.timestamp,end:$0.timestamp+$0.duration,range:$0.substringRange) }
                    if text != self.latest { self.lastUpdate=Date();self.latest=text }
                    if result.isFinal { self.commit(text);self.rotateRequest();return }
                    if let end=text.range(of:"[。！？.!?]",options:[.regularExpression,.backwards]) {
                        self.commit(String(text[..<end.upperBound]))
                    }
                }
                if let error=error, (error as NSError).code != 216 {
                    self.failure("本机转写暂时中断："+error.localizedDescription)
                    self.errors += 1
                    if self.errors >= 3 { self.stop() }
                }
            }
        }
    }
    func commit(_ text:String) {
        if let tail=delta.take(latest,pieces:pieces,limit:text.utf16.count) { emit(UUID().uuidString,tail) }
    }
    func rotateRequest() { guard running else { return };commit(latest);request?.endAudio();task?.cancel();open() }
    func append(_ buffer:CMSampleBuffer) { if running { request?.appendAudioSampleBuffer(buffer) } }
    func append(_ buffer:AVAudioPCMBuffer) { if running { request?.append(buffer) } }
    func stop() { commit(latest);running=false;rotate?.cancel();silence?.cancel();request?.endAudio();task?.cancel();request=nil;task=nil;epoch += 1 }
}
// Both sources share the host clock. Never concatenate microphone buffers onto
// system buffers: doing so doubles time and loses overlapping speech.
struct TimelineMixer {
    let origin:Double
    var through=0
    var blocks:[Int:[Float]]=[:]
    mutating func add(_ values:[Float],at:Double) {
        let start=Int(((at-origin)*16000).rounded())
        guard start < through*320+16000*30 else { return }
        for (i,value) in values.enumerated() {
            let sample=start+i;guard sample>=through*320 else { continue }
            let block=sample/320,offset=sample%320
            if blocks[block]==nil { blocks[block]=[Float](repeating:0,count:320) }
            blocks[block]![offset] += value.isFinite ? value:0
        }
    }
    mutating func drain(to time:Double,final:Bool=false)->[[Float]] {
        let target=final ? (blocks.keys.max().map{$0+1} ?? through):max(through,Int((time-origin)*50)-10)
        guard target>through else { return [] }
        var result:[[Float]]=[]
        while through<target { result.append((blocks.removeValue(forKey:through) ?? [Float](repeating:0,count:320)).map{max(-1,min(1,$0))});through += 1 }
        return result
    }
}
final class CaptureEngine: NSObject, SCStreamOutput, SCStreamDelegate {
    let queue=DispatchQueue(label:"com.aaron.tinghuitai.capture")
    let ci=CIContext(options:[.cacheIntermediates:false])
    let text:(String,String)->Void;let frame:(Data)->Void;let failure:(String)->Void
    var screen:SCStream?;var audio:SCStream?;var speech:SpeechStream?;var file:FileHandle?
    var microphone:AVAudioEngine?;var mixTimer:DispatchSourceTimer?;var mixer=TimelineMixer(origin:ProcessInfo.processInfo.systemUptime)
    let mixedFormat=AVAudioFormat(commonFormat:.pcmFormatFloat32,sampleRate:16000,channels:1,interleaved:false)!
    let meterLock=NSLock()
    func meterSnapshot()->Double { meterLock.lock();defer{meterLock.unlock()};return Date().timeIntervalSince(audioLevelAt)<1 ? audioLevel:0 }
    var gate=PageGate();var seconds:Double=0;var audioLevel:Double=0;var audioLevelAt=Date.distantPast;var paused=false;var closing=false
    init(text:@escaping(String,String)->Void,frame:@escaping(Data)->Void,failure:@escaping(String)->Void) { self.text=text;self.frame=frame;self.failure=failure }
    func start(target:MeetingTarget,content:SCShareableContent,locale:String,audioPath:String) async throws {
        guard let display=content.displays.first else { throw CaptureError.message("没有可采集的显示器") }
        guard FileManager.default.fileExists(atPath:audioPath) else { throw CaptureError.message("本机录音文件未创建") }
        file=try FileHandle(forWritingTo:URL(fileURLWithPath:audioPath));try file?.seekToEnd()
        speech=try SpeechStream(locale:locale,queue:queue,emit:text,failure:failure)
        queue.sync { speech?.start() }
        let size=target.window.frame.size;let scale=min(1,960/max(size.width,size.height))
        let vc=SCStreamConfiguration();vc.width=max(32,Int(size.width*scale));vc.height=max(32,Int(size.height*scale));vc.minimumFrameInterval=CMTime(value:1,timescale:3);vc.showsCursor=false;vc.queueDepth=3;vc.capturesAudio=false
        let vs=SCStream(filter:SCContentFilter(desktopIndependentWindow:target.window),configuration:vc,delegate:self)
        try vs.addStreamOutput(self,type:.screen,sampleHandlerQueue:queue);screen=vs
        let ac=SCStreamConfiguration();ac.capturesAudio=true;ac.sampleRate=16000;ac.channelCount=1;ac.excludesCurrentProcessAudio=true;ac.width=32;ac.height=32;ac.minimumFrameInterval=CMTime(value:1,timescale:1)
        let own=content.applications.filter { $0.processID==ProcessInfo.processInfo.processIdentifier }
        let a=SCStream(filter:SCContentFilter(display:display,excludingApplications:own,exceptingWindows:[]),configuration:ac,delegate:self)
        try a.addStreamOutput(self,type:.audio,sampleHandlerQueue:queue);audio=a
        do {
            let mic=AVAudioEngine(),input=mic.inputNode,inputFormat=input.outputFormat(forBus:0)
            guard inputFormat.sampleRate>0,inputFormat.channelCount>0,let converter=AVAudioConverter(from:inputFormat,to:mixedFormat) else { throw CaptureError.message("麦克风不可用，未开始仅录系统声音的会议") }
            input.installTap(onBus:0,bufferSize:2048,format:inputFormat) { [weak self] buffer,time in
                guard let self=self,let converted=AVAudioPCMBuffer(pcmFormat:self.mixedFormat,frameCapacity:AVAudioFrameCount(Double(buffer.frameLength)*16000/inputFormat.sampleRate)+32) else { return }
                var supplied=false;var conversionError:NSError?
                converter.convert(to:converted,error:&conversionError) { _,status in
                    if supplied { status.pointee = .noDataNow;return nil };supplied=true;status.pointee = .haveData;return buffer
                }
                if let error=conversionError { self.failure("麦克风采集失败："+error.localizedDescription);return }
                guard let samples=converted.floatChannelData?[0] else { return }
                let values=Array(UnsafeBufferPointer(start:samples,count:Int(converted.frameLength))),at=AVAudioTime.seconds(forHostTime:time.hostTime)
                self.queue.async { if !self.paused && !self.closing { self.mixer.add(values,at:at) } }
            }
            microphone=mic;try mic.start()
            queue.sync { mixer=TimelineMixer(origin:ProcessInfo.processInfo.systemUptime) }
            try await vs.startCapture();try await a.startCapture()
            let timer=DispatchSource.makeTimerSource(queue:queue);timer.schedule(deadline:.now(),repeating:.milliseconds(20));timer.setEventHandler { [weak self] in self?.flushMix() };mixTimer=timer;timer.resume()
        }
        catch { await stop();throw error }
    }
    func pause(_ value:Bool) async {
        await withCheckedContinuation { (c:CheckedContinuation<Void,Never>) in queue.async { self.paused=value;if value { self.flushMix(final:true);self.speech?.stop() } else { self.mixer=TimelineMixer(origin:ProcessInfo.processInfo.systemUptime);self.gate=PageGate();self.speech?.start() };c.resume() } }
    }
    func stop() async {
        closing=true;microphone?.inputNode.removeTap(onBus:0);microphone?.stop();microphone=nil;mixTimer?.cancel();mixTimer=nil;try? await screen?.stopCapture();try? await audio?.stopCapture()
        await withCheckedContinuation { (c:CheckedContinuation<Void,Never>) in queue.async { self.flushMix(final:true);self.speech?.stop();try? self.file?.synchronize();try? self.file?.close();self.file=nil;c.resume() } }
        screen=nil;audio=nil
    }
    func stream(_ stream:SCStream,didStopWithError error:Error) { if !closing { failure("会议采集已中断："+error.localizedDescription) } }
    func stream(_ stream:SCStream,didOutputSampleBuffer sampleBuffer:CMSampleBuffer,of type:SCStreamOutputType) {
        guard !paused,!closing,sampleBuffer.isValid else { return }
        if type == .audio {
            do { let values=try systemSamples(sampleBuffer);mixer.add(values,at:CMSampleBufferGetPresentationTimeStamp(sampleBuffer).seconds) } catch { failure("系统声音采集失败："+error.localizedDescription) }
            return
        }
        guard type == .screen,let pixel=sampleBuffer.imageBuffer else { return }
        if let a=CMSampleBufferGetSampleAttachmentsArray(sampleBuffer,createIfNecessary:false) as? [[SCStreamFrameInfo:Any]],let raw=a.first?[.status] as? Int,raw != SCFrameStatus.complete.rawValue { return }
        let image=CIImage(cvPixelBuffer:pixel);let extent=image.extent
        let thumb=image.transformed(by:CGAffineTransform(scaleX:64/extent.width,y:36/extent.height))
        var luminance=[UInt8](repeating:0,count:64*36)
        luminance.withUnsafeMutableBytes { ci.render(thumb,toBitmap:$0.baseAddress!,rowBytes:64,bounds:CGRect(x:0,y:0,width:64,height:36),format:.L8,colorSpace:CGColorSpaceCreateDeviceGray()) }
        guard gate.accepts(luminance,now:ProcessInfo.processInfo.systemUptime),let cg=ci.createCGImage(image,from:extent) else { return }
        let bitmap=NSBitmapImageRep(cgImage:cg)
        for quality in [0.55,0.35,0.20] { if let jpeg=bitmap.representation(using:.jpeg,properties:[.compressionFactor:quality]),jpeg.count<=160000 { frame(jpeg);return } }
    }
    func systemSamples(_ sample:CMSampleBuffer) throws -> [Float] {
        guard let desc=sample.formatDescription,let format=CMAudioFormatDescriptionGetStreamBasicDescription(desc)?.pointee else { return [] }
        guard format.mFormatID==kAudioFormatLinearPCM,format.mChannelsPerFrame==1,abs(format.mSampleRate-16000)<1 else { throw CaptureError.message("系统声音格式不符合本机录音要求") }
        var list=AudioBufferList(mNumberBuffers:1,mBuffers:AudioBuffer(mNumberChannels:1,mDataByteSize:0,mData:nil));var block:CMBlockBuffer?
        let code=CMSampleBufferGetAudioBufferListWithRetainedBlockBuffer(sample,bufferListSizeNeededOut:nil,bufferListOut:&list,bufferListSize:MemoryLayout<AudioBufferList>.size,blockBufferAllocator:nil,blockBufferMemoryAllocator:nil,flags:0,blockBufferOut:&block)
        guard code==noErr,let ptr=list.mBuffers.mData else { return [] }
        let count=CMSampleBufferGetNumSamples(sample)
        if format.mFormatFlags & kAudioFormatFlagIsFloat != 0 && format.mBitsPerChannel==32 {
            return Array(UnsafeBufferPointer(start:ptr.assumingMemoryBound(to:Float.self),count:count))
        } else if format.mBitsPerChannel==16 { return UnsafeBufferPointer(start:ptr.assumingMemoryBound(to:Int16.self),count:count).map{Float($0)/32768} }
        else { throw CaptureError.message("系统声音编码暂不支持") }
    }
    func flushMix(final:Bool=false) {
        guard final || (!paused && !closing) else { return }
        for values in mixer.drain(to:ProcessInfo.processInfo.systemUptime,final:final) {
            guard let buffer=AVAudioPCMBuffer(pcmFormat:mixedFormat,frameCapacity:320),let samples=buffer.floatChannelData?[0] else { continue }
            buffer.frameLength=320;for i in 0..<320 { samples[i]=values[i] };speech?.append(buffer)
            let pcm=values.map{Int16(max(-32768,min(32767,Int($0*32767))))},bytes=pcm.withUnsafeBytes{Data($0)}
            let power=values.reduce(0.0){$0+Double($1*$1)}
            meterLock.lock();audioLevel=min(1,sqrt(power/320)*5);audioLevelAt=Date();meterLock.unlock()
            do { try file?.write(contentsOf:bytes);seconds += 0.02 } catch { failure("原始录音保存失败："+error.localizedDescription) }
        }
    }
}
final class AudioMeter:NSView {
    var level:Double=0 { didSet { needsDisplay=true } }
    override var intrinsicContentSize:NSSize { NSSize(width:30,height:18) }
    override func draw(_ dirtyRect:NSRect) {
        let value=max(0,min(1,level));let weights:[Double]=[0.45,0.8,1,0.65,0.35]
        for (i,w) in weights.enumerated() {
            let h=max(3,CGFloat(value*w)*16)
            (value>0.015 ? NSColor.controlAccentColor:NSColor.tertiaryLabelColor).setFill()
            NSBezierPath(roundedRect:NSRect(x:CGFloat(i)*6,y:(bounds.height-h)/2,width:3,height:h),xRadius:1.5,yRadius:1.5).fill()
        }
    }
}
enum MiniView:String { case expanded,compact,hidden }
// Presentation never owns the recording lifecycle. Preserve the top-right anchor.
func miniFrame(_ old:NSRect,size:NSSize,screens:[NSRect])->NSRect {
    guard let screen=screens.max(by:{ a,b in
        let ia=old.intersection(a),ib=old.intersection(b)
        return (ia.isNull ? 0:ia.width*ia.height)<(ib.isNull ? 0:ib.width*ib.height)
    }) else { return NSRect(x:old.maxX-size.width,y:old.maxY-size.height,width:size.width,height:size.height) }
    let width=min(size.width,screen.width),height=min(size.height,screen.height)
    return NSRect(x:min(max(old.maxX-width,screen.minX),screen.maxX-width),y:min(max(old.maxY-height,screen.minY),screen.maxY-height),width:width,height:height)
}
final class MeetingPanel:NSPanel {
    var onHide:(()->Void)?
    override var canBecomeKey:Bool { true };override var canBecomeMain:Bool { false }
    override func cancelOperation(_ sender:Any?) { onHide?() }
}
// Expand the full reminder inside the same mini window.
final class FlippedCardStack:NSStackView { override var isFlipped:Bool { true } }
final class MiniInsightButton:NSButton {
    let category:String;let bodyText:String;var expanded=false;var sourceLabel="";var stableKey="";var readMore="展开全文";var collapse="收起"
    init(category:String,text:String,target:AnyObject?,action:Selector) {
        self.category=category;bodyText=text
        super.init(frame:.zero);title=category+" · "+text;self.target=target;self.action=action
        isBordered=false;setButtonType(.momentaryPushIn);toolTip=title
    }
    required init?(coder:NSCoder) { fatalError("init(coder:) has not been implemented") }
    override var intrinsicContentSize:NSSize {
        let paragraph=NSMutableParagraphStyle();paragraph.lineBreakMode = .byWordWrapping;paragraph.minimumLineHeight=17;paragraph.maximumLineHeight=17
        let rect=(bodyText as NSString).boundingRect(with:NSSize(width:258,height:6000),options:[.usesLineFragmentOrigin,.usesFontLeading],attributes:[.font:NSFont.systemFont(ofSize:13),.paragraphStyle:paragraph])
        return NSSize(width:282,height:50+(expanded ? max(17,ceil(rect.height)):min(51,max(17,ceil(rect.height)))))
    }
    override func draw(_ dirtyRect:NSRect) {
        let shape=NSBezierPath(roundedRect:bounds.insetBy(dx:0.5,dy:0.5),xRadius:10,yRadius:10)
        (isHighlighted ? NSColor.controlAccentColor.withAlphaComponent(0.1):NSColor.controlBackgroundColor).setFill();shape.fill()
        NSColor.separatorColor.withAlphaComponent(0.5).setStroke();shape.lineWidth=1;shape.stroke()
        (category as NSString).draw(at:NSPoint(x:12,y:bounds.height-21),withAttributes:[.font:NSFont.systemFont(ofSize:10,weight:.semibold),.foregroundColor:NSColor.secondaryLabelColor])
        ((expanded ? "−":"+") as NSString).draw(at:NSPoint(x:bounds.width-22,y:bounds.height-21),withAttributes:[.font:NSFont.systemFont(ofSize:11),.foregroundColor:NSColor.tertiaryLabelColor])
        let paragraph=NSMutableParagraphStyle();paragraph.lineBreakMode = .byWordWrapping;paragraph.minimumLineHeight=17;paragraph.maximumLineHeight=17
        (bodyText as NSString).draw(with:NSRect(x:12,y:25,width:258,height:bounds.height-50),options:expanded ? [.usesLineFragmentOrigin]:[.usesLineFragmentOrigin,.truncatesLastVisibleLine],attributes:[.font:NSFont.systemFont(ofSize:13),.foregroundColor:NSColor.labelColor,.paragraphStyle:paragraph])
        let footer=[sourceLabel,expanded ? collapse:readMore].filter { !$0.isEmpty }.joined(separator:" · ")
        (footer as NSString).draw(at:NSPoint(x:12,y:8),withAttributes:[.font:NSFont.systemFont(ofSize:10),.foregroundColor:NSColor.secondaryLabelColor])
    }
}
final class AppDelegate:NSObject,NSApplicationDelegate,NSWindowDelegate {
    let api:LocalAPI;let locale:String;let english:Bool;let autoStart:Bool
    var panel:MeetingPanel!;var status:NSTextField!;var cards=FlippedCardStack();var startButton:NSButton!;var pauseButton:NSButton!;var endButton:NSButton!
    var mirroring=false;var meter=AudioMeter();var compactMeter=AudioMeter();var sessionId="";var lastSessionId="";var transportIssue=false;var transportMessage="";var heartbeating=false;var engine:CaptureEngine?;var busy=false;var paused=false;var error="";var tick:Timer?
    var textQueue:[(String,String)]=[];var pendingFrame:Data?;var sending=false;var lastCards="";var lastHeartbeat=Date()
    var viewMode=MiniView.expanded;var expandedRoot:NSStackView!;var compactRoot:NSStackView!;var compactButton:NSButton!;var compactPause:NSButton!;var statusItem:NSStatusItem!;var pauseItem:NSMenuItem!;var endItem:NSMenuItem!;var expandedHeight:CGFloat=170;var cardCount=0
    var showHistory=false;var expandedCards=Set<String>();var historySession="";var presentedRoot:NSStackView?;var presentationConstraints:[NSLayoutConstraint]=[];var cardScroll=NSScrollView();var cardViewport:NSLayoutConstraint!;var joinTarget:UInt32?
    init(server:String,locale:String,english:Bool,autoStart:Bool) { api=LocalAPI(server);self.locale=locale;self.english=english;self.autoStart=autoStart }
    func tr(_ zh:String,_ en:String)->String { english ? en : zh }
    func applicationDidFinishLaunching(_ notification:Notification) {
        NSApp.setActivationPolicy(.accessory)
        panel=MeetingPanel(contentRect:NSRect(x:0,y:0,width:310,height:170),styleMask:[.titled,.closable,.nonactivatingPanel,.utilityWindow],backing:.buffered,defer:false)
        panel.title=tr("听会台 · 小窗","LiveMate · Mini");panel.level = .floating;panel.isFloatingPanel=true;panel.hidesOnDeactivate=false;panel.isReleasedWhenClosed=false
        panel.collectionBehavior=[.canJoinAllSpaces,.fullScreenAuxiliary];panel.standardWindowButton(.zoomButton)?.isHidden=true;panel.standardWindowButton(.miniaturizeButton)?.isHidden=true
        panel.delegate=self;panel.isMovableByWindowBackground=true;panel.onHide={ [weak self] in self?.hidePanel() }
        panel.standardWindowButton(.closeButton)?.toolTip=tr("隐藏小窗，听会继续","Hide mini window; keep listening")
        let root=NSStackView();root.orientation = .vertical;root.alignment = .leading;root.spacing=10;root.edgeInsets=NSEdgeInsets(top:10,left:14,bottom:10,right:14);root.translatesAutoresizingMaskIntoConstraints=false
        expandedRoot=root
        let heading=NSStackView();heading.spacing=8;heading.translatesAutoresizingMaskIntoConstraints=false;root.addArrangedSubview(heading);heading.widthAnchor.constraint(equalToConstant:282).isActive=true
        status=NSTextField(wrappingLabelWithString:tr("切回会议窗口，点开始","Return to your meeting and press Start"));status.font = .systemFont(ofSize:12);status.maximumNumberOfLines=2;status.lineBreakMode = .byTruncatingTail;status.textColor = .secondaryLabelColor;status.setContentCompressionResistancePriority(.defaultLow,for:.horizontal);heading.addArrangedSubview(meter);heading.addArrangedSubview(status)
        let fold=NSButton(title:tr("收起","Collapse"),target:self,action:#selector(collapsePanel));fold.bezelStyle = .rounded;fold.toolTip=tr("缩成迷你条，听会继续","Collapse to a mini bar; keep listening");heading.addArrangedSubview(fold)
        cards.orientation = .vertical;cards.alignment = .leading;cards.spacing=8
        cardScroll.documentView=cards;cardScroll.hasVerticalScroller=true;cardScroll.autohidesScrollers=true;cardScroll.drawsBackground=false;cardScroll.borderType = .noBorder;cardScroll.translatesAutoresizingMaskIntoConstraints=false;root.addArrangedSubview(cardScroll)
        cardScroll.widthAnchor.constraint(equalToConstant:282).isActive=true;cardViewport=cardScroll.heightAnchor.constraint(equalToConstant:0);cardViewport.isActive=true;cardScroll.isHidden=true
        let controls=NSStackView();controls.spacing=8;root.addArrangedSubview(controls)
        startButton=NSButton(title:tr("开始","Start"),target:self,action:#selector(startClicked));startButton.bezelStyle = .rounded;controls.addArrangedSubview(startButton)
        pauseButton=NSButton(title:tr("暂停","Pause"),target:self,action:#selector(pauseClicked));pauseButton.bezelStyle = .rounded;pauseButton.isHidden=true;controls.addArrangedSubview(pauseButton)
        endButton=NSButton(title:tr("结束","End"),target:self,action:#selector(endClicked));endButton.bezelStyle = .rounded;endButton.isHidden=true;controls.addArrangedSubview(endButton)
        let expand=NSButton(title:tr("听会台 ↗","Open LiveMate ↗"),target:self,action:#selector(openMain));expand.bezelStyle = .rounded;controls.addArrangedSubview(expand)
        compactRoot=NSStackView();compactRoot.spacing=5;compactRoot.edgeInsets=NSEdgeInsets(top:5,left:8,bottom:5,right:8);compactRoot.translatesAutoresizingMaskIntoConstraints=false
        compactButton=NSButton(title:tr("待开始 · 展开","Ready · Expand"),target:self,action:#selector(showPanel));compactButton.bezelStyle = .rounded;compactButton.isBordered=false;compactButton.font = .systemFont(ofSize:12);compactButton.cell?.lineBreakMode = .byTruncatingTail;compactButton.toolTip=tr("展开小窗","Expand mini window");compactButton.setContentCompressionResistancePriority(.defaultLow,for:.horizontal);compactRoot.addArrangedSubview(compactMeter);compactRoot.addArrangedSubview(compactButton)
        compactPause=NSButton(title:tr("暂停","Pause"),target:self,action:#selector(pauseClicked));compactPause.bezelStyle = .rounded;compactPause.controlSize = .small;compactRoot.addArrangedSubview(compactPause)
        setupMenu()
        if let rect=NSScreen.main?.visibleFrame { panel.setFrameOrigin(NSPoint(x:rect.maxX-328,y:rect.maxY-panel.frame.height-18)) }
        if let saved=UserDefaults.standard.string(forKey:"miniWindowFrame") { panel.setFrame(NSRectFromString(saved),display:false) }
        viewMode=UserDefaults.standard.string(forKey:"miniWindowMode")=="compact" ? .compact:.expanded
        refreshPresentation();panel.orderFrontRegardless()
        NotificationCenter.default.addObserver(self,selector:#selector(screensChanged),name:NSApplication.didChangeScreenParametersNotification,object:nil)
        tick=Timer.scheduledTimer(withTimeInterval:0.5,repeats:true) { [weak self] _ in self?.heartbeat() }
        if autoStart { Task { @MainActor in _ = try? await api.request("launch-ack",[:]);startClicked() } }
    }
    func setupMenu() {
        statusItem=NSStatusBar.system.statusItem(withLength:NSStatusItem.variableLength)
        let menu=NSMenu();menu.autoenablesItems=false
        func item(_ title:String,_ action:Selector)->NSMenuItem { let i=NSMenuItem(title:title,action:action,keyEquivalent:"");i.target=self;menu.addItem(i);return i }
        _=item(tr("显示小窗","Show mini window"),#selector(showPanel))
        _=item(tr("缩成迷你条","Collapse to mini bar"),#selector(collapsePanel))
        _=item(tr("隐藏小窗 · 听会继续","Hide mini window · keep listening"),#selector(hidePanel))
        menu.addItem(.separator())
        pauseItem=item(tr("暂停听会","Pause listening"),#selector(pauseClicked))
        endItem=item(tr("结束会议","End meeting"),#selector(endClicked))
        _=item(tr("打开听会台","Open LiveMate"),#selector(openMain))
        statusItem.menu=menu
    }
    func refreshPresentation() {
        // A hidden expanded stack still contributes its minimum fitting size to
        // NSPanel. Keep only the visible mode attached so the mini bar can shrink.
        let visibleRoot = viewMode == .compact ? compactRoot!:expandedRoot!
        if presentedRoot !== visibleRoot,let body=panel.contentView {
            NSLayoutConstraint.deactivate(presentationConstraints);presentedRoot?.removeFromSuperview()
            body.addSubview(visibleRoot);presentedRoot=visibleRoot
            presentationConstraints=[visibleRoot.leadingAnchor.constraint(equalTo:body.leadingAnchor),visibleRoot.trailingAnchor.constraint(equalTo:body.trailingAnchor),visibleRoot.topAnchor.constraint(equalTo:body.topAnchor),visibleRoot.bottomAnchor.constraint(lessThanOrEqualTo:body.bottomAnchor)]
            NSLayoutConstraint.activate(presentationConstraints)
            body.layoutSubtreeIfNeeded()
        }
        let active = !sessionId.isEmpty
        compactPause.isHidden = !active;compactPause.title=tr(paused ? "继续":"暂停",paused ? "Resume":"Pause")
        startButton.isEnabled = !busy;pauseButton.isEnabled = !busy;endButton.isEnabled = !busy;compactPause.isEnabled = !busy
        pauseItem.isEnabled=active && !busy;pauseItem.title=tr(paused ? "继续听会":"暂停听会",paused ? "Resume listening":"Pause listening");endItem.isEnabled=active && !busy
        let brief = (!error.isEmpty || transportIssue) ? tr("需注意","Needs attention") : busy ? tr("正在处理","Working") : active ? tr(paused ? "已暂停":"正在听",paused ? "Paused":"Listening") : lastSessionId.isEmpty ? tr("待开始","Ready"):tr("已结束","Ended")
        compactButton.title=(active && !paused ? "● ":"")+brief+(cardCount>0 ? " · \(cardCount)":"")
        compactButton.toolTip=status.stringValue
        statusItem.button?.title=tr("听会", "LiveMate")+(active ? (paused ? " Ⅱ":" ●"):"")
        statusItem.button?.toolTip=status.stringValue
        guard viewMode != .hidden else { return }
        let screenHeight=NSScreen.screens.first(where:{$0.visibleFrame.intersects(panel.frame)})?.visibleFrame.height ?? 800
        cardViewport.constant=min(cards.frame.height,max(80,min(320,screenHeight-140)))
        expandedRoot.layoutSubtreeIfNeeded();expandedHeight=max(80,ceil(expandedRoot.fittingSize.height))
        let chrome=panel.frame.height-(panel.contentView?.frame.height ?? panel.frame.height)
        let size=NSSize(width:viewMode == .compact ? 238:310,height:viewMode == .compact ? 38+chrome:expandedHeight+chrome)
        let next=miniFrame(panel.frame,size:size,screens:NSScreen.screens.map { $0.visibleFrame });if next != panel.frame { panel.setFrame(next,display:true) }
    }
    @objc func showPanel() { viewMode = .expanded;refreshPresentation();panel.orderFrontRegardless();savePosition() }
    @objc func collapsePanel() { viewMode = .compact;refreshPresentation();panel.orderFrontRegardless();savePosition() }
    @objc func hidePanel() { savePosition();viewMode = .hidden;panel.orderOut(nil);refreshPresentation() }
    @objc func screensChanged() { refreshPresentation() }
    func savePosition() { guard viewMode != .hidden else { return };UserDefaults.standard.set(NSStringFromRect(panel.frame),forKey:"miniWindowFrame");UserDefaults.standard.set(viewMode.rawValue,forKey:"miniWindowMode") }
    func windowDidMove(_ notification:Notification) { savePosition() }
    func windowShouldClose(_ sender:NSWindow)->Bool { hidePanel();return false }
    func applicationShouldHandleReopen(_ sender:NSApplication,hasVisibleWindows flag:Bool)->Bool { showPanel();return false }
    func showError(_ message:String) { error=message;status.stringValue=message;refreshPresentation() }
    func showTransportError(_ message:String) { transportIssue=true;transportMessage=message;status.stringValue=error.isEmpty ? message:error;refreshPresentation() }
    func recoverTransport() {
        transportIssue=false;transportMessage=""
        if sessionId.isEmpty { status.stringValue=error.isEmpty ? tr("切回会议窗口，点开始","Return to your meeting and press Start"):error }
        refreshPresentation()
    }
    func joinMeeting(_ link:String) {
        guard !busy,sessionId.isEmpty,let url=URL(string:link),url.scheme=="https",["vc.feishu.cn","vc.larksuite.com","meet.google.com"].contains(url.host ?? "") else { return }
        busy=true;status.stringValue=tr("正在打开会议；如有登录或等候室请先完成","Opening meeting; finish sign-in or the waiting room if needed");refreshPresentation()
        Task { @MainActor in
            var handedToCapture=false
            defer { if !handedToCapture { busy=false;refreshPresentation() } }
            do {
                _ = try await api.request("launch-ack",[:])
                guard CGPreflightScreenCaptureAccess() || CGRequestScreenCaptureAccess() else { NSWorkspace.shared.open(url);throw CaptureError.message(tr("会议链接已打开。允许屏幕和系统声音后，切回会议点开始","Meeting link opened. Allow Screen & System Audio, then press Start from that meeting")) }
                let before=try await SCShareableContent.excludingDesktopWindows(true,onScreenWindowsOnly:true)
                let oldIds=Set(before.windows.map{$0.windowID}),meetingId=url.lastPathComponent
                guard NSWorkspace.shared.open(url) else { throw CaptureError.message("会议链接未能打开") }
                for _ in 0..<40 {
                    try await Task.sleep(nanoseconds:250_000_000)
                    let content=try await SCShareableContent.excludingDesktopWindows(true,onScreenWindowsOnly:true),front=NSWorkspace.shared.frontmostApplication?.processIdentifier
                    if let target=content.windows.first(where:{w in
                        guard w.windowLayer==0,w.frame.width>200,w.owningApplication?.processID==front else { return false }
                        let title=w.title ?? "",bundle=w.owningApplication?.bundleIdentifier ?? ""
                        return recognizedMeeting(bundle:bundle,title:title) && (title.contains(meetingId) || !oldIds.contains(w.windowID))
                    }) {
                        joinTarget=target.windowID;busy=false;handedToCapture=true;startClicked();return
                    }
                }
                // No URL or meeting ID is available for an existing Lark window.
                // Do not guess and capture an unrelated old meeting.
                showError(tr("会议链接已打开；入会后切回会议，点小窗开始","Meeting link opened; after joining, return to it and press Start"))
            } catch { showError(error.localizedDescription) }
        }
    }
    @objc func startClicked() {
        guard !busy,sessionId.isEmpty else { return };let meetingFront=NSWorkspace.shared.frontmostApplication?.processIdentifier;busy=true;status.stringValue=tr("正在接入会议…","Connecting…");refreshPresentation()
        Task { @MainActor in
            do {
                if let current=try? await api.request("status"),current["active"] as? Bool == true,current["captureMode"] as? String == "browser" {
                    adoptBrowser(current);busy=false;refreshPresentation();return
                }
                guard CGPreflightScreenCaptureAccess() || CGRequestScreenCaptureAccess() else { throw CaptureError.message(tr("请允许听会台录制屏幕和系统音频，再点开始","Allow Screen & System Audio Recording, then press Start")) }
                let authorized=await withCheckedContinuation { (c:CheckedContinuation<Bool,Never>) in SFSpeechRecognizer.requestAuthorization { c.resume(returning:$0 == .authorized) } }
                guard authorized else { throw CaptureError.message(tr("请允许听会台使用本机语音识别","Allow on-device Speech Recognition for LiveMate")) }
                let micAuthorized=await AVCaptureDevice.requestAccess(for:.audio)
                guard micAuthorized else { throw CaptureError.message(tr("请允许麦克风，才能同时记录你和同事的声音；尚未开始录制","Allow Microphone to capture both sides; recording has not started")) }
                guard let recognizer=SFSpeechRecognizer(locale:Locale(identifier:locale)),recognizer.supportsOnDeviceRecognition else { throw CaptureError.message(tr("这门语言尚未支持本机转写；请先下载系统识别语言","On-device recognition is unavailable for this language")) }
                let content=try await SCShareableContent.excludingDesktopWindows(true,onScreenWindowsOnly:true)
                let target:MeetingTarget
                if let id=joinTarget {
                    joinTarget=nil
                    guard let window=content.windows.first(where:{$0.windowID==id}) else { throw CaptureError.message(tr("选定的会议窗口已关闭；请重新加入","The selected meeting window closed; join again")) }
                    target=MeetingTarget(window:window)
                } else { target=try findTarget(content,front:meetingFront) }
                let j=try await api.request("start",["target":target.json,"lang":locale.hasPrefix("en") ? "en" : "zh","uiLang":english ? "en" : "zh"])
                guard let id=j["sessionId"] as? String,let file=j["audioPath"] as? String else { throw CaptureError.message("已有会议在采集；请先结束当前采集") }
                sessionId=id;lastSessionId=id;lastHeartbeat=Date();error=""
                let capture=CaptureEngine(text:{ [weak self] key,text in DispatchQueue.main.async { self?.textQueue.append((key,text));self?.flushEvents() } },frame:{ [weak self] data in DispatchQueue.main.async { self?.pendingFrame=data;self?.flushEvents() } },failure:{ [weak self] message in DispatchQueue.main.async { guard let self=self else { return };self.showError(message);if !self.busy && !self.paused { self.pauseClicked() } } })
                engine=capture;try await capture.start(target:target,content:content,locale:locale,audioPath:file)
                UserDefaults.standard.set(target.json,forKey:"pinnedMeetingWindow")
                startButton.isHidden=true;pauseButton.isHidden=false;endButton.isHidden=false;lastCards="";renderStatus(j)
            } catch { if !sessionId.isEmpty { await engine?.stop();try? await api.request("end",["sessionId":sessionId]);sessionId="";engine=nil };showError(error.localizedDescription) }
            busy=false;refreshPresentation()
        }
    }
    func findTarget(_ content:SCShareableContent,front:pid_t?) throws -> MeetingTarget {
        let order=(CGWindowListCopyWindowInfo(.optionOnScreenOnly,kCGNullWindowID) as? [[String:Any]] ?? []).compactMap { $0[kCGWindowNumber as String] as? UInt32 }
        let windows=content.windows.filter { $0.windowLayer==0 && $0.frame.width>200 && $0.frame.height>120 }
        if let current=windows.filter({$0.owningApplication?.processID==front && $0.owningApplication?.processID != ProcessInfo.processInfo.processIdentifier}).sorted(by:{(order.firstIndex(of:$0.windowID) ?? 999)<(order.firstIndex(of:$1.windowID) ?? 999)}).first { return MeetingTarget(window:current) }
        if let pin=UserDefaults.standard.dictionary(forKey:"pinnedMeetingWindow"),let id=pin["windowId"] as? Int,let bundle=pin["bundleId"] as? String,let title=pin["title"] as? String,let old=windows.first(where:{Int($0.windowID)==id && $0.owningApplication?.bundleIdentifier==bundle && $0.title==title}) { return MeetingTarget(window:old) }
        throw CaptureError.message(tr("切回要听的会议或播放窗口，点小窗的开始","Return to the meeting or playback window and press Start here"))
    }
    func flushEvents() {
        guard !sending,!sessionId.isEmpty else { return };sending=true;let id=sessionId
        Task { @MainActor in
            defer { sending=false }
            do {
                while sessionId==id,!textQueue.isEmpty { let e=textQueue[0];try await api.request("text",["sessionId":id,"key":e.0,"text":e.1]);textQueue.removeFirst() }
                if sessionId==id,let image=pendingFrame { pendingFrame=nil;do { try await api.request("frame",["sessionId":id,"jpeg":image.base64EncodedString()]) } catch { if pendingFrame==nil { pendingFrame=image };throw error } }
            } catch { showTransportError(tr("与听会台断开，正在重连","Disconnected, reconnecting")) }
        }
    }
    func adoptBrowser(_ j:[String:Any]) {
        guard let id=j["sessionId"] as? String else { return }
        mirroring=true;sessionId=id;lastSessionId=id;error="";paused=j["phase"] as? String == "paused"
        startButton.isHidden=true;pauseButton.isHidden=false;endButton.isHidden=false;renderStatus(j)
    }
    func resetSession() {
        sessionId="";mirroring=false;paused=false;engine=nil;meter.level=0;compactMeter.level=0
        startButton.isHidden=false;pauseButton.isHidden=true;endButton.isHidden=true
        status.stringValue=tr("已结束 · 可回听会台继续","Ended · Continue in LiveMate");refreshPresentation()
    }
    func heartbeat() {
        guard !heartbeating else { return }
        heartbeating=true
        Task { @MainActor in
            defer { heartbeating=false }
            do {
                if sessionId.isEmpty || mirroring {
                    let j=try await api.request("status")
                    if transportIssue { recoverTransport() }
                    if j["active"] as? Bool == true,j["captureMode"] as? String == "browser" { adoptBrowser(j) }
                    else if mirroring { resetSession() }
                    else if j["command"] as? String == "join",let link=j["meetingUrl"] as? String,!busy { joinMeeting(link) }
                    else if j["command"] as? String == "start",!busy { _ = try? await api.request("launch-ack",[:]);startClicked() }
                    return
                }
                let id=sessionId;flushEvents()
                let level=paused ? 0:(engine?.meterSnapshot() ?? 0)
                meter.level=level;compactMeter.level=level
                let j=try await api.request("heartbeat",["sessionId":id,"audioSeconds":engine?.seconds ?? 0,"audioLevel":level,"error":error,"view":viewMode.rawValue]);lastHeartbeat=Date()
                guard sessionId==id else { return };if transportIssue && textQueue.isEmpty && pendingFrame==nil { recoverTransport() }
                if let command=j["command"] as? String { if command=="stop" { endClicked();return };if command=="pause" && !paused { pauseClicked() };if command=="resume" && paused { pauseClicked() } }
                renderStatus(j)
            } catch { meter.level=0;compactMeter.level=0;showTransportError(error.localizedDescription);if !mirroring && !sessionId.isEmpty && Date().timeIntervalSince(lastHeartbeat)>16 { endClicked() } }
        }
    }
    func drainEvents() async -> Bool {
        // Keep the session and its queued final text until the server acknowledges it.
        for _ in 0..<150 {
            flushEvents()
            if !sending && textQueue.isEmpty && pendingFrame==nil { return true }
            try? await Task.sleep(nanoseconds:100_000_000)
        }
        return false
    }
    var confirmationHandlers:[ConfirmationHandler]=[]
    func renderStatus(_ j:[String:Any]) {
        if mirroring { paused=j["phase"] as? String == "paused";let level=paused ? 0:(j["audioLevel"] as? Double ?? 0);meter.level=level;compactMeter.level=level }
        if error.isEmpty && !transportIssue { let phase=j["phase"] as? String ?? "listening";status.stringValue=phase=="thinking" ? tr("正在判断这条信息…","Assessing new information…") : phase=="paused" ? tr("已暂停","Paused") : phase=="model_unavailable" ? tr("提醒暂不可用，录音继续","Insights unavailable; recording continues") : (mirroring ? tr("正在听 · 与大窗同步","Listening · Synced with main window"):tr("正在听 · 本机转写","Listening · On device")) }
        refreshPresentation()
        let c=j["cards"] as? [String:Any] ?? [:]
        if historySession != sessionId { historySession=sessionId;showHistory=false;expandedCards=[];cardScroll.contentView.scroll(to:.zero) }
        let top=cardScroll.contentView.bounds.origin.y
        let anchor=cards.arrangedSubviews.first { $0.frame.maxY>top }
        let anchorKey=anchor?.identifier;let offset=top-(anchor?.frame.minY ?? top)
        let displayed:[String:Any]=["historyOpen":showHistory,"cards":c,"confirmation":j["confirmation"] ?? NSNull()]
        guard let data=try? JSONSerialization.data(withJSONObject:displayed),let key=String(data:data,encoding:.utf8),key != lastCards else { return };lastCards=key
        confirmationHandlers=[]
        for view in cards.arrangedSubviews { cards.removeArrangedSubview(view);view.removeFromSuperview() }
        var rows:[(String,[String:Any])]=[]
        if let confirmation=j["confirmation"] as? [String:Any],let cid=confirmation["id"] as? String {
            let question=NSTextField(wrappingLabelWithString:tr("需要你确认 · ","Your call · ")+(confirmation["question"] as? String ?? ""));question.font = .systemFont(ofSize:13,weight:.medium);cards.addArrangedSubview(question)
            let statement=confirmation["statement"] as? String ?? ""
            let proposal=NSTextField(wrappingLabelWithString:statement);proposal.font = .systemFont(ofSize:12);proposal.textColor = .secondaryLabelColor;proposal.toolTip=statement;cards.addArrangedSubview(proposal)
            for label in [question,proposal] {
                label.translatesAutoresizingMaskIntoConstraints=false
                let bounds=(label.stringValue as NSString).boundingRect(with:NSSize(width:282,height:2000),options:[.usesLineFragmentOrigin,.usesFontLeading],attributes:[.font:label.font!])
                let height=ceil(bounds.height)+8
                label.widthAnchor.constraint(equalToConstant:282).isActive=true;label.heightAnchor.constraint(equalToConstant:height).isActive=true
            }
            let controls=NSStackView();controls.orientation = .horizontal;controls.spacing=8
            for (label,response) in [(tr("确认","Confirm"),"confirm"),(tr("纠正","Correct"),"correct"),(tr("稍后","Later"),"later")] {
                let button=NSButton(title:label,target:nil,action:nil);button.bezelStyle = .rounded
                let handler=ConfirmationHandler { [weak self] in guard let self=self else { return };if response=="correct" { self.openMain();return };button.isEnabled=false;Task { @MainActor in do { let next=try await self.api.request("confirmation",["sessionId":self.sessionId,"confirmationId":cid,"response":response]);self.lastCards="";self.renderStatus(next) }catch{button.isEnabled=true;self.showError(error.localizedDescription)} } }
                button.target=handler;button.action=#selector(ConfirmationHandler.click);confirmationHandlers.append(handler);controls.addArrangedSubview(button)
            };cards.addArrangedSubview(controls)
        }
        if let s=c["suggestion"] as? [String:Any],s["text"] is String { rows.append((tr("建议","Suggestion"),s)) }
        for insight in (c["insights"] as? [[String:Any]] ?? []).prefix(2) { if insight["text"] is String { rows.append((tr("洞察","Insight"),insight)) } }
        let currentKeys=Set(rows.compactMap { $0.1["key"] as? String })
        let history=(c["history"] as? [[String:Any]] ?? []).filter { !currentKeys.contains($0["key"] as? String ?? "") }
        if !history.isEmpty {
            let toggle=NSButton(title:(showHistory ? "▾ ":"▸ ")+tr("之前的提醒","Earlier reminders")+" (\(history.count))",target:self,action:#selector(toggleHistory));toggle.isBordered=false
            toggle.identifier=NSUserInterfaceItemIdentifier("history-toggle");cards.addArrangedSubview(toggle)
            if showHistory { rows += history.map { (tr("之前的提醒","Earlier reminder"),$0) } }
        }
        for (label,item) in rows {
            let text=item["text"] as? String ?? ""
            let b=MiniInsightButton(category:label,text:text,target:self,action:#selector(toggleCard(_:)));b.stableKey=item["key"] as? String ?? text;b.expanded=expandedCards.contains(b.stableKey);b.sourceLabel=item["sourceLabel"] as? String ?? "";b.readMore=tr("展开全文","Read more");b.collapse=tr("收起","Collapse");b.identifier=NSUserInterfaceItemIdentifier(b.stableKey);b.translatesAutoresizingMaskIntoConstraints=false;cards.addArrangedSubview(b)
            let height=b.intrinsicContentSize.height
            b.widthAnchor.constraint(equalToConstant:282).isActive=true;b.heightAnchor.constraint(equalToConstant:height).isActive=true
        }
        cardCount=rows.count+(j["confirmation"] is [String:Any] ? 1:0)
        let contentHeight=ceil(cards.fittingSize.height)
        cards.setFrameSize(NSSize(width:282,height:contentHeight));cardScroll.isHidden=cardCount==0;refreshPresentation()
        cards.layoutSubtreeIfNeeded()
        if let key=anchorKey,let next=cards.arrangedSubviews.first(where:{$0.identifier==key}) { cardScroll.contentView.scroll(to:NSPoint(x:0,y:max(0,next.frame.minY+offset))) }
        else if showHistory { cardScroll.contentView.scroll(to:NSPoint(x:0,y:top)) }
        cardScroll.reflectScrolledClipView(cardScroll.contentView)
    }
    @objc func toggleHistory() { showHistory.toggle();lastCards="";Task { @MainActor in if let state=try? await api.request("status") { renderStatus(state) } } }
    @objc func toggleCard(_ sender:MiniInsightButton) {
        if expandedCards.contains(sender.stableKey) { expandedCards.remove(sender.stableKey) }else{expandedCards.insert(sender.stableKey)}
        sender.expanded=expandedCards.contains(sender.stableKey)
        for c in sender.constraints where c.firstAttribute == .height { c.constant=sender.intrinsicContentSize.height }
        sender.invalidateIntrinsicContentSize();sender.needsDisplay=true;cards.layoutSubtreeIfNeeded();cards.setFrameSize(NSSize(width:282,height:ceil(cards.fittingSize.height)));refreshPresentation()
    }
    @objc func pauseClicked() {
        guard !busy,!sessionId.isEmpty else { return };busy=true;refreshPresentation();let value = !paused
        Task { @MainActor in
            defer { busy=false;refreshPresentation() }
            if mirroring {
                do { _ = try await api.request("command",["sessionId":sessionId,"command":value ? "pause":"resume"]) }
                catch { showError(error.localizedDescription) };return
            }
            await engine?.pause(value)
            if value {
                let saved=await drainEvents()
                if !saved { await engine?.pause(false);showError(tr("最后一句还在保存，请稍后重试","Saving the last sentence; retry shortly"));return }
            }
            do {
                _ = try await api.request("pause",["sessionId":sessionId,"paused":value])
                paused=value;if !value { error="" };pauseButton.title=tr(paused ? "继续":"暂停",paused ? "Resume":"Pause")
            } catch { await engine?.pause(!value);showError(error.localizedDescription) }
        }
    }
    @objc func endClicked() {
        guard !busy,!sessionId.isEmpty else { return };busy=true;refreshPresentation();let id=sessionId
        Task { @MainActor in
            if mirroring {
                do { _ = try await api.request("command",["sessionId":id,"command":"stop"]) }
                catch { showError(error.localizedDescription) };busy=false;refreshPresentation();return
            }
            await engine?.stop();flushEvents()
            // Recognition emits its last local partial before the existing Session is finalized.
            guard await drainEvents() else { showError(tr("最后一句尚未送达，录音已留在本机；正在重试保存","Last sentence not delivered; audio saved locally, retrying"));busy=false;refreshPresentation();return }
            do { try await api.request("end",["sessionId":id]);sessionId="";engine=nil;textQueue=[];pendingFrame=nil;paused=false;error="";status.stringValue=tr("已结束 · 可回听会台继续","Ended · Continue in LiveMate");startButton.isHidden=false;pauseButton.isHidden=true;endButton.isHidden=true }
            catch { showError(tr("收尾未确认，正在重试","Final save unconfirmed, retrying")) }
            busy=false;refreshPresentation()
        }
    }
    @objc func openMain() { let id=sessionId.isEmpty ? lastSessionId:sessionId;Task { @MainActor in do { _ = try await api.request("open-main",["sessionId":id]) }catch{showError(tr("无法打开听会台：","Unable to open LiveMate: ")+error.localizedDescription)} } }
    func applicationShouldTerminate(_ sender:NSApplication)->NSApplication.TerminateReply { if !sessionId.isEmpty && !mirroring { endClicked();return .terminateCancel };return .terminateNow }
}
let argv=CommandLine.arguments
func argument(_ key:String,_ fallback:String)->String { if let i=argv.firstIndex(of:key),i+1<argv.count { return argv[i+1] };return fallback }
if argv.contains("--self-test") {
    var mix=TimelineMixer(origin:100)
    mix.add([Float](repeating:0.25,count:320),at:100);mix.add([Float](repeating:0.5,count:320),at:100)
    let simultaneous=mix.drain(to:100.23)
    precondition(simultaneous.count==1 && simultaneous[0].count==320 && simultaneous[0].allSatisfy{$0==0.75},"Two simultaneous sources must occupy the same 20ms, not 40ms")
    mix.add([Float](repeating:1,count:320),at:100);precondition(mix.blocks.isEmpty,"Late buffers must not rewrite saved audio")
    mix.add([Float](repeating:2,count:320),at:100.02);let final=mix.drain(to:100.25,final:true);precondition(final.count==1 && final[0].allSatisfy{$0==1})
    let screen=NSRect(x:0,y:0,width:1440,height:900),old=NSRect(x:1112,y:500,width:310,height:280)
    let compact=miniFrame(old,size:NSSize(width:246,height:66),screens:[screen])
    precondition(compact.maxX==old.maxX && compact.maxY==old.maxY)
    let restored=miniFrame(compact,size:NSSize(width:310,height:480),screens:[screen])
    precondition(restored.maxX==old.maxX && restored.maxY==old.maxY)
    let removedDisplay=miniFrame(NSRect(x:3000,y:1400,width:310,height:480),size:NSSize(width:246,height:66),screens:[screen])
    precondition(screen.contains(removedDisplay))
    let negativeDisplay=NSRect(x:-1600,y:0,width:1600,height:1000)
    precondition(negativeDisplay.contains(miniFrame(NSRect(x:-350,y:600,width:310,height:200),size:NSSize(width:246,height:66),screens:[screen,negativeDisplay])))
    var g=PageGate();let a=[UInt8](repeating:80,count:2304),b=[UInt8](repeating:200,count:2304)
    precondition(!g.accepts(a,now:0));precondition(!g.accepts(a,now:0.34));precondition(g.accepts(a,now:0.68));precondition(!g.accepts(a,now:9))
    var cursor=a;for i in 0..<40 { cursor[i]=255 };precondition(!g.accepts(cursor,now:10))
    precondition(!g.accepts(b,now:11));precondition(!g.accepts(b,now:11.34));precondition(g.accepts(b,now:11.68))
    precondition(recognizedMeeting(bundle:"com.bytedance.Feishu",title:"飞书会议"));precondition(!recognizedMeeting(bundle:"com.bytedance.Feishu",title:"飞书文档"));precondition(recognizedMeeting(bundle:"com.google.Chrome",title:"Meet - abc-defg-hij"));precondition(!recognizedMeeting(bundle:"com.google.Chrome",title:"Bank account"))
    var speechDelta=SpeechDelta()
    precondition(speechDelta.take("hello",pieces:[SpeechPiece(start:0,end:1,range:NSRange(location:0,length:5))])=="hello")
    precondition(speechDelta.take("hello",pieces:[SpeechPiece(start:0,end:1,range:NSRange(location:0,length:5))])==nil)
    precondition(speechDelta.take("Hallo world",pieces:[SpeechPiece(start:0,end:1,range:NSRange(location:0,length:5)),SpeechPiece(start:1.1,end:2,range:NSRange(location:6,length:5))])=="world")
    print("native_self_test_passed");exit(0)
}
if argv.contains("--probe") {
    let r=SFSpeechRecognizer(locale:Locale(identifier:argument("--locale","zh-CN")))
    let j:[String:Any]=["screenPermission":CGPreflightScreenCaptureAccess(),"speechPermission":SFSpeechRecognizer.authorizationStatus().rawValue,"microphonePermission":AVCaptureDevice.authorizationStatus(for:.audio).rawValue,"onDevice":r?.supportsOnDeviceRecognition ?? false]
    print(String(data:try! JSONSerialization.data(withJSONObject:j),encoding:.utf8)!);exit(0)
}
let app=NSApplication.shared
let delegate=AppDelegate(server:argument("--server","http://127.0.0.1:47823"),locale:argument("--locale","zh-CN"),english:argument("--ui-lang","zh")=="en",autoStart:argv.contains("--start"))
if argv.contains("--presentation-test") {
    // Exercise actual AppKit sizing and visibility without starting capture or
    // touching meeting data. Pure rectangle tests cannot detect fitting-size bugs.
    delegate.applicationDidFinishLaunching(Notification(name:NSApplication.didFinishLaunchingNotification))
    delegate.tick?.invalidate()
    delegate.panel.contentView?.layoutSubtreeIfNeeded()
    let idleHeight=delegate.panel.contentView!.frame.height
    precondition(idleHeight<=140,"Empty mini window must not reserve a card area")
    delegate.showTransportError("Temporary connection failure");delegate.recoverTransport()
    precondition(delegate.error.isEmpty && !delegate.status.stringValue.contains("failure"))
    delegate.showError("Capture failed");delegate.showTransportError("Connection failed");delegate.recoverTransport()
    precondition(delegate.error=="Capture failed" && delegate.status.stringValue=="Capture failed","Reconnect must preserve capture errors")
    delegate.error="";delegate.sessionId="presentation-only"
    let long=String(repeating:"This is a long preview with evidence. ",count:12)
    delegate.renderStatus(["cards":["suggestion":["text":long],"insights":[["text":long],["text":long]]]])
    delegate.panel.contentView?.layoutSubtreeIfNeeded()
    precondition(delegate.cardCount==3 && delegate.cards.arrangedSubviews.count==3)
    if let card=delegate.cards.arrangedSubviews.first as? MiniInsightButton { delegate.toggleCard(card);delegate.panel.contentView?.layoutSubtreeIfNeeded();precondition(card.frame.height>101,"Expanded text must be readable inside mini window");delegate.toggleCard(card) }
    precondition(delegate.cardScroll.frame.height<=320 && delegate.panel.contentView!.frame.height<=450)
    for card in delegate.cards.arrangedSubviews { precondition(card.frame.height<=101 && card.toolTip?.contains(long)==true) }
    delegate.renderStatus(["cards":["suggestion":["text":long],"insights":[["text":long],["text":long]]],"confirmation":["id":"test-only","question":long,"statement":long]])
    delegate.panel.contentView?.layoutSubtreeIfNeeded()
    precondition(delegate.cardCount==4 && delegate.cardScroll.frame.height<=320)
    precondition(delegate.cards.frame.height>delegate.cardScroll.frame.height,"Long confirmation remains scrollable")
    let old=(0..<8).map { ["key":"old-\($0)","text":long,"sourceLabel":"38:06 · Speaker 1"] }
    delegate.showHistory=true;delegate.lastCards=""
    delegate.renderStatus(["cards":["suggestion":["key":"latest","text":long],"history":old]])
    delegate.panel.contentView?.layoutSubtreeIfNeeded()
    precondition(delegate.cardCount==9 && delegate.cards.frame.height>delegate.cardScroll.frame.height)
    let anchor=delegate.cards.arrangedSubviews.first { $0.identifier?.rawValue=="old-4" }!
    let reading=anchor.frame.minY+12
    delegate.cardScroll.contentView.scroll(to:NSPoint(x:0,y:reading))
    delegate.renderStatus(["cards":["suggestion":["key":"new-latest","text":"A new reminder"],"history":old]])
    delegate.panel.contentView?.layoutSubtreeIfNeeded()
    let kept=delegate.cards.arrangedSubviews.first { $0.identifier?.rawValue=="old-4" }!
    precondition(abs(delegate.cardScroll.contentView.bounds.origin.y-kept.frame.minY-12)<2,"New reminders must preserve the history being read")
    delegate.showHistory=false;delegate.lastCards=""
    delegate.renderStatus(["cards":["suggestion":["text":"A short actionable suggestion"],"insights":[]]])
    delegate.panel.contentView?.layoutSubtreeIfNeeded()
    precondition(delegate.cardCount==1 && delegate.panel.contentView!.frame.height<250)
    delegate.renderStatus(["cards":["insights":[]]])
    delegate.panel.contentView?.layoutSubtreeIfNeeded()
    precondition(delegate.cardScroll.isHidden && delegate.panel.contentView!.frame.height<150)
    delegate.collapsePanel();delegate.panel.contentView?.layoutSubtreeIfNeeded()
    precondition(abs(delegate.panel.frame.width-238)<1)
    precondition(abs((delegate.panel.contentView?.frame.height ?? 0)-38)<1)
    delegate.showPanel();precondition(delegate.panel.isVisible && abs(delegate.panel.frame.width-310)<1)
    delegate.hidePanel();precondition(!delegate.panel.isVisible)
    _=delegate.applicationShouldHandleReopen(app,hasVisibleWindows:false);precondition(delegate.panel.isVisible)
    delegate.hidePanel()
    print("native_presentation_test_passed: 0/1/3 cards; scrollable confirmation; error recovery; compact 238x38; expand; hide; reopen");exit(0)
}
app.delegate=delegate;app.run()

final class ConfirmationHandler:NSObject { let handler:()->Void;init(_ handler:@escaping()->Void){self.handler=handler};@objc func click(){handler()} }
