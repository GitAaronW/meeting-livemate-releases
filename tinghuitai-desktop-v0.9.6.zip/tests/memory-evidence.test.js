'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),os=require('os'),path=require('path');
const mem=require('../app/memory');
test('memory cards preserve evidence and require explicit confirmation',t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-memory-evidence-'));t.after(()=>{mem.closeAll();fs.rmSync(dir,{recursive:true,force:true});});
 const db=mem.open(dir);
 const a=mem.putCard(db,{project:'chansey',kind:'decision',state:'active',text:'保留两种 Pin 方案',meeting_id:'m1',meeting_title:'产品会',speaker:'Aaron',source_type:'meeting',source_refs:[{at:42,text:'我们保留两种'}],confidence:.72,confirmed:false,needs_review:true,conflict_key:'pin'});
 assert.equal(a.confirmed,0);assert.equal(a.source_type,'meeting');assert.equal(a.speaker,'Aaron');assert.equal(a.confidence,.72);
 const b=mem.putCard(db,{project:'chansey',kind:'decision',state:'active',text:'只保留无摄像头 Pin',meeting_id:'m2',speaker:'S3',source_type:'meeting',conflict_key:'pin'});
 assert.equal(mem.conflicts(db,'chansey','pin').length,2);
 const reviewed=mem.reviewCard(db,a.id,'confirm','Aaron 确认');assert.equal(reviewed.confirmed,1);assert.equal(reviewed.human_edited,1);
 const rejected=mem.reviewCard(db,b.id,'reject');assert.equal(rejected.state,'revoked');assert.equal(mem.conflicts(db,'chansey','pin').length,1);
});
