'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),os=require('os'),path=require('path'),{spawn}=require('child_process');
const state=require('../app/server-state');
test('pid replacement is atomic and exit cleanup cannot delete another process identity',t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-pid-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 state.writePid(dir,1234);state.writePid(dir,5678);state.clearPid(dir,1234);
 assert.equal(fs.readFileSync(path.join(dir,'server.pid'),'utf8'),'5678');
 assert.deepEqual(fs.readdirSync(dir),['server.pid']);state.clearPid(dir,5678);assert.deepEqual(fs.readdirSync(dir),[]);
 const alias=dir+'-link';fs.symlinkSync(dir,alias);t.after(()=>fs.rmSync(alias,{force:true}));
 assert.equal(state.dataDirectoryId(dir),state.dataDirectoryId(alias));assert.match(state.dataDirectoryId(dir),/^[a-f0-9]{64}$/);
});
test('successful listener registers actual pid; graceful exit cleans only its own pid',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-listen-pid-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const code=`const state=require(${JSON.stringify(require.resolve('../app/server-state'))});process.on('SIGTERM',()=>process.exit(0));require('http').createServer().listen(0,'127.0.0.1',()=>{state.registerPid(${JSON.stringify(dir)});process.send(process.pid);});`;
 const child=spawn(process.execPath,['-e',code],{stdio:['ignore','ignore','ignore','ipc']});t.after(()=>child.kill('SIGKILL'));
 const pid=await new Promise((resolve,reject)=>{child.once('message',resolve);child.once('error',reject);});
 assert.equal(fs.readFileSync(path.join(dir,'server.pid'),'utf8'),String(pid));
 const exited=new Promise(resolve=>child.once('exit',resolve));child.kill('SIGTERM');assert.equal(await exited,0);
 assert.equal(fs.existsSync(path.join(dir,'server.pid')),false);
});
