'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const create=require('../app/update-routes');
async function call(route,method,path='/update',authed=true){let status,body;const res={writeHead(code){status=code;},end(text){body=JSON.parse(text);}};await route({method},res,new URL(path,'http://localhost'),authed);return {status,body};}
test('updater routes keep owner-local and recording protection; no changes means no restart',async()=>{
 let active=false,local=true,starts=0,applies=0,rollbacks=0,changed=false;
 const route=create({dataDir:'/unused',active:()=>active,isLocalReq:()=>local,localReqReason:()=>'',log:()=>{},restart:()=>starts++,updater:{check:async()=>({ok:true,current:'0.8.1',latest:'0.8.0',hasUpdate:false}),prevVersion:()=>'',prevInfo:()=>({}),apply:async(_log,canApply)=>{applies++;assert(canApply());return {updated:changed};},rollback:async(_log,canApply)=>{rollbacks++;assert(canApply());return {version:'0.8.0'};}}});
 assert.equal((await call(route,'GET')).body.current,'0.8.1');assert.equal((await call(route,'POST','/update',false)).status,401);
 local=false;assert.equal((await call(route,'POST')).status,403);local=true;active=true;for(const p of ['/update','/update-rollback'])assert.equal((await call(route,'POST',p)).status,409);assert.equal(applies+rollbacks,0);
 active=false;assert.equal((await call(route,'POST')).body.restarting,false);assert.equal(starts,0);changed=true;assert.equal((await call(route,'POST')).body.restarting,true);assert.equal(starts,1);
 assert.equal((await call(route,'POST','/update-rollback')).status,200);assert.equal(rollbacks,1);assert.equal(starts,2);
});
