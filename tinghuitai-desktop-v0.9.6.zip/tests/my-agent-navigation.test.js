'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const source=fs.readFileSync(require.resolve('../web/my-agent.js'),'utf8');
function fixture(shell=false){
 const calls=[],location={href:'http://127.0.0.1:47823/tinghuitai/work.html#focus',assign:url=>calls.push(url)},window=shell?{thtOpenMeeting:(...args)=>calls.push(args)}:{};
 const context={window,location,URL};vm.createContext(context);
 const helper=source.split('\n').find(line=>line.includes('function openMeeting('));vm.runInContext(helper,context);
 return {open:context.openMeeting,calls};
}
test('standalone workbench opens the canonical meeting with evidence timestamp and result',()=>{
 const f=fixture();assert.equal(f.open('meeting / one',42.5,'draft / 1'),true);
 const url=new URL(f.calls[0]);assert.equal(url.pathname,'/tinghuitai/');assert.equal(url.searchParams.get('id'),'meeting / one');assert.equal(url.searchParams.get('module'),'draft / 1');assert.equal(url.hash,'#t=42.5');assert.equal(url.searchParams.has('view'),false);
});
test('embedded shell keeps the current Agent and routes directly to the result',()=>{
 const f=fixture(true);f.open('meeting',15,'result');assert.deepEqual(f.calls,[['meeting',15,'result']]);
});
test('missing meeting cannot create a misleading navigation and negative timestamp is ignored',()=>{
 const f=fixture();assert.equal(f.open(''),false);assert.equal(f.calls.length,0);f.open('meeting',-1);assert.equal(new URL(f.calls[0]).hash,'');
});
