 'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),tools=require('../app/tools');
function fixture(t,extra=0){const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-search-scope-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));fs.mkdirSync(path.join(dir,'pending'));
 const write=(id,record)=>fs.writeFileSync(path.join(dir,'pending','sess-'+id+'.json'),JSON.stringify({id,...record}));
 write('carl',{title:'Carl CAD review',start:new Date('2026-10-06T12:00:00').toISOString(),participants:['Carl'],names:{S0:'Aaron Wang'},summary:'CAD delivery remains uncertain',transcript:[{t:30,speaker:'S0',text:'Only in original: voice evidence'}]});
 write('other',{title:'Other review',start:new Date('2026-10-05T12:00:00').toISOString(),participants:['Melanie'],summary:'CAD delivery',transcript:[{t:10,text:'CAD delivery'}]});
 for(let i=0;i<extra;i++)write('extra-'+i,{title:'Extra '+i,start:new Date('2026-10-01T12:00:00').toISOString()});
 return dir;
}
test('metadata lookup respects local date and recorded participants without exposing transcript',async t=>{
 const dir=fixture(t),r=await tools.call('meetings.search',{dateFrom:'2026-10-06',dateTo:'2026-10-06',participant:'Aaron',section:'metadata'},{dataDir:dir});
 assert.equal(r.ok,true);assert.equal(r.items.length,1);assert.equal(r.items[0].meetingId,'carl');assert.equal(r.items[0].sourceType,'meeting_metadata');assert.ok(!JSON.stringify(r).includes('voice evidence'));
 assert.equal((await tools.call('meetings.search',{participant:'Unknown',section:'metadata'},{dataDir:dir})).items.length,0);
});
test('notes lookup matches the title and keeps original speech for an explicit deep lookup',async t=>{
 const dir=fixture(t),r=await tools.call('meetings.search',{query:'Carl',section:'notes'},{dataDir:dir});assert.equal(r.items[0].kind,'metadata');
 const notes=await tools.call('meetings.search',{query:'voice evidence',section:'notes'},{dataDir:dir});assert.equal(notes.items.length,0);
 const speech=await tools.call('meetings.search',{query:'voice evidence',section:'all'},{dataDir:dir});assert.equal(speech.items[0].sourceType,'meeting_original');assert.equal(speech.items[0].speaker,'Aaron Wang');assert.equal(speech.items[0].at,30);
});
test('derived notes require verification and caller date scope never expands',async t=>{
 const dir=fixture(t),r=await tools.call('meetings.search',{query:'CAD delivery',dateFrom:'2026-10-06',dateTo:'2026-10-06',section:'notes'},{dataDir:dir});assert.ok(r.items.length);assert.ok(r.items.every(x=>x.meetingId==='carl'));const notes=r.items.filter(x=>x.kind!=='metadata');assert.ok(notes.length);assert.ok(notes.every(x=>x.sourceType==='derived_notes'&&x.requiresVerification));
 const empty=await tools.call('meetings.search',{dateFrom:'2026-10-04',dateTo:'2026-10-04',section:'metadata'},{dataDir:dir});assert.equal(empty.items.length,0);assert.equal(empty.incomplete,false);
});
test('invalid dates, reversed ranges and completely unscoped reads are rejected',async t=>{
 const dir=fixture(t);for(const args of [{dateFrom:'2026-02-30'},{dateFrom:'2026-10-07',dateTo:'2026-10-06'},{}])assert.equal((await tools.call('meetings.search',args,{dataDir:dir})).ok,false);
});
test('bounded history and unreadable files expose processing gaps rather than exhaustive no-match',async t=>{
 const dir=fixture(t,45),r=await tools.call('meetings.search',{query:'NoMatch'},{dataDir:dir});assert.equal(r.items.length,0);assert.equal(r.incomplete,true);assert.ok(r.unscannedFiles>0);
 const broken=fixture(t);fs.writeFileSync(path.join(broken,'pending','sess-broken.json'),'{');const fail=await tools.call('meetings.search',{query:'NoMatch'},{dataDir:broken});assert.equal(fail.incomplete,true);assert.equal(fail.unreadableFiles,1);
});

test('file modification time cannot impersonate a meeting date',async t=>{
 const dir=fixture(t);fs.writeFileSync(path.join(dir,'pending','sess-undated.json'),JSON.stringify({id:'undated',title:'Undated record'}));
 const metadata=await tools.call('meetings.search',{meetingId:'undated',section:'metadata'},{dataDir:dir});assert.equal(metadata.items[0].dateSource,'file_modified');
 const dated=await tools.call('meetings.search',{meetingId:'undated',dateFrom:'2026-10-01',section:'metadata'},{dataDir:dir});assert.equal(dated.items.length,0);assert.equal(dated.incomplete,true);assert.equal(dated.unknownDateMeetings,1);
});

test('missing participant metadata is a coverage gap, never an exhaustive no-match',async t=>{
 const dir=fixture(t);fs.writeFileSync(path.join(dir,'pending','sess-unnamed.json'),JSON.stringify({id:'unnamed',title:'No names',start:'2026-10-06T12:00:00Z'}));
 const r=await tools.call('meetings.search',{meetingId:'unnamed',participant:'Carl',section:'metadata'},{dataDir:dir});assert.equal(r.items.length,0);assert.equal(r.incomplete,true);assert.equal(r.unknownParticipantMeetings,1);
});
