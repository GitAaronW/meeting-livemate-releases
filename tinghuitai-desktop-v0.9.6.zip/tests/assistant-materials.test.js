'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),os=require('os'),path=require('path');
const materials=require('../app/assistant-materials');
test('material upload gives an opaque local ID and preserves useful text without accepting arbitrary paths',t=>{
 const dataDir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-material-'));t.after(()=>fs.rmSync(dataDir,{recursive:true,force:true}));
 const saved=materials.put(dataDir,{name:'../../brief.md',base64:Buffer.from('融资相关资料').toString('base64')});
 assert.equal(saved.name,'brief.md');assert.equal(saved.path,undefined);
 const [record]=materials.load(dataDir,[saved.id]);assert.equal(record.text,'融资相关资料');assert.ok(record.path.startsWith(path.join(dataDir,'state')));
 assert.throws(()=>materials.load(dataDir,['../../settings']),/编号/);assert.throws(()=>materials.put(dataDir,{name:'file.pdf',base64:'AAAA'}),/暂支持/);
 assert.throws(()=>materials.put(dataDir,{name:'fake.png',base64:Buffer.from('not a png').toString('base64')}),/不一致/);
 assert.throws(()=>materials.put(dataDir,{name:'binary.md',base64:Buffer.from([0,1,2]).toString('base64')}),/文字/);
 assert.throws(()=>materials.load(dataDir,Array(6).fill(saved.id)),/最多/);
});
