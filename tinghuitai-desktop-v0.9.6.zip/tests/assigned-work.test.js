'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),path=require('path'),os=require('os');
const {Intake,possible,promptContext}=require('../app/assigned-work');
const {adapters,slackMessage,larkMessage}=require('../app/tools/assigned-work-channels');
const {Hub}=require('../app/work-hub'),{Jobs}=require('../app/meeting-board-jobs');
const msg=(id='1',extra={})=>({provider:'slack',account:'slack:team:user',id,channel:'DABC',thread:id,sender:'boss',senderType:'user',userId:'user',addressed:true,at:1791330000000,version:'1',body:'Please prepare the QBR draft',url:'https://example.com/task/'+id,...extra});
function fixture(t,options={}){
 const dataDir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-intake-'));t.after(()=>fs.rmSync(dataDir,{recursive:true,force:true}));
 const hub=new Hub(dataDir,path.join(dataDir,'hub')),jobs=new Jobs(dataDir),calls={ask:0,prepare:0},pages={slack:[],lark:[]},clock=()=>1791330010000;
 const channels=Object.fromEntries(['slack','lark'].map(provider=>[provider,{identity:async()=>({key:'team:user',userId:'user',name:'Test User'}),page:async(a,flow,range)=>({messages:flow==='mention'?pages[provider]:[],next:null}),thread:async m=>({body:m.body,partial:false}),seed:async(a,i)=>msg(i.thread,{account:a.key})}]));
 const ask=async(s,u)=>{calls.ask++;return JSON.stringify({assigned:true,title:'QBR draft',evidence:'Please prepare the QBR draft'});};
 const prepare=async()=>{calls.prepare++;return {ok:true,text:'# QBR draft\n\nEvidence and editable first draft.',proposal:null};};
 const args={dataDir,hub,jobs,channels,env:()=>({}),clock,ask,prepare,...options};const intake=new Intake(args);intake.enable(true);return {intake,args,hub,jobs,calls,pages};
}
test('zero new messages means zero model calls, both channels checked',async t=>{const f=fixture(t);await f.intake.tick();await f.intake.tick();assert.equal(f.calls.ask,0);assert.equal(f.calls.prepare,0);assert.equal(f.intake.status().channels.length,2);});
test('bots, own messages, nonaddressed and announcements are filtered before model',async t=>{const f=fixture(t);for(const extra of [{senderType:'bot'},{sender:'user'},{addressed:false},{body:'公告：请准备 QBR'}])assert.equal(possible(msg('1',extra)),false);f.pages.slack=[msg('1',{senderType:'bot'}),msg('2',{addressed:false}),msg('3',{body:'谢谢你'})];await f.intake.tick();assert.equal(f.calls.ask,0);});
test('maximum two drafts per round; excess assignments are retained',async t=>{const f=fixture(t);f.pages.slack=[msg('1'),msg('2'),msg('3')];await f.intake.tick();assert.equal(f.calls.prepare,2);assert.equal(f.hub.data.tasks.length,2);assert.equal(Object.values(f.intake.state.records).filter(r=>r.state==='pending').length,1);await f.intake.tick();assert.equal(f.calls.prepare,3);assert.equal(f.hub.data.tasks.length,3);});
test('overlap and restart do not regenerate drafts or create duplicate tasks',async t=>{const f=fixture(t);f.pages.slack=[msg('1')];await f.intake.tick();const g=new Intake(f.args);await g.tick();assert.equal(f.calls.prepare,1);assert.equal(f.calls.ask,1);assert.equal(f.hub.data.tasks.length,1);assert.equal(f.jobs.assistantList().length,1);assert.equal(f.jobs.assistantList()[0].comment,'');});
test('multiple messages in one thread do not alternate versions on repeated scans',async t=>{const f=fixture(t);f.pages.slack=[msg('1'),msg('2',{thread:'1',body:'Please prepare the QBR draft by Friday'})];await f.intake.tick();await f.intake.tick();assert.equal(f.calls.prepare,1);});
test('manual edits survive updated assignment and become needs_review',async t=>{const f=fixture(t);f.pages.slack=[msg('1')];await f.intake.tick();const s=f.hub.data.sources[0];f.hub.update('sources',s.id,{notes:'My own edits'},s.revision);f.pages.slack=[msg('1',{version:'2',body:'Please prepare the QBR draft by Monday'})];await f.intake.tick();assert.equal(s.notes,'My own edits');assert.equal(s.changed,true);assert.equal(f.calls.prepare,1);assert.equal(Object.values(f.intake.state.records)[0].state,'needs_review');assert.match(s.body,/Monday/);});
test('CAS protects a draft edited while the model is working',async t=>{const f=fixture(t);f.args.prepare=async()=>{const s=f.hub.data.sources[0];f.hub.update('sources',s.id,{notes:'Concurrent user edit'},s.revision);return {ok:true,text:'AI overwrite'};};const g=new Intake(f.args);g.enable(true);f.pages.slack=[msg('1')];await g.tick();assert.equal(f.hub.data.sources[0].notes,'Concurrent user edit');assert.equal(f.hub.data.tasks.length,0);assert.match(Object.values(g.state.records)[0].error,/刷新/);});
test('cross-channel same document and task merges sources into one task',async t=>{const f=fixture(t),body='Please prepare the QBR draft https://docs.google.com/presentation/d/shared/edit';f.pages.slack=[msg('1',{body})];await f.intake.tick();f.pages.lark=[msg('2',{provider:'lark',body})];await f.intake.tick();assert.equal(f.calls.prepare,1);assert.equal(f.hub.data.tasks.length,1);assert.equal(f.hub.data.tasks[0].sourceIds.length,2);});
test('notifications failing to save retry delivery without regenerating work',async t=>{const f=fixture(t),notify=f.jobs.notify.bind(f.jobs);f.jobs.notify=()=>{throw Error('disk full');};f.pages.slack=[msg('1')];await f.intake.tick();assert.equal(Object.values(f.intake.state.records)[0].state,'prepared');assert.ok(Object.values(f.intake.state.records)[0].notification);f.jobs.notify=notify;await f.intake.tick();assert.equal(f.calls.prepare,1);assert.equal(f.jobs.assistantList().length,1);});
test('crash after Hub save recovers first draft without another model call',async t=>{const f=fixture(t);f.pages.slack=[msg('1')];await f.intake.tick();const r=Object.values(f.intake.state.records)[0];r.state='pending';delete r.notesHash;delete r.sourceId;delete r.taskId;f.intake.save();const g=new Intake(f.args);await g.tick();assert.equal(f.calls.prepare,1);assert.equal(f.hub.data.tasks.length,1);assert.equal(Object.values(g.state.records)[0].state,'prepared');});
test('account errors are visible and do not masquerade as empty success',async t=>{const f=fixture(t);f.args.channels.lark.identity=async()=>{throw Error('Keychain unavailable');};await f.intake.tick();assert.equal(f.intake.status().channels.find(c=>c.provider==='lark').status,'error');assert.match(f.intake.status().channels.find(c=>c.provider==='lark').error,/Keychain/);assert.equal(f.calls.prepare,0);});
test('page cursor and pending message survive restart before generation',async t=>{const f=fixture(t);let called;f.args.channels.slack.page=async(a,flow,r)=>{called=r.page;return {messages:flow==='mention'?[msg('1')]:[],next:flow==='mention'?'next':null};};await f.intake.collect('slack');const g=new Intake(f.args);assert.equal(Object.values(g.state.records).length,1);await g.collect('slack');assert.equal(g.state.accounts['slack:team:user'].flows.mention.range.page,'next');});
test('relevant context stays within one project and excludes assignment drafts',t=>{const f=fixture(t);f.hub.data.sources=[{id:'a',title:'QBR alpha',body:'QBR draft',projectId:'alpha'},{id:'b',title:'QBR beta',body:'QBR draft',projectId:'beta'},{id:'c',title:'QBR',body:'QBR draft',assignment:true,projectId:'alpha'}];const p=promptContext(f.hub,msg(), 'QBR');assert.equal(new Set(p.map(x=>x.projectId)).size,1);assert.ok(!p.some(x=>x.id==='c'));});
test('adapters use current user credentials, Slack search and Lark user search pagination',async()=>{
 const calls=[],slackCall=async(token,method,args)=>{calls.push({token,method,args});return {ok:true,data:method==='auth.test'?{user_id:'me',team_id:'team'}:{messages:{matches:[],pagination:{page_count:3}}}};};
 const larkRun=async args=>{calls.push({cli:args});return {ok:true,json:args[0]==='auth'?{appId:'app',identities:{user:{openId:'ou_me',available:true,userName:'Me'}}}:{data:{messages:[],has_more:true,page_token:'next'}}};};
 const a=adapters({env:()=>({SLACK_USER_TOKEN:'user-token',SLACK_BOT_TOKEN:'bot-token'}),slackCall,larkRun}),s=await a.slack.identity(),l=await a.lark.identity();
 assert.equal(l.userId,'ou_me');const range={since:1791330000000,end:1791330010000,page:1};assert.equal((await a.slack.page(s,'mention',range)).next,2);assert.equal(calls.at(-1).token,'user-token');assert.match(calls.at(-1).args.query,/<@me>/);assert.equal((await a.lark.page(l,'mention',{...range,page:'cursor'})).next,'next');assert.ok(calls.at(-1).cli.includes('--is-at-me'));assert.ok(!calls.at(-1).cli.some(s=>/\.\d{3}Z$/.test(s)));assert.ok(calls.at(-1).cli.includes('--no-reactions'));assert.ok(calls.at(-1).cli.includes('user'));await a.lark.page(l,'dm',range);assert.ok(calls.at(-1).cli.includes('p2p'));
});
test('adapter normalization preserves edit versions and addressed-user identity',()=>{assert.equal(slackMessage({ts:'1791330000.01',user:'boss',text:'<@me> draft',edited:{ts:'2'},channel:{id:'CABC'}},{key:'t',userId:'me'},'mention').version,'2');assert.equal(larkMessage({message_id:'om_1',chat_id:'oc_1',create_time:'1791330000000',sender:{id:'boss',sender_type:'user'},mentions:[{id:{open_id:'me'}}],content:'{"text":"请准备草稿"}'},{key:'l',userId:'me'},'mention').addressed,true);});
test('intake routes reject unauthenticated, nonlocal and cross-origin requests',async t=>{const f=fixture(t);for(const [ctx,origin,code] of [[{authed:false,isLocal:true},'',401],[{authed:true,isLocal:false},'',403],[{authed:true,isLocal:true},'https://other.example',403]]){let status;const req={method:'GET',headers:{host:'127.0.0.1:47823',origin}},res={writeHead:c=>status=c,end:()=>{}};assert.equal(await f.intake.route(req,res,new URL('http://local/assigned-work'),ctx),true);assert.equal(status,code);}});

test('identity failure blocks pending work from a previously ready account',async t=>{const f=fixture(t);f.pages.slack=[msg('1')];await f.intake.collect('slack');f.args.channels.slack.identity=async()=>{throw Error('Logged out');};await f.intake.tick();assert.equal(f.calls.prepare,0);assert.equal(f.calls.ask,0);assert.equal(f.intake.state.accounts['slack:team:user'].status,'error');});
test('account switch preserves but does not process previous user pending messages',async t=>{const f=fixture(t);f.pages.slack=[msg('1')];await f.intake.collect('slack');f.pages.slack=[];f.args.channels.slack.identity=async()=>({key:'other:new',userId:'new',name:'New User'});await f.intake.tick();assert.equal(f.calls.prepare,0);assert.equal(f.intake.state.accounts['slack:team:user'].status,'inactive');});
test('emptying the draft is a manual edit and cannot be silently restored',async t=>{const f=fixture(t);f.pages.slack=[msg('1')];await f.intake.tick();const s=f.hub.data.sources[0];f.hub.update('sources',s.id,{notes:''},s.revision);f.pages.slack=[msg('1',{version:'2'})];await f.intake.tick();assert.equal(s.notes,'');assert.equal(f.calls.prepare,1);assert.equal(Object.values(f.intake.state.records)[0].state,'needs_review');});
test('updates to a merged origin preserve the single task and flag both sources',async t=>{const f=fixture(t),body='Please prepare the QBR draft https://docs.google.com/presentation/d/shared/edit';f.pages.slack=[msg('1',{body})];await f.intake.tick();f.pages.lark=[msg('2',{provider:'lark',body})];await f.intake.tick();f.pages.lark=[msg('2',{provider:'lark',body:body+' by Monday',version:'2'})];await f.intake.tick();assert.equal(f.calls.prepare,1);assert.equal(f.hub.data.tasks.length,1);assert.equal(f.hub.data.sources.find(s=>s.notes).changed,true);assert.ok(Object.values(f.intake.state.records).every(r=>r.state==='needs_review'));});
test('known assignment thread replies without a new mention are watched; unchanged replies make no model calls',async t=>{const f=fixture(t);f.pages.slack=[msg('1')];await f.intake.tick();const reply=msg('2',{thread:'1',body:'Please prepare the QBR draft by Monday',addressed:false});f.args.channels.slack.thread=async m=>({body:m.body,snapshot:[msg('1'),reply]});f.pages.slack=[];await f.intake.tick();assert.equal(f.calls.prepare,2);await f.intake.tick();assert.equal(f.calls.prepare,2);assert.equal(f.hub.data.tasks.length,1);});

test('Slack search-only grant reads the exact thread with current user and marks partial',async()=>{
 const root='1790740976.390849',reply='1790782071.009399',calls=[];
 const messages=[{ts:reply,user:'boss',text:'Final due October 12',channel:{id:'CABC',name:'qbr-team'},permalink:'https://team.slack.com/archives/CABC/p1790782071009399?thread_ts='+root},{ts:root,user:'boss',text:'<@me> Please prepare QBR',channel:{id:'CABC',name:'qbr-team'},permalink:'https://team.slack.com/archives/CABC/p1790740976390849?thread_ts='+root},{ts:'1790780000.1',user:'other',text:'Unrelated work',channel:{id:'CABC',name:'qbr-team'},permalink:'https://team.slack.com/archives/CABC/p17907800001?thread_ts=1790000000.1'},{ts:'1790780000.2',user:'other',text:'Wrong channel',channel:{id:'CXYZ'},thread_ts:root}];
 const a=adapters({env:()=>({SLACK_USER_TOKEN:'mine',SLACK_BOT_TOKEN:'other'}),slackCall:async(token,method,args)=>{calls.push({token,method,args});return method==='conversations.replies'?{ok:false,error:'Slack 拒绝：missing_scope'}:{ok:true,data:{messages:{matches:/in:CABC/.test(args.query)?[]:messages,pagination:{page_count:1}}}};}});
 const t=await a.slack.seed({key:'t',userId:'me'},{channel:'CABC',thread:root});
 assert.equal(t.partial,true);assert.match(t.readNote,/可能不完整/);assert.equal(t.addressed,true);assert.deepEqual(t.snapshot.map(m=>m.id),[root,reply]);assert.ok(!t.body.includes('Unrelated'));assert.ok(calls.every(c=>c.token==='mine'));assert.equal(calls.length,3);assert.equal(calls[1].args.query,'<@me> on:2026-09-30');assert.equal(calls[2].args.query,'in:qbr-team after:2026-09-29');assert.equal(slackMessage(messages[0],{key:'t',userId:'me'},'mention').thread,root);
});
test('Slack fallback is bounded and requires verified original author and addressee',async()=>{
 let searches=0;const a=adapters({env:()=>({SLACK_USER_TOKEN:'mine'}),slackCall:async(token,method,args)=>method==='conversations.replies'?{ok:false,error:'missing_scope'}:(searches++,{ok:true,data:{messages:{matches:[{ts:'1790782071.009399',thread_ts:'1790740976.390849',channel:{id:'CABC'},user:'boss',text:'Reply only'}],pagination:{page_count:100}}}})});
 await assert.rejects(a.slack.seed({key:'t',userId:'me'},{channel:'CABC',thread:'1790740976.390849'}),/未读到原帖/);assert.equal(searches,3);
});
test('Slack auth or connection failure never falls back to search',async()=>{
 for(const error of ['Slack 拒绝：invalid_auth','Slack 拒绝：not_in_channel','Slack 连不上：timeout']){
  const methods=[],a=adapters({env:()=>({SLACK_USER_TOKEN:'mine'}),slackCall:async(token,method)=>{methods.push(method);return {ok:false,error};}});
  await assert.rejects(a.slack.thread(msg()),new RegExp(error));assert.deepEqual(methods,['conversations.replies']);
 }
});
test('partial evidence is saved with the draft and passed to the model',async t=>{
 let context;const f=fixture(t,{prepare:async c=>(context=c.context,{ok:true,text:'Evidence-backed partial first draft'})});f.args.channels.slack.thread=async m=>({body:m.body,partial:true,readNote:'搜索读取；线程可能不完整'});f.pages.slack=[msg('1')];await f.intake.tick();assert.equal(f.hub.data.sources[0].assignmentPartial,true);assert.match(f.hub.data.sources[0].assignmentReadNote,/可能不完整/);assert.match(context,/不得宣称已读取完整/);
});
test('records with no verified active account cannot be processed',async t=>{
 const f=fixture(t);const r=f.intake.remember(msg('1'));await f.intake.process([r]);assert.equal(f.calls.ask,0);assert.equal(f.calls.prepare,0);
});


test('explicit task template is included before generic context without crossing project boundaries',t=>{
 const f=fixture(t);f.hub.data.sources=[{id:'s-generic',title:'QBR draft project',body:'QBR prepare draft',projectId:'hardware'},{id:'s-template',title:'Doc 2 Software Exploration',body:'Actual six-slide template',projectId:''},{id:'s-team',title:'QBR software',body:'Team evidence',projectId:''},{id:'s-other',title:'QBR',body:'Other project',projectId:'other'}];
 const p=promptContext(f.hub,msg(),'QBR','Use s-template as the actual template');
 assert.equal(p[0].id,'s-template');assert.match(p[0].body,/Actual six-slide/);assert.ok(p.some(s=>s.id==='s-team'));assert.ok(p.every(s=>s.projectId===''));
});
test('highest relevant unassigned source is not discarded for a weaker named project',t=>{
 const f=fixture(t);f.hub.data.sources=[{id:'s-template',title:'QBR prepare draft',body:'QBR prepare draft',projectId:''},{id:'s-generic',title:'QBR unrelated',body:'',projectId:'hardware'}];
 assert.deepEqual(promptContext(f.hub,msg(),'QBR').map(s=>s.id),['s-template']);
});
test('a document linked by the assignment selects its existing local template',t=>{
 const f=fixture(t);f.hub.data.sources=[{id:'s-template',title:'Actual template',body:'Known template',url:'https://docs.google.com/presentation/d/template/edit',projectId:'software'},{id:'s-generic',title:'QBR prepare draft',body:'QBR prepare draft',projectId:'hardware'}];
 const p=promptContext(f.hub,msg('1',{body:'Please prepare QBR https://docs.google.com/presentation/d/template/view'}),'QBR');assert.deepEqual(p.map(s=>s.id),['s-template']);
});
test('an explicit task project prevents referenced templates from crossing its boundary',t=>{
 const f=fixture(t);f.hub.data.sources=[{id:'s-template',title:'QBR',body:'QBR prepare draft',projectId:'other'},{id:'s-right',title:'QBR',body:'QBR prepare draft',projectId:'software'}];
 const p=promptContext(f.hub,msg('1',{projectId:'software'}),'QBR','s-template');assert.deepEqual(p.map(s=>s.id),['s-right']);
});

test('third party thread keywords cannot rewrite a prepared draft',async t=>{
 const f=fixture(t);f.pages.slack=[msg('1')];await f.intake.tick();const r=Object.values(f.intake.state.records)[0],before=r.fingerprint;
 f.pages.slack=[];f.args.channels.slack.thread=async m=>({body:m.body,snapshot:[msg('2',{thread:'1',sender:'other',addressed:false,body:'Please review this by Monday'})]});
 await f.intake.tick();await f.intake.tick();assert.equal(f.calls.prepare,1);assert.equal(r.fingerprint,before);assert.equal(r.stale,true);assert.equal(r.state,'prepared');
});
test('third party updates from collection obey the same authority guard',async t=>{
 const f=fixture(t);f.pages.slack=[msg('1')];await f.intake.tick();f.pages.slack=[msg('2',{thread:'1',sender:'other',addressed:false,body:'Please prepare another draft'})];await f.intake.tick();assert.equal(f.calls.prepare,1);
});
test('explicitly addressed new requirements remain actionable',async t=>{
 const f=fixture(t);f.pages.slack=[msg('1')];await f.intake.tick();f.pages.slack=[msg('2',{thread:'1',sender:'other',addressed:true,body:'Please prepare the QBR draft by Monday'})];await f.intake.tick();assert.equal(f.calls.prepare,2);
});
test('assigner cancellation preserves the draft and surfaces source review without another model call',async t=>{
 const f=fixture(t);f.pages.slack=[msg('1')];await f.intake.tick();const before=f.hub.data.sources[0].notes;
 f.pages.slack=[];f.args.channels.slack.thread=async m=>({body:m.body,snapshot:[msg('2',{thread:'1',addressed:false,body:'取消这个任务'})]});await f.intake.tick();
 assert.equal(f.calls.prepare,1);assert.equal(f.hub.data.sources[0].notes,before);assert.equal(f.hub.data.sources[0].changed,true);assert.equal(Object.values(f.intake.state.records)[0].state,'needs_review');
});
test('no hit is observable per stream rather than presented as a verified feed',async t=>{
 const f=fixture(t);await f.intake.tick();await f.intake.tick();await f.intake.tick();const s=f.intake.status().channels.find(x=>x.provider==='slack');assert.equal(s.flows.mention.lastHits,0);assert.equal(s.flows.dm.emptyRuns,3);assert.ok(s.flows.dm.checkedAt);assert.equal(f.calls.prepare,0);
});
test('provider retry-after defers polling while allowing the other provider',async t=>{
 const f=fixture(t);let attempts=0;f.args.channels.slack.page=async()=>{attempts++;throw Object.assign(Error('ratelimited'),{retryAfter:300});};await f.intake.tick();await f.intake.tick();assert.equal(attempts,1);assert.equal(f.intake.status().channels.find(x=>x.provider==='lark').status,'ready');assert.ok(f.intake.status().channels.find(x=>x.provider==='slack').retryAt);
});
test('seed title comes from user requirements rather than the current QBR example',async t=>{
 const f=fixture(t);await f.intake.collect('slack');const r=f.intake.remember(msg(),{force:true,instruction:'Prepare QBR software experiments'});assert.equal((await f.intake.classify(r)).title,'Prepare QBR software experiments');
});
test('ordinary Lark message watches only explicit related replies and discloses partial scope',async()=>{
 const requests=[],a=adapters({env:()=>({}),larkRun:async args=>{requests.push(args);return {ok:true,data:{messages:[{message_id:'om_root',sender:{id:'boss'},create_time:'1791330000000',content:'{"text":"prepare draft"}'},{message_id:'om_reply',parent_id:'om_root',sender:{id:'boss'},create_time:'1791330001000',content:'{"text":"取消这个任务"}'},{message_id:'om_other',sender:{id:'other'},content:'{"text":"Cancel something unrelated"}'}]}};}});
 const r=await a.lark.thread(msg('om_root',{provider:'lark',thread:'om_root',channel:'oc_chat'}));assert.equal(r.partial,true);assert.match(r.readNote,/独立后续/);assert.deepEqual(r.snapshot.map(x=>x.id),['om_root','om_reply']);assert.match(r.body,/取消/);assert.ok(!r.body.includes('unrelated'));assert.ok(requests[0].includes('--chat-id'));
});
test('Lark search timestamps use explicit timezone offsets',async()=>{
 let args;const a=adapters({env:()=>({}),larkRun:async x=>(args=x,{ok:true,data:{messages:[]}})});await a.lark.page({key:'test',userId:'me'},'mention',{since:1791330000000,end:1791330010000});assert.match(args[args.indexOf('--start')+1],/[+-]\d{2}:\d{2}$/);assert.match(args[args.indexOf('--end')+1],/[+-]\d{2}:\d{2}$/);
});
test('Slack call preserves rate-limit metadata for intake backoff',async()=>{
 const {call}=require('../app/tools/slack');const r=await call('mine','search.messages',{},async()=>({status:429,headers:{get:()=> '600'},json:async()=>({ok:false,error:'ratelimited'})}));assert.equal(r.retryAfter,600);assert.equal(r.status,429);
});
test('Lark formatted timestamps and native message link survive normalization',()=>{
 const m=larkMessage({message_id:'om_test',chat_id:'oc_test',sender:{id:'boss'},create_time:'2026-10-02 01:41',update_time:'2026-10-02 01:42',content:'{"text":"Please draft this"}',message_app_link:'https://applink.larksuite.com/client/chat/open?message_id=om_test'},{key:'a',userId:'me'},'dm');assert.equal(m.at,new Date('2026-10-02T01:41:00').getTime());assert.ok(m.at>0);assert.match(m.url,/message_id=om_test/);assert.match(m.body,/draft/);
});

test('thread rate limits defer watching and drafting until retry-after without model work',async t=>{
 const f=fixture(t);f.pages.slack=[msg('1')];await f.intake.tick();f.pages.slack=[];let reads=0;
 f.args.channels.slack.thread=async()=>{reads++;throw Object.assign(Error('ratelimited'),{retryAfter:600});};
 await f.intake.tick();await f.intake.tick();assert.equal(reads,1);assert.equal(f.calls.prepare,1);assert.equal(f.intake.state.accounts['slack:team:user'].status,'error');assert.ok(f.intake.state.accounts['slack:team:user'].retryAt);assert.equal(f.intake.status().channels.find(x=>x.provider==='lark').status,'ready');
});
test('draft thread rate limits also defer further requests for that account',async t=>{
 const f=fixture(t);f.pages.slack=[msg('1'),msg('2')];let reads=0;
 f.args.channels.slack.thread=async()=>{reads++;throw Object.assign(Error('ratelimited'),{retryAfter:600});};
 await f.intake.tick();await f.intake.tick();assert.equal(reads,1);assert.equal(f.calls.prepare,0);assert.equal(f.calls.ask,1);
});
