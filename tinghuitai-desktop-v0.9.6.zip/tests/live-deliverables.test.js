'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),os=require('os'),path=require('path');
const {create,candidate}=require('../app/live-deliverables'),{Hub}=require('../app/work-hub'),jobs=require('../app/meeting-board-jobs');
const wait=()=>new Promise(r=>setTimeout(r,5));
function setup(t,ask){const dataDir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-draft-'));t.after(()=>fs.rmSync(dataDir,{recursive:true,force:true}));const hub=new Hub(dataDir,path.join(dataDir,'hub'));const session={id:'meeting-draft',uiLang:'zh',title:'AI 硬件脑暴',start:new Date().toISOString(),transcript:[{id:'s1',text:'Aaron 请准备 AI 硬件的脑暴方案，做出典型一天的看板。',at:10}]};return {dataDir,hub,session,consider:create({dataDir,hub,ask})};}
const value={title:'AI 硬件的一天',goal:'做一份典型一天的可展示脑暴看板',form:'timeline',quote:'准备 AI 硬件的脑暴方案'};
test('real meeting service detects an evidenced objective and saves an editable draft on its own canvas', {timeout:15000}, async t=>{
 const http=require('http'),net=require('net'),{spawn}=require('child_process'),WS=require('ws');
 const dataDir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-live-draft-http-'));let child,ws;
 const calls=[],requests=[];
 const api=http.createServer((req,res)=>{let body='';req.on('data',d=>body+=d);req.on('end',()=>{
  const request=JSON.parse(body),system=request.messages[0].content;calls.push(system);requests.push(request);
  const content=JSON.stringify(system.includes('Create the actual useful meeting deliverable')?
   {title:value.title,body:'## 早晨出门\nAI 提前整理当天行程；胸针用一次轻提示确认。\n## 待验证\n是否减少掏手机。',nodes:[{label:'早晨',detail:'整理行程'}]}:
   {md:'',deliverable:value});
  res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify({choices:[{message:{content}}]}));
 })});
 await new Promise(r=>api.listen(0,'127.0.0.1',r));
 const reserve=net.createServer();await new Promise(r=>reserve.listen(0,'127.0.0.1',r));const port=reserve.address().port;await new Promise(r=>reserve.close(r));
 t.after(async()=>{ws?.terminate();if(child&&!child.exitCode){child.kill();await Promise.race([new Promise(r=>child.once('exit',r)),new Promise(r=>setTimeout(r,1000))]);}api.closeAllConnections();await new Promise(r=>api.close(r));fs.rmSync(dataDir,{recursive:true,force:true});});
 fs.writeFileSync(path.join(dataDir,'settings.json'),JSON.stringify({RELAY_TOKEN:'t'.repeat(32),ARCHIVE_TARGET:'local',LOCAL_GATE:'off',LLM_CHAIN:[{type:'openai',name:'test',baseUrl:'http://127.0.0.1:'+api.address().port+'/v1',key:'test',models:{live:'test',post:'test'}}]}));
 child=spawn(process.execPath,[path.join(__dirname,'../app/server.js')],{env:{...process.env,THT_DATA_DIR:dataDir,THT_PORT:String(port),THT_NO_OPEN:'1',THT_TEST:'1',THT_LLM_AUTOPICK:'off',THT_LARK_CLI:'/usr/bin/false',LIVE_CARD_WARMUP:'off'},stdio:'ignore'});
 const base='http://127.0.0.1:'+port;
 for(let i=0;i<80;i++){try{if((await fetch(base+'/health')).ok)break;}catch{}await new Promise(r=>setTimeout(r,50));}
 ws=new WS(base.replace('http','ws')+'?token='+'t'.repeat(32));await new Promise((r,j)=>{ws.once('open',r);ws.once('error',j);});
 ws.send(JSON.stringify({type:'start',sessionId:'live-draft-acceptance',rate:16000,title:'AI 硬件脑暴',projectId:'software-test'}));
 await new Promise(r=>setTimeout(r,200));
 ws.send(JSON.stringify({type:'__test_final',triage:true,text:'Aaron 请准备 AI 硬件的脑暴方案，做出典型一天的看板。我们需要从真实使用场景出发，描述用户正在做什么、AI 如何帮忙，以及硬件是否必要，用来现场展示讨论。'}));
 let board;
 for(let i=0;i<100;i++){
  const r=await fetch(base+'/meeting-board?id=live-draft-acceptance',{headers:{Authorization:'Bearer '+'t'.repeat(32)}});board=await r.json();
  if(board.source?.board?.modules?.length)break;await new Promise(r=>setTimeout(r,50));
 }
 assert.equal(calls.filter(s=>s.includes('Create the actual useful meeting deliverable')).length,1);assert.equal(requests.find(r=>r.messages[0].content.includes('Create the actual useful meeting deliverable')).max_tokens,1800);
 const module=board.source?.board?.modules?.[0];assert(module,'same meeting has the generated artifact');
 assert.equal(module.title,value.title);assert.equal(module.view,'timeline');assert.match(module.context,/AI 草稿/);assert.match(module.body,/是否减少掏手机/);assert(module.sourceRefs.length);
});
test('candidate requires exact meeting evidence; inference alone does not launch a task',()=>{assert.equal(candidate(value,[]),null);assert.equal(candidate({...value,quote:'请发邮件'},[{id:'s',text:'我们聊 AI 硬件'}]),null);});
test('local draft grows on the same board, retains concurrent edits, and never becomes a confirmed task',async t=>{let resolve;const x=setup(t,()=>new Promise(r=>resolve=r));const j=x.consider(x.session,value);assert(j);assert.equal(x.consider(x.session,value),null);while(!resolve)await wait();const src=x.hub.data.sources[0];x.hub.update('sources',src.id,{board:{modules:[{id:'edited',kind:'note',title:'Aaron 编辑',body:'不要覆盖',edited:true,sourceRefs:[]}]}},src.revision);resolve(JSON.stringify({title:value.title,body:'## 早晨\n- 用户出门；AI 梳理当天安排。\n## 待验证\n- 硬件是否真的减少手机操作。'}));while(['queued','running','thinking'].includes(jobs.get(x.dataDir).find(x.session.id,j.id).state))await wait();const result=jobs.get(x.dataDir).find(x.session.id,j.id);assert.equal(result.state,'completed');const mods=x.hub.data.sources[0].board.modules;assert.equal(mods.length,2);assert.equal(mods[0].body,'不要覆盖');assert.match(mods[1].context,/AI 草稿/);assert.deepEqual(mods[1].sourceRefs,['s1']);assert.equal(x.hub.data.tasks.length,0);assert.equal(x.consider(x.session,value),null);});
test('stopping a draft prevents a late model result from writing to the board',async t=>{let resolve;const x=setup(t,()=>new Promise(r=>resolve=r));const j=x.consider(x.session,value);while(!resolve)await wait();jobs.get(x.dataDir).cancel(x.session.id,j.id);resolve('{"body":"must not save"}');await wait();assert.equal(jobs.get(x.dataDir).find(x.session.id,j.id).state,'cancelled');assert.equal(x.hub.data.sources[0].board?.modules?.length||0,0);});
test('changing project context discards an in-flight draft',async t=>{let resolve;const x=setup(t,()=>new Promise(r=>resolve=r));const j=x.consider(x.session,value);while(!resolve)await wait();x.hub.data.sources[0].projectId='other-project';resolve('{"body":"wrong project"}');await wait();assert.equal(jobs.get(x.dataDir).find(x.session.id,j.id).state,'failed');assert.equal(x.hub.data.sources[0].board?.modules?.length||0,0);});

test('both live parsers retain the evidenced deliverable and keep insight rendering separate',async t=>{
 const L=require('../app/live-insight'),D=require('../app/live-deliverables');
 for(const rapid of [false,true]){
  const parsed=(rapid?L.parseRapid:L.parse)(JSON.stringify({md:'先把一个真实场景做透。',insights:[{kind:'question',point:'先用一个真实场景检验硬件价值。',confidence:.9}],deliverable:value}));
  assert.deepEqual(parsed.deliverable,value);
  const x=setup(t,async()=>'{"body":"## 一天的场景\\n- 早晨整理安排。"}');
  assert(x.consider(x.session,parsed.deliverable));
  const normalized=rapid?L.normalizeRapid(parsed):L.normalize(parsed);
  assert(normalized.insight);assert(!JSON.stringify(normalized).includes('deliverable'));
  assert.match(D.detectionPrompt({rapid}),/Return one JSON object/);
  assert(!L.userPrompt({rapid,withDeliverable:true}).includes('markdown，没有'));
 }
});
test('native feed uses the same deliverable pipeline and holds at most two concurrent drafts',async t=>{
 const {InsightFeed}=require('../app/native-meeting');const pending=[];
 const x=setup(t,()=>new Promise(r=>pending.push(r)));
 const feed=new InsightFeed({dataDir:x.dataDir,session:x.session,ask:async()=>JSON.stringify({suggestion:null,insights:[],deliverable:value}),onDeliverable:x.consider,onChange(){}});
 t.after(()=>feed.close());feed.revision=1;await feed.run();await wait();
 assert.equal(jobs.get(x.dataDir).items.length,1);
 const row={id:'s2',text:'比较耳机和胸针各自适合什么交互场景',at:20};x.session.transcript.push(row);
 assert(x.consider(x.session,{title:'形态比较',goal:'比较耳机与胸针的交互取舍',form:'comparison',quote:row.text}));
 x.session.transcript.push({id:'s3',text:'把下周评审的资料排一下准备顺序',at:30});
 assert.equal(x.consider(x.session,{title:'准备安排',goal:'整理下周评审资料准备计划',quote:'把下周评审的资料排一下准备顺序'}),null);
 while(pending.length<2)await wait();for(const resolve of pending)resolve('{"body":"AI 草稿"}');await wait();
});

test('automatic draft cap is configurable and does not call the model after reaching it',async t=>{
 const x=setup(t,async()=>'{"body":"draft"}');const store=jobs.get(x.dataDir);
 for(let i=0;i<6;i++)store.items.push({id:'old-'+i,meetingId:x.session.id,action:'draft',state:'completed',request:{goal:'unrelated '+i,quote:'old '+i}});
 assert.equal(x.consider(x.session,value),null);
 const logs=[];const disabled=create({...x,ask:()=>{throw Error('must not run')},env:()=>({LIVE_DRAFT_MAX_PER_MEETING:0}),log:m=>logs.push(m)});
 assert.equal(disabled(x.session,value),null);assert.match(logs[0],/limit reached/);
});
