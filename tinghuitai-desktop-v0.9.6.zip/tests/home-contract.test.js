'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {check}=require('../scripts/check-home-contract');
const root=path.resolve(__dirname,'..');
test('production source fixes the workspace home',()=>assert.equal(check(root),true));
test('deployment refuses a secondary checkout or missing workspace',t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-home-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 assert.throws(()=>check(dir),/唯一维护目录/);
 assert.throws(()=>check(dir,{requireCanonical:false}),/缺少新版工作区/);
});
