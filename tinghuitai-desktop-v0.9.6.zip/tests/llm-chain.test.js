'use strict';
// 模型适配层：换提供方只改配置；同一份调用在「命令行」和「OpenAI 兼容接口」两类适配器上都跑得通；降级不静默。
const test=require('node:test'),assert=require('node:assert/strict');
const llm=require('../app/llm');
const okFetch=(seen)=>async(url,opt)=>{seen.push({url,body:JSON.parse(opt.body),auth:opt.headers.Authorization});return{json:async()=>({model:'served-model',choices:[{message:{content:'{"highlights":[]}'}}],usage:{prompt_tokens:5,completion_tokens:2}})};};
const badFetch=async()=>({json:async()=>({error:{type:'invalid_request_error',message:'no balance'}})});

test('老设置推出的降级链和以前一致：先命令行，再 OpenAI 兼容接口；显示名、档位模型都对',()=>{
 const chain=llm.chainOf({LLM_PROVIDER:'claude',DEEPSEEK_API_KEY:'k',LLM_BASE_URL:'https://api.deepseek.com',LLM_MODEL:'deepseek-chat',LLM_MODEL_QUICK:''});
 assert.deepEqual(chain.map(p=>[p.type,p.label]),[['cli','Claude'],['openai','DeepSeek']]);
 assert.equal(llm.pickModel(chain[0],'live'),'sonnet');assert.equal(llm.pickModel(chain[0],'triage'),'sonnet');assert.equal(llm.pickModel(chain[0],'post'),'opus');
 assert.equal(llm.pickModel(chain[1],'live'),'deepseek-chat');
 assert.deepEqual(llm.chainOf({LLM_PROVIDER:'',DEEPSEEK_API_KEY:''}),[]);
});
test('Codex 可单独配置 quick 模型；留空时沿用 Codex 当前默认模型',()=>{
 const explicit=llm.chainOf({LLM_PROVIDER:'codex',LLM_MODEL_QUICK:'fast-model'})[0];
 assert.equal(llm.pickModel(explicit,'quick'),'fast-model');
 assert.equal(llm.pickModel(llm.chainOf({LLM_PROVIDER:'codex',LLM_MODEL_QUICK:''})[0],'quick'),'');
});
test('换一家 OpenAI 兼容提供方只改配置：地址、密钥字段、档位模型都从 LLM_CHAIN 来，业务调用不变',async()=>{
 const seen=[],env={QWEN_API_KEY:'qk',LLM_CHAIN:[{type:'openai',name:'通义',baseUrl:'https://dashscope.aliyuncs.com/compatible-mode/v1/',keyFrom:'QWEN_API_KEY',models:{live:'qwen-turbo',post:'qwen-max'}}]};
 const r=await llm.ask(env,{kind:'triage',system:'s',user:'u',maxTokens:100,fetchImpl:okFetch(seen)});
 assert.equal(r.text,'{"highlights":[]}');assert.equal(r.provider,'通义');assert.equal(r.degraded,false);assert.deepEqual(r.usage,{in:5,out:2});
 assert.equal(seen[0].url,'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions');assert.equal(seen[0].body.model,'qwen-turbo');assert.equal(seen[0].auth,'Bearer qk');
 const post=await llm.ask(env,{kind:'post',system:'s',user:'u',fetchImpl:okFetch(seen)});assert.equal(seen[1].body.model,'qwen-max');assert.equal(post.model,'served-model');
});
test('前一家失败、后一家成功 → degraded 且带第一家的原因码；全失败 → 没有正文、原因码是最后一家的；没配 → no_provider；缺密钥的条目被跳过',async()=>{
 const env={A:'a',B:'b',LLM_CHAIN:[{type:'openai',name:'甲',baseUrl:'https://a.example/v1',keyFrom:'A'},{type:'openai',name:'缺钥匙',baseUrl:'https://x.example/v1',keyFrom:'NOPE'},{type:'openai',name:'乙',baseUrl:'https://b.example/v1',keyFrom:'B'}]};
 assert.deepEqual(llm.chainOf(env).map(p=>p.label),['甲','乙']);
 const seen=[],mixed=async(url,opt)=>url.startsWith('https://a.')?badFetch():okFetch(seen)(url,opt);
 const r=await llm.ask(env,{kind:'live',system:'s',user:'u',fetchImpl:mixed});
 assert.equal(r.provider,'乙');assert.equal(r.degraded,true);assert.equal(r.degradedReason,'api:invalid_request_error');assert.deepEqual(r.attempts,[{provider:'甲',errorCode:'api:invalid_request_error'}]);
 const dead=await llm.ask(env,{kind:'live',system:'s',user:'u',fetchImpl:badFetch});
 assert.equal(dead.text,null);assert.equal(dead.errorCode,'api:invalid_request_error');assert.equal(dead.attempts.length,2);assert.equal(dead.degraded,false);
 assert.equal((await llm.ask({},{system:'s',user:'u'})).errorCode,'no_provider');
});
test('业务代码里没有品牌分支：server.js 不再直接认 deepseek / claude 的地址和模型名',()=>{
 const src=require('fs').readFileSync(require('path').join(__dirname,'../app/server.js'),'utf8');
 assert.doesNotMatch(src,/chat\/completions/);assert.doesNotMatch(src,/deepseek/i);assert.doesNotMatch(src,/cliLlm\.askDetailed/);
});
test('跳过链上前几家（熔断）：一样出结果，但算降级；每一家的超时由调用方定',async()=>{
 const seen=[],env={A:'a',B:'b',LLM_CHAIN:[{type:'openai',name:'甲',baseUrl:'https://a.example/v1',keyFrom:'A'},{type:'openai',name:'乙',baseUrl:'https://b.example/v1',keyFrom:'B'}]};
 const r=await llm.ask(env,{kind:'post',system:'s',user:'u',skip:1,fetchImpl:okFetch(seen)});
 assert.equal(r.provider,'乙');assert.equal(r.degraded,true);assert.equal(r.degradedReason,'skipped');assert.equal(r.skipped,1);
 assert.equal(seen.length,1,'被跳过的那家一次都不该碰');assert.equal(seen[0].url,'https://b.example/v1/chat/completions');
 assert.equal((await llm.ask(env,{system:'s',user:'u',skip:9,fetchImpl:okFetch(seen)})).errorCode,'chain_exhausted');
 // noFallback 压过 skip：这一次只许走第一家
 const only=await llm.ask(env,{system:'s',user:'u',skip:1,noFallback:true,fetchImpl:okFetch(seen)});
 assert.equal(only.provider,'甲');assert.equal(only.degraded,false);
});
test('接口这条路：温度可以按调用方定，输入超上限先截，会后那套老规矩留住',async()=>{
 const seen=[],env={A:'a',LLM_CHAIN:[{type:'openai',name:'甲',baseUrl:'https://a.example/v1',keyFrom:'A'}]};
 await llm.ask(env,{system:'s',user:'x'.repeat(60000),temperature:0.1,maxTokens:3000,fetchImpl:okFetch(seen)});
 assert.equal(seen[0].body.temperature,0.1);assert.equal(seen[0].body.max_tokens,3000);
 assert.equal(seen[0].body.messages[1].content.length,48000,'接口这条路的输入上限搬进了适配层');
 await llm.ask(env,{system:'s',user:'u',fetchImpl:okFetch(seen)});
 assert.equal(seen[1].body.temperature,0.2,'不指定还是老默认');
});
test('即时反应通道可跳过全量 THINK.md，减少重复上下文；其他调用仍带思考指南',async()=>{
 const fs=require('fs'),os=require('os'),path=require('path'),dir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-think-'));
 fs.writeFileSync(path.join(dir,'THINK.md'),'UNIQUE_THINK_GUIDE');
 const seen=[],env={A:'a',LLM_CHAIN:[{type:'openai',name:'甲',baseUrl:'https://a.example/v1',keyFrom:'A'}]};
 await llm.ask(env,{system:'FAST_SYSTEM',user:'u',dataDir:dir,thinkGuide:false,fetchImpl:okFetch(seen)});
 await llm.ask(env,{system:'SLOW_SYSTEM',user:'u',dataDir:dir,fetchImpl:okFetch(seen)});
 assert.equal(seen[0].body.messages[0].content,'FAST_SYSTEM');
 assert.ok(seen[1].body.messages[0].content.includes('UNIQUE_THINK_GUIDE') && seen[1].body.messages[0].content.includes('SLOW_SYSTEM'));
 fs.rmSync(dir,{recursive:true,force:true});
});
test('用量账本只有一种行：适配层记一笔，服务端和会后管线共用',()=>{
 const fs=require('fs'),os=require('os'),path=require('path');
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-usage-'));
 llm.noteUsage(dir,{text:'回答',usage:{in:12,out:3},usageProvider:'api',model:'m'},{tier:'post',sessionId:'s1',purpose:'brief'});
 llm.noteUsage(dir,{text:'四个字',usageProvider:'claude',model:'opus'},{system:'ab',user:'cdef',tier:'post',sessionId:'s1',purpose:'summary'});
 llm.noteUsage(dir,{text:'不记',usageProvider:'api',model:'m'},{tier:'post',sessionId:'s1',purpose:'x'});
 const rows=fs.readFileSync(path.join(dir,'state','usage.jsonl'),'utf8').trim().split('\n').map(JSON.parse);
 assert.equal(rows.length,2,'HTTP 接口没回用量就不记，不估一个假的');
 assert.deepEqual([rows[0].in,rows[0].out,rows[0].est],[12,3,false]);
 assert.deepEqual([rows[1].in,rows[1].out,rows[1].est],[3,2,true]);
 assert.equal(rows[1].provider,'claude');assert.equal(rows[1].purpose,'summary');
 fs.rmSync(dir,{recursive:true,force:true});
});

test('abort stops an API request and never falls through to another provider',async()=>{
 const controller=new AbortController();let calls=0,started;
 const ready=new Promise(r=>started=r);
 const env={A:'a',B:'b',LLM_CHAIN:[{type:'openai',name:'A',baseUrl:'https://a.example/v1',keyFrom:'A',models:{post:'primary',postFallback:'backup'}},{type:'openai',name:'B',baseUrl:'https://b.example/v1',keyFrom:'B'}]};
 const result=llm.ask(env,{signal:controller.signal,json:true,thinkGuide:false,fetchImpl:async(_url,opts)=>{calls++;started();return new Promise((_,reject)=>opts.signal.addEventListener('abort',()=>reject(Error('aborted')),{once:true}));}});
 await ready;controller.abort();await assert.rejects(result,e=>e.cancelled===true);assert.equal(calls,1);
});

const rapidEnv = { LLM_PROVIDER:'codex', ACTIVE_INTELLIGENCE_MODE:'rapid', DEEPSEEK_API_KEY:'k', LLM_BASE_URL:'https://api.deepseek.com', LLM_MODEL:'deepseek-chat' };
test('quick stage route is narrow; explicit model, chain and primary override preserve order',()=>{
 const order=(env,kind,stage)=>llm.chainForStage(env,{kind,stage}).map(p=>p.label);
 for(const stage of ['native-live','insight-fast','live-signal']) assert.deepEqual(order(rapidEnv,'quick',stage),['DeepSeek','Codex']);
 for(const stage of ['live-draft','live-background','myagent','']) assert.deepEqual(order(rapidEnv,'quick',stage),['Codex','DeepSeek']);
 for(const kind of ['post','think','verify','live']) assert.deepEqual(order(rapidEnv,kind,'native-live'),['Codex','DeepSeek']);
 for(const overrides of [{ACTIVE_INTELLIGENCE_MODE:'legacy'},{LLM_QUICK_ROUTE:'primary'},{LLM_MODEL_QUICK:'my-choice'},
  {LLM_CHAIN:[{type:'cli',kind:'codex'},{type:'openai',name:'Mine',key:'k',baseUrl:'https://mine.example'}]}]) {
  assert.equal(order({...rapidEnv,...overrides},'quick','native-live')[0],'Codex');
 }
 assert.equal(llm.chainForStage(rapidEnv,{kind:'quick',stage:'native-live',noFallback:true})[0].label,'Codex');
 assert.deepEqual(llm.routeLabels(rapidEnv),{quick:'DeepSeek',draft:'DeepSeek',primary:'Codex'});
});
test('quick API failure falls back visibly to native Codex with actual model and attempt receipts',async t=>{
 const cli=require('../app/cli-llm'), original=cli.askDetailed, calls=[];
 cli.askDetailed=async(kind,user,opts)=>{calls.push({kind,opts});return{ok:true,text:'fallback',model:'actual-codex'};};t.after(()=>cli.askDetailed=original);
 const phases=[];const result=await llm.ask(rapidEnv,{kind:'quick',stage:'native-live',nativeOnly:true,thinkGuide:false,user:'u',fetchImpl:badFetch,onAttempt:x=>phases.push(x)});
 assert.equal(result.provider,'Codex');assert.equal(result.model,'actual-codex');assert.equal(result.degraded,true);
 assert.match(result.degradedReason,/api:/);assert.equal(result.attempts[0].provider,'DeepSeek');assert.equal(calls[0].kind,'codex');
 assert.ok(phases.some(x=>x.phase==='failed'&&x.nextProvider==='Codex'));
});
test('native quick route uses API, excludes other CLIs and leaves images with a capable provider',async t=>{
 const fs=require('fs'),os=require('os'),path=require('path'),cli=require('../app/cli-llm');
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-quick-image-')),file=path.join(dir,'shot.png');
 fs.writeFileSync(file,Buffer.from('89504e470d0a1a0a','hex'));const original=cli.askDetailed;
 const calls=[];cli.askDetailed=async(kind,user,opts)=>{calls.push({kind,opts});return{ok:true,text:'image understood',model:'vision-codex'};};
 t.after(()=>{cli.askDetailed=original;fs.rmSync(dir,{recursive:true,force:true});});
 const seen=[];const fast=await llm.ask(rapidEnv,{kind:'quick',stage:'native-live',nativeOnly:true,thinkGuide:false,user:'u',fetchImpl:okFetch(seen)});
 assert.equal(fast.provider,'DeepSeek');assert.equal(fast.model,'served-model');assert.equal(calls.length,0);
 const image=await llm.ask(rapidEnv,{kind:'quick',stage:'native-live',nativeOnly:true,thinkGuide:false,dataDir:dir,images:[{path:file}],user:'u',fetchImpl:okFetch(seen)});
 assert.equal(image.provider,'Codex');assert.equal(calls[0].opts.images[0].path,file);assert.equal(seen.length,1);
 const visionEnv={...rapidEnv,LLM_CHAIN:[{type:'openai',name:'Vision API',key:'k',baseUrl:'https://vision.example',vision:true},{type:'cli',kind:'codex'}]};
 const vision=await llm.ask(visionEnv,{kind:'quick',stage:'native-live',nativeOnly:true,thinkGuide:false,dataDir:dir,images:[{path:file}],user:'u',fetchImpl:okFetch(seen)});
 assert.equal(vision.provider,'Vision API');assert.equal(calls.length,1);
 const native=await llm.ask({LLM_CHAIN:[{type:'cli',kind:'claude'},{type:'cli',kind:'codex'}]},{kind:'quick',stage:'native-live',nativeOnly:true,thinkGuide:false,user:'u'});
 assert.equal(native.provider,'Codex');assert.equal(calls.at(-1).kind,'codex');
 const bad=await llm.ask(rapidEnv,{kind:'quick',stage:'native-live',thinkGuide:false,dataDir:dir,images:[{path:'/etc/outside.png'}],user:'u'});
 assert.equal(bad.text,null);assert.equal(calls.length,2);
});

test('live draft alone uses the fast route; API model selection and explicit route preferences are respected',async()=>{
 const order=(env,kind,stage,extra={})=>llm.chainForStage(env,{kind,stage,...extra}).map(p=>p.label);
 assert.deepEqual(order(rapidEnv,'post','live-draft'),['DeepSeek','Codex']);
 assert.deepEqual(order({...rapidEnv,LLM_MODEL_POST:require('../app/config').defaults.LLM_MODEL_POST},'post','live-draft'),['DeepSeek','Codex'],'legacy Claude default does not pin an unrelated Codex draft');
 assert.deepEqual(order({...rapidEnv,LLM_PROVIDER:'claude',LLM_MODEL_POST:'chosen'},'post','live-draft'),['Claude','DeepSeek'],'an applicable explicit Claude post model keeps the chain');
 for(const stage of ['myagent','insight-deep','live-background','native-live',''])assert.deepEqual(order(rapidEnv,'post',stage),['Codex','DeepSeek']);
 for(const kind of ['think','verify','quick','live'])assert.deepEqual(order(rapidEnv,kind,'live-draft'),['Codex','DeepSeek']);
 for(const overrides of [{ACTIVE_INTELLIGENCE_MODE:'legacy'},{LLM_QUICK_ROUTE:'primary'},{LLM_MODEL_QUICK:'chosen'},
  {LLM_CHAIN:[{type:'cli',kind:'codex',models:{post:'chosen'}},{type:'openai',name:'Mine',key:'k',baseUrl:'https://mine.example'}]}])assert.equal(order({...rapidEnv,...overrides},'post','live-draft')[0],'Codex');
 assert.equal(order(rapidEnv,'post','live-draft',{noFallback:true})[0],'Codex');
 const seen=[];await llm.ask({...rapidEnv,LLM_MODEL:'my-api-model'},{kind:'post',stage:'live-draft',nativeOnly:true,thinkGuide:false,user:'u',fetchImpl:okFetch(seen)});
 assert.equal(seen[0].body.model,'my-api-model','LLM_MODEL names the API model; it is not a primary-route preference');
 assert.deepEqual(llm.routeLabels(rapidEnv),{quick:'DeepSeek',draft:'DeepSeek',primary:'Codex'});
 const settings=require('fs').readFileSync(require('path').join(__dirname,'../web/src/07-settings-top.js'),'utf8');assert.match(settings,/llmRoutes\?\.draft/);
});
test('live draft fallback is visible and keeps timeout, vision and native-only restrictions',async t=>{
 const cli=require('../app/cli-llm'),original=cli.askDetailed,calls=[];t.after(()=>cli.askDetailed=original);
 cli.askDetailed=async(kind,user,opts)=>{calls.push({kind,opts});return {ok:true,text:'draft',model:'actual-codex'};};
 const r=await llm.ask(rapidEnv,{kind:'post',stage:'live-draft',nativeOnly:true,thinkGuide:false,user:'u',timeoutMs:60000,fetchImpl:badFetch});
 assert.equal(r.provider,'Codex');assert.equal(r.degraded,true);assert.equal(r.attempts[0].provider,'DeepSeek');assert.equal(calls[0].opts.timeoutMs,60000);
 assert.equal((await llm.ask({LLM_PROVIDER:'claude',ACTIVE_INTELLIGENCE_MODE:'rapid',DEEPSEEK_API_KEY:'k',LLM_BASE_URL:'https://api.deepseek.com',LLM_MODEL:'deepseek-chat'},
  {kind:'post',stage:'live-draft',nativeOnly:true,thinkGuide:false,user:'u',fetchImpl:badFetch})).text,null);assert.equal(calls.length,1,'no Claude adapter is invoked');
 const fs=require('fs'),dir=fs.mkdtempSync('/private/tmp/tht-draft-vision-'),file=require('path').join(dir,'shot.png');t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));fs.writeFileSync(file,Buffer.from('89504e470d0a1a0a','hex'));
 const image=await llm.ask(rapidEnv,{kind:'post',stage:'live-draft',nativeOnly:true,thinkGuide:false,dataDir:dir,images:[{path:file}],user:'u',fetchImpl:okFetch([])});assert.equal(image.provider,'Codex');assert.equal(calls.at(-1).kind,'codex');
});
test('cancellation before or during live draft fallback never saves a late result',async t=>{
 const cli=require('../app/cli-llm'),original=cli.askDetailed;let cliCalls=0;t.after(()=>cli.askDetailed=original);
 const before=new AbortController();cli.askDetailed=async()=>{cliCalls++;return {ok:true,text:'late'};};
 await assert.rejects(llm.ask(rapidEnv,{kind:'post',stage:'live-draft',nativeOnly:true,thinkGuide:false,user:'u',signal:before.signal,fetchImpl:async()=>{before.abort();return badFetch();}}),e=>e.cancelled===true);assert.equal(cliCalls,0);
 const during=new AbortController();cli.askDetailed=async()=>{cliCalls++;during.abort();return {ok:true,text:'late'};};
 await assert.rejects(llm.ask(rapidEnv,{kind:'post',stage:'live-draft',nativeOnly:true,thinkGuide:false,user:'u',signal:during.signal,fetchImpl:badFetch}),e=>e.cancelled===true);assert.equal(cliCalls,1);
});
