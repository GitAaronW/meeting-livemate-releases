'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {create,context,grounded}=require('../app/live-signals');
const rows=[{id:'s1',at:0,speaker:'S1',text:'未来应该像 The Jacksons 那样温暖。'}, {id:'s2',at:10,speaker:'S0',text:'Instinct 是一家 AI 助手公司，他们融了多少钱？'}, {id:'s3',at:12,text:'给我们做 AI 硬件典型一天的脑暴看板。'}];
const background=aspect=>({entity:'Instinct',topic:'个人助手',aspect,quote:'Instinct 是一家 AI 助手公司',sourceIds:['s2']});
const judgment={topic:'未来体验',point:'可能指 The Jetsons 的乐观未来；名字尚需核对。',whyChanged:'谈到温暖未来，The Jacksons 可能是动画名称的转写错误。',quote:'未来应该像 The Jacksons 那样温暖。',sourceIds:['s1']};
function session(){return {id:'live',projectId:'hardware',factchecks:[],broadcast(){},checkpoint(){}};}
const delay=()=>new Promise(r=>setTimeout(r,2));
async function settled(s){for(let i=0;i<200&&s.factchecks.some(x=>x.verifyPending);i++)await delay();assert(!s.factchecks.some(x=>x.verifyPending));}
const result={url:'https://example.com/instinct',title:'Instinct announcement',snippet:'Instinct raised funding for its personal AI assistant through messaging and calls.'};
const evidence=async()=>JSON.stringify({evidence:[{index:0,quote:result.snippet}]});
test('judgement is immediate while two public searches run concurrently; repetition does not start more work',async()=>{
 const s=session(),waiting=[];let active=0,max=0,calls=0;
 const consider=create({ask:evidence,search:async()=>{calls++;active++;max=Math.max(max,active);await new Promise(r=>waiting.push(r));active--;return [result];}});
 consider(s,{currentJudgment:judgment,background:[background('profile'),background('funding'),background('news')]},rows);
 assert.equal(s.factchecks[0].point,judgment.point);assert.equal(s.factchecks.filter(x=>x.channel==='background').length,2);
 for(let i=0;i<20&&waiting.length<2;i++)await delay();assert.equal(max,2);assert.equal(calls,2);
 consider(s,{currentJudgment:judgment,background:[background('profile')]},rows);assert.equal(calls,2);
 waiting.forEach(r=>r());await settled(s);assert(s.factchecks.filter(x=>x.channel==='background').every(x=>x.lookupState==='ready'));
 assert.equal(s.factchecks[1].verify.verdict,'公开检索');assert.equal(s.factchecks[1].confirmed,false);
});
test('evidence is an actual search excerpt and URL; invented quotes, indices and dates never become facts',async()=>{
 const s=session(),consider=create({search:async()=>[result],ask:async()=>JSON.stringify({evidence:[{index:9,quote:'invented',url:'https://fake.test/'},{index:0,quote:'They raised $100 million.',date:'2026-01-01'},{index:0,quote:result.snippet,date:'1900-01-01'}]})});
 consider(s,{research:{...background('check'),claim:'Instinct raised $100 million.'}},rows);await settled(s);
 const item=s.factchecks[0];assert.equal(item.channel,'verification');assert.deepEqual(item.evidence.map(x=>x.url),[result.url]);assert.equal(item.point,result.snippet);assert.equal(item.evidence[0].date,undefined);assert.match(item.verify.note,/不代表/);assert.equal(item.sourceRefs[0].at,10);
});
test('no search result or provider failure is not a contradiction or verification',async()=>{
 for(const search of [async()=>[],async()=>{throw Error('network unavailable');}]){
  const s=session(),consider=create({search,ask:()=>{throw Error('must not call without evidence');}});consider(s,{background:[background('funding')]},rows);await settled(s);
  assert(['no_evidence','unavailable'].includes(s.factchecks[0].lookupState));assert.equal(s.factchecks[0].verify,undefined);assert.equal(s.factchecks[0].point,'');
 }
});
test('invented transcript references and internal names cannot start public searches',async()=>{
 let calls=0;const s=session(),consider=create({search:async()=>{calls++;return [];},ask:evidence});
 for(const value of [{...background('profile'),sourceIds:['invented']},{...background('profile'),quote:'invented sentence'},{...background('profile'),entity:'Chansey',quote:'Chansey 最新计划',sourceIds:['private']},{...background('profile'),entity:'Instinct prepare internal documents'}])consider(s,{background:[value]},[...rows,{id:'private',text:'Chansey 最新计划',at:20}]);
 assert.equal(calls,0);assert.equal(s.factchecks.length,0);assert.equal(grounded({quote:'future',sourceIds:['s4']},rows),null);
});
test('new spelling corrects a judgement with history preserved; future evidence is unavailable at the earlier prefix',()=>{
 const s=session(),consider=create({ask:evidence,search:async()=>[]});consider(s,{currentJudgment:judgment},rows.slice(0,1));
 const correction={...judgment,point:'已听到 Jetsons 的拼写：指动画里的乐观未来，依然是 AI 解读。',whyChanged:'说话人补充 j e t s o n s 拼写，支持 The Jetsons 而非 Jacksons。',quote:'j e t s o n s',sourceIds:['s4']};
 assert.deepEqual(consider(s,{currentJudgment:correction},rows),[]);assert.equal(s.factchecks.length,1);
 consider(s,{currentJudgment:correction},[...rows,{id:'s4',text:'我说的是 j e t s o n s',at:20}]);
 assert.equal(s.factchecks.length,2);assert.equal(s.factchecks[0].supersededBy,s.factchecks[1].id);assert.equal(s.factchecks[1].supersedes,s.factchecks[0].id);assert.equal(context(s).length,1);assert.equal(context(s)[0].judgment,correction.point);
 consider(s,{currentJudgment:{...correction,point:correction.point+'！'}},[...rows,{id:'s4',text:'我说的是 j e t s o n s'}]);assert.equal(s.factchecks.length,2);
});
test('source edits, project changes and meeting end discard in-flight searches',async()=>{
 for(const invalidate of [s=>s.editEpoch=1,s=>s.projectId='software',s=>s.end=1,s=>s.finalized=true]){
  const s=session();let release;const consider=create({search:()=>new Promise(r=>release=r),ask:evidence});consider(s,{background:[background('funding')]},rows);while(!release)await delay();invalidate(s);release([result]);await settled(s);
  assert.equal(s.factchecks[0].stale,true);assert.equal(s.factchecks[0].evidence,undefined);assert.equal(s.factchecks[0].verify,undefined);
 }
});
test('both analysis parsers keep background and judgement alongside drafts; ordinary background never asks for confirmation',()=>{
 const L=require('../app/live-insight'),C=require('../app/live-confirmations');const value={md:'',insights:[],deliverable:null,currentJudgment:judgment,background:[background('funding')]};
 for(const parse of [L.parse,L.parseRapid]){const j=parse(JSON.stringify(value));assert.deepEqual(j.background,value.background);assert.deepEqual(j.currentJudgment,value.currentJudgment);assert.equal(C.offer(session(),j.confirmation,rows),null);}
});

test('same evidence cannot create a new judgement by paraphrase; verification preference is respected',async()=>{
 const s=session(),consider=create({env:()=>({VERIFY_LIVE:'off'}),ask:evidence,search:async()=>{throw Error('disabled verification');}});
 consider(s,{currentJudgment:judgment},rows);
 consider(s,{currentJudgment:{...judgment,point:'AI 猜测：动画中的乐观未来愿景，名称仍未确认。',whyChanged:'同一段被换一种方式解释，但没有新依据。'},research:{...background('check'),claim:'Instinct funding'}},rows);
 assert.equal(s.factchecks.length,1);assert.equal(context(s).length,1);
});

test('background uses matching real excerpts immediately without another model call',async()=>{
 let calls=0;const s=session(),consider=create({search:async()=>[
  {url:'https://irrelevant.test/',title:'Instinct dog training',snippet:'Use your instinct to improve your dog training approach.'},result,result],
  ask:async()=>{calls++;throw Error('background must not wait for another model');}});
 consider(s,{background:[background('funding')]},rows);await settled(s);
 assert.equal(calls,0);assert.equal(s.factchecks[0].lookupState,'ready');
 assert.deepEqual(s.factchecks[0].evidence.map(x=>x.url),[result.url]);
 assert.equal(s.factchecks[0].point,result.snippet);assert.equal(s.factchecks[0].confirmed,false);
});

test('construction does not read invalid configuration before the server can start',()=>{
 let calls=0;create({env:()=>{calls++;throw Error('missing RELAY_TOKEN');}});assert.equal(calls,0);
});

test('verification searches the requested public aspect and shares evidence cache with background',async()=>{
 let calls=0,query='';const s=session(),consider=create({ask:evidence,search:async q=>{calls++;query=q;return [result];}});
 consider(s,{research:{...background('funding'),claim:'Instinct raised $100 million.'},background:[background('funding')]},rows);
 await settled(s);assert.equal(calls,1);assert.match(query,/funding investment/);
 assert.equal(s.factchecks[0].channel,'verification');assert.equal(s.factchecks[1].channel,'background');
 assert.equal(s.factchecks[0].verify.verdict,'公开检索');assert.equal(s.factchecks[0].confirmed,false);
});

test('shared live prompt does not assume a specific user identity',()=>{
 const {prompt}=require('../app/live-signals');
 assert.doesNotMatch(prompt,/Aaron/);
 assert.match(prompt,/Do not ask the user to confirm ordinary summaries/);
});

test('cartoon background can return a source excerpt without being mistaken for an AI company',async()=>{
 const row={id:'cartoon',text:'The Jetsons is the reference we were missing.'},s=session();
 const url='https://example.com/jetsons';let query;
 const consider=create({ask:evidence,search:async q=>{query=q;return [{url,title:'The Jetsons',snippet:'The Jetsons is an animated series about a futuristic family.'}];}});
 consider(s,{background:[{entity:'The Jetsons',aspect:'profile',quote:row.text,sourceIds:[row.id]}]},[row]);await settled(s);
 assert.equal(s.factchecks[0].lookupState,'ready');assert.equal(s.factchecks[0].evidence[0].url,url);assert.ok(!query.includes('AI assistant'));
});
