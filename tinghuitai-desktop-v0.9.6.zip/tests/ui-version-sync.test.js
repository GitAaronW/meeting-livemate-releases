 'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),path=require('path');
const sync=require('../web/version-sync'),{status}=require('../app/ui-refresh-state');
const idle=()=>({sessions:[],boardJobs:[],threads:{running:0,queued:0},hubJobs:[]});
const health=()=>({ok:true,version:'next',activeSessions:0,uiRefresh:status(idle())});
function harness(options={}){let clock=0,blocked=false,current=health(),loads=0;const memo=new Map(),notices=[];
 const api=sync.create({build:'old',now:()=>clock,storage:{getItem:k=>memo.get(k),setItem:(k,v)=>memo.set(k,v)},readHealth:async()=>{if(current instanceof Error)throw current;return current;},busy:()=>blocked,reload:()=>loads++,notify:d=>notices.push(d),...options});
 return {api,memo,notices,get loads(){return loads;},time:t=>clock=t,busy:v=>blocked=v,health:v=>current=v};}
test('backend idle proof includes meetings, assistant/board jobs, card queues and import jobs',()=>{
 assert.equal(status(idle()).idle,true);
 for(const x of [{sessions:[{finalized:false}]},{boardJobs:[{state:'thinking'}]},{threads:{running:0,queued:1}},{hubJobs:[{status:'running'}]},{boardJobs:[{state:'uncertain'}]}])assert.equal(status({...idle(),...x}).idle,false);
 assert.equal(status({...idle(),sessions:[{finalized:true}],boardJobs:[{state:'completed'},{state:'failed'},{state:'planned'}]}).idle,true);
 for(const x of [{threads:{running:-1,queued:0}},{hubJobs:undefined},{boardJobs:[{}]}])assert.equal(status({...idle(),...x}).idle,false);
 assert.equal(status().idle,false);
});
test('auto refresh waits 60 seconds without interaction and reloads only once per target',async()=>{
 const x=harness();await x.api.check();x.time(59999);await x.api.check();assert.equal(x.loads,0);
 x.api.interaction();x.time(119998);await x.api.check();assert.equal(x.loads,0);
 x.time(119999);await x.api.check();assert.equal(x.loads,1);
 await x.api.check();assert.equal(x.loads,1,'even stale cached HTML does not loop');
 x.health({...health(),version:'newer'});await x.api.check();assert.equal(x.loads,2);
});
test('recording, active server jobs, edits and older health schemas prevent manual and automatic refresh',async()=>{
 for(const h of [{...health(),activeSessions:1},{...health(),uiRefresh:{schema:1,idle:false}},{ok:true,version:'next',activeSessions:0}]){const x=harness();x.health(h);x.time(70000);await x.api.check(true);assert.equal(x.loads,0);assert.equal(x.notices.at(-1).safe,false);}
 const x=harness();x.time(70000);x.busy(true);await x.api.check(true);assert.equal(x.loads,0);x.busy(false);await x.api.check();assert.equal(x.loads,1);
});
test('network failures and unavailable storage do not refresh; explicit refresh retains all safety gates',async()=>{
 const x=harness();x.health(Error('401 / disconnected'));x.time(90000);await x.api.check();assert.equal(x.loads,0);assert.equal(x.notices.length,0);
 const locked=harness({storage:{getItem:()=>{throw Error('disabled');}}});locked.time(90000);await locked.api.check(true);assert.equal(locked.loads,0);
 const manual=harness({automatic:false});manual.time(90000);await manual.api.check();assert.equal(manual.loads,0);await manual.api.check(true);assert.equal(manual.loads,1);
});
test('concurrent readbacks cannot issue duplicate reloads',async()=>{
 let release;const x=harness({readHealth:()=>new Promise(r=>release=r)});x.time(90000);const first=x.api.check();await x.api.check();release(health());await first;assert.equal(x.loads,1);
});
function element(patch={}){return {tagName:'TEXTAREA',value:'',defaultValue:'',type:'text',getClientRects:()=>[{}],...patch};}
function doc({fields=[],frames=[],dialog=false,win={},focus=null}={}){return {defaultView:win,activeElement:focus,querySelector:s=>dialog?{}:null,querySelectorAll:s=>s==='iframe'?frames:fields};}
test('DOM guards protect inputs, attachments, dictation, dialogs, selection and child frames',()=>{
 assert.equal(sync.documentBusy(doc()),false);
 for(const e of [element({value:'unsent'}),element({type:'file',files:[{}]}),element({isContentEditable:true}),element({type:'checkbox',checked:true,defaultChecked:false}),element({tagName:'SELECT',options:[{selected:true,defaultSelected:false}]})])assert.equal(sync.documentBusy(doc({fields:[e]})),true);
 const focus=element();assert.equal(sync.documentBusy(doc({fields:[focus],focus})),false);
 assert.equal(sync.documentBusy(doc({dialog:true})),true);
 assert.equal(sync.documentBusy(doc({win:{thtAgentBusy:()=>true}})),true);
 assert.equal(sync.documentBusy(doc({win:{thtRefreshBusy:()=>true}})),true);
 assert.equal(sync.documentBusy(doc({frames:[{contentDocument:doc({fields:[element({value:'QBR draft'})]})}]})),true);
 assert.equal(sync.documentBusy(doc({frames:[{contentDocument:null}]})),true);
 assert.equal(sync.documentBusy(doc({frames:[{get contentDocument(){throw Error('cross origin');}}]})),true);
 assert.equal(sync.documentBusy(doc({fields:[element({value:'hidden',getClientRects:()=>[]})]})),false);
});
test('UI version is stamped into every independent page and offline cache includes the refresh controller',()=>{
 const version=require('../package.json').version;
 for(const f of ['index.html','work.html','briefs.html','activity.html','memory.html','knowledge-map.html','meeting-board.html'])assert.match(fs.readFileSync(path.join(__dirname,'../web',f),'utf8'),new RegExp('name="tht-build" content="'+version.replaceAll('.','\\.')+'"'));
 const ready=fs.readFileSync(path.join(__dirname,'../web/src/10-ready-bar.js'),'utf8');assert.match(ready,/buildVersion/);assert.doesNotMatch(ready,/h\.version/);
 const sw=fs.readFileSync(path.join(__dirname,'../web/sw.js'),'utf8');assert.match(sw,/\.\/version-sync\.js/);assert.match(sw,/version-sync\\\.js/);assert.match(sw,/\.\/build-info\.js/);
});

test('initialized controls are pristine while subsequent user edits and draft text stay protected',()=>{
 const input=element({tagName:'INPUT',value:'saved search'}),select=element({tagName:'SELECT',options:[{selected:true,defaultSelected:false},{selected:false,defaultSelected:true}]});
 const page=doc({fields:[input,select],focus:input});sync.captureBaseline(page);assert.equal(sync.documentBusy(page),false);
 input.value='unsaved change';assert.equal(sync.documentBusy(page),true);input.value='saved search';
 select.options[0].selected=false;select.options[1].selected=true;assert.equal(sync.documentBusy(page),true);
 const draft=element({value:'restored unsent message'}),draftPage=doc({fields:[draft]});sync.captureBaseline(draftPage);assert.equal(sync.documentBusy(draftPage),true);
});
test('a failing busy hook warns once and remains blocked',()=>{
 let warnings=0;const page=doc({win:{console:{warn:()=>warnings++},thtRefreshBusy:()=>{throw Error('missing binding');}}});
 assert.equal(sync.documentBusy(page),true);assert.equal(sync.documentBusy(page),true);assert.equal(warnings,1);
});
test('the assembled index busy hook resolves the actual shared application bindings',()=>{
 const vm=require('node:vm'),html=fs.readFileSync(path.join(__dirname,'../web/index.html'),'utf8');
 const source=[html.match(/let cur = null[^;]*running = false[^;]*;/)?.[0],html.match(/let nativeState=\{[^;]*;/)?.[0],html.match(/let assistantBusy=false[^;]*;/)?.[0],html.match(/window\.thtRefreshBusy=\(\)=>[^;]*;/)?.[0]];
 assert.equal(source.every(Boolean),true);const context=vm.createContext({window:{}});vm.runInContext(source.join('\n'),context);
 assert.equal(context.window.thtRefreshBusy(),false);vm.runInContext('browserCommandPending=true',context);assert.equal(context.window.thtRefreshBusy(),true);
});
test('an update with no restart exits Updating and restores the banner button',async()=>{
 const vm=require('node:vm'),source=fs.readFileSync(path.join(__dirname,'../web/src/26-updater.js'),'utf8');
 const body=source.match(/\$\('#upd-go'\)\.onclick=async\(\)=>\{([\s\S]*?)\n    \};/)[1];
 const go={disabled:false},x={disabled:false},messages=[];const context={runtimePending:false,versionSync:{check:async()=>({pending:false})},$:s=>s==='#upd-go'?go:x,show:(text,canGo)=>messages.push({text,canGo}),ui:'zh',buildVersion:'0.9.4',relayBase:()=>'',cfg:{},fetch:async()=>({json:async()=>({ok:true,restarting:false,version:'0.9.4'})}),AbortSignal,encodeURIComponent};
 await vm.runInNewContext('(async()=>{'+body+'})()',context);
 assert.equal(messages.at(-1).text,'已是最新 v0.9.4');assert.equal(go.disabled,false);assert.equal(x.disabled,false);
});
