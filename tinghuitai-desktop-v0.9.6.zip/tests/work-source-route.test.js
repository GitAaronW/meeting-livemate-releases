'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const source=fs.readFileSync(require.resolve('../web/work.js'),'utf8');
const boot=source.split('\n').find(line=>line.startsWith('async function loadInitialRoute('));
function fixture(hash,fail=false){
 const calls=[],location={hash};
 const context={URLSearchParams,location,load:async()=>{calls.push('load');location.hash='#view=sources&node=';if(fail)throw Error('read unavailable');},sourceDetail:async id=>calls.push(id)};
 vm.createContext(context);vm.runInContext(boot,context);return {run:context.loadInitialRoute,calls};
}
test('MyAgent draft link opens its source after list rendering rewrites the hash',async()=>{
 const f=fixture('#sources&source=s-qbr');await f.run();assert.deepEqual(f.calls,['load','s-qbr']);
});
test('canonical workbench route preserves encoded source identity during hydration',async()=>{
 const f=fixture('#view=sources&node=&source=s-qbr%2Fone');await f.run();assert.deepEqual(f.calls,['load','s-qbr/one']);
});
test('ordinary list does not open a source and failed loading cannot open an unusable draft',async()=>{
 const ordinary=fixture('#sources');await ordinary.run();assert.deepEqual(ordinary.calls,['load']);
 const failed=fixture('#sources&source=s-qbr',true);await assert.rejects(failed.run(),/read unavailable/);assert.deepEqual(failed.calls,['load']);
});

// A real browser emits popstate before hashchange for location.hash navigation.
// The first event must not canonicalize away the deep-link before the second reads it.
test('opening a draft in an already loaded workbench survives popstate before hashchange',async()=>{
 const handlers={},calls=[],location={hash:'#sources&source=s-qbr'},context={
  URLSearchParams,location,window:{addEventListener:(name,fn)=>handlers[name]=fn,scrollTo:()=>{}},
  fromHash:()=> 'sources',viewState:{},sessionStorage:{getItem:()=>null},
  render:()=>{calls.push('render');location.hash='#view=sources&node=';},
  sourceDetail:async id=>calls.push(id),message:()=>{}
 };
 vm.createContext(context);
 for(const name of ['popstate','hashchange'])vm.runInContext(source.split('\n').find(l=>l.startsWith("window.addEventListener('"+name+"'")),context);
 handlers.popstate();assert.equal(location.hash,'#sources&source=s-qbr');
 handlers.hashchange();await Promise.resolve();assert.deepEqual(calls,['render','s-qbr']);
});
test('ordinary browser back navigation still renders the workbench view',()=>{
 const handlers={},calls=[],context={URLSearchParams,location:{hash:'#tasks'},window:{addEventListener:(name,fn)=>handlers[name]=fn,scrollTo:()=>{}},fromHash:()=> 'tasks',viewState:{tasks:{query:'QBR'}},sessionStorage:{getItem:()=>null},render:()=>calls.push('render')};
 vm.createContext(context);vm.runInContext(source.split('\n').find(l=>l.startsWith("window.addEventListener('popstate'")),context);
 handlers.popstate();assert.deepEqual(calls,['render']);assert.equal(context.query,'QBR');
});
