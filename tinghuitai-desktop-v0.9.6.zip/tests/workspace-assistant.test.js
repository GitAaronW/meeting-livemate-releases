'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('fs'),os=require('os'),path=require('path'),http=require('http');
const route=require('../app/workspace-assistant'),{Jobs}=require('../app/meeting-board-jobs');
function fixture(t){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-assistant-'));
 t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const start=new Date();start.setDate(start.getDate()-1);start.setHours(21,30,0,0);
 const meeting={id:'last-night',title:'Investor mockups',start:start.getTime(),end:start.getTime()+3600000,transcript:[{text:'Carl has not been booked.'}],summary:'## 未定事项\nCarl 的评审时间尚未确定。'};
 const ctx={authed:true,dataDir:dir,hub:{data:{sources:[{id:'source-old',sessionId:meeting.id,title:meeting.title,body:'original speech',date:start.toISOString()}],projects:[]}},
  session:id=>id===meeting.id?meeting:id==='empty'?{id,title:'Empty meeting',transcript:[]}:null,
  planAction:async()=>({ok:true,text:'Retrieved project material.'}),executeAction:async()=>{throw Error('must not execute');}};
 ctx.askCodex=async({requestText,context,onProgress,conversationId})=>{
  const comment=requestText;assert.doesNotMatch(requestText,/【听会台资料/);
  if(context.indexedMeetingLookup)return {text:JSON.stringify({reply:context.indexedMeetingLookup,action:null}),threadId:'codex:'+conversationId};
  const out=await ctx.planAction({instruction:comment,context:JSON.stringify(context),lang:'zh',meetingId:'',onProgress});
  if(!out?.ok)throw Object.assign(Error(out?.reason||'no answer'),{stage:'start'});
  return {text:JSON.stringify({reply:out.text,action:out.proposal||null}),threadId:'codex:'+conversationId};
 };
 return {ctx,meeting,dir};
}
async function endpoint(t,ctx){
 const server=http.createServer((req,res)=>route(req,res,new URL(req.url,'http://localhost'),ctx));
 await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(()=>new Promise(r=>server.close(r)));
 const base='http://127.0.0.1:'+server.address().port+'/workspace-assistant';
 return async(body,headers={})=>{const response=await fetch(base,body?{method:'POST',headers:{'Content-Type':'application/json',...headers},body:JSON.stringify(body)}:{});return {status:response.status,...await response.json()};};
}
async function finished(call){for(let i=0;i<50;i++){const j=await call();if(j.jobs.every(x=>!['queued','running','planning','retrieving','syncing','thinking','executing'].includes(x.state)))return j.jobs;await new Promise(r=>setTimeout(r,10));}throw Error('job timed out');}
test('outside a meeting, last-night minutes are retrieved without model or transcript dependency',async t=>{
 const f=fixture(t);f.ctx.planAction=async()=>{throw Error('model should not be needed');};f.ctx.askCodex=async()=>{throw Error('Codex should not be needed');};const call=await endpoint(t,f.ctx);
 assert.equal((await call({action:'chat',comment:'翻一下昨天晚上的会议纪要',contextId:'empty'})).status,202);
 const j=(await finished(call))[0];assert.equal(j.state,'completed');assert.match(j.reply,/Carl 的评审时间尚未确定/);assert.match(j.reply,/\/tinghuitai\/\?id=last-night/);assert.match(j.reply,/参考稿/);assert.match(j.codexSyncError,/本机记录已保存/);
 assert.equal(new Jobs(f.dir).list(route.GLOBAL)[0].reply,j.reply);
 assert.ok(j.events.some(e=>e.state==='retrieving'));assert.ok(!j.events.some(e=>e.state==='thinking'));
});
test('assistant conversations persist across meeting contexts and reach the read-tool planner',async t=>{
 const f=fixture(t),inputs=[],ask=f.ctx.askCodex;f.ctx.askCodex=async request=>{inputs.push(request);return ask(request);};f.ctx.planAction=async()=>({ok:true,text:'First answer'});const call=await endpoint(t,f.ctx);
 await call({action:'chat',comment:'查一下项目资料'});await finished(call);
 await call({action:'chat',comment:'接着比较两个方案',contextId:'empty'});await finished(call);
 const context=inputs[1].context;assert.doesNotMatch(inputs[1].requestText,/【听会台资料/);assert.equal(context.selectedMeeting.id,'empty');assert.equal(context.meetings[0].id,'last-night');assert.equal(inputs[0].kind,'chat');assert.equal(inputs[1].kind,'chat');assert.equal((await call()).jobs.length,2);
});
test('ambiguous dates do not choose one meeting and mutation requests bypass cached retrieval',async t=>{
 const f=fixture(t),morning={...f.meeting,id:'morning',title:'Morning meeting',start:new Date(f.meeting.start).setHours(9)};
 f.ctx.hub.data.sources.push({sessionId:morning.id,title:morning.title,body:'morning',date:new Date(morning.start).toISOString()});
 const original=f.ctx.session;f.ctx.session=id=>id===morning.id?morning:original(id);
 assert.match(route.minutes(f.ctx,'找昨天的会议纪要','zh').reply,/Morning meeting/);
 assert.doesNotMatch(route.minutes(f.ctx,'找昨天晚上的会议纪要','zh').reply,/Morning meeting/);
 assert.equal(route.minutes(f.ctx,'找到昨天会议纪要并发给 Shawn','zh'),null);
 assert.equal(route.minutes(f.ctx,'重新生成昨天的会议总结给我看','zh'),null);
});
test('writes are proposals only; forged confirmation is rejected and confirmed action executes once',async t=>{
 const f=fixture(t);let writes=0;
 f.ctx.planAction=async()=>({ok:true,text:'Review this message',proposal:{name:'slack.message.send',args:{channel:'C123',text:'Draft'}}});
 f.ctx.executeAction=async p=>{writes++;assert.match(p.args.text,/由 Codex 协助发送/);return {ok:true,result:{ok:true,data:{}},receipt:{status:'sent'}};};
 const call=await endpoint(t,f.ctx);await call({action:'run',comment:'发给 Slack 频道'});const job=(await finished(call))[0];assert.equal(job.state,'awaiting_confirmation');assert.equal(writes,0);
 assert.equal((await call({action:'confirm',jobId:job.id,confirmed:true,proposal:{name:'fake'}})).status,400);
 assert.equal((await call({action:'confirm',jobId:job.id,confirmed:true})).status,202);await finished(call);
 await call({action:'confirm',jobId:job.id,confirmed:true});assert.equal(writes,1);
});
test('a changed workspace blocks execution of the old proposal',async t=>{
 const f=fixture(t);f.ctx.hub.data.sources[0].board={modules:[]};f.ctx.planAction=async()=>({ok:true,text:'Draft',proposal:{name:'slack.message.send',args:{channel:'C123',text:'Draft'}}});
 const call=await endpoint(t,f.ctx);await call({action:'run',comment:'Send a draft',contextId:'last-night'});const job=(await finished(call))[0];
 f.ctx.hub.data.sources[0].board.modules.push({id:'new',body:'changed'});
 assert.equal((await call({action:'confirm',jobId:job.id,confirmed:true})).status,409);
});
test('authentication, origin, deduplication and failed model replies retain their actual status',async t=>{
 const f=fixture(t),call=await endpoint(t,f.ctx);f.ctx.authed=false;assert.equal((await call()).status,401);f.ctx.authed=true;
 assert.equal((await call({action:'chat',comment:'hello'},{origin:'https://elsewhere.example'})).status,403);
 f.ctx.planAction=async()=>({ok:false,reason:'model_unavailable'});
 const request={action:'chat',comment:'请查一个项目',requestId:'one'};const first=await call(request);assert.equal((await call(request)).job.id,first.job.id);assert.equal(first.job.requestId,'one');assert.ok(!('request' in first.job));
 const j=(await finished(call))[0];assert.equal(j.state,'failed');assert.equal(j.error,'model_unavailable');assert.equal(j.comment,request.comment);
});

test('an indexed meeting still yields its saved record when the pending file is unavailable',t=>{
 const f=fixture(t);f.ctx.session=()=>null;f.ctx.hub.data.sources[0].body='## 尚未约定\nCarl 的时间没有约定。\n\n[30] 原话';
 const out=route.minutes(f.ctx,'翻一下昨天晚上的会议纪要','zh');assert.match(out.reply,/Carl 的时间没有约定/);assert.doesNotMatch(out.reply,/\[30\]/);
});

test('assistant exposes live retrieval and model progress in its persisted job journal',async t=>{
 const f=fixture(t);f.ctx.planAction=async({onProgress})=>{onProgress('retrieving','正在查找飞书文档');onProgress('thinking','正在整理结果');return {ok:true,text:'Done'};};
 const call=await endpoint(t,f.ctx),accepted=await call({action:'chat',comment:'查产品文档',requestId:'progress-test'});assert.equal(accepted.status,202);
 const jobs=await finished(call),job=jobs.find(x=>x.id===accepted.job.id);assert.equal(job.state,'completed');
 assert.equal(job.codexThreadId,'codex:progress-test');
 assert.deepEqual(job.events.map(x=>x.message),['正在处理请求','正在查找会议与项目资料','正在调用 Codex 主助手','正在查找飞书文档','正在整理结果','结果已保存']);
});

test('two independent tasks overlap, expose early native links, and remain saved after reload',async t=>{
 const f=fixture(t),call=await endpoint(t,f.ctx);let running=0,peak=0;const releases=[];
 f.ctx.askCodex=async({onProgress,conversationId})=>{running++;peak=Math.max(peak,running);onProgress('thinking','Native task started',{threadId:'native-'+conversationId});await new Promise(resolve=>releases.push(resolve));running--;return {text:JSON.stringify({reply:'Draft '+conversationId,action:null}),threadId:'native-'+conversationId};};
 const one=await call({action:'auto',comment:'帮我写展示计划',requestId:'parallel-one'}),two=await call({action:'auto',comment:'生成素材清单',requestId:'parallel-two'});
 for(let i=0;i<30&&releases.length<2;i++)await new Promise(r=>setTimeout(r,10));assert.equal(peak,2);assert.equal(releases.length,2);
 const active=(await call()).jobs;assert.ok(active.filter(j=>['thinking','running','planning'].includes(j.state)).length===2);assert.ok(active.every(j=>j.codexThreadId.startsWith('native-')));
 releases.forEach(r=>r());await finished(call);const saved=new Jobs(f.dir).list(route.GLOBAL);assert.equal(saved.length,2);assert.ok(saved.every(j=>j.state==='planned'));assert.notEqual(one.job.id,two.job.id);
});
test('development access starts disabled, is local-only, and never uses a fallback on failure',async t=>{
 const f=fixture(t);let prefs={};f.ctx.settings={load:()=>({...prefs}),save:value=>{prefs={...value};}};f.ctx.isLocal=true;const server=http.createServer((req,res)=>route(req,res,new URL(req.url,'http://localhost'),f.ctx));await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(()=>new Promise(r=>server.close(r)));const base='http://127.0.0.1:'+server.address().port+'/workspace-assistant/preferences';
 assert.equal((await (await fetch(base)).json()).developerPreviewEnabled,false);f.ctx.isLocal=false;assert.equal((await fetch(base,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({developerPreviewEnabled:true})})).status,403);f.ctx.isLocal=true;
 const response=await fetch(base,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({developerPreviewEnabled:true})});assert.equal(response.status,200);assert.equal((await response.json()).developerPreviewEnabled,true);
 f.ctx.askCodex=async()=>{throw Error('native unavailable');};f.ctx.planAction=async()=>{throw Error('Fallback must not run for development');};const call=await endpoint(t,f.ctx);assert.equal((await call({action:'develop',comment:'修复这个布局'})).status,202);assert.equal((await finished(call))[0].error,'native unavailable');
});

// Native persistence must not delay the already indexed meeting record.
test('cached minutes appear while the actual Codex turn is still pending',async t=>{
 const f=fixture(t),call=await endpoint(t,f.ctx);let release,request;
 f.ctx.askCodex=async args=>{request=args;args.onProgress('thinking','Connected',{threadId:'native-cached'});await new Promise(r=>release=r);return {threadId:'native-cached',text:'ignored paraphrase',model:'selected-model',effort:'medium'};};
 const accepted=await call({action:'chat',comment:'翻一下昨天晚上的会议纪要',requestId:'cached-native',model:'selected-model'});
 for(let i=0;i<30&&!release;i++)await new Promise(r=>setTimeout(r,10));
 const job=(await call()).jobs.find(j=>j.id===accepted.job.id);
 assert.equal(job.state,'syncing');assert.match(job.reply,/Carl 的评审时间尚未确定/);assert.equal(job.codexThreadId,'native-cached');assert.equal(request.model,'selected-model');assert.equal(request.kind,'chat');assert.equal(request.requestText,'翻一下昨天晚上的会议纪要');assert.match(request.context.indexedMeetingLookup,/Carl/);
 release();const final=(await finished(call))[0];assert.equal(final.state,'completed');assert.equal(final.reply,job.reply);assert.equal(final.codexThreadId,'native-cached');assert.equal(final.model,'selected-model');assert.equal(final.effort,'medium');
});

test('event streams require auth, update multiple tabs, and reconnect without replaying work',async t=>{
 const f=fixture(t);let calls=0,release;
 f.ctx.askCodex=async({onProgress})=>{calls++;onProgress('thinking','Working',{threadId:'stream-native',reply:'Partial reply',stream:true});await new Promise(r=>release=r);return {threadId:'stream-native',text:'{"reply":"Done","action":null}'};};
 const server=http.createServer((req,res)=>route(req,res,new URL(req.url,'http://localhost'),{...f.ctx,authed:req.headers.authorization==='test'}));
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 t.after(()=>{server.closeAllConnections();server.close();});
 const base='http://127.0.0.1:'+server.address().port+'/workspace-assistant',headers={authorization:'test','Content-Type':'application/json'};
 assert.equal((await fetch(base+'/events')).status,401);
 assert.equal((await fetch(base+'/events',{headers:{...headers,origin:'https://wrong.example'}})).status,403);
 const readers=[];
 async function open(){const r=await fetch(base+'/events',{headers});assert.match(r.headers.get('content-type'),/text\/event-stream/);const reader=r.body.getReader();readers.push(reader);return reader;}
 async function until(reader,pattern){let text='';for(let n=0;n<20;n++){const {value,done}=await reader.read();if(done)throw Error('stream ended');text+=Buffer.from(value).toString();if(pattern.test(text))return text;}throw Error('event missing');}
 const a=await open(),b=await open();await until(a,/"jobs":\[\]/);await until(b,/"jobs":\[\]/);
 const accepted=await fetch(base,{method:'POST',headers,body:JSON.stringify({action:'auto',comment:'制作展示草稿',requestId:'stream-once'})});assert.equal(accepted.status,202);
 await Promise.all([until(a,/Partial reply/),until(b,/Partial reply/)]);assert.equal(calls,1);
 await a.cancel();const c=await open();await until(c,/Partial reply/);assert.equal(calls,1);
 release();await Promise.all([until(b,/"reply":"Done"/),until(c,/"reply":"Done"/)]);
 for(const r of readers)try{await r.cancel();}catch{}
});


test('an explicitly selected model never silently falls back on startup failure',async t=>{
 const f=fixture(t);let fallbackCalls=0;f.ctx.askCodex=async()=>{throw Object.assign(Error('model unavailable'),{stage:'start'});};f.ctx.planAction=async()=>{fallbackCalls++;return {ok:true,text:'Different model'};};
 const call=await endpoint(t,f.ctx),accepted=await call({action:'chat',comment:'分析这个项目',model:'selected-model'}),job=(await finished(call)).find(j=>j.id===accepted.job.id);
 assert.equal(job.state,'failed');assert.match(job.error,/未切换其他模型/);assert.equal(fallbackCalls,0);
});

// A fresh trial installation must never wait for an absent desktop app.
test('API default starts MyAgent without Codex and preserves its label and cancellation signal',async t=>{
 const f=fixture(t);let cli=0,planned=0;f.ctx.settings={load:()=>({FREE_AI_URL:'https://trial.example',FREE_AI_TOKEN:'trial-token'})};
 f.ctx.askCodex=async()=>{cli++;throw Error('must not call');};
 f.ctx.planAction=async({signal})=>{planned++;assert.ok(signal instanceof AbortSignal);return {ok:true,text:'Free model answered'};};
 const call=await endpoint(t,f.ctx),accepted=await call({action:'chat',comment:'Brainstorm hardware',lang:'en'});
 const job=(await finished(call)).find(j=>j.id===accepted.job.id);assert.equal(job.state,'completed');assert.equal(job.reply,'Free model answered');assert.equal(cli,0);assert.equal(planned,1);
 assert.ok(job.events.some(e=>/configured AI/.test(e.message)));
});

test('Agent receives notes-first retrieval and evidence-based follow-up rules in the shared retrieval context',async t=>{
 const f=fixture(t);let input;const ask=f.ctx.askCodex;f.ctx.askCodex=async request=>{input=request;return ask(request);};const call=await endpoint(t,f.ctx);await call({action:'chat',comment:'Carl 的后续准备怎么样'});await finished(call);
 assert.match(input.context.meetingRetrieval.strategy,/metadata.*date.*participant/);assert.match(input.context.meetingRetrieval.strategy,/notes.*transcript/);assert.match(input.context.meetingRetrieval.followUps,/explicit assigned or accepted/);assert.match(input.context.meetingRetrieval.followUps,/unstated deadlines as unknown/);
});

test('provider fallback retains the same conservative meeting retrieval rules',async t=>{
 const f=fixture(t);let context;f.ctx.askCodex=async()=>{throw Object.assign(Error('unavailable'),{stage:'start'});};f.ctx.planAction=async input=>{context=JSON.parse(input.context);return {ok:true,text:'Draft'};};
 const call=await endpoint(t,f.ctx);await call({action:'chat',comment:'Carl 的后续准备怎么样'});await finished(call);
 assert.match(context.meetingRetrieval.strategy,/notes.*transcript/);assert.match(context.meetingRetrieval.followUps,/explicit assigned or accepted/);
});

for(const provider of ['Codex','DeepSeek'])test('outgoing identity follows the actual AI: '+provider,async t=>{
 const f=fixture(t),owner=require('../app/owner-tracking');owner.saveOwnerName(f.ctx.dataDir,'Shawn');let sent;
 f.ctx.planAction=async()=>({ok:true,provider,text:'Review',proposal:{name:'slack.message.send',args:{channel:'C123',text:'Draft\n\n— 由 Codex 代 Aaron Wang 发送。'}}});
 if(provider!=='Codex')f.ctx.askCodex=async()=>{throw Error('unavailable');};
 f.ctx.executeAction=async p=>{sent=p.args.text;return {ok:true,result:{ok:true},receipt:{status:'sent'}};};
 const call=await endpoint(t,f.ctx);await call({action:'run',comment:'Send draft'});const job=(await finished(call))[0];
 assert.equal(job.state,'awaiting_confirmation');assert.equal(job.proposal.args.text,'Draft\n\n— 由 '+provider+' 代 Shawn 发送。');
 await call({action:'confirm',jobId:job.id,confirmed:true});await finished(call);assert.equal(sent,job.proposal.args.text);
});
test('renaming the local user invalidates a pending message without sending',async t=>{
 const f=fixture(t),owner=require('../app/owner-tracking');owner.saveOwnerName(f.ctx.dataDir,'Shawn');
 f.ctx.planAction=async()=>({ok:true,text:'Review',proposal:{name:'slack.message.send',args:{channel:'C123',text:'Draft'}}});
 const call=await endpoint(t,f.ctx);await call({action:'run',comment:'Send draft'});const job=(await finished(call))[0];
 owner.saveOwnerName(f.ctx.dataDir,'Hannah');assert.equal((await call({action:'confirm',jobId:job.id,confirmed:true})).status,409);
});
