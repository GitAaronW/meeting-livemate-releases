'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),http=require('node:http');
const {InsightFeed,create,rules,jpegSize,cards,panelCards}=require('../app/native-meeting');
const delay=ms=>new Promise(r=>setTimeout(r,ms));
function setup(t,ask=async()=>'{"suggestion":null,"insights":[]}'){
 const dataDir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-native-'));const session={id:'s-native',uiLang:'zh',transcript:[],onMacResult({text}){if(this.transcript.at(-1)?.text===text)return;this.transcript.push({id:'seg-'+this.transcript.length,text,t:'00:01'});}};
 const feed=new InsightFeed({dataDir,session,ask});t.after(()=>{feed.close();fs.rmSync(dataDir,{recursive:true,force:true});});return {dataDir,session,feed};
}
function cancelTimer(f){clearTimeout(f.timer);f.timer=null;}
function jpeg(w=960,h=540){return Buffer.from([255,216,255,192,0,8,8,h>>8,h&255,w>>8,w&255,1,255,217]).toString('base64');}
test('quiet means no model call; duplicate sentence is not a new event',async t=>{
 let n=0;const {feed}=setup(t,async()=>{n++;return '{"suggestion":null,"insights":[]}';});await delay(180);assert.equal(n,0);assert.equal(feed.text({key:'a',text:'目标是展示模型。'}),true);cancelTimer(feed);assert.equal(feed.text({key:'a',text:'目标是展示模型。'}),false);assert.equal(feed.text({key:'b',text:'目标是展示模型。'}),false);await feed.run();assert.equal(n,1);await feed.run();await delay(150);assert.equal(n,1);
});
test('coalesces incoming events, single flight, only six recent sentences and one bounded image',async t=>{
 const inputs=[];let release;const {feed}=setup(t,async(sys,user,opts)=>{inputs.push({sys,json:JSON.parse(user),opts});if(inputs.length===1)await new Promise(r=>release=r);return '{"suggestion":null,"insights":[]}';});
 feed.text({key:'0',text:'句子0'});cancelTimer(feed);const first=feed.run();await delay(1);
 for(let i=1;i<=12;i++)feed.text({key:String(i),text:'新句'+i+'x'.repeat(500)});feed.frame(jpeg());assert.equal(feed.frame(jpeg()),false);await feed.run();assert.equal(inputs.length,1);release();await first;cancelTimer(feed);await feed.run();assert.equal(inputs.length,2);assert.equal(inputs[1].json.transcript.length<=6,true);assert.equal(inputs[1].json.transcript.reduce((n,x)=>n+x.text.length,0)<=2400,true);assert.equal(inputs[1].opts.images.length,1);assert.equal(inputs[1].opts.tools,false);assert.equal(inputs[1].opts.thinkGuide,false);assert.equal(inputs[1].opts.timeoutMs,25000);
});
test('caps visible cards and removes invented source references',()=>{
 const c=cards(JSON.stringify({suggestion:{text:'x'.repeat(400),sourceIds:['s','invented']},insights:[{text:'1',sourceIds:['s']},{text:'2',sourceIds:['s']},{text:'3',sourceIds:['s']}]}),new Set(['s']));assert.equal(c.suggestion.text.length,400);assert.deepEqual(c.suggestion.sourceIds,['s']);assert.equal(c.insights.length,2);
});
test('pause invalidates a late reply and blocks new events; resume alone is quiet',async t=>{
 let release,n=0;const {feed}=setup(t,async()=>{n++;await new Promise(r=>release=r);return '{"suggestion":{"text":"late","sourceIds":[]},"insights":[]}';});feed.text({key:'a',text:'这里需要判断'});cancelTimer(feed);const p=feed.run();feed.pause(true);assert.equal(feed.text({key:'b',text:'pause'}),false);release();await p;assert.equal(feed.cardState.suggestion,null);feed.pause(false);await feed.run();assert.equal(n,1);
});
test('hot configuration applies at the next event, with hard budget limits',async t=>{
 let prompt;const {feed,dataDir}=setup(t,async(s)=>{prompt=s;return '{"suggestion":null,"insights":[]}';});fs.mkdirSync(path.join(dataDir,'state'),{recursive:true});fs.writeFileSync(path.join(dataDir,'state','native-insight-rules.json'),JSON.stringify({revision:2,prompt:'Updated rule',recentSentences:999,maxTextChars:99999,minGapMs:1}));const r=rules(dataDir);assert.equal(r.recentSentences,6);assert.equal(r.maxTextChars,2400);assert.equal(r.minGapMs,1000);feed.text({key:'a',text:'新的信息'});cancelTimer(feed);await feed.run();assert.ok(prompt.startsWith('Updated rule'));assert.match(prompt,/optional deliverable/);assert.equal(feed.ruleRevision,'2');
});
test('image bounds, latest-frame storage and no duplicate frame calls',async t=>{
 const {feed,dataDir}=setup(t);assert.deepEqual(jpegSize(Buffer.from(jpeg(),'base64')),{width:960,height:540});assert.throws(()=>feed.frame(jpeg(1200)),/frame_dimensions/);assert.throws(()=>feed.frame(Buffer.alloc(160001).toString('base64')),/frame_too_large/);assert.throws(()=>feed.frame('invalid'),/invalid_jpeg/);feed.frame(jpeg(900));feed.frame(jpeg(800));cancelTimer(feed);await feed.run();const files=fs.readdirSync(path.join(dataDir,'state','native-frames','s-native'));assert.equal(files.length,1);assert.equal(feed.frame(jpeg(800)),false);
});
test('HTTP handoff adopts the same meeting, pause/end are explicit, local and origin checks apply',async t=>{
 const dataDir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-native-route-'));let adopted=0,finalized=0;
 const session={id:'same-session',title:'已在开的会',audioPath:'/tmp/test.pcm',transcript:[],uiLang:'zh',enableNativeCapture(){this.nativeCapture=true;adopted++;},broadcast(){},checkpoint(){},onMacResult(){},async finalize(){this.finalized=true;finalized++;}};
 let manager;const server=http.createServer((req,res)=>manager.route(req,res,new URL(req.url,'http://local'),req.headers['x-remote']!=='yes'));await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port;
 manager=create({dataDir,port,activeSession:()=>session,startSession:()=>{throw Error('must not create another meeting');},ask:async()=>'{"suggestion":null,"insights":[]}'});t.after(()=>{manager.close();server.closeAllConnections();server.close();fs.rmSync(dataDir,{recursive:true,force:true});});
 const req=(route,body={},headers={})=>fetch('http://127.0.0.1:'+port+'/asr-relay/native/'+route,{method:'POST',headers:{'content-type':'application/json',...headers},body:JSON.stringify(body)});
 assert.equal((await req('start',{}, {'x-remote':'yes'})).status,403);assert.equal((await req('start',{}, {origin:'https://evil.example'})).status,403);
 assert.equal((await req('start',{target:{windowId:15,bundleId:'com.bytedance.Feishu',title:'视频会议'}})).status,200);assert.equal(manager.status().sessionId,'same-session');assert.equal(adopted,1);assert.equal(finalized,0);
 for(const view of ['compact','hidden','expanded']){const response=await req('heartbeat',{sessionId:session.id,view});assert.equal(response.status,200);assert.equal((await response.json()).view,view);assert.equal(manager.status().sessionId,'same-session');assert.equal(manager.status().active,true);assert.equal(finalized,0);}
 await req('heartbeat',{sessionId:session.id,view:'unknown'});assert.equal(manager.status().view,'expanded');
 const proposal=require('../app/live-confirmations').offer(session,{question:'先做可展示的看板？',statement:'先生成典型一天的看板草稿。',impact:'conflict',quote:'CAD 和看板暂时不能同时交付',whyNow:'两个产物占用同一个制作窗口，必须先定交付顺序。',sourceIds:['s1']},[{id:'s1',speaker:'Aaron',t:'01:20',text:'CAD 和看板暂时不能同时交付'}]);
 assert.equal(manager.status().confirmation.id,proposal.id);
 assert.equal((await req('confirmation',{sessionId:'other',confirmationId:proposal.id,response:'confirm'})).status,409);
 assert.equal((await req('confirmation',{sessionId:session.id,confirmationId:proposal.id,response:'confirm'})).status,200);
 assert.equal(manager.status().confirmation,null);
 assert.equal(require('../app/memory').open(dataDir).prepare('SELECT confirmed FROM cards WHERE id=?').get('live-'+proposal.id).confirmed,1);
 assert.equal((await req('confirmation',{sessionId:session.id,confirmationId:proposal.id,response:'confirm'})).status,200);
 assert.equal(manager.requestCommand(session.id,'stop'),true);assert.equal(manager.status().command,'stop');assert.equal(finalized,0);assert.equal(manager.requestCommand('other','stop'),false);assert.equal((await req('end',{sessionId:'another'})).status,409);assert.equal((await req('pause',{sessionId:session.id,paused:true})).status,200);assert.equal(manager.status().phase,'paused');assert.equal(finalized,0);await req('end',{sessionId:session.id});assert.equal(finalized,1);assert.equal(manager.status().active,false);
});

test('source edits discard a late interpretation and leave the mini window listening',async t=>{
 let release,signals=0;const {feed,session}=setup(t,async()=>new Promise(r=>release=r));
 feed.onSignals=()=>signals++;feed.text({key:'a',text:'名称可能需要纠正'});cancelTimer(feed);const pending=feed.run();
 session.editEpoch=1;release('{"suggestion":null,"insights":[]}');await pending;
 assert.equal(signals,0);assert.equal(feed.phase,'listening');assert.equal(feed.busy,false);
});

test('native and browser mini views display the validated current judgement from the same Session',async t=>{
 const quote='未来应该像 The Jacksons 那样温暖。';
 const {feed,session,dataDir}=setup(t,async()=>JSON.stringify({suggestion:null,insights:[],currentJudgment:{topic:'未来体验',point:'可能是在说 The Jetsons 的乐观未来；这只是 AI 解读。',whyChanged:'说话人用温暖的未来生活解释了这个名称。',quote,sourceIds:['seg-0']}}));
 feed.onSignals=require('../app/live-signals').create({dataDir,ask:async()=>{throw Error('no extra call');}});
 feed.text({key:'a',text:quote});cancelTimer(feed);await feed.run();
 assert.equal(session.factchecks.length,1);assert.equal(feed.cardState.insights.length,1);
 assert.match(feed.cardState.insights[0].text,/AI 解读/);
 assert.deepEqual(feed.cardState.insights[0].sourceIds,['seg-0']);
 const manager=create({dataDir,activeSession:()=>session,startSession:()=>{throw Error('same session only');},ask:async()=>''});t.after(()=>manager.close());
 const s=manager.status();assert.equal(s.sessionId,session.id);assert.equal(s.captureMode,'browser');assert.equal(s.cards.insights[0].text,feed.cardState.insights[0].text);
 session.factchecks[0].supersededBy='new';assert.equal(manager.status().cards.insights.length,0);
});

test('same Jetsons point is shown once; another useful insight survives even with the same sources',()=>{
 const {mergeJudgmentCards}=require('../app/native-meeting');
 const next={suggestion:null,insights:[
  {text:'“The Jetsons”是1962年美国动画《杰森一家》，以飞行汽车、机器人管家等轻松未来生活著称，可作乐观科技感的视觉参照。',sourceIds:['j1','j2']},
  {text:'此草稿明天先交 CAD 白模给 Carl，预算上限为两万元。',sourceIds:['j1','j2']}]};
 const signals=[{channel:'judgment',point:'老板指的是1962年动画《杰森一家》，其乐观未来感来自日常化的飞行汽车与机器人管家，而非宏大科技叙事；同事未听过，需先对齐这一参照。',sourceRefs:[{segId:'j1'},{segId:'j2'}]}];
 const result=mergeJudgmentCards(next,signals);
 assert.equal(result.insights.length,2);assert.equal(result.insights.filter(x=>x.text.includes('Jetsons')||x.text.includes('杰森一家')).length,1);
 assert.ok(result.insights.some(x=>x.text.includes('两万元')));assert.ok(result.insights.some(x=>x.text.startsWith('AI 解读：')));
});

 test('mini history uses the persisted Session, bounds old reminders and readable sources',()=>{
 const session={transcript:[{id:'s',t:2286,speaker:'Aaron',text:'source'}],nativeInsights:{history:[]}};
 for(let i=0;i<45;i++)session.nativeInsights=panelCards(session,{suggestion:{text:'reminder '+i,sourceIds:['s']},insights:[]},{append:true,now:()=>i});
 const state=panelCards(session,{suggestion:{text:'now',sourceIds:['s']},insights:[{text:'insight',sourceIds:['s']}]});
 assert.equal(state.history.length,40);assert.equal(state.suggestion.sourceLabel,'38:06 · Aaron');assert.equal(state.insights.length,1);
 assert.equal(new Set(state.history.map(x=>x.key)).size,40);assert.equal(state.history[0].text,'reminder 5');
 const bounded=cards(JSON.stringify({suggestion:{text:'x'.repeat(1600),sourceIds:['s']}}),new Set(['s']));assert.equal(bounded.suggestion.text.length,1200);
 });
 test('open main is a local controlled route, not an arbitrary URL opener',async t=>{
 const dataDir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-open-main-'));let calls=[];let manager;
 const server=http.createServer((req,res)=>manager.route(req,res,new URL(req.url,'http://local'),req.headers['x-remote']!=='yes'));await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port;
 manager=create({dataDir,port,startSession:()=>{},activeSession:()=>null,ask:async()=>'',openMain:async args=>{require('../app/desktop-open').localUrl(args);calls.push(args);return {mode:'installed-app'};}});
 t.after(()=>{manager.close();server.closeAllConnections();server.close();fs.rmSync(dataDir,{recursive:true,force:true});});
 const post=(body,headers={})=>fetch('http://127.0.0.1:'+port+'/native/open-main',{method:'POST',headers:{'content-type':'application/json',...headers},body:JSON.stringify(body)});
 assert.equal((await post({sessionId:'same-meeting'},{origin:'https://evil.example'})).status,403);assert.equal((await post({sessionId:'same-meeting'},{'x-remote':'yes'})).status,403);assert.equal(calls.length,0);
 assert.equal((await post({sessionId:'https://evil.example'})).status,409);assert.equal(calls.length,0);
 assert.equal((await post({sessionId:'same-meeting'})).status,200);assert.deepEqual(calls,[{port,sessionId:'same-meeting'}]);
 });

test('join link validation accepts the selected meeting only, never arbitrary pages',()=>{
 const {meetingLink}=require('../app/native-meeting');
 for(const u of ['https://vc.feishu.cn/j/123456789','https://vc.larksuite.com/j/123456789?pwd=abc','https://meet.google.com/abc-defg-hij'])assert.equal(meetingLink(u),u);
 for(const u of [null,{},'https://meet.google.com.evil/abc-defg-hij','https://user:pass@meet.google.com/abc-defg-hij','http://meet.google.com/abc-defg-hij','https://meet.google.com/lookup/private','https://vc.feishu.cn/j/123','https://vc.feishu.cn/doc/123456789'])assert.throws(()=>meetingLink(u));
});
test('joining respects the existing recorder, serializes different links and recovers launch failure',async t=>{
 const dataDir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-join-'));let current=null,callback,opens=0;
 let manager;const server=http.createServer((req,res)=>manager.route(req,res,new URL(req.url,'http://local'),true));await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port;
 manager=create({dataDir,port,activeSession:()=>current,startSession:()=>{throw Error('joining must not create a session before capture');},ask:async()=>'',canLaunch:()=>true,launch:(bin,args,opt,cb)=>{opens++;callback=cb;}});
 t.after(()=>{manager.close();server.closeAllConnections();server.close();fs.rmSync(dataDir,{recursive:true,force:true});});
 const req=(route,body)=>fetch('http://127.0.0.1:'+port+'/asr-relay/native/'+route,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});
 const url='https://meet.google.com/abc-defg-hij';
 assert.equal((await req('join',{url})).status,200);assert.equal(manager.status().command,'join');assert.equal(manager.status().meetingUrl,url);assert.equal(opens,1);
 assert.equal((await req('join',{url})).status,200);assert.equal(opens,1);
 assert.equal((await req('join',{url:'https://meet.google.com/xyz-abcd-efg'})).status,409);
 await req('launch',{autoStart:true});assert.equal(manager.status().command,'join');
 callback(Error('launch failed'));assert.equal(manager.status().command,'');assert.equal(manager.status().meetingUrl,'');
 assert.equal((await req('join',{url})).status,200);callback(null);await req('launch-ack',{});assert.equal(manager.status().command,'');
 current={id:'already',transcript:[],nativeCapture:false};assert.equal((await req('join',{url})).status,409);assert.equal(manager.status().sessionId,'already');assert.equal(opens,2);
});

test('repeated suggestion and interpretation use one card; English label follows the session',()=>{
 const text='The Jetsons reference suggests optimistic technology as an ordinary part of everyday life.';
 const next={suggestion:{text,sourceIds:['a']},insights:[]};
 const result=require('../app/native-meeting').mergeJudgmentCards(next,[{channel:'judgment',point:text,sourceRefs:[{segId:'a'}]}],true);
 assert.equal(result.suggestion,null);assert.equal(result.insights.length,1);assert.ok(result.insights[0].text.startsWith('AI interpretation: '));
});
