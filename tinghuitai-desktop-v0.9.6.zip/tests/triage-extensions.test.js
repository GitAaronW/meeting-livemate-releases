'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {run}=require('../app/triage-extensions');
for(const broken of ['deliverables','signals','confirmation'])test('optional '+broken+' failure leaves other work running',()=>{
 const called=[],logs=[],hooks={log:m=>logs.push(m)};
 for(const name of ['deliverables','signals','confirmation'])hooks[name]=()=>{called.push(name);if(name===broken)throw Error('injected');};
 assert.doesNotThrow(()=>run({}, {deliverable:{},insights:[{confirmation:{}}]},[],hooks));
 assert.deepEqual(called,['deliverables','signals','confirmation','confirmation']);assert.ok(logs.length);
});
