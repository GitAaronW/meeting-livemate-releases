'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..'),read=p=>fs.readFileSync(path.join(root,p),'utf8');
test('settings edits stay as drafts until the shared save action',()=>{const js=read('web/src/07-settings-top.js');assert.match(js,/s-asr'\)\.onchange = paintAsr/);assert.doesNotMatch(js,/s-asr'\)\.onchange[^;]*fetch/);assert.match(js,/await saveServerDraft\(form\)/);});
test('view feedback uses an inline editor and legacy cards use a neutral label',()=>{const js=read('web/src/11-render.js');assert.match(js,/view-inline-feedback/);assert.doesNotMatch(js,/const comment=prompt/);assert.match(js,/legacy:en\?'Note':'提醒'/);});
test('task dialog has one title and the footer version describes the loaded build',()=>{const html=read('web/index.template.html'),ready=read('web/src/10-ready-bar.js');assert.equal((html.match(/id="task-dialog"/g)||[]).length,1);assert.doesNotMatch(html,/v5\.3|09-09/);assert.match(ready,/tht-build/);assert.doesNotMatch(ready,/h\.version/);});
