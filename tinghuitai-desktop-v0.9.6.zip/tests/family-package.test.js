'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),os=require('os'),path=require('path'),{execFileSync}=require('child_process');
const gate=path.resolve(__dirname,'../scripts/check-family-package.py');
test('family exemption covers only one byte-identical preset; other files still enter the public gate',()=>{
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'tht-family-'));
 try{
  const app=path.join(root,'Live.app'),dir=path.join(app,'Contents/Resources/program');fs.mkdirSync(dir,{recursive:true});
  const content=JSON.stringify({PRESET_VERSION:'family-test',LLM_PROVIDER:'api',DEEPSEEK_API_KEY:'fixture-secret-only'});
  const expected=path.join(root,'authorized.json'),preset=path.join(dir,'preset.json');fs.writeFileSync(expected,content);fs.writeFileSync(preset,content,{mode:0o600});
  const scan=path.join(root,'scan.sh');fs.writeFileSync(scan,'#!/bin/bash\n[ ! -f "$1/Contents/Resources/program/preset.json" ] || exit 9\n[ ! -f "$1/leaked.txt" ] || exit 8\n');
  const run=()=>execFileSync('python3',['-c','import importlib.util,sys; s=importlib.util.spec_from_file_location("gate",sys.argv[1]);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.check(*sys.argv[2:])',gate,app,expected,scan],{stdio:'pipe'});
  run();fs.writeFileSync(path.join(app,'leaked.txt'),'not exempt');assert.throws(run);fs.unlinkSync(path.join(app,'leaked.txt'));
  fs.writeFileSync(preset,content+' ');assert.throws(run);fs.writeFileSync(preset,content);fs.chmodSync(preset,0o644);assert.throws(run);fs.chmodSync(preset,0o600);
  fs.writeFileSync(path.join(app,'preset.json'),content);assert.throws(run);
 }finally{fs.rmSync(root,{recursive:true,force:true});}
});
test('fresh family configuration is private; upgrading fills blanks and preserves existing user settings and history',()=>{
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'tht-family-config-'));
 try{
  const program=path.join(root,'program'),data=path.join(root,'data');fs.mkdirSync(path.join(program,'app'),{recursive:true});
  fs.copyFileSync(path.resolve(__dirname,'../app/config.js'),path.join(program,'app/config.js'));
  const preset={PRESET_VERSION:'family-test',ASR_PROVIDER:'volc',VOLC_APP_KEY:'fixture-app',VOLC_ACCESS_KEY:'fixture-asr',VOLC_RESOURCE_ID:'fixture-resource',DEEPSEEK_API_KEY:'fixture-llm',LLM_PROVIDER:'api',LLM_MODEL:'deepseek-chat'};
  fs.writeFileSync(path.join(program,'preset.json'),JSON.stringify(preset),{mode:0o600});
  const run=()=>JSON.parse(execFileSync(process.execPath,['-e','const c=require(process.argv[1]);console.log(JSON.stringify(c.load()))',path.join(program,'app/config.js')],{env:{...process.env,THT_DATA_DIR:data},encoding:'utf8'}));
  const first=run();assert.equal(first.DEEPSEEK_API_KEY,preset.DEEPSEEK_API_KEY);assert.equal(first.LLM_PROVIDER,'api');assert.ok(first.RELAY_TOKEN);assert.equal(fs.statSync(path.join(data,'settings.json')).mode&0o777,0o600);
  const previous={...first,DEEPSEEK_API_KEY:'wifes-own-key',LLM_PROVIDER:'codex',LLM_MODEL:'her-model',VOLC_ACCESS_KEY:'her-asr',JEV_API_KEY:''};
  fs.writeFileSync(path.join(data,'settings.json'),JSON.stringify(previous));fs.writeFileSync(path.join(data,'meeting.json'),'preserve this meeting');
  fs.writeFileSync(path.join(program,'preset.json'),JSON.stringify({...preset,PRESET_VERSION:'family-next',JEV_API_KEY:'fixture-jev'}));
  const upgraded=run();assert.equal(upgraded.DEEPSEEK_API_KEY,'wifes-own-key');assert.equal(upgraded.LLM_PROVIDER,'codex');assert.equal(upgraded.LLM_MODEL,'her-model');assert.equal(upgraded.VOLC_ACCESS_KEY,'her-asr');assert.equal(upgraded.JEV_API_KEY,'fixture-jev');assert.equal(upgraded.RELAY_TOKEN,first.RELAY_TOKEN);assert.equal(fs.readFileSync(path.join(data,'meeting.json'),'utf8'),'preserve this meeting');
 }finally{fs.rmSync(root,{recursive:true,force:true});}
});
