'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const {createService}=require('../app/free-ai-service');
const token='trial-'.repeat(8),key='private-upstream-key';
const body={model:'deepseek-chat',messages:[{role:'system',content:'system'},{role:'user',content:'hello'}],stream:false};
async function fixture(ask){let config={FREE_AI_TOKEN:token,DEEPSEEK_API_KEY:key};const srv=createService({load:()=>config,ask,timeoutMs:150});await new Promise(r=>srv.listen(0,'127.0.0.1',r));return {srv,url:'http://127.0.0.1:'+srv.address().port,rotate:()=>{config={...config,FREE_AI_TOKEN:'other-'.repeat(8)};}};}
const post=(h,b=body,t=token)=>fetch(h.url+'/chat/completions',{method:'POST',headers:{authorization:'Bearer '+t,'content-type':'application/json'},body:JSON.stringify(b)});
test('trial relay routes only AI, rejects bad token/schema/oversized bodies and supports immediate revocation',async()=>{let calls=0;const h=await fixture(async(env,args)=>{calls++;assert.equal(env.DEEPSEEK_API_KEY,key);assert.equal(args.user,'hello');return{text:'reply',model:'deepseek-chat',usage:{in:4,out:2}};});try{
 assert.equal((await fetch(h.url+'/health')).status,200);assert.equal((await fetch(h.url+'/setup')).status,404);
 assert.equal((await post(h,body,'wrong')).status,401);assert.equal((await post(h,{...body,tools:[]})).status,400);
 assert.equal((await post(h,{...body,messages:[{role:'assistant',content:'x'}]})).status,400);
 assert.equal((await post(h,{...body,messages:[{role:'user',content:'a'.repeat(200000)}]})).status,413);
 const ok=await post(h);assert.equal(ok.status,200);assert.equal((await ok.json()).choices[0].message.content,'reply');
 h.rotate();assert.equal((await post(h)).status,401);assert.equal(calls,1);
 }finally{h.srv.closeAllConnections();h.srv.close();}});
test('upstream errors never echo credentials; deadline cancels the model request',async()=>{let aborted=false;const h=await fixture((_env,{signal})=>new Promise((_,reject)=>signal.addEventListener('abort',()=>{aborted=true;reject(Error(key));})));try{const r=await post(h);assert.equal(r.status,504);assert.equal(aborted,true);assert.ok(!(await r.text()).includes(key));}finally{h.srv.closeAllConnections();h.srv.close();}});
test('disconnect aborts work instead of continuing to spend',async()=>{let started,done;const ready=new Promise(r=>started=r),ended=new Promise(r=>done=r);const h=await fixture((_env,{signal})=>new Promise((_,reject)=>{started();signal.addEventListener('abort',()=>{done();reject(Error('stopped'));});}));try{const controller=new AbortController();const pending=post(h); // Deadline also guarantees bounded cleanup.
 await ready;h.srv.closeAllConnections();await ended;await pending.catch(()=>{});
 }finally{h.srv.close();}});
