'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),os=require('os'),path=require('path');
const desktop=require('../app/desktop-open');
test('desktop launch discovers this user app and retains the requested meeting without copying a profile',async()=>{
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'tht-desktop-'));
 try{
  for(const name of ['Foreign.app','Live.app'])fs.mkdirSync(path.join(root,name));
  const info=f=>f.includes('Foreign.app')?{CrAppModeShortcutURL:'https://example.com/tinghuitai/',CrAppModeShortcutID:'a'.repeat(32)}:{CrAppModeShortcutURL:'http://127.0.0.1:49201/tinghuitai/index.html',CrAppModeShortcutID:'b'.repeat(32)};
  const findApp=port=>desktop.findApp(port,{roots:[root],readPlist:info});
  const spec=desktop.launchSpec({port:49201,sessionId:'real-meeting'},{platform:'darwin',exists:()=>true,findApp});
  assert.equal(spec.mode,'installed-app');assert.ok(spec.args.includes('--app-id='+'b'.repeat(32)));
  assert.ok(spec.args.includes('--app-launch-url-for-shortcuts-menu-item=http://127.0.0.1:49201/tinghuitai/index.html?id=real-meeting'));
  assert.equal(spec.args.some(x=>x.includes('profile')||x.includes('user-data')),false);
  const result=await desktop.openMain({port:49201,sessionId:'real-meeting'},{platform:'darwin',exists:()=>true,findApp,spawn:(cmd,args,opt)=>{assert.equal(cmd,'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome');assert.deepEqual(args,spec.args);const child=new(require('events').EventEmitter)();child.unref=()=>{};queueMicrotask(()=>child.emit('spawn'));return child;}});
  assert.equal(result.url,spec.url);assert.equal(result.mode,'installed-app');
 }finally{fs.rmSync(root,{recursive:true,force:true});}
});
test('opening main rejects arbitrary targets and has an explicit standalone app fallback',()=>{
 for(const bad of ['../other','https://evil.test/','x&other=1'])assert.throws(()=>desktop.localUrl({sessionId:bad}));
 assert.throws(()=>desktop.localUrl({port:70000}));
 const fallback=desktop.launchSpec({sessionId:'one'},{platform:'darwin',exists:()=>true,findApp:()=>null});
 assert.equal(fallback.mode,'app-window');assert.equal(fallback.args.at(-1),'--app=http://127.0.0.1:47823/tinghuitai/index.html?id=one');
 assert.equal(desktop.launchSpec({}, {platform:'darwin',exists:()=>false}).mode,'browser');
});
