'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),os=require('os'),path=require('path'),{spawnSync}=require('child_process');
test('build rejects mismatched manifest before copying or producing a ZIP',t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-build-version-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));fs.mkdirSync(path.join(dir,'scripts'));
 fs.copyFileSync(path.join(__dirname,'../scripts/build-release.sh'),path.join(dir,'scripts/build-release.sh'));
 fs.writeFileSync(path.join(dir,'package.json'),JSON.stringify({version:'0.8.1'}));fs.writeFileSync(path.join(dir,'version.json'),JSON.stringify({version:'0.8.0'}));
 const out=path.join(dir,'should-not-exist.zip'),r=spawnSync('/bin/bash',[path.join(dir,'scripts/build-release.sh'),out],{encoding:'utf8'});
 assert.equal(r.status,1);assert.match(r.stderr,/版本不一致/);assert.equal(fs.existsSync(out),false);
});
test('release and runtime version have a single value',()=>{assert.equal(require('../package.json').version,require('../version.json').version);});
