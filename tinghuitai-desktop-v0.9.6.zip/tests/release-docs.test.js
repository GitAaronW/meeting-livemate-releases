'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),os=require('os'),path=require('path');
const {sanitize,PUBLIC_DOCS}=require('../scripts/release-docs');
test('public release docs keep only usage guides and remove internal records and unknown future docs',()=>{
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'tht-release-docs-'));
 try{
  const docs=path.join(root,'docs');fs.mkdirSync(docs);
  for(const n of PUBLIC_DOCS)fs.writeFileSync(path.join(docs,n),'usage');
  for(const n of ['internal-meeting.md','0.9.6-acceptance.json','new-private-notes.txt'])fs.writeFileSync(path.join(docs,n),'private reference');
  fs.mkdirSync(path.join(docs,'private'));fs.writeFileSync(path.join(docs,'private','meeting.json'),'private');
  const settings=path.join(root,'settings.json');fs.writeFileSync(settings,'untouched');sanitize(root);
  assert.deepEqual(fs.readdirSync(docs).sort(),[...PUBLIC_DOCS].sort());assert.equal(fs.readFileSync(settings,'utf8'),'untouched');
  sanitize(root);assert.deepEqual(fs.readdirSync(docs).sort(),[...PUBLIC_DOCS].sort());
 }finally{fs.rmSync(root,{recursive:true,force:true});}
});
test('both installer paths sanitize copied docs before producing distributable assets',()=>{
 for(const file of ['scripts/build-release.sh','packaging/make-app.sh'])assert.match(fs.readFileSync(path.resolve(__dirname,'..',file),'utf8'),/node "\$SRC\/scripts\/release-docs\.js"/);
});
