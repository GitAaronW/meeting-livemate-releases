'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),{EventEmitter}=require('events');
const safe=require('../app/public-page-fetch');
function transport({status=200,headers={'content-type':'text/html'},chunks=['<title>Useful page</title>']}={}){
 const calls=[];
 const request=(url,opts,respond)=>{const req=new EventEmitter();req.setTimeout=()=>{};req.destroy=e=>{if(e)req.emit('error',e);};req.end=()=>{
  calls.push({url,opts});queueMicrotask(()=>{const res=new EventEmitter();res.statusCode=status;res.headers=headers;res.destroy=()=>{};respond(res);for(const chunk of chunks)res.emit('data',Buffer.from(chunk));res.emit('end');});
 };return req;};return {calls,request};
}
test('reject private, mapped, reserved and non-HTTPS destinations',()=>{
 for(const ip of ['127.0.0.1','0.0.0.0','10.0.0.3','172.16.1.2','192.168.1.1','169.254.169.254','100.64.0.1','224.0.0.1','::1','::ffff:127.0.0.1','fe80::1','fc00::1','2002:7f00:1::','2001:db8::1'])assert.equal(safe.publicAddress(ip),false,ip);
 for(const ip of ['8.8.8.8','1.1.1.1','2606:4700:4700::1111','2001:4860:4860::8888'])assert.equal(safe.publicAddress(ip),true,ip);
 for(const url of ['http://example.com','https://localhost','https://127.1','https://2130706433','https://[::1]','https://user:pass@example.com','https://example.com:8443'])assert.equal(safe.publicUrl(url),null,url);
});
test('DNS private or mixed addresses are rejected before any request',async()=>{
 for(const addresses of [[{address:'10.0.0.1',family:4}],[{address:'8.8.8.8',family:4},{address:'::1',family:6}]]){
  const io=transport(),fetch=safe.create({...io,lookup:async()=>addresses});await assert.rejects(fetch('https://example.com'),/non-public/);assert.equal(io.calls.length,0);
 }
});
test('TLS connection uses pinned validated address despite DNS rebinding, both lookup modes',async()=>{
 let lookups=0;const io=transport(),fetch=safe.create({...io,lookup:async()=>[{address:++lookups===1?'8.8.8.8':'127.0.0.1',family:4}]});
 assert.match(await(await fetch('https://example.com')).text(),/Useful/);
 const opts=io.calls[0].opts;assert.equal(opts.servername,'example.com');assert.equal(opts.agent,false);
 opts.lookup('example.com',{},(err,address,family)=>{assert.equal(err,null);assert.equal(address,'8.8.8.8');assert.equal(family,4);});
 opts.lookup('example.com',{all:true},(err,addresses)=>{assert.equal(err,null);assert.deepEqual(addresses,[{address:'8.8.8.8',family:4}]);});assert.equal(lookups,1);
});
test('redirect is manual; next host gets new DNS validation and internal DNS is blocked',async()=>{
 const io=transport({status:302,headers:{location:'https://next.example/secret'}});let n=0;
 const fetch=safe.create({...io,lookup:async()=>[{address:++n===1?'8.8.8.8':'192.168.1.1',family:4}]});
 const first=await fetch('https://example.com');assert.equal(first.status,302);assert.equal(io.calls.length,1);
 await assert.rejects(fetch(first.headers.get('location')),/non-public/);assert.equal(io.calls.length,1);
});
test('response cap is measured in bytes and abort during DNS opens no connection',async()=>{
 const io=transport({chunks:['中'.repeat(100)]}),fetch=safe.create({...io,cap:30,lookup:async()=>[{address:'8.8.8.8',family:4}]});assert.equal(Buffer.byteLength(await(await fetch('https://example.com')).text()),30);
 const ctl=new AbortController(),never=safe.create({...io,lookup:()=>new Promise(()=>{})}),pending=never('https://example.com',{signal:ctl.signal});ctl.abort();await assert.rejects(pending,/Aborted/);assert.equal(io.calls.length,1);
});
