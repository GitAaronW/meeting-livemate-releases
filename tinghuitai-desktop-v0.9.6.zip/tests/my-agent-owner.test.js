'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),vm=require('node:vm');
const source=fs.readFileSync(require.resolve('../web/my-agent.js'),'utf8'),routes=require('../app/setup-routes'),owner=require('../app/owner-tracking');
class Node {
 constructor(tag){this.tag=tag;this.children=[];this.disabled=false;this.hidden=false;this.textContent='';this.value='';this.attrs={};this.classes=new Set();this.classList={add:x=>this.classes.add(x),remove:x=>this.classes.delete(x),contains:x=>this.classes.has(x)};}
 append(...nodes){this.children.push(...nodes);} replaceChildren(...nodes){this.children=nodes;} setAttribute(k,v){this.attrs[k]=v;} focus(){this.focused=true;} click(){if(!this.disabled)this.onclick?.();}
}
function fixture(t,options={}){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-owner-ui-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const card=new Node('section'),composerStatus=new Node('small'),requests=[],timers=[],storage={relayToken:'owner-ui-token'};
 const context={window:options.boot?{THT_BOOT:{relayToken:'owner-ui-token'}}:{},ownerCard:card,document:{createElement:tag=>new Node(tag)},localStorage:{getItem:()=>options.storageThrows?(()=>{throw Error('storage unavailable');})():JSON.stringify(storage)},tr:zh=>zh,$:()=>composerStatus,errorText:e=>e.message,AbortController,setTimeout:(fn,ms)=>{const timer={fn,ms};timers.push(timer);return timer;},clearTimeout:()=>{}};
 const stored={RELAY_TOKEN:'owner-ui-token'};let hold=null;
 context.fetch=async(url,init={})=>{
  const request={url,init};requests.push(request);if(options.hold&&init.method==='POST')await new Promise(resolve=>hold=resolve);
  let status,body;const req={method:init.method||'GET',headers:Object.fromEntries(Object.entries(init.headers||{}).map(([k,v])=>[k.toLowerCase(),v])),async *[Symbol.asyncIterator](){yield init.body||'';}};
  await routes(req,{writeHead:n=>status=n,end:value=>body=JSON.parse(value)},new URL(url,'http://127.0.0.1'),{isLocal:options.isLocal!==false,tokenOk:value=>value===stored.RELAY_TOKEN,settings:{dataDir:dir,load:()=>({...stored}),defaults:{},save:()=>{}},active:()=>false});
  request.status=status;return {ok:status>=200&&status<300,status,json:async()=>options.badReceipt&&init.method==='POST'?{}:body};
 };
 vm.createContext(context);
 const make=source.slice(source.indexOf(' const make='),source.indexOf(' function openMeeting('));
 const api=source.slice(source.indexOf(' async function api('),source.indexOf(' const panel='));
 const greeting=source.slice(source.indexOf(' let ownerLoaded='),source.indexOf(' function composer('));
 vm.runInContext(make+api+greeting+';this.greet=greetOwner;',context);
 return {dir,card,requests,timers,storage,greet:context.greet,flush:()=>new Promise(setImmediate),release:()=>hold?.(),fetch:context.fetch,controls(){const [label,name,row,status]=card.children;return {label,name,save:row.children[0],skip:row.children[1],status};}};
}
test('remember click reaches the protected owner route and saves the typed name in the existing profile',async t=>{
 const f=fixture(t);await f.greet();const id=owner.loadOwnerProfile(f.dir).id,c=f.controls();c.name.value='  Shawn 王  ';c.save.click();await f.flush();
 const r=f.requests.find(x=>x.init.method==='POST');assert.equal(r.status,200);assert.equal(r.init.headers['x-tht-token'],'owner-ui-token');assert.equal(JSON.parse(r.init.body).displayName,'Shawn 王');
 const profile=owner.loadOwnerProfile(f.dir);assert.equal(profile.id,id);assert.equal(profile.displayName,'Shawn 王');assert.equal(profile.needsName,false);assert.match(f.card.children[0].textContent,/已记住，Shawn 王/);assert.equal(f.card.attrs['aria-busy'],'false');
 f.timers.find(x=>x.ms===2500).fn();assert.equal(f.card.hidden,true);
});
test('skip click works with an empty name and persists without inventing an outgoing identity',async t=>{
 const f=fixture(t);await f.greet();f.controls().skip.click();await f.flush();assert.equal(f.requests[1].status,200);
 const profile=owner.loadOwnerProfile(f.dir);assert.equal(profile.displayName,'我');assert.equal(profile.needsName,false);assert.ok(profile.namePromptSkippedAt);assert.match(f.card.children[0].textContent,/已跳过/);
});
test('a rejected save shows the error beside the buttons and preserves the name for a successful retry',async t=>{
 const f=fixture(t);await f.greet();const c=f.controls();c.name.value='Shawn';f.storage.relayToken='expired';c.save.click();await f.flush();
 assert.equal(f.requests[1].status,403);assert.equal(owner.loadOwnerProfile(f.dir).needsName,true);assert.equal(f.card.hidden,false);assert.equal(c.name.value,'Shawn');assert.match(c.status.textContent,/请从本机设置/);assert.ok(c.status.classList.contains('ma-owner-error'));assert.equal(c.name.disabled,false);assert.equal(c.save.disabled,false);assert.equal(c.skip.disabled,false);
 f.storage.relayToken='owner-ui-token';c.save.click();await f.flush();assert.equal(f.requests[2].status,200);assert.equal(owner.loadOwnerProfile(f.dir).displayName,'Shawn');
});
test('a rejected skip remains visible and retryable; query token alone does not weaken the header check',async t=>{
 const f=fixture(t);await f.greet();const c=f.controls();f.storage.relayToken='expired';c.skip.click();await f.flush();assert.equal(f.requests[1].status,403);assert.equal(c.skip.disabled,false);assert.equal(f.card.hidden,false);assert.equal(owner.loadOwnerProfile(f.dir).needsName,true);assert.ok(c.status.textContent);
});
test('the remote owner route stays forbidden even with the correct token',async t=>{
 const f=fixture(t,{isLocal:false});await f.greet(); // Remote setup deliberately does not expose an owner prompt.
 assert.equal(f.card.children.length,0);assert.equal(f.requests[0].status,200);
 const response=await f.fetch('/setup/owner?token=owner-ui-token',{method:'POST',headers:{'Content-Type':'application/json','x-tht-token':'owner-ui-token'},body:JSON.stringify({displayName:'Shawn'})});assert.equal(response.status,403);assert.equal(owner.loadOwnerProfile(f.dir).needsName,true);
});
test('empty remember click explains what to do and does not send a request',async t=>{
 const f=fixture(t);await f.greet();const c=f.controls();c.name.value='  ';c.save.click();await f.flush();assert.equal(f.requests.length,1);assert.equal(c.name.focused,true);assert.match(c.status.textContent,/请填写称呼/);assert.equal(c.skip.disabled,false);
});
test('pending save disables both buttons and enter to prevent duplicate or conflicting requests',async t=>{
 const f=fixture(t,{hold:true});await f.greet();const c=f.controls();c.name.value='Shawn';c.save.click();assert.equal(c.name.disabled,true);assert.equal(c.save.disabled,true);assert.equal(c.skip.disabled,true);assert.equal(f.card.attrs['aria-busy'],'true');assert.equal(c.status.textContent,'正在保存…');
 c.skip.click();c.name.onkeydown({key:'Enter',preventDefault(){}});assert.equal(f.requests.filter(x=>x.init.method==='POST').length,1);f.release();await f.flush();assert.equal(owner.loadOwnerProfile(f.dir).displayName,'Shawn');
});
test('Enter saves the name through the same authenticated route',async t=>{
 const f=fixture(t);await f.greet();const c=f.controls();c.name.value='王';let prevented=false;c.name.onkeydown({key:'Enter',preventDefault(){prevented=true;}});await f.flush();assert.equal(prevented,true);assert.equal(f.requests[1].status,200);assert.equal(owner.loadOwnerProfile(f.dir).displayName,'王');
});
test('missing success receipt is not displayed as a saved name',async t=>{
 const f=fixture(t,{badReceipt:true});await f.greet();const c=f.controls();c.name.value='Shawn';c.save.click();await f.flush();assert.equal(f.card.children.length,4);assert.equal(c.save.disabled,false);assert.match(c.status.textContent,/未保存/);
});

test('fresh install without saved settings uses the current boot token for both owner buttons',async t=>{
 for(const skip of [false,true]){const f=fixture(t,{boot:true});delete f.storage.relayToken;await f.greet();const c=f.controls();c.name.value='Shawn';(skip?c.skip:c.save).click();await f.flush();assert.equal(f.requests[1].status,200);assert.equal(owner.loadOwnerProfile(f.dir).needsName,false);}
});
test('local boot token wins over stale saved settings after restart',async t=>{
 const f=fixture(t,{boot:true});f.storage.relayToken='old-token';await f.greet();const c=f.controls();c.name.value='Shawn';c.save.click();await f.flush();assert.equal(f.requests[1].status,200);assert.equal(f.requests[1].init.headers['x-tht-token'],'owner-ui-token');
});
test('unavailable local storage does not block boot-authenticated naming',async t=>{
 const f=fixture(t,{boot:true,storageThrows:true});await f.greet();const c=f.controls();c.name.value='Shawn';c.save.click();await f.flush();assert.equal(f.requests[1].status,200);
});
test('query authentication alone is still refused by the protected owner POST',async t=>{
 const f=fixture(t);await f.greet();const r=await f.fetch('/setup/owner?token=owner-ui-token',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({skip:true})});assert.equal(r.status,403);assert.equal(owner.loadOwnerProfile(f.dir).needsName,true);
});

test('placeholder name explains the next action and allows skipping without a retry loop',async t=>{
 const f=fixture(t);await f.greet();const c=f.controls();c.name.value='我';c.save.click();await f.flush();assert.equal(f.requests[1].status,200);assert.equal(owner.loadOwnerProfile(f.dir).needsName,true);assert.equal(c.name.value,'我');assert.match(c.status.textContent,/请换一个称呼，或选择先跳过/);assert.equal(c.save.disabled,false);c.skip.click();await f.flush();assert.equal(owner.loadOwnerProfile(f.dir).needsName,false);assert.match(f.card.children[0].textContent,/已跳过/);
});
test('every standalone page with MyAgent loads current local bootstrap before the agent',()=>{
 const web=path.join(__dirname,'../web');for(const file of fs.readdirSync(web).filter(x=>x.endsWith('.html'))){const html=fs.readFileSync(path.join(web,file),'utf8');if(/<script[^>]+src="my-agent\.js/.test(html)){assert.ok(html.includes('src="bootstrap.js"'),file+' missing bootstrap');assert.ok(html.indexOf('src="bootstrap.js"')<html.indexOf('src="my-agent.js'),file+' boot must come first');}}
});
