'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const source=fs.readFileSync(require.resolve('../web/my-agent.js'),'utf8');
class Node{
 constructor(tag,text=''){this.tagName=tag.toUpperCase();this.children=[];this.textContent=text;}
 append(...nodes){this.children.push(...nodes);}
}
function fixture(){
 const opened=[],ctx={make:(tag,text='')=>new Node(tag,text),document:{createTextNode:text=>new Node('#text',text)},URL,location:{href:'http://127.0.0.1:47823/tinghuitai/',origin:'http://127.0.0.1:47823'},openMeeting:(...args)=>{opened.push(args);return true;}};
 vm.createContext(ctx);vm.runInContext(source.slice(source.indexOf(' function answerBody('),source.indexOf(' async function command('))+';this.render=rich;this.body=answerBody;',ctx);return {...ctx,opened};
}
const all=n=>[n,...n.children.flatMap(all)],text=n=>n.textContent+n.children.map(text).join('');
test('legacy transport replies render only the human answer with real newlines',()=>{
 const f=fixture(),raw=JSON.stringify({reply:'# Decision\n\n**Graphite**\n- Hands free',action:{name:'send_message',args:{text:'MACHINE PAYLOAD'}}}),n=f.render(raw);
 assert.equal(n.children[0].tagName,'H2');assert.equal(all(n).find(x=>x.tagName==='STRONG').textContent,'Graphite');assert.equal(text(all(n).find(x=>x.tagName==='LI')),'Hands free');assert.doesNotMatch(text(n),/reply|action|MACHINE PAYLOAD|\\n/);
 assert.equal(f.body('```json\n'+raw+'\n```'),JSON.parse(raw).reply);
});
test('ordinary JSON and escaped text are not mistaken for a transport reply',()=>{
 const f=fixture();for(const value of ['{"status":"ok"}','{"reply":"literal","custom":true}','A literal \\n is two characters.'])assert.equal(f.body(value),value);
});
test('tables, ordered steps, quotes and code blocks are legible and remain text',()=>{
 const f=fixture(),n=f.render('| Device | Role |\n| --- | --- |\n| **Phone** | Main agent |\n\n1. Open\n2. Discuss\n\n> Source note\n\n```html\n<img src=x onerror=alert(1)>\n```');
 assert.equal(all(n).filter(x=>x.tagName==='TABLE').length,1);assert.equal(all(n).filter(x=>x.tagName==='TH').length,2);assert.equal(all(n).filter(x=>x.tagName==='TD').length,2);assert.equal(all(n).find(x=>x.tagName==='OL').children.length,2);assert.equal(text(all(n).find(x=>x.tagName==='BLOCKQUOTE')),'Source note');assert.equal(all(n).find(x=>x.tagName==='PRE').children[0].textContent,'<img src=x onerror=alert(1)>');assert.equal(all(n).filter(x=>x.tagName==='IMG').length,0);
});
test('source links preserve meeting navigation and reject executable or credential URLs',()=>{
 const f=fixture(),n=f.render('[Meeting](./?id=meeting-1&module=card-2#t=12) [Unsafe](javascript:alert) [Credential](https://user:pass@example.com/) [Source](https://example.com/)');
 const links=all(n).filter(x=>x.tagName==='A');assert.equal(links.length,2);let prevented=false;links[0].onclick({preventDefault:()=>prevented=true});assert.equal(prevented,true);assert.deepEqual(f.opened,[['meeting-1',12,'card-2']]);assert.match(text(n),/\[Unsafe\]/);
});
test('partial fenced code stays visible while a normal reply streams',()=>{
 const f=fixture(),n=f.render('Example:\n```js\nconst value = 1;');assert.equal(all(n).find(x=>x.tagName==='PRE').children[0].textContent,'const value = 1;');assert.equal(f.body('Normal streamed reply'),'Normal streamed reply');
});
