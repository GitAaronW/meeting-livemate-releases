'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),os=require('os'),path=require('path');
const gate=require('../app/send-gate');
function setup(t){const dataDir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-receipt-'));t.after(()=>fs.rmSync(dataDir,{recursive:true,force:true}));return {dataDir,kind:'proof',key:'one',body:{confirmed:true}};}
test('pending write failure never executes external action or leaves a locked job',async t=>{
 const opts=setup(t),write=fs.writeFileSync;let calls=0;
 fs.writeFileSync=(file,data,...args)=>{if(String(data).includes('"status":"pending"'))throw Error('disk full');return write(file,data,...args);};
 try{await assert.rejects(gate.send({...opts,run:async()=>calls++}),e=>e.code===500&&e.receiptWriteFailed);assert.equal(calls,0);}finally{fs.writeFileSync=write;}
 assert.equal((await gate.send({...opts,run:async()=>({id:++calls})})).status,'sent');assert.equal(calls,1);
});
test('external success + receipt write failure is uncertain, never sent success, never automatic resend',async t=>{
 const opts=setup(t),write=fs.writeFileSync;let calls=0;
 fs.writeFileSync=(file,data,...args)=>{if(String(data).includes('"status":"sent"'))throw Error('disk full');return write(file,data,...args);};
 try{await assert.rejects(gate.send({...opts,run:async()=>({id:++calls})}),e=>e.code===500&&e.uncertain&&e.receiptWriteFailed);}finally{fs.writeFileSync=write;}
 const file=path.join(opts.dataDir,'state/send-receipts/proof',gate.hash('one')+'.json');assert.equal(JSON.parse(fs.readFileSync(file)).status,'pending');
 await assert.rejects(gate.send({...opts,run:async()=>calls++}),e=>e.code===409&&e.uncertain);assert.equal(calls,1);
 assert.equal(fs.readdirSync(path.dirname(file)).filter(n=>n.endsWith('.tmp')).length,0);
});
test('corrupt receipt is not treated as absent, including explicit retry',async t=>{
 const opts=setup(t),dir=path.join(opts.dataDir,'state/send-receipts/proof');fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,gate.hash('one')+'.json'),'{broken');
 let calls=0;await assert.rejects(gate.send({...opts,body:{confirmed:true,retryConfirmed:true},run:async()=>calls++}),e=>e.receiptReadFailed&&e.uncertain);assert.equal(calls,0);
});
test('flush failure before run prevents external execution',async t=>{
 const opts=setup(t),sync=fs.fsyncSync;let calls=0;fs.fsyncSync=()=>{throw Error('flush failed');};
 try{await assert.rejects(gate.send({...opts,run:async()=>calls++}),e=>e.receiptWriteFailed);assert.equal(calls,0);}finally{fs.fsyncSync=sync;}
});
