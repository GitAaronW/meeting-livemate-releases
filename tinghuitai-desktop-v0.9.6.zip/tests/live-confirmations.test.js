'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {offer,visible,respond}=require('../app/live-confirmations');
const memory=require('../app/memory');
const now=1800000000000;
const rows=[{id:'s1',speaker:'Aaron',t:'03:12',text:'8 日前交 CAD 还是先完成展示看板？两件暂时不能同时交付。'}];
const proposal={question:'先交 CAD，展示看板后移吗？',statement:'先完成 CAD 交付，展示看板后移。',impact:'conflict',quote:'8 日前交 CAD 还是先完成展示看板？',whyNow:'两件暂时不能同时交付，需要决定先做哪个以继续准备。',confidence:.6,sourceIds:['s1','invented']};
function fixture(t){const dataDir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-confirm-'));t.after(()=>fs.rmSync(dataDir,{recursive:true,force:true}));return {dataDir,session:{id:'meeting-a',projectId:'software',title:'典型一天',checkpoint(){return true;},broadcast(){}}};}
test('only one grounded action-changing proposal is visible; ordinary memories and ungrounded interruptions stay quiet; confidence is not proof',t=>{
 const {session}=fixture(t);
 for(const patch of [{impact:'preference'},{whyNow:'信息很重要'},{sourceIds:['invented']},{question:''},{quote:'编造的冲突'}])assert.equal(offer(session,{...proposal,...patch},rows,now),null);
 const item=offer(session,proposal,rows,now);assert.equal(visible(session,now).id,item.id);assert.equal(item.sourceRefs.length,1);assert.equal(item.sourceRefs[0].at,'03:12');
 assert.equal(offer(session,{...proposal,statement:'另一项重要决定'},rows,now+1000),null);
 session.end=now+1000;assert.equal(visible(session,now+1000),null);
});
test('later hides the prompt without creating confirmed memory; duplicate is never offered again',t=>{
 const {dataDir,session}=fixture(t),item=offer(session,proposal,rows,now);
 respond(session,item.id,'later',{dataDir,now:now+10});assert.equal(visible(session,now+10),null);assert.equal(item.state,'deferred');
 assert.equal(fs.existsSync(path.join(dataDir,'state','memory.db')),false);
 assert.equal(offer(session,proposal,rows,now+200000),null);
 assert.equal(offer(session,{...proposal,statement:'第二项'},rows,now+10000),null);
 assert.ok(offer(session,{...proposal,statement:'第二项'},rows,now+200000));
});
test('confirmation saves the current owner evidence to existing memory, remains meeting-scoped, and preserves older decisions',t=>{
 const {dataDir,session}=fixture(t),db=memory.open(dataDir),owner=require('../app/owner-tracking').saveOwnerName(dataDir,'Taylor');
 memory.putCard(db,{id:'old',kind:'decision',text:'旧决定',state:'active',project:'software',confirmed:1});
 const item=offer(session,proposal,rows,now);respond(session,item.id,'confirm',{dataDir,now:now+10});
 const saved=db.prepare('SELECT * FROM cards WHERE id=?').get(item.memoryId);
 assert.equal(saved.text,proposal.statement);assert.equal(saved.confirmed,1);assert.equal(saved.speaker,'Taylor');assert.equal(saved.source_type,'user');assert.equal(item.actor,'Taylor');assert.equal(item.actorId,owner.id);assert.equal(saved.project,'software');assert.equal(saved.memory_tier,'meeting');assert.equal(saved.meeting_id,session.id);
 assert.equal(JSON.parse(saved.source_refs).at(-1).type,'user-confirmation');assert.equal(JSON.parse(saved.source_refs).at(-1).actorId,owner.id);assert.equal(db.prepare('SELECT text FROM cards WHERE id=?').get('old').text,'旧决定');
 respond(session,item.id,'confirm',{dataDir,now:now+20});assert.equal(db.prepare('SELECT COUNT(*) AS n FROM cards').get().n,2);
 assert.throws(()=>respond(session,item.id,'later',{dataDir,now:now+20}),/已处理/);
});
test('correction records the actual edited decision; stale prompts cannot be confirmed',t=>{
 const {dataDir,session}=fixture(t),item=offer(session,proposal,rows,now);
 assert.throws(()=>respond(session,item.id,'correct',{dataDir,text:' ',now:now+1}),/纠正/);
 respond(session,item.id,'correct',{dataDir,text:'只先做上午的看板',now:now+1});
 const saved=memory.open(dataDir).prepare('SELECT * FROM cards WHERE id=?').get(item.memoryId);
 assert.equal(saved.text,'只先做上午的看板');assert.equal(saved.speaker,'我');assert.equal(item.actor,'我');assert.match(item.actorId,/^owner-/);
 const next=offer(session,{...proposal,statement:'第二项'},rows,now+200000);
 assert.throws(()=>respond(session,next.id,'confirm',{dataDir,now:now+500000}),/讨论已变化/);assert.equal(visible(session,now+500000),null);
});
test('journal write failure rolls back both confirmation and SQLite memory; failed offer restores earlier trace states',t=>{
 const {dataDir,session}=fixture(t),item=offer(session,proposal,rows,now);session.checkpoint=()=>false;
 assert.throws(()=>respond(session,item.id,'confirm',{dataDir,now:now+1}),/保存失败/);assert.equal(item.state,'pending');assert.equal(item.memoryId,undefined);
 assert.equal(memory.open(dataDir).prepare('SELECT COUNT(*) AS n FROM cards').get().n,0);
 assert.equal(offer(session,{...proposal,statement:'另一项'},rows,now+400000),null);assert.equal(session.liveConfirmations.length,1);assert.equal(item.state,'pending');
});
