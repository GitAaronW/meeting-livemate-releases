'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{EventEmitter}=require('node:events');
const root=path.join(__dirname,'..');
function updater(results,requests=[]){
 let i=0;const https={get(url,options,callback){requests.push({url,headers:options.headers});const req=new EventEmitter();req.setTimeout=()=>{};req.destroy=e=>req.emit('error',e);queueMicrotask(()=>{const item=results[i++];if(item instanceof Error){req.emit('error',item);return;}const res=new EventEmitter();res.statusCode=item.status||200;res.headers={};res.resume=()=>{};callback(res);if(res.statusCode===200){res.emit('data',Buffer.from(item.body));res.emit('end');}});return req;}};
 const module={exports:{}};vm.runInNewContext(fs.readFileSync(path.join(root,'app/updater.js'),'utf8'),{require:n=>n==='https'?https:require(n),module,__dirname:path.join(root,'app'),Buffer,process});return module.exports;
}
test('private/missing feeds report source access separately from the usable installed version',async()=>{
 const r=await updater([404,403].map(status=>({status}))).check();assert.equal(r.ok,false);assert.equal(r.code,'update_feed_unavailable');assert.equal(r.current,require('../package.json').version);assert.equal(r.hasUpdate,false);
});
test('DNS failures and invalid manifests give distinct reasons; one good feed still wins',async()=>{
 const offline=await updater(Array.from({length:2},()=>Error('ENOTFOUND'))).check();assert.equal(offline.code,'update_network_unavailable');
 const invalid=await updater(Array.from({length:2},()=>({body:'{"version":"garbage"}'}))).check();assert.equal(invalid.code,'update_feed_invalid');
 const mixed=await updater([{body:'{"version":"0.9.5"}'},{body:'{"version":"0.9.6"}'}]).check();assert.equal(mixed.ok,true);assert.equal(mixed.latest,'0.9.6');assert.equal(mixed.hasUpdate,false);
 const fallback=await updater([{status:404},{body:'{"version":"0.9.6"}'}]).check();assert.equal(fallback.ok,true);assert.equal(fallback.latest,'0.9.6');
});
test('updates use only the public artifact repository and never send account or AI credentials',async()=>{
 const requests=[];await updater([{body:'{"version":"0.9.6"}'},{body:'{"version":"0.9.6"}'}],requests).check();
 assert.equal(requests.length,2);
 assert.deepEqual(requests.map(r=>r.url),['https://raw.githubusercontent.com/GitAaronW/meeting-livemate-releases/main/version.json','https://api.github.com/repos/GitAaronW/meeting-livemate-releases/contents/version.json']);
 for(const r of requests){assert.equal(r.headers.Authorization,undefined);assert.equal(r.headers.authorization,undefined);assert.doesNotMatch(r.url,/token|api_key|tinghuitai-desktop/);}
});
test('update HTTP response carries the failure code and never restarts on a check',async()=>{
 let starts=0,response;const route=require('../app/update-routes')({updater:{check:async()=>({ok:false,current:'0.9.6',hasUpdate:false,code:'update_feed_unavailable',error:'unavailable'}),prevVersion:()=>'',prevInfo:()=>({})},restart:()=>starts++});
 await route({method:'GET'},{writeHead:()=>{},end:s=>response=JSON.parse(s)},new URL('http://localhost/update'),true);assert.equal(response.code,'update_feed_unavailable');assert.equal(response.current,'0.9.6');assert.equal(starts,0);
});
function ui(result,lang='zh'){
 const source=fs.readFileSync(path.join(root,'web/src/26-updater.js'),'utf8'),start=source.indexOf('    async function load(){'),end=source.indexOf("    $('#m-update').onclick",start);
 const nodes=new Map();const $=s=>{if(!nodes.has(s))nodes.set(s,{hidden:false,textContent:'',innerHTML:'',insertAdjacentHTML:()=>{}});return nodes.get(s);};
 const c=vm.createContext({$,ui:lang,info:{ok:true,current:'stale'},latest:'',relayBase:()=>'',cfg:{},fetch:async()=>{if(result instanceof Error)throw result;return result;},readJSON:async r=>r,AbortSignal,encodeURIComponent,esc:s=>s,TypeError});vm.runInContext(source.slice(start,end),c);return {load:()=>c.load(),$: $};
}
test('check dialog displays installed version and access failure without calling the local service down',async()=>{
 for(const lang of ['zh','en']){const x=ui({ok:false,current:'0.9.6',code:'update_feed_unavailable',error:'unavailable'},lang);await x.load();assert.match(x.$('#upd-now').textContent,/0\.9\.6/);assert.match(x.$('#upd-body').textContent,lang==='zh'?/本机 App 正常运行/:/local app is running/);assert.equal(x.$('#upd-do').hidden,true);assert.equal(x.$('#upd-back').hidden,true);}
});
test('a failed local fetch clears stale feed data and gives the local service recovery message',async()=>{
 const x=ui(new TypeError('Failed to fetch'));await x.load();assert.match(x.$('#upd-now').textContent,/连接不到听会台服务/);assert.doesNotMatch(x.$('#upd-now').textContent,/stale/);
});
