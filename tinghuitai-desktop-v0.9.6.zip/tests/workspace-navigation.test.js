'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const source=fs.readFileSync(require.resolve('../web/src/26-meeting-board.js'),'utf8');
function fixture(running=false){let clicked='',requested='',note='';const ctx={running,cur:{id:'current'},ui:'zh',cfg:{relayToken:''},relayBase:()=>'',AbortSignal,encodeURIComponent,fetch:async u=>{requested=u;return {ok:true,json:async()=>({sessions:[{id:'selected',title:'Selected meeting'}]})};},normalizeSession:s=>s,resetSigs(){},render(){},note:s=>note=s,document:{getElementById:id=>({click(){clicked=id;}})}};vm.createContext(ctx);vm.runInContext(source.slice(0,source.indexOf('// Keep the existing recorder')),ctx);return {ctx,result:()=>({clicked,requested,note})};}
test('sharing uses the selected workspace meeting rather than the stale recorder session',async()=>{const f=fixture();await f.ctx.workspaceShareAction({action:'full',sessionId:'selected'});assert.match(f.result().requested,/ids=selected/);assert.equal(f.result().clicked,'x-full');assert.equal(f.ctx.cur.id,'selected');});
test('sharing another meeting cannot switch the active recorder session',async()=>{const f=fixture(true);await f.ctx.workspaceShareAction({action:'slack',sessionId:'selected'});assert.equal(f.result().clicked,'');assert.equal(f.result().requested,'');assert.equal(f.ctx.cur.id,'current');assert.match(f.result().note,/结束当前会议/);});
test('browser back and direct result URLs restore meeting, result and evidence position together',()=>{
 const calls=[],context={URLSearchParams,location:{search:'?id=previous&module=design',hash:'#t=24.5'},crypto:{randomUUID:()=> 'navigation-1'},sessionStorage:{setItem:(...args)=>calls.push(args)},window:{thtOpenWorkbench:(...args)=>calls.push(args),thtCloseWorkbench:(...args)=>calls.push(args)}};
 vm.createContext(context);vm.runInContext("let viewedMeetingId='',requestedModule='',navigationId='',requestedAt=0;"+source.split('\n').find(line=>line.includes('function restoreRoute()')),context);
 vm.runInContext('restoreRoute()',context);
 assert.equal(vm.runInContext('viewedMeetingId',context),'previous');assert.equal(vm.runInContext('requestedModule',context),'design');assert.equal(vm.runInContext('requestedAt',context),24.5);assert.equal(vm.runInContext('navigationId',context),'navigation-1');assert.deepEqual(calls,[['tht-selected-meeting','previous'],[true]]);
});

test('work routes normalize equivalent iframe hashes without creating another history entry',()=>{
 const c={URLSearchParams,encodeURIComponent};vm.createContext(c);vm.runInContext(source.split('\n').find(l=>l.includes('function workRoute(')),c);
 assert.equal(c.workRoute('view=sources&node='),'sources');assert.equal(c.workRoute('sources'),'sources');assert.equal(c.workRoute('view=graph&node=p1'),'graph&node=p1');assert.equal(c.workRoute('graph&node=p1'),'graph&node=p1');
});
