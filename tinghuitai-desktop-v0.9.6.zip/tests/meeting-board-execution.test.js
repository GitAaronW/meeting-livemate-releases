'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),os=require('os'),path=require('path'),http=require('http');
const {Hub}=require('../app/work-hub'),{Jobs,get}=require('../app/meeting-board-jobs'),route=require('../app/meeting-board-routes'),actions=require('../app/meeting-board-actions'),agent=require('../app/local-agent');
const proposal={name:'lark.message.send',args:{recipient:'Aaron',text:'Please review the draft.'}};
async function fixture(t,{plan=async()=>({ok:true,text:'Review this message',proposal}),execute}={}){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-exec-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));const h=new Hub(dir,dir),source=h.ingestSession({id:'m',transcript:[{text:'Prepare a draft'}]});h.update('sources',source.id,{board:{modules:[{id:'task',kind:'task',title:'Prepare',body:'Draft for review',edited:false,sourceRefs:['segment-0']}]}},source.revision);
 let calls=0,seen;const ctx={authed:true,dataDir:dir,hub:h,session:id=>({id,end:'ended',title:'Review',transcript:[{text:'Prepare a draft'}]}),ask:async()=>'',planAction:plan,executeAction:execute||((p,c)=>agent.execute({},p,{dataDir:dir,sessionId:c.meetingId,actionKey:c.actionKey,callTool:async(name,args)=>{calls++;seen={name,args};return {ok:true,data:{url:'https://example.com/result',note:'Delivered'}};}}))};
 const s=http.createServer((req,res)=>route(req,res,new URL(req.url,'http://localhost'),ctx));await new Promise(r=>s.listen(0,'127.0.0.1',r));t.after(()=>new Promise(r=>s.close(r)));const url='http://127.0.0.1:'+s.address().port+'/meeting-board';
 const post=async j=>{const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:'m',...j})});return {status:r.status,...await r.json()};};
 const wait=async(jobId,state)=>{for(let n=0;n<100;n++){const j=get(dir).list('m').find(j=>j.id===jobId);if(state.includes(j?.state))return j;await new Promise(r=>setTimeout(r,5));}throw Error('Task timeout');};
 const start=async(requestId='one')=>{const r=await post({action:'run',async:true,revision:source.revision,moduleId:'task',comment:'Send this draft to Aaron',requestId});assert.equal(r.status,202);return wait(r.job.id,['awaiting_confirmation','planned','failed']);};
 return {dir,h,source,post,wait,start,calls:()=>calls,seen:()=>seen};
}
test('E1/E2/E5: only confirmed server proposal executes; concurrent confirms and identical actions deduplicate',async t=>{
 const f=await fixture(t),j=await f.start();assert.equal(f.calls(),0);assert(j.proposal.args.text.endsWith(actions.SIGN));assert(!('request' in j));assert(!('actionKey' in j));
 assert.equal((await f.post({action:'confirm',jobId:j.id})).status,400);
 assert.equal((await f.post({action:'confirm',jobId:j.id,confirmed:true,proposal:{name:'shell',args:{}}})).status,400);
 assert.equal((await f.post({id:'other',action:'confirm',jobId:j.id,confirmed:true})).status,404);assert.equal(f.calls(),0);
 const r=await Promise.all([f.post({action:'confirm',jobId:j.id,confirmed:true}),f.post({action:'confirm',jobId:j.id,confirmed:true})]);assert(r.every(x=>x.status===202));
 const done=await f.wait(j.id,['completed']);assert.equal(f.calls(),1);assert.equal(done.resultUrl,'https://example.com/result');assert.equal(f.seen().args.text,j.proposal.args.text);
 const second=await f.start('two');await f.post({action:'confirm',jobId:second.id,confirmed:true});await f.wait(second.id,['completed']);assert.equal(f.calls(),1,'same action uses durable send receipt');
});
test('E3/E4: cancellation and changes to target title/body prevent writes',async t=>{
 const f=await fixture(t),cancelled=await f.start();assert.equal((await f.post({action:'cancel',jobId:cancelled.id})).job.state,'cancelled');assert.equal((await f.post({action:'confirm',jobId:cancelled.id,confirmed:true})).status,409);
 const j=await f.start('next'),b=structuredClone(f.source.board);b.modules[0].title='Changed title';f.h.update('sources',f.source.id,{board:b},f.source.revision);
 assert.equal((await f.post({action:'confirm',jobId:j.id,confirmed:true})).status,409);assert.equal(f.calls(),0);
});
test('E6: uncertain receipt blocks even a newly planned identical action; restart never resends',async t=>{
 let calls=0;const f=await fixture(t,{execute:(p,c)=>agent.execute({},p,{dataDir:f.dir,sessionId:c.meetingId,actionKey:c.actionKey,callTool:async()=>{calls++;return {ok:false,error:'timeout',uncertain:true};}})});
 const j=await f.start();await f.post({action:'confirm',jobId:j.id,confirmed:true});await f.wait(j.id,['uncertain']);assert.equal((await f.post({action:'confirm',jobId:j.id,confirmed:true})).status,409);
 const second=await f.start('new');await f.post({action:'confirm',jobId:second.id,confirmed:true});await f.wait(second.id,['uncertain']);assert.equal(calls,1);
 const disk=JSON.parse(fs.readFileSync(path.join(f.dir,'meeting-board-jobs.json'),'utf8'));disk[0].state='executing';fs.writeFileSync(path.join(f.dir,'meeting-board-jobs.json'),JSON.stringify(disk));const recovered=new Jobs(f.dir);assert.equal(recovered.list('m')[0].state,'uncertain');assert.throws(()=>recovered.confirm('m',j.id,true,()=>{},()=>{calls++;}),e=>e.status===409);assert.equal(calls,1);
});
test('E7: no proposal is a planning reply, never completed external work; links cannot execute code',async t=>{
 const f=await fixture(t,{plan:async()=>({ok:true,text:'Which recipient?',proposal:null})}),j=await f.start();assert.equal(j.state,'planned');assert.equal(j.reply,'Which recipient?');assert.equal(f.calls(),0);assert.equal((await f.post({action:'confirm',jobId:j.id,confirmed:true})).status,409);
 for(const url of ['javascript:alert(1)','data:text/html,test','https://user:pass@example.com/'])assert.equal(actions.safeUrl(url),'');
 assert.equal(actions.result({ok:true,result:{ok:true,data:{url:'javascript:alert(1)'}}}).url,'');
});
test('invalid selection cannot plan; proposed unsupported tools cannot become executable',async t=>{
 let plans=0;const f=await fixture(t,{plan:async()=>{plans++;return {ok:true,text:'bad',proposal:{name:'shell.exec',args:{cmd:'rm'}}};}});
 assert.equal((await f.post({action:'run',async:true,moduleId:'task',comment:'Do it',revision:f.source.revision,selection:{start:0,end:4,original:'fake'}})).status,409);assert.equal(plans,0);
 const j=await f.start();assert.equal(j.state,'failed');assert.equal(f.calls(),0);
});
test('pending confirmations survive restart; failed journal persist never invokes executor',async t=>{
 const f=await fixture(t),j=await f.start();const recovered=new Jobs(f.dir);assert.equal(recovered.list('m')[0].state,'awaiting_confirmation');let calls=0;recovered.save=()=>{throw Error('disk full');};assert.throws(()=>recovered.confirm('m',j.id,true,()=>{},()=>{calls++;}));await new Promise(r=>setImmediate(r));assert.equal(calls,0);assert.equal(recovered.list('m')[0].state,'awaiting_confirmation');
});
test('English task planning and execution receipt follow the selected interface language',async t=>{
 let captured;const f=await fixture(t,{plan:async c=>{captured=c;return {ok:true,text:'Review this message',proposal};}});
 const r=await f.post({action:'run',async:true,revision:f.source.revision,moduleId:'task',comment:'Send the draft',requestId:'english',lang:'en'}),j=await f.wait(r.job.id,['awaiting_confirmation']);assert.equal(captured.lang,'en');
 await f.post({action:'confirm',jobId:j.id,confirmed:true});const done=await f.wait(j.id,['completed']);assert.equal(done.reply,'Action completed');
 let system;await agent.plan({}, {instruction:'Draft only',dataDir:f.dir,lang:'en',askWithTools:async(env,opts)=>{system=opts.system;return {ok:true,text:JSON.stringify({reply:'Draft ready',action:null})};}});assert(system.includes('简短英文答复'));assert(!system.includes('简短中文答复'));
});

test('board uses the actual provider and local name and freezes the preview',async t=>{
 const f=await fixture(t,{plan:async()=>({ok:true,provider:'DeepSeek',text:'Review',proposal:{name:'lark.message.send',args:{recipient:'ou_test',text:'Draft'}}})});
 require('../app/owner-tracking').saveOwnerName(f.dir,'Shawn');const j=await f.start();
 assert.equal(j.proposal.args.text,'Draft\n\n— 由 DeepSeek 代 Shawn 发送。');
 await f.post({action:'confirm',jobId:j.id,confirmed:true});await f.wait(j.id,['completed']);assert.equal(f.seen().args.text,j.proposal.args.text);
});
test('legacy unbound message proposals require a fresh review',t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-legacy-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 assert.throws(()=>actions.validateIdentity({pendingProposal:proposal},dir),/重新生成/);
});
