const {test}=require('node:test'),assert=require('node:assert/strict');
const routes=require('../app/setup-routes');
function harness(initial={},dataDir){
 let stored={RELAY_TOKEN:'test-token',ASR_PROVIDER:'deepgram',DEEPGRAM_API_KEY:'test-dg',LLM_BASE_URL:'https://api.deepseek.com',LLM_MODEL:'deepseek-chat',...initial};
 const defaults={ASR_PROVIDER:'',DEEPGRAM_API_KEY:'',VOLC_APP_KEY:'',VOLC_ACCESS_KEY:'',DEEPSEEK_API_KEY:'',LLM_PROVIDER:'',LLM_BASE_URL:'',LLM_MODEL:'',JEV_API_KEY:'',JEV_GATE:'',FREE_AI_URL:'',FREE_AI_TOKEN:''};
 return {get stored(){return stored;},async call(url,body,active=false,opts={}){let status,data;const req={method:body===undefined?'GET':'POST',headers:{'content-type':'application/json','x-tht-token':opts.token===undefined?'test-token':opts.token},async *[Symbol.asyncIterator](){yield JSON.stringify(body)}};const res={writeHead:s=>status=s,end:s=>data=JSON.parse(s)};
 await routes(req,res,new URL(url,'http://localhost'),{isLocal:opts.isLocal!==false,tokenOk:t=>t==='test-token',settings:{dataDir,load:()=>({...stored}),save:s=>stored=s,defaults},active:()=>active,testModel:opts.testModel||(()=>{throw Error('unexpected model call')})});return{status,data};}};
}
test('blank saved Deepgram field preserves key on later saves',async()=>{const h=harness();assert.equal((await h.call('/setup',{ASR_PROVIDER:'deepgram',DEEPGRAM_API_KEY:''})).status,200);assert.equal(h.stored.DEEPGRAM_API_KEY,'test-dg');});
test('speech provider credentials are reported independently without leaking keys',async()=>{const h=harness();const r=await h.call('/setup');assert.equal(r.data.volcConfigured,false);assert.equal(r.data.deepgramConfigured,true);assert.equal(r.data.modelConfigured,false);assert.ok(!JSON.stringify(r.data).includes('test-dg'));});
test('active meeting prevents CLI provider changes',async()=>{const h=harness();assert.equal((await h.call('/setup/detect',{kind:'claude'},true)).status,409);assert.equal(h.stored.LLM_PROVIDER,undefined);});
test('MyAgent can switch back to DeepSeek without exposing a new product identity',async()=>{const h=harness({LLM_PROVIDER:'codex',DEEPSEEK_API_KEY:'test-key'});const r=await h.call('/setup/agent',{kind:'deepseek'});assert.equal(r.status,200);assert.equal(r.data.agentLabel,'MyAgent');assert.equal(h.stored.LLM_PROVIDER,'deepseek');});
test('MyAgent refuses provider changes during a meeting',async()=>{const h=harness({LLM_PROVIDER:'codex',DEEPSEEK_API_KEY:'test-key'});assert.equal((await h.call('/setup/agent',{kind:'deepseek'},true)).status,409);assert.equal(h.stored.LLM_PROVIDER,'codex');});
test('MyAgent switch is refused for non-local requests',async()=>{const h=harness({LLM_PROVIDER:'codex',DEEPSEEK_API_KEY:'test-key'});assert.equal((await h.call('/setup/agent',{kind:'deepseek'},false,{isLocal:false})).status,403);assert.equal(h.stored.LLM_PROVIDER,'codex');});
test('MyAgent switch is refused without the relay token',async()=>{const h=harness({LLM_PROVIDER:'codex',DEEPSEEK_API_KEY:'test-key'});assert.equal((await h.call('/setup/agent',{kind:'deepseek'},false,{token:'wrong'})).status,403);assert.equal(h.stored.LLM_PROVIDER,'codex');});
test('MyAgent keeps the current backend when DeepSeek has no key or the CLI probe fails',async()=>{const h=harness({LLM_PROVIDER:'codex',DEEPSEEK_API_KEY:''});assert.equal((await h.call('/setup/agent',{kind:'deepseek'})).status,409);assert.equal(h.stored.LLM_PROVIDER,'codex');
 const cli=require('../app/cli-llm'),orig=cli.probe;cli.probe=async()=>({ok:false,reason:'not_installed'});try{const r=await h.call('/setup/agent',{kind:'claude'});assert.equal(r.status,409);assert.equal(h.stored.LLM_PROVIDER,'codex');}finally{cli.probe=orig;}
 assert.equal((await h.call('/setup/agent',{kind:'gemini'})).status,400);assert.equal(h.stored.LLM_PROVIDER,'codex');});

// 09-22 手机复现：远端页面拿不到 boot，「开始听会」被卡。带口令的远端只读 GET /setup 放行且不含密钥；写操作仍 403。
test('remote GET /setup with phone token returns readiness without secrets',async()=>{const h=harness({DEEPGRAM_API_KEY:'dgSecretValue9',VOLC_ACCESS_KEY:'volcSecretValue9',DEEPSEEK_API_KEY:'dsSecretValue9',LLM_BASE_URL:'https://internal.example/v1',ARCHIVE_TARGET:'/Users/x/private'});const r=await h.call('/setup',undefined,false,{isLocal:false});assert.equal(r.status,200);assert.equal(r.data.asrConfigured,true);assert.equal(r.data.macAsrAvailable!==undefined,true);
  const body=JSON.stringify(r.data);for(const v of ['test-token','dgSecretValue9','volcSecretValue9','dsSecretValue9','internal.example','/Users/x/private'])assert.equal(body.includes(v),false,'远端响应不该含 '+v);
  assert.deepEqual(Object.keys(r.data).sort(),['agentLabel','asrConfigured','asrProvider','macAsrAvailable','modelConfigured','ready']);});
test('remote GET /setup also accepts ?token= and local GET still returns the full state',async()=>{const h=harness();const r=await h.call('/setup?token=test-token',undefined,false,{isLocal:false,token:''});assert.equal(r.status,200);assert.equal(r.data.asrConfigured,true);const l=await h.call('/setup');assert.equal(l.status,200);assert.equal('base' in l.data,true);});
test('remote GET /setup without a valid token is refused',async()=>{const h=harness();assert.equal((await h.call('/setup',undefined,false,{isLocal:false,token:'wrong'})).status,403);});
test('remote POST /setup is still refused even with the token',async()=>{const h=harness();assert.equal((await h.call('/setup',{ASR_PROVIDER:'mac'},false,{isLocal:false})).status,403);assert.equal(h.stored.ASR_PROVIDER,'deepgram');});
test('model test uses the draft key without persisting it',async()=>{const h=harness({DEEPSEEK_API_KEY:'saved-key'});let draft;const r=await h.call('/setup/test',{DEEPSEEK_API_KEY:'draft-key',LLM_BASE_URL:'https://api.deepseek.com',LLM_MODEL:'deepseek-chat'},false,{testModel:d=>{draft=d;return true;}});assert.equal(r.status,200);assert.equal(draft.DEEPSEEK_API_KEY,'draft-key');assert.equal(h.stored.DEEPSEEK_API_KEY,'saved-key');});

test('free edition readiness includes MyAgent without leaking service tokens',async()=>{const h=harness({FREE_AI_URL:'https://trial.example',FREE_AI_TOKEN:'trial-secret',JEV_API_KEY:'jev-secret'});const r=await h.call('/setup');assert.equal(r.data.freeAiConfigured,true);assert.equal(r.data.modelConfigured,true);assert.equal(r.data.ready,true);assert.equal(r.data.jevConfigured,true);assert.ok(!JSON.stringify(r.data).includes('trial-secret'));assert.ok(!JSON.stringify(r.data).includes('jev-secret'));});
test('blank JEV keeps a saved key, explicit off disables it; setup cannot replace the service token',async()=>{const h=harness({JEV_API_KEY:'own-jev',JEV_GATE:'on',FREE_AI_TOKEN:'saved-token'});assert.equal((await h.call('/setup',{JEV_API_KEY:'',JEV_GATE:'off',FREE_AI_TOKEN:'replace-token'})).status,200);assert.equal(h.stored.JEV_API_KEY,'own-jev');assert.equal(h.stored.JEV_GATE,'off');assert.equal(h.stored.FREE_AI_TOKEN,'saved-token');assert.equal((await h.call('/setup',{JEV_GATE:'garbage'})).status,400);});

test('optional outgoing name round-trips in the existing owner profile',async t=>{
 const fs=require('fs'),os=require('os'),path=require('path');const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-identity-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const h=harness({},dir),first=(await h.call('/setup')).data.ownerProfile;
 assert.equal((await h.call('/setup',{ownerDisplayName:'Shawn'})).status,200);
 const named=(await h.call('/setup')).data.ownerProfile;assert.equal(named.displayName,'Shawn');assert.equal(named.id,first.id);
 assert.equal((await h.call('/setup',{ownerDisplayName:'bad\nname'})).status,400);
 assert.equal((await h.call('/setup',{ownerDisplayName:''})).status,200);assert.equal((await h.call('/setup')).data.ownerProfile.displayName,'我');
});
