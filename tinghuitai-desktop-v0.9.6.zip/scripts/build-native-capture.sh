#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APP="$ROOT/app/native-capture/TinghuitaiCapture.app"
mkdir -p "$APP/Contents/MacOS"
cat > "$APP/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleIdentifier</key><string>com.aaron.tinghuitai.capture</string>
<key>CFBundleName</key><string>听会台小窗</string>
<key>CFBundleExecutable</key><string>TinghuitaiCapture</string>
<key>CFBundleVersion</key><string>1</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>LSMinimumSystemVersion</key><string>13.0</string>
<key>LSUIElement</key><true/>
<key>NSSpeechRecognitionUsageDescription</key><string>在本机将会议的系统声音转成文字；不上传原始音频。</string>
<key>NSScreenCaptureUsageDescription</key><string>捕获当前会议的系统声音和窗口；仅在画面变化时分析小图。</string>
<key>NSMicrophoneUsageDescription</key><string>在本机同时录下你的声音和会议系统声音；不上传原始音频。</string>
</dict></plist>
PLIST
BUILD_DIR="$(mktemp -d /tmp/tinghuitai-capture.XXXXXX)"
trap 'rm -rf "$BUILD_DIR"' EXIT
SDK="${THT_SWIFT_SDK:-$(xcrun --show-sdk-path)}"
# Some Command Line Tools installs point at a newer SDK than their compiler.
if [ -d /Library/Developer/CommandLineTools/SDKs/MacOSX15.5.sdk ]; then
  SDK="${THT_SWIFT_SDK:-/Library/Developer/CommandLineTools/SDKs/MacOSX15.5.sdk}"
fi
for ARCH in arm64 x86_64; do
  swiftc -O -sdk "$SDK" -target "$ARCH-apple-macos13.0" -framework AppKit -framework ScreenCaptureKit -framework Speech -framework AVFoundation -framework CoreImage "$ROOT/app/native-capture/TinghuitaiCapture.swift" -o "$BUILD_DIR/$ARCH"
done
lipo -create "$BUILD_DIR/arm64" "$BUILD_DIR/x86_64" -output "$APP/Contents/MacOS/TinghuitaiCapture"
# Desktop file-provider metadata can return immediately after xattr -cr.
# Sign a clean temporary bundle, then copy only its content back.
CLEAN="$BUILD_DIR/TinghuitaiCapture.app"
/usr/bin/ditto --noextattr --norsrc "$APP" "$CLEAN"
xattr -cr "$CLEAN"
codesign --force --sign - --identifier com.aaron.tinghuitai.capture "$CLEAN"
codesign --verify --strict "$CLEAN"
/usr/bin/ditto --noextattr --norsrc "$CLEAN" "$APP"
# Verify before copying onto a Desktop file provider, which adds Finder metadata.
# Deployment verifies the installed bundle again in Application Support.
"$APP/Contents/MacOS/TinghuitaiCapture" --self-test
