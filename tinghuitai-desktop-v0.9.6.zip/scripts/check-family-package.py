#!/usr/bin/env python3
"""Explicit private-family gate. It never relaxes the public package gate."""
import json, pathlib, shutil, subprocess, sys, tempfile

ALLOWED = {'PRESET_VERSION', 'ASR_PROVIDER', 'VOLC_APP_KEY', 'VOLC_ACCESS_KEY',
           'VOLC_RESOURCE_ID', 'DEEPSEEK_API_KEY', 'LLM_PROVIDER', 'LLM_BASE_URL',
           'LLM_MODEL', 'JEV_API_KEY', 'JEV_GATE', 'LOCAL_GATE',
           'ACTIVE_INTELLIGENCE_MODE'}

def check(package, expected, public_gate=None):
    expected = pathlib.Path(expected)
    content = expected.read_bytes()
    preset = json.loads(content)
    if not isinstance(preset, dict) or set(preset) - ALLOWED:
        raise ValueError('家庭预配置包含不允许的字段')
    if not all(isinstance(v, str) and v.strip() for v in preset.values()):
        raise ValueError('家庭预配置有空值或非字符串')
    if preset.get('LLM_PROVIDER') != 'api' or not preset.get('DEEPSEEK_API_KEY'):
        raise ValueError('家庭包必须明确使用已授权的 API，不能继承其他人的 Codex 登录')
    if preset.get('ASR_PROVIDER') == 'volc' and not all(preset.get(k) for k in ('VOLC_APP_KEY','VOLC_ACCESS_KEY','VOLC_RESOURCE_ID')):
        raise ValueError('ASR 预配置不完整')
    with tempfile.TemporaryDirectory(prefix='tht-family-gate-') as tmp:
        root = pathlib.Path(tmp) / 'package'
        subprocess.run(['/usr/bin/ditto', str(package), str(root)], check=True)
        found = list(root.rglob('preset.json'))
        valid = {'Contents/Resources/program/preset.json', '听会台.app/Contents/Resources/program/preset.json'}
        if len(found) != 1 or str(found[0].relative_to(root)) not in valid or found[0].read_bytes() != content:
            raise ValueError('家庭凭据必须逐字匹配、且只在指定位置出现一次')
        if found[0].stat().st_mode & 0o077:
            raise ValueError('家庭凭据文件权限必须为 600')
        found[0].unlink()
        # All remaining files must pass the unchanged public scan, including
        # encoded secrets and nested archives. Only the exact preset is exempt.
        gate = public_gate or pathlib.Path(__file__).with_name('check-package.sh')
        subprocess.run(['bash', str(gate), str(root)], check=True)
    return True

if __name__ == '__main__':
    try:
        if len(sys.argv) != 3: raise ValueError('用法：check-family-package.py <app目录> <授权预配置>')
        check(sys.argv[1], sys.argv[2])
        print('家庭专用包凭据检查通过；此包不可作为公开资产上传。')
    except Exception as error:
        print('家庭包检查失败：'+str(error), file=sys.stderr)
        sys.exit(1)
