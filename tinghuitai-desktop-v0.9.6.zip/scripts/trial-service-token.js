'use strict';
// Local service owner only. Rotation revokes installed trial packages until redistributed.
const fs=require('fs'),crypto=require('crypto');
const {CONFIG}=require('../app/free-ai-service');
const c=JSON.parse(fs.readFileSync(CONFIG,'utf8'));
if(process.argv[2]!=='revoke')throw Error('Usage: node scripts/trial-service-token.js revoke');
c.FREE_AI_TOKEN=crypto.randomBytes(32).toString('hex');
const temp=CONFIG+'.tmp';fs.writeFileSync(temp,JSON.stringify(c,null,2),{mode:0o600});fs.renameSync(temp,CONFIG);
console.log('Trial token revoked. Existing trial packages can no longer use this service.');
