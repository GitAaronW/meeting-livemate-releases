#!/bin/bash
# Build the public source ZIP from an explicit allowlist. No local settings,
# credentials, caches, agent instructions, or repository metadata are copied.
set -euo pipefail
SRC="$(cd "$(dirname "$0")/.." && pwd)"
V="$(node -p "require('$SRC/package.json').version")"
node - "$SRC" <<'NODE'
const path=require('path'),root=process.argv[2];
const version=require(path.join(root,'package.json')).version;
if(!/^\d+\.\d+\.\d+$/.test(version)||require(path.join(root,'version.json')).version!==version){
  console.error('版本不一致：运行版本只认 package.json，发布清单必须匹配');process.exit(1);
}
const fs=require('fs');
for(const page of ['index.html','work.html']){const s=fs.readFileSync(path.join(root,'web',page),'utf8');if(!s.includes('name="tht-build" content="'+version+'"')){console.error('界面构建版本不一致，先运行 npm run build');process.exit(1);}}
if(fs.readFileSync(path.join(root,'web/build-info.js'),'utf8').replace(/^\/\/[^\n]*\n/gm,'').trim()!=='window.THT_BUILD='+JSON.stringify(version)+';'){console.error('界面构建版本不一致，先运行 npm run build');process.exit(1);}
NODE
OUT="${1:-/tmp/tinghuitai-desktop-v${V}.zip}"
STAGE="$(mktemp -d /tmp/tinghuitai-release.XXXXXX)"
ROOT="$STAGE/tinghuitai-desktop"
trap 'rm -rf "$STAGE"' EXIT
mkdir -p "$ROOT"

for item in app web scripts docs tests node_modules version.json CHANGELOG.md CHANGELOG.json package.json package-lock.json README.md AI-SETUP.md 开始用.md 安装.command 启动.command 修复并打开.command 自检.command; do
  [ -e "$SRC/$item" ] && /usr/bin/ditto --noextattr --norsrc "$SRC/$item" "$ROOT/$item"
done
node "$SRC/scripts/release-docs.js" "$ROOT"
find "$ROOT" -name '.DS_Store' -delete
find "$ROOT" \( -name 'preset.json' -o -name '.env' -o -name '*.pem' \) -delete
rm -f "$OUT"
(cd "$STAGE" && /usr/bin/ditto -c -k --norsrc tinghuitai-desktop "$OUT")
echo "$OUT"
