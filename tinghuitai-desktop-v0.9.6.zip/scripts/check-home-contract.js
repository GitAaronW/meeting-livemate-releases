'use strict';
const fs=require('node:fs'),path=require('node:path');
const canonical='/Users/aaron.wang/Desktop/01 工作项目/Chansey 项目 For ChatGPT/听会台优化/tinghuitai-desktop';
function check(root,{requireCanonical=true}={}){
  if(requireCanonical&&fs.realpathSync(root)!==fs.realpathSync(canonical))throw new Error('只能从唯一维护目录安装：'+canonical);
  for(const name of ['meeting-board.html','meeting-board-ui.js','meeting-board.css'])if(!fs.existsSync(path.join(root,'web',name)))throw new Error('缺少新版工作区：'+name);
  for(const name of ['index.template.html','index.html']){
    const text=fs.readFileSync(path.join(root,'web',name),'utf8');
    if(!text.includes('title="工作台：项目、事项与资料">工作台')||!text.includes('id="work-frame"'))throw new Error(name+' 缺少统一工作台名称或保留收音的导航');
    if(!text.includes('class="app workspace-primary"')||!text.includes('id="workspace-frame"'))throw new Error(name+' 未固定工作区首页');
  }
  const source=fs.readFileSync(path.join(root,'web/src/26-meeting-board.js'),'utf8');
  if(!source.includes("frame.src='meeting-board.html?embedded=1'"))throw new Error('首页未接入会议工作区');
  // The build script remains responsible for generated-file formatting.
  const built=fs.readFileSync(path.join(root,'web/index.html'),'utf8');
  if(!built.includes(source.trim()))throw new Error('生成首页未包含最新入口代码，请先 build');
  return true;
}
module.exports={check};
if(require.main===module){try{check(path.resolve(__dirname,'..'));console.log('唯一维护目录与工作区首页检查通过');}catch(e){console.error(e.message);process.exitCode=1;}}
