'use strict';
// Public installers need usage guides, not internal requirements or acceptance records.
const fs=require('fs'),path=require('path');
const PUBLIC_DOCS=new Set(['RAY.md','SHARING.md','assigned-work.md','原生小窗.md']);
function sanitize(root){
 const dir=path.join(root,'docs');if(!fs.existsSync(dir))return;
 for(const name of fs.readdirSync(dir))if(!PUBLIC_DOCS.has(name))fs.rmSync(path.join(dir,name),{recursive:true,force:true});
}
if(require.main===module){if(!process.argv[2])throw Error('release program directory required');sanitize(process.argv[2]);}
module.exports={sanitize,PUBLIC_DOCS};
