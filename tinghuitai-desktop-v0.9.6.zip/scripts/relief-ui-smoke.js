'use strict';
// 界面冒烟：把「每个入口都点一遍，看它开得起来、也关得掉」这件事自动化。
// 起因：2026-09-11/12 连着三次是同一类问题——功能还在，界面上点不到，或者打开了关不掉。
// 这些都不是逻辑错，单元测试一条都拦不住，只能真的打开页面点一遍。
// 用法：node scripts/relief-ui-smoke.js   （自己起隔离实例、自己开无头 Chrome、自己收摊）
const {spawn,execFileSync}=require('child_process'), fs=require('fs'), os=require('os'), path=require('path'), WebSocket=require('ws');
const CHROME='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const PORT=Number(process.env.SMOKE_PORT||47871), CDP=Number(process.env.SMOKE_CDP||47872);
const DATA=fs.mkdtempSync(path.join(os.tmpdir(),'tht-smoke-')), PROFILE=path.join(DATA,'chrome');
const chromeLog=path.join(DATA,'chrome.log');
const SHOTS=path.join(DATA,'shots'); fs.mkdirSync(SHOTS,{recursive:true});
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
let server, chrome, ws, id=0, pending=new Map();

function send(method,params={}){ const i=++id; ws.send(JSON.stringify({id:i,method,params}));
  return new Promise((res,rej)=>{ const timer=setTimeout(()=>{pending.delete(i);rej(new Error(method+' 超时'));},30000);pending.set(i,{res,rej,timer}); }); }
async function evaluate(expr){
  const r=await send('Runtime.evaluate',{expression:`(async()=>{${expr}})()`,awaitPromise:true,returnByValue:true});
  if (r.exceptionDetails) throw new Error((r.exceptionDetails.exception?.description||'页面里报错了')+' · '+expr.slice(0,180));
  return r.result.value;
}
async function shot(name){ const r=await send('Page.captureScreenshot',{}); fs.writeFileSync(path.join(SHOTS,name+'.png'), Buffer.from(r.data,'base64')); }

(async()=>{
 const checks=[],errors=[];const assert=(value,label)=>{if(!value)throw Error(label);checks.push(label);console.log('PASS '+label)};
 try{
  const previous=new Date();previous.setDate(previous.getDate()-1);previous.setHours(21,0,0,0);
  const {Hub}=require('../app/work-hub'),hub=new Hub(DATA,path.join(DATA,'state','work-hub'));
  fs.mkdirSync(path.join(DATA,'pending'),{recursive:true});
  for(const [id,title] of [['offline-smoke-evening','昨晚的产品讨论'],['offline-smoke-other','另一场会议']]){
   const session={id,title,start:previous.toISOString(),end:new Date(previous.getTime()+3600000).toISOString(),condensed:{highlights:[],todos:[],factchecks:[]},transcript:[{segId:'s1',speaker:'Aaron',text:'Carl 的时间没有约定。',t:30}],summary:'## 尚未约定\nCarl 的时间没有约定。',todos:[],highlights:[],factchecks:[{id:'judge-old',channel:'judgment',topic:'投资人展示',point:'可能先展示渲染图；AI 推断。',whyChanged:'先前讨论的是概念材料。',sourceRefs:[{segId:'s1'}],supersededBy:'judge-current'},{id:'judge-current',channel:'judgment',topic:'投资人展示',point:'先做好可拿在手里的模型；AI 判断，尚未确认。',whyChanged:'刚才明确讨论了实物可信度，需要调整展示重点。',sourceRefs:[{segId:'s1'}],supersedes:'judge-old'},{id:'public-background',channel:'background',topic:'投资人展示',entity:'公开材料',lookupState:'ready',sourceRefs:[{segId:'s1'}],evidence:[{url:'https://example.com/evidence',title:'公开来源（测试资料）',excerpt:'This is a retrieved excerpt for the browser acceptance fixture.',retrievedAt:new Date().toISOString()}]}]};
   fs.writeFileSync(path.join(DATA,'pending','sess-'+id+'.json'),JSON.stringify(session));const source=hub.ingestSession(session);
   hub.update('sources',source.id,{board:{goal:'对齐投资人展示准备',cursor:1,modules:[{id:'summary-one',edited:false,kind:'summary',title:'展示安排',topic:'投资人展示',body:'### 已知\nCarl 的时间没有约定。\n### 仍需明确\n- 评审时间',sourceRefs:['s1']},{id:'action-one',edited:false,kind:'task',title:'整理展示资料',topic:'投资人展示',body:'与 Hannah 收集概念、渲染和样机资料。'+Array.from({length:30},(_,i)=>'\n\n第 '+(i+1)+' 项：展示材料需要保留来源与当前进展。').join(''),owner:'Aaron',sourceRefs:['s1']}]}},source.revision);
  }
  hub.data.tasks.push({id:'quiet-task',key:'manual:quiet',triage:'mine',text:'过时的无期限想法',status:'todo',owner:'Aaron',businessUpdatedAt:'2026-01-01T00:00:00Z',sourceIds:[]},{id:'fresh-task',key:'manual:fresh',triage:'mine',text:'当前展示安排',status:'todo',owner:'Aaron',businessUpdatedAt:new Date().toISOString(),sourceIds:[]});hub.save();
  // macOS has /usr/bin/false; a nonexistent override would fall back to real Codex.
  const disabledCodex='/usr/bin/false';fs.accessSync(disabledCodex,fs.constants.X_OK);
  server=spawn(process.execPath,[path.join(__dirname,'../app/server.js')],{env:{...process.env,THT_DATA_DIR:DATA,THT_PORT:String(PORT),THT_NO_OPEN:'1',THT_LLM_AUTOPICK:'off',LIVE_CARD_WARMUP:'off',THT_CODEX_APP_SERVER_BIN:disabledCodex},stdio:'ignore'});
  for(let i=0;i<50;i++){try{if((await fetch(`http://127.0.0.1:${PORT}/health`)).ok)break}catch{}await sleep(200)}
  // Canonical routes: old URLs preserve identity and never expose old pages.
  for(const [route,target] of [['archive.html?id=offline-smoke-evening','./?id=offline-smoke-evening'],['meeting-board.html?id=offline-smoke-evening','./?id=offline-smoke-evening'],['activity.html','work.html#activity'],['briefs.html','work.html#briefs']]){const r=await fetch(`http://127.0.0.1:${PORT}/tinghuitai/`+route,{redirect:'manual'});assert(r.status===302&&r.headers.get('location')===target,'canonical redirect '+route)}
  for(const route of ['/meeting-board','/asr-relay/meeting-board']){const r=await fetch(`http://127.0.0.1:${PORT}`+route+'?id=offline-smoke-evening');assert(r.status===200&&(await r.json()).source.board.modules.length===2,'board HTTP namespace '+route)}
  for(const asset of ['live-signals-ui.js','build-info.js','version-sync.js','board-language.js']){const response=await fetch(`http://127.0.0.1:${PORT}/tinghuitai/`+asset);assert(response.ok&&response.headers.get('content-type').includes('javascript'),'meeting script is served as JavaScript: '+asset);}
  chrome=spawn(CHROME,['--headless=new',`--remote-debugging-port=${CDP}`,`--user-data-dir=${PROFILE}`,'--no-first-run','--window-size=1440,900','--disable-gpu','about:blank'],{stdio:['ignore','ignore',fs.openSync(chromeLog,'w')]});
  let target;for(let i=0;i<50&&!target;i++){await sleep(200);try{target=(await(await fetch(`http://127.0.0.1:${CDP}/json/list`)).json()).find(t=>t.type==='page')}catch{}}
  if(!target)throw Error('Chrome connection: '+fs.readFileSync(chromeLog,'utf8').slice(-1500));ws=new WebSocket(target.webSocketDebuggerUrl);await new Promise(r=>ws.on('open',r));ws.on('message',d=>{const m=JSON.parse(d);if(m.id&&pending.has(m.id)){const p=pending.get(m.id);pending.delete(m.id);clearTimeout(p.timer);m.error?p.rej(Error(m.error.message)):p.res(m.result)}if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails.exception?.description||m.params.exceptionDetails.text)});
  await send('Page.enable');await send('Runtime.enable');
  await send('Page.addScriptToEvaluateOnNewDocument',{source:`const realFetch=window.fetch;window.fetch=(url,options)=>String(url).includes('/workspace-assistant/models')?(localStorage.getItem('tht-ui-models-fail')?Promise.reject(Error('models unavailable')):Promise.resolve(new Response(JSON.stringify({models:[{id:'gpt-6.1-sol',name:'GPT-6.1-Sol',isDefault:true,description:'Latest workhorse model for coding and everyday work.',reasoningEffort:'medium'},{id:'gpt-6-astra',name:'GPT-6-Astra',description:'Frontier intelligence for the most demanding work.',reasoningEffort:'medium'}]}),{status:200,headers:{'Content-Type':'application/json'}}))):realFetch(url,options);`});await send('Page.navigate',{url:`http://127.0.0.1:${PORT}/tinghuitai/?id=offline-smoke-evening`});await sleep(3200);
  assert(await evaluate(`const f=document.querySelector('#workspace-frame');return f?.contentDocument?.querySelector('#canvas')&&getComputedStyle(document.querySelector('#main')).display==='none'&&['start','b-hist','gear2','m-update','b-feedback'].every(id=>document.getElementById(id).offsetParent!==null)`),'one canvas and essential controls');
  assert(await evaluate(`return document.querySelector('#workspace-frame').contentDocument.querySelector('#canvas').textContent.includes('与 Hannah')`),'complete meeting content appears');await shot('01-meeting');
  assert(await evaluate(`const d=document.querySelector('#workspace-frame').contentDocument,c=d.querySelector('.signal-judgment');return c.textContent.includes('当前判断')&&c.textContent.includes('尚未确认')&&c.textContent.includes('实物可信度')`),'current judgement is visible, explained and unconfirmed');
  assert(await evaluate(`const d=document.querySelector('#workspace-frame').contentDocument,s=d.querySelector('.signal-background');return s.closest('[data-module-id]').dataset.moduleId==='action-one'&&s.querySelector('a').href==='https://example.com/evidence'&&s.textContent.includes('不代表整条说法已经验证')`),'public evidence stays with its topic and has a real source link');
  await evaluate(`const d=document.querySelector('#workspace-frame').contentDocument,s=d.querySelector('.signal-background');s.querySelector('details').open=true;return true`);
  assert(await evaluate(`const d=document.querySelector('#workspace-frame').contentDocument;return d.querySelector('.signal-background details').textContent.includes('Carl 的时间没有约定')`),'object source references resolve to the original transcript');
  assert(await evaluate(`const d=document.querySelector('#workspace-frame').contentDocument;return d.querySelector('[data-module-id^="judgment:"]').textContent.includes('可能先展示渲染图')`),'judgement corrections preserve the earlier interpretation');
  await sleep(5500);
  assert(await evaluate(`return document.querySelector('#workspace-frame').contentDocument.querySelector('.signal-background details').open`),'live refresh preserves expanded source evidence');
  // Presentation-only confirmation fixture; real HTTP persistence is tested in native-meeting.test.js.
  await evaluate(`const w=document.querySelector('#workspace-frame').contentWindow;w.__originalFetch=w.fetch.bind(w);w.__confirmation={id:'ui-proposal',question:'先生成典型一天的看板？',statement:'先生成看板草稿，未知信息留空。',sourceRefs:[{speaker:'Aaron',at:'01:20',text:'准备典型一天看板'}]};w.fetch=async function(url,opts){if(opts?.body&&JSON.parse(opts.body).action==='live-confirmation'){w.__confirmation=null;return new w.Response(JSON.stringify({ok:true}));}const r=await w.__originalFetch(url,opts);if(String(url).includes('meeting-board')&&!opts?.body){const j=await r.json();j.session.liveConfirmation=w.__confirmation;return new w.Response(JSON.stringify(j),{headers:{'Content-Type':'application/json'}});}if(opts?.body&&JSON.parse(opts.body).action==='live-confirmation'){w.__confirmation=null;return new w.Response(JSON.stringify({ok:true}));}return r;};return true`);
  await sleep(5500);
  assert(await evaluate(`const d=document.querySelector('#workspace-frame').contentDocument;return d.querySelectorAll('.live-confirmation').length===1&&d.querySelector('.live-confirmation').textContent.includes('尚未确认')`),'single important confirmation sits on the existing canvas');
  await evaluate(`const d=document.querySelector('#workspace-frame').contentDocument,c=d.querySelector('.live-confirmation');[...c.querySelectorAll('button')].find(b=>b.textContent==='纠正').click();c.querySelector('textarea').value='只做上午的看板';return true`);await sleep(5500);
  assert(await evaluate(`return document.querySelector('#workspace-frame').contentDocument.querySelector('.live-confirmation textarea').value==='只做上午的看板'`),'live updates preserve the correction draft');
  await evaluate(`const c=document.querySelector('#workspace-frame').contentDocument.querySelector('.live-confirmation');[...c.querySelectorAll('button')].find(b=>b.textContent==='稍后').click();return true`);await sleep(500);
  assert(await evaluate(`return !document.querySelector('#workspace-frame').contentDocument.querySelector('.live-confirmation')`),'later removes the interruption');
  await evaluate(`const w=document.querySelector('#workspace-frame').contentWindow;w.fetch=w.__originalFetch;return true`);

  // Explicit re-open must work even when the selected meeting is unchanged.
  await evaluate(`const d=document.querySelector('#workspace-frame').contentDocument;d.querySelector('#filters button:last-child').click();d.querySelector('#canvas').scrollTop=600;return true`);
  assert(await evaluate(`return document.querySelector('#workspace-frame').contentDocument.querySelector('#canvas').scrollTop>100`),'same-meeting reopen begins from a genuinely scrolled canvas');
  await evaluate(`const b=document.querySelector('[data-pc-open="offline-smoke-evening"]');if(!b)throw Error('post-meeting reopen button missing');b.click();return true`);await sleep(400);
  assert(await evaluate(`const d=document.querySelector('#workspace-frame').contentDocument;return d.querySelector('#canvas').scrollTop===0&&d.querySelector('#filters .active').textContent==='全部话题'`),'same-meeting card click clears filtering and returns to the top');
  await evaluate(`document.querySelector('#workspace-frame').contentDocument.querySelector('#canvas').scrollTop=220;return true`);await sleep(5500);
  assert(await evaluate(`return document.querySelector('#workspace-frame').contentDocument.querySelector('#canvas').scrollTop===220`),'normal context sync and refresh preserve the reading position');
  await evaluate(`window.thtOpenMeeting('offline-smoke-evening',30,'action-one');return true`);await sleep(400);
  await evaluate(`window.__resultPosition=document.querySelector('#workspace-frame').contentDocument.querySelector('#canvas').scrollTop;return true`);await sleep(5500);
  assert(await evaluate(`return document.querySelector('#workspace-frame').contentDocument.querySelector('#canvas').scrollTop===window.__resultPosition`),'result navigation consumes its timestamp and stays on the requested result');

  await evaluate(`document.getElementById('b-assistant').click();return true`);await sleep(200);
  assert(await evaluate(`const d=document.querySelector('#workspace-frame').contentDocument;return d.querySelector('#context-used summary').textContent.includes('本次使用的资料')&&d.querySelector('#context-manifest').textContent.includes('来源')`),'meeting context initializes inside the living canvas');
  assert(await evaluate(`const d=document;return !d.querySelector('.ma-panel').hidden&&d.querySelectorAll('.ma-form button[type=submit]').length===1&&d.querySelector('.ma-send').getAttribute('aria-label')==='发送'`),'MyAgent one send');
  assert(await evaluate(`return document.querySelector('.ma-add')&&document.querySelector('.ma-model')&&document.querySelector('.ma-voice')&&document.querySelector('.ma-hint').textContent.includes('Shift')`),'composer materials model voice and keyboard controls');
  assert(await evaluate(`const d=document,t=d.querySelector('.ma-form textarea'),m=d.querySelector('.ma-model');return !t.required&&d.querySelector('.ma-send').disabled&&m.getBoundingClientRect().width<=164&&d.querySelector('.ma-voice svg')&&d.querySelector('.ma-voice').title==='语音输入'&&t.getBoundingClientRect().height<=65`),'compact composer has a recognizable microphone and disabled blank send');
  assert(await evaluate(`const m=document.querySelector('.ma-model'),d=document.querySelector('.ma-model-info');return m.selectedOptions[0].textContent.includes('GPT-6.1 Sol')&&d.querySelector('summary').textContent.includes('中度')&&m.title.includes('本机 Codex 配置')&&d.querySelector('p').textContent.includes('切换仅用于后续消息')&&!d.open`),'default model and reasoning are explained from runtime metadata without expanding the composer');
  await evaluate(`const d=document.querySelector('.ma-model-info');d.querySelector('summary').click();const m=document.querySelector('.ma-model');m.value='gpt-6-astra';m.dispatchEvent(new Event('change'));return true`);
  assert(await evaluate(`const d=document.querySelector('.ma-model-info');return d.open&&d.querySelector('p').textContent.includes('复杂工作')&&document.querySelector('.ma-model').title.includes('不会悄悄换模型')`),'model explanation follows selection and explains explicit model failure');
  await evaluate(`localStorage.setItem('tht-ui-models-fail','1');return true`);await send('Page.reload');await sleep(3000);
  assert(await evaluate(`const m=document.querySelector('.ma-model');return m.value==='gpt-6-astra'&&m.title.includes('仍使用你的选择')&&document.querySelector('.ma-model-info p').textContent.includes('保留当前选择')`),'failed model lookup keeps the saved explicit model instead of silently using default');
  await evaluate(`localStorage.removeItem('tht-ui-models-fail');return true`);await send('Page.reload');await sleep(3000);
  await evaluate(`const m=document.querySelector('.ma-model');m.value='';m.dispatchEvent(new Event('change'));document.querySelector('.ma-model-info').open=false;return true`);
  await evaluate(`const t=document.querySelector('.ma-form textarea');t.value=Array(12).fill('这是一段较长的输入。').join(String.fromCharCode(10));t.dispatchEvent(new Event('input'));return true`);
  assert(await evaluate(`const t=document.querySelector('.ma-form textarea');return t.getBoundingClientRect().height===144&&!document.querySelector('.ma-send').disabled`),'composer grows with the draft up to its height limit');
  await evaluate(`const t=document.querySelector('.ma-form textarea');t.value='';t.dispatchEvent(new Event('input'));return true`);
  assert(await evaluate(`return document.querySelector('.ma-form textarea').getBoundingClientRect().height<=65`),'empty composer shrinks again');
  await evaluate(`const d=new DataTransfer();d.items.add(new File(['Meeting context'],'meeting-context.md',{type:'text/markdown'}));const f=document.querySelector('.ma-file');f.files=d.files;f.dispatchEvent(new Event('change'));const t=document.querySelector('.ma-panel textarea');t.value='Attachment draft';t.dispatchEvent(new Event('input'));return true`);await sleep(500);
  assert(await evaluate(`return document.querySelector('.ma-materials').textContent.includes('meeting-context.md')`),'composer uploads material through the live endpoint');
  await send('Page.reload');await sleep(1600);
  assert(await evaluate(`return document.querySelector('.ma-materials').textContent.includes('meeting-context.md')&&document.querySelector('.ma-panel textarea').value==='Attachment draft'`),'uploaded attachment and draft survive refresh');
  // A network failure must retain the full draft and retry the original request.
  await evaluate(`window.__agentFetch=window.fetch.bind(window);const originalFetch=window.__agentFetch;window.__agentRequests=[];window.__failAgentOnce=true;window.fetch=async(url,options)=>{if(String(url).includes('/workspace-assistant')&&options?.method==='POST'&&!String(url).includes('/materials')){window.__agentRequests.push(JSON.parse(options.body));if(window.__failAgentOnce){window.__failAgentOnce=false;throw new TypeError('Failed to fetch');}}return originalFetch(url,options);};window.myAgentAsk('Carl 的时间没有约定。','',{contextId:'offline-smoke-evening',objectId:'action-one'});const t=document.querySelector('.ma-form textarea');t.value='翻一下昨天晚上的会议纪要';t.dispatchEvent(new Event('input'));document.querySelector('.ma-send').click();return true`);await sleep(200);
  assert(await evaluate(`return document.querySelector('.ma-form textarea').value.includes('翻一下昨天')&&document.querySelector('.ma-quote').textContent.includes('Carl')&&document.querySelector('.ma-materials').textContent.includes('meeting-context.md')&&document.querySelector('.ma-retry')&&document.querySelector('.ma-error').textContent.includes('消息已保留')&&!document.querySelector('.ma-error').textContent.includes('Failed to fetch')`),'failed send keeps text, reference, materials and an actionable error');
  await evaluate(`sessionStorage.setItem('tht-ui-original-request',JSON.stringify(window.__agentRequests[0]));return true`);
  await send('Page.reload');await sleep(1600);
  assert(await evaluate(`return document.querySelector('.ma-retry')&&document.querySelector('.ma-form textarea').value.includes('翻一下昨天')`),'unconfirmed delivery survives page reload without automatic resend');
  await evaluate(`window.__agentFetch=window.fetch.bind(window);const originalFetch=window.__agentFetch;window.__retryPayload=null;window.fetch=async(url,options)=>{if(String(url).includes('/workspace-assistant')&&options?.method==='POST'&&!String(url).includes('/materials'))window.__retryPayload=JSON.parse(options.body);return originalFetch(url,options);};document.querySelector('.ma-retry').click();return true`);await sleep(800);
  assert(await evaluate(`const j=document.querySelectorAll('.ma-job');return !document.querySelector('.ma-retry')&&window.__retryPayload?.pageContext.objectId==='action-one'&&window.__retryPayload?.materialIds.length===1&&document.querySelector('.ma-form textarea').value===''&&j.length===1`),'manual retry uses the saved context and reconciles to one accepted message');
  assert(await evaluate(`return window.__retryPayload.requestId===JSON.parse(sessionStorage.getItem('tht-ui-original-request')).requestId`),'retry retains the original request ID across reload');
  // Accepted request with a lost response is reconciled from the live receipt.
  await evaluate(`const originalFetch=window.__agentFetch;window.__lostPayload=null;window.fetch=async(url,options)=>{const response=await originalFetch(url,options);if(String(url).includes('/workspace-assistant')&&options?.method==='POST'&&!String(url).includes('/materials')){window.__lostPayload=JSON.parse(options.body);await response.json();throw new TypeError('Failed to fetch');}return response;};const t=document.querySelector('.ma-form textarea');t.value='翻一下昨天晚上的会议纪要';t.dispatchEvent(new Event('input'));document.querySelector('.ma-send').click();return true`);await sleep(1200);
  assert(await evaluate(`return !document.querySelector('.ma-retry')&&document.querySelectorAll('.ma-job').length===2&&document.querySelector('.ma-form textarea').value===''`),'lost POST response is reconciled from SSE without resending or duplicate bubbles');
  await evaluate(`window.fetch=window.__agentFetch;return true`);
  await evaluate(`document.querySelector('.ma-materials button')?.click();return true`);
  assert(await evaluate(`const d=document,t=d.querySelector('.ma-panel textarea');t.value='IME draft';t.dispatchEvent(new d.defaultView.KeyboardEvent('keydown',{key:'Enter',isComposing:true,bubbles:true,cancelable:true}));t.dispatchEvent(new d.defaultView.KeyboardEvent('keydown',{key:'Enter',shiftKey:true,bubbles:true,cancelable:true}));return t.value==='IME draft'`),'IME and Shift Enter keep draft');
  await evaluate(`const d=document,t=d.querySelector('.ma-panel textarea');t.value='翻一下昨天晚上的会议纪要';t.dispatchEvent(new d.defaultView.KeyboardEvent('keydown',{key:'Enter',bubbles:true,cancelable:true}));return true`);await sleep(2200);
  assert(await evaluate(`const d=document;return d.querySelector('.ma-conversation').textContent.includes('Carl 的时间没有约定')&&d.querySelectorAll('.ma-conversation a[href*="/tinghuitai/?id="]').length>=1`),'Enter retrieves exact minutes without active recording');
  await shot('02-agent');
  await evaluate(`const d=document.querySelector('#workspace-frame').contentDocument,m=d.querySelector('#meeting');m.value='offline-smoke-other';m.dispatchEvent(new d.defaultView.Event('change'));return true`);await sleep(700);await send('Page.reload');await sleep(1700);await evaluate(`document.getElementById('b-assistant').click();return true`);await sleep(300);
  assert(await evaluate(`const d=document;return location.search.includes('offline-smoke-other')&&d.querySelector('.ma-conversation').textContent.includes('翻一下昨天')`),'meeting switch and refresh preserve conversation');
  await evaluate(`document.querySelector('.ma-close').click();document.querySelector('#b-this').click();return true`);await sleep(150);
  assert(await evaluate(`return document.querySelector('#workspace-frame').contentDocument.querySelector('#export-dialog').open`),'unified export');
  await evaluate(`document.querySelector('#workspace-frame').contentDocument.querySelector('#export-close').click();return true`);
  await evaluate(`document.querySelector('[data-ui=en]').click();return true`);await sleep(1300);
  assert(await evaluate(`return document.querySelector('#workspace-frame').contentDocument.querySelector('#recap-title').textContent.includes('AI')`),'language reaches canvas');
  await evaluate(`document.querySelector('[data-ui=zh]').click();return true`);await sleep(300);
  await evaluate(`window.__recorderDocument=crypto.randomUUID();window.__meetingCanvas=document.querySelector('#workspace-frame').contentWindow;document.querySelector('#b-work-top').click();return true`);await sleep(1200);
  assert(await evaluate(`return location.pathname.endsWith('/tinghuitai/')&&!document.querySelector('#work-frame').hidden&&document.querySelector('#workspace-frame').hidden&&document.querySelector('#b-work-top').textContent==='← 听会台'`),'work switch keeps recorder document alive');
  await evaluate(`document.querySelector('#b-assistant').click();return true`);await sleep(200);
  assert(await evaluate(`return !document.querySelector('.ma-panel').hidden`),'MyAgent follows current surface');
  await evaluate(`document.querySelector('#b-work-top').click();return true`);await sleep(300);
  assert(await evaluate(`return !!window.__recorderDocument&&window.__meetingCanvas===document.querySelector('#workspace-frame').contentWindow&&document.querySelector('#work-frame').hidden&&!document.querySelector('#workspace-frame').hidden&&document.querySelector('#b-work-top').textContent==='工作台'`),'return retains recorder and original canvas');
  await evaluate(`document.querySelector('.ma-panel textarea').value='Keep my draft';document.querySelector('.ma-panel textarea').dispatchEvent(new Event('input'));document.querySelector('[data-ui=en]').click();return true`);await sleep(100);
  assert(await evaluate(`return document.querySelector('.ma-send').getAttribute('aria-label')==='Send'`),'open MyAgent follows language immediately');
  await evaluate(`document.querySelector('[data-ui=zh]').click();return true`);
  for(let i=0;i<3;i++){
   await evaluate(`window.thtOpenWorkbench('sources');return true`);await sleep(500);
   await evaluate(`const d=document.querySelector('#work-frame').contentDocument;const b=d.querySelector('[data-source]');if(!b)throw Error('source meeting button missing');b.click();return true`);await sleep(600);
   assert(await evaluate(`return document.querySelector('#work-frame').hidden&&document.querySelector('#workspace-frame').contentDocument.querySelectorAll('#workspace-frame').length===0&&window.__meetingCanvas===document.querySelector('#workspace-frame').contentWindow&&document.querySelector('.ma-panel textarea').value==='Keep my draft'`),'source link avoids nested application '+i);
   await evaluate(`history.back();return true`);await sleep(400);
   assert(await evaluate(`return !document.querySelector('#work-frame').hidden`),'browser back restores work '+i);
   await evaluate(`history.forward();return true`);await sleep(400);
   assert(await evaluate(`return !document.querySelector('#workspace-frame').hidden`),'browser forward restores meeting '+i);
  }
  await send('Page.navigate',{url:`http://127.0.0.1:${PORT}/tinghuitai/work.html`});await sleep(1300);
  for(const view of ['tasks','graph','sources','people','memory','briefs','activity','focus']){await evaluate(`document.querySelector('[data-view=${view}]').click();return true`);await sleep(200);assert(await evaluate(`return location.pathname.endsWith('/work.html')&&document.querySelector('.topbar')&&document.querySelector('.ma-fab')`),'shared work shell '+view)}
  await evaluate(`document.querySelector('[data-view=tasks]').click();return true`);await sleep(200);
  assert(await evaluate(`return !document.querySelector('#content').textContent.includes('过时的无期限想法')`),'quiet task absent from default');
  await evaluate(`const q=document.querySelector('#filters input');q.value='过时';q.dispatchEvent(new Event('input',{bubbles:true}));return true`);await sleep(600);
  assert(await evaluate(`return document.querySelector('#content').textContent.includes('过时的无期限想法')`),'quiet task searchable');
  await evaluate(`document.querySelector('#work-lang').click();return true`);await sleep(100);assert(await evaluate(`return document.documentElement.lang==='en'&&document.querySelector('[data-view=tasks]').textContent==='Work items'`),'work core language switch');await evaluate(`document.querySelector('#work-lang').click();return true`);await shot('03-work');await evaluate(`document.querySelector('.back-link').click();return true`);await sleep(1900);
  assert(await evaluate(`return location.pathname.endsWith('/tinghuitai/')&&location.search.includes('offline-smoke-other')`),'work returns to selected meeting');
  await send('Emulation.setDeviceMetricsOverride',{width:430,height:932,deviceScaleFactor:1,mobile:true});await sleep(300);await evaluate(`document.getElementById('b-assistant').click();return true`);await sleep(300);
  assert(await evaluate(`const d=document,r=d.querySelector('.ma-panel textarea').getBoundingClientRect();return r.width>100&&r.right<=d.defaultView.innerWidth+2`),'mobile composer remains usable');await shot('04-mobile');
  // Synthetic events exercise the real routes and both views; this is not real capture acceptance.
  await send('Emulation.setDeviceMetricsOverride',{width:1440,height:1000,deviceScaleFactor:1,mobile:false});
  const native=await evaluate(`const r=await fetch('/asr-relay/native/start',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({target:{windowId:15,bundleId:'com.bytedance.Feishu',title:'飞书会议 · 验收模拟'}})});if(!r.ok)throw Error('native start '+r.status);return r.json()`);
  const nativeId=native.sessionId;assert(nativeId.startsWith('native-'),'native route works through deployed namespace');await sleep(2800);
  assert(await evaluate(`return window.thtNativeStatus.active&&window.thtNativeStatus.sessionId===${JSON.stringify(nativeId)}&&!document.querySelector('#b-native').hidden&&!document.querySelector('#workspace-frame').hidden`),'full canvas and native mini entry coexist');
  assert((await (await fetch(`http://127.0.0.1:${PORT}/native/status`)).json()).calls===0,'quiet native session makes zero model calls');
  const nativePost=async(route,body)=>{const r=await fetch(`http://127.0.0.1:${PORT}/asr-relay/native/${route}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({sessionId:nativeId,...body})});if(!r.ok)throw Error('native '+route+' '+r.status);return r.json()};
  await nativePost('text',{key:'first',text:'本场目标是给投资人展示可用的模型。'});
  await sleep(1000);const board=await (await fetch(`http://127.0.0.1:${PORT}/asr-relay/meeting-board?id=${nativeId}`)).json();
  assert(board.session.nativeCapture&&board.session.transcript.some(x=>x.text.includes('投资人')),'native text reaches the same meeting canvas');
  await nativePost('pause',{paused:true});assert((await (await fetch(`http://127.0.0.1:${PORT}/native/status`)).json()).active,'pause does not finalize the meeting');await nativePost('pause',{paused:false});
  await evaluate(`document.querySelector('#stop').click();return true`);await sleep(200);
  const stopping=await (await fetch(`http://127.0.0.1:${PORT}/native/status`)).json();assert(stopping.active&&stopping.command==='stop','full view stop waits for the native helper to flush');
  await nativePost('text',{key:'last',text:'这是结束前需要保存的最后一句。'});await nativePost('end',{});
  const saved=JSON.parse(fs.readFileSync(path.join(DATA,'pending','sess-'+nativeId+'.json'),'utf8'));
  assert(saved.transcript.some(x=>x.text.includes('最后一句'))&&saved.nativeCapture,'final sentence is archived before ending');await sleep(2400);
  assert(!(await (await fetch(`http://127.0.0.1:${PORT}/native/status`)).json()).active,'native meeting ends explicitly');await shot('05-native-full');
  if(errors.length)console.error(JSON.stringify({browserErrors:errors}));
  assert(errors.length===0,'zero browser runtime exceptions');console.log(JSON.stringify({checks:checks.length,shots:SHOTS,data:DATA}));
 }catch(e){console.error(e.stack);console.error(JSON.stringify({browserErrors:errors}));if(ws){try{await shot('failure');console.error(await evaluate(`return document.querySelector('#workspace-frame')?.contentDocument?.querySelector('#canvas')?.textContent||document.querySelector('#content')?.textContent`));}catch{}}process.exitCode=1}finally{if(ws)ws.close();if(chrome)chrome.kill();if(server)server.kill();console.log('Artifacts '+SHOTS)}
})();
