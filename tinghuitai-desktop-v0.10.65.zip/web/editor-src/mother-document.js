const {Editor}=require('@tiptap/core');
const Collaboration=require('@tiptap/extension-collaboration').default;
const Y=require('yjs');
import format from '../../app/mother-document-schema.js';
import localCache from './document-cache.js';
import transport from './document-sync.js';
import materialPreview from './material-preview.js';
const documentLinks=require('./document-link');
const {DOMSerializer}=require('@tiptap/pm/model');
window.ChatDocumentSelection=window.ChatDocumentSelection||require('../chat-document-selection');

const root=document.getElementById('canvas');
const el=(tag,text='',cls='')=>{const n=document.createElement(tag);n.textContent=text;n.className=cls;return n;};
const box=el('section','','mother-workspace');box.id='mother-workspace';root.prepend(box);
const heading=el('div','','mother-heading'),choose=el('select'),fresh=el('button'),records=el('button'),forkButton=el('button'),status=el('small','','mother-status');
choose.setAttribute('aria-label','Topic document');status.setAttribute('role','status');heading.append(choose,fresh,records,status);
const identity=el('div','','mother-identity'),documentLink=el('a','↗','mother-document-link');documentLink.hidden=true;documentLink.target='_blank';documentLink.rel='noopener';identity.append(choose,documentLink,status);box.append(identity);
const title=el('h1','','mother-title'),toolbar=el('div','','mother-toolbar'),host=el('div','','mother-editor');
const start=el('div','','mother-start'),startTitle=el('input'),inherit=el('button'),blank=el('button');startTitle.maxLength=160;start.append(startTitle,inherit,blank);
const history=el('details','','mother-history');history.append(el('summary'),el('div'));
const metadata=el('div','','surface-metadata'),materials=el('div','','surface-materials'),candidateToggle=el('button','','mother-candidate-toggle');candidateToggle.type='button';candidateToggle.hidden=true;box.append(heading,title,metadata,materials,start,toolbar,candidateToggle,host,history);
const candidateOpen=new Map(),agendaOpen=new Map();
const agendaToggle=el('button','','mother-agenda-toggle');agendaToggle.type='button';agendaToggle.hidden=true;box.insertBefore(agendaToggle,host);
const options=el('details','','mother-document-options'),optionsSummary=el('summary','···'),optionsPanel=el('div','','mother-options-panel'),historyButton=el('button'),historyDialog=el('dialog','','mother-history-dialog'),historyClose=el('button','×');
optionsSummary.setAttribute('aria-label','文档更多操作');optionsPanel.append(heading,metadata,candidateToggle,agendaToggle,historyButton);options.append(optionsSummary,optionsPanel);identity.append(options);
historyButton.type=historyClose.type='button';historyClose.setAttribute('aria-label','关闭版本历史');historyDialog.append(historyClose,history);box.append(historyDialog);
historyButton.onclick=()=>{options.open=false;history.hidden=false;history.open=true;historyDialog.showModal();};historyClose.onclick=()=>historyDialog.close();historyDialog.addEventListener('close',()=>{history.open=false;optionsSummary.focus();});
options.addEventListener('toggle',()=>{if(options.open)for(const button of optionsPanel.querySelectorAll('button'))button.setAttribute('aria-label',button.textContent.trim());});
options.addEventListener('keydown',e=>{if(e.key==='Escape'){options.open=false;optionsSummary.focus();}});document.addEventListener('pointerdown',e=>{if(options.open&&!options.contains(e.target))options.open=false;});
const agendaStyle=el('style');document.head.append(agendaStyle);
function calendarAgenda(){
 const selectors=[];for(const block of host.querySelectorAll('.tiptap>blockquote[sourceref$=":premeeting-materials"]')){let inside=false;for(const [index,node] of [...block.children].entries()){if(/^H[1-6]$/.test(node.tagName))inside=/^(议程|Agenda)$/i.test(node.textContent.trim());if(inside)selectors.push('.mother-editor .tiptap>blockquote[sourceref="'+CSS.escape(block.getAttribute('sourceref'))+'"]>:nth-child('+(index+1)+')');}}
 agendaToggle.hidden=selectors.length<2;const open=!!agendaOpen.get(active?.id);agendaStyle.textContent=!open&&selectors.length?selectors.join(',')+'{display:none}':'';agendaToggle.setAttribute('aria-expanded',String(open));agendaToggle.textContent=tr('日历说明','Calendar description')+' · '+(open?tr('收起','Hide'):tr('展开','Show'));
}
agendaToggle.onclick=()=>{if(!active)return;agendaOpen.set(active.id,!agendaOpen.get(active.id));calendarAgenda();};
function materialLabel(item,index,rows){
 const full=String(item.title||item.url),others=rows.filter((_,i)=>i!==index).map(x=>String(x.title||x.url));let label=full;
 if(full.length>28&&others.some(x=>x.slice(0,24)===full.slice(0,24))){let prefix=0;while(prefix<full.length&&others.every(x=>x[prefix]===full[prefix]))prefix++;label=full.slice(prefix).replace(/^[\s:：|·—–\-_/]+/,'')||full;label=label.length>30?'…'+label.slice(-29):label;}
 if(others.includes(full))label=(index+1)+'. '+label;return label;
}
function candidates(){
 const s=active;let count=0;if(s?.editor)s.editor.state.doc.forEach(n=>{if(n.type.name==='blockquote'&&n.attrs.sourceRef?.endsWith(':premeeting-candidates'))count+=n.content.content.filter(c=>c.type.name==='bulletList').reduce((n,c)=>n+c.childCount,0);});
 candidateToggle.hidden=!count;const open=!!candidateOpen.get(s?.id);candidateToggle.setAttribute('aria-expanded',String(open));candidateToggle.textContent=tr('资料候选','Suggested materials')+' · '+count+' · '+(open?tr('收起','Hide'):tr('展开','Show'));host.classList.toggle('candidates-folded',!open);
 calendarAgenda();
 box.classList.toggle('same-meeting-title',!!s&&s.title===(board.session?.title||board.source?.title));
}
candidateToggle.onclick=()=>{if(!active)return;candidateOpen.set(active.id,!candidateOpen.get(active.id));candidates();};
window.addEventListener('tht-board-data',e=>{const session=e.detail.data.session,event=e.detail.data.source?.calendarEvent,at=event?.start||session?.start;metadata.replaceChildren();metadata.append(forkButton);const date=new Date(at);if(Number.isFinite(date.getTime()))metadata.append(el('span',date.toLocaleDateString(e.detail.lang==='en'?'en-US':'zh-CN',{month:'short',day:'numeric',weekday:'short'})));document.documentElement.lang=e.detail.lang==='en'?'en':'zh-CN';materials.replaceChildren();const sourceMaterialRows=e.detail.data.source?.materialLinks||[],materialRows=[...sourceMaterialRows],seenURLs=new Set(materialRows.map(m=>{try{return new URL(m.url).href;}catch{return m.url;}}));for(const meeting of e.detail.data.continuity?.meetings||[])for(const note of meeting.referenceNotes||[]){let url;try{url=new URL(note.url);if(url.protocol!=='https:'||url.username||url.password)continue;}catch{continue;}if(seenURLs.has(url.href))continue;seenURLs.add(url.href);materialRows.push({url:url.href,title:note.title||(e.detail.lang==='en'?'Original meeting notes':'原始会议纪要'),read:!!note.text,excerpt:note.text?String(note.text).slice(0,2000):'',notLocalTranscript:true});}const visibleMaterialRows=materialRows.filter(item=>materialPreview.preview(item,e.detail.lang));let more=null;if(visibleMaterialRows.length>6){more=el('details','','surface-material-more');more.append(el('summary',(e.detail.lang==='en'?'More materials · ':'更多资料 · ')+(visibleMaterialRows.length-6)));}for(const [index,item] of visibleMaterialRows.entries()){const view=materialPreview.preview(item,e.detail.lang);if(!view)continue;const row=el('div','','surface-material'),link=el('a',sourceMaterialRows.includes(item)?materialLabel({...item,title:view.title},sourceMaterialRows.indexOf(item),sourceMaterialRows):view.title),preview=el('div','','surface-material-preview'),toggle=el('button',e.detail.lang==='en'?'Preview':'预览','surface-material-toggle'),original=el('a',view.openLabel);link.title=view.title;link.href=view.href;link.target='_blank';link.rel='noopener noreferrer';original.href=view.href;original.target='_blank';original.rel='noopener noreferrer';preview.id='material-preview-'+index;preview.append(el('strong',view.title),el('small',view.label),el('span',view.href,'surface-material-url'));preview.setAttribute('aria-busy',String(view.state==='loading'));if(view.excerpt)preview.append(el('p',view.excerpt));preview.append(original);toggle.type='button';toggle.setAttribute('aria-label',(e.detail.lang==='en'?'Preview: ':'预览：')+view.title);toggle.setAttribute('aria-controls',preview.id);toggle.setAttribute('aria-expanded','false');toggle.onclick=()=>{row.classList.remove('preview-dismissed');const open=toggle.getAttribute('aria-expanded')!=='true';toggle.setAttribute('aria-expanded',String(open));row.classList.toggle('preview-open',open);};row.onkeydown=event=>{if(event.key==='Escape'){row.classList.remove('preview-open');toggle.setAttribute('aria-expanded','false');toggle.focus();row.classList.add('preview-dismissed');}};row.onpointerenter=()=>row.classList.remove('preview-dismissed');row.append(link,toggle,preview);if(index<6)materials.append(row);else more.append(row);}if(more)materials.append(more);});
let meetingId='',board={},lang='zh',active=null,transition=Promise.resolve(),timer,applying=false,lastDataKey='',importing=false;
const tr=(zh,en)=>lang==='en'?en:zh;
const auth=()=>{try{return window.THT_BOOT?.relayToken||parent.THT_BOOT?.relayToken||JSON.parse(localStorage.getItem('tht-settings')||'{}').relayToken||'';}catch{return '';}};
async function api(body,params={}){
 const u=new URL('/mother-documents',location.origin);for(const [k,v] of Object.entries(params))u.searchParams.set(k,v);u.searchParams.set('token',auth());
 const controller=new AbortController(),limit=setTimeout(()=>controller.abort(),body?.action==='organizeCollection'?330000:body?.action==='propose'?180000:15000);
 try{const r=await fetch(u,{cache:'no-store',signal:controller.signal,...(body?{method:'POST',headers:{'Content-Type':'application/json','x-tht-token':auth()},body:JSON.stringify(body)}:{})});const j=await r.json();if(!r.ok)throw Object.assign(Error(j.error||r.status),{status:r.status});return j;}finally{clearTimeout(limit);}
}
function state(text,error=false){status.textContent=text;status.classList.toggle('error',error);}
function labels(){choose.setAttribute('aria-label',tr('主题文档','Topic document'));candidates();ai.title=tr('评论或交给 AI 修改','Comment or ask AI to edit');ai.setAttribute('aria-label',ai.title);documentLink.setAttribute('aria-label',tr('打开这份方案的本机链接','Open this solution locally'));documentLink.title=tr('本机链接 · 不会对外分享','Local link · Not a public share');optionsSummary.setAttribute('aria-label',tr('文档更多操作','More document actions'));historyButton.textContent=tr('版本历史','Version history');historyClose.setAttribute('aria-label',tr('关闭版本历史','Close version history'));forkButton.textContent=tr('接续所选内容','Carry over selection');fresh.textContent=tr('新主题','New topic');records.textContent=tr('会议记录','Meeting notes');startTitle.placeholder=tr('这份文档讨论什么？','What is this document about?');inherit.textContent=tr('从本场成果起稿','Start from this meeting');blank.textContent=tr('新建方案','Start a solution');image.textContent=tr('图片','Image');caption.textContent=tr('图注','Caption');history.firstElementChild.textContent=tr('版本历史','History');for(const b of toolbar.querySelectorAll('[data-en]'))b.textContent=lang==='en'?b.dataset.en:b.dataset.zh;}
function displayStatus(s){if(s!==active)return;if(s.editorError){state(s.editorError.message,true);return;}if(s.localError)state(tr('本机保存失败 · 请勿关闭文档','Local save failed · Keep this document open'),true);else if(s.syncError?.status)state(s.syncError.message,true);else if(s.syncError)state(s.localSaved?tr('已存本机 · 离线编辑','Saved locally · Editing offline'):tr('离线 · 正在保存本机','Offline · Saving locally'));else if(s.actionError)state(s.actionError,true);else state(s.dirty?tr('正在保存','Saving'):tr('本地 · 已保存','Local · Saved'));}
function persist(s){
 if(!s.cache){s.localError=Error('Local storage unavailable');displayStatus(s);return Promise.resolve(false);}
 const generation=++s.localGeneration;s.localSaved=false;
 const saved=s.cache.save({update:Y.encodeStateAsUpdate(s.doc),title:s.title,projectId:s.projectId});s.localPromise=saved;
 return saved.then(()=>{if(generation===s.localGeneration){s.localSaved=true;s.localError=null;displayStatus(s);}return true;},e=>{s.localError=e;s.localSaved=false;displayStatus(s);return false;});
}
async function sync(s=active){if(!s||s.closed)return false;const ok=await transport.sync(s,api);displayStatus(s);if(s===active&&ok&&s.dirty){clearTimeout(timer);timer=setTimeout(()=>sync(s),300);}return ok;}
function selection(){if(!active)return [];const {from,to}=active.editor.state.selection,ids=[];active.editor.state.doc.forEach((node,pos)=>{if((from===to?pos<=from&&pos+node.nodeSize>from:pos+node.nodeSize>from&&pos<to)&&node.attrs.blockId)ids.push(node.attrs.blockId);});return ids.slice(0,12);}
async function ask(idsOverride,quoteOverride){
 const s=active;if(!s)return;const ids=Array.isArray(idsOverride)?idsOverride:selection();if(!ids.length)return;
 const quote=quoteOverride||s.editor.state.doc.textBetween(s.editor.state.selection.from,s.editor.state.selection.to,'\n')||s.editor.state.selection.$from.parent.textContent;
 if(!await sync(s)||s.dirty||s!==active){state(tr('先连接本机服务并保存，再让 AI 修改','Reconnect and save before asking AI to edit'),true);return;}
 const meta={contextId:meetingId,motherDocumentId:s.id,blockIds:ids,projectId:s.projectId||'',page:'mother-document'};
 if(parent!==window)parent.postMessage({type:'tht-agent-ask',quote,meta},location.origin);else window.myAgentAsk?.(quote,'',meta);
}
const tools=[['B','B','加粗 / Bold',e=>e.chain().focus().toggleBold().run()],['H2','H2','标题 / Heading',e=>e.chain().focus().toggleHeading({level:2}).run()],['☐','☐','待办 / To-do',e=>e.chain().focus().toggleTaskList().run()],['•','•','列表 / List',e=>e.chain().focus().toggleBulletList().run()],['表格','Table','插入表格 / Insert table',e=>e.chain().focus().insertTable({rows:3,cols:3,withHeaderRow:true}).run()],['＋行','+ Row','加一行 / Add row',e=>e.chain().focus().addRowAfter().run()],['＋列','+ Column','加一列 / Add column',e=>e.chain().focus().addColumnAfter().run()],['↶','↶','撤销 / Undo',e=>e.chain().focus().undo().run()],['↷','↷','重做 / Redo',e=>e.chain().focus().redo().run()]];
for(const [zh,en,hint,run] of tools){const b=el('button',zh);b.dataset.zh=zh;b.dataset.en=en;b.type='button';b.title=hint;b.setAttribute('aria-label',hint);b.onpointerdown=e=>e.preventDefault();b.onclick=()=>active?.editor&&run(active.editor);toolbar.append(b);}
const image=el('button','图片'),imageInput=el('input');image.title='插入图片 / Insert image';image.type='button';imageInput.type='file';imageInput.accept='image/png,image/jpeg,image/webp,image/gif';imageInput.hidden=true;toolbar.append(image,imageInput);image.onclick=()=>imageInput.click();
imageInput.onchange=()=>{const selected=active,f=imageInput.files[0];if(!f||!selected)return;if(f.size>1800000){state(tr('图片须小于 1.8 MB','Image must be smaller than 1.8 MB'),true);return;}const reader=new FileReader();reader.onload=()=>{if(selected!==active)return;selected.editor.chain().focus().setImage({src:reader.result,alt:f.name}).run();};reader.onerror=()=>state(tr('图片未能读取','Could not read image'),true);reader.readAsDataURL(f);imageInput.value='';};
const caption=el('button','图注');caption.title='编辑选中图片说明 / Edit image description';caption.onclick=()=>{if(!active?.editor.isActive('image')){state(tr('先选中图片','Select an image first'));return;}const alt=prompt(tr('图片说明','Image description'),active.editor.getAttributes('image').alt||'');if(alt!==null)active.editor.chain().focus().updateAttributes('image',{alt,title:alt}).run();};toolbar.append(caption);
const ai=el('button','','mother-ai');ai.type='button';ai.innerHTML='<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8z"/><path d="M8 10h8M8 14h5"/></svg>';ai.onpointerdown=e=>e.preventDefault();ai.onclick=()=>ask();toolbar.append(ai);
records.onclick=()=>window.dispatchEvent(new CustomEvent('tht-transcript-toggle'));
fresh.onclick=()=>{start.hidden=false;startTitle.value='';startTitle.focus();};
forkButton.onclick=async()=>{const meeting=meetingId,epoch=requestEpoch;try{await require('./meeting-fork-dialog')({api,meetingId:meeting,projectId:board.source?.projectManual?board.source.projectId||'':'',tr,onCreate:async request=>{if(meeting!==meetingId||epoch!==requestEpoch)throw Error(tr('会议已切换，请重新选择','Meeting changed; select again'));const current=active;if(current&&(!await sync(current)||current.dirty||current!==active))throw Error(tr('请先保存当前文档','Save the current document first'));const source=board.source;const doc=await api({...request,action:'fork',meetingId:meeting,sourceRevision:source?.revision});if(meeting!==meetingId||epoch!==requestEpoch)return;if(source.motherDocumentId!==doc.id)board.source={...source,motherDocumentId:doc.id,revision:source.revision+1};await openDoc(doc.id,doc);await catalog();}});}catch(e){state(e.message,true);}};
async function create(useExisting){
 const source=board.source,meeting=meetingId,epoch=requestEpoch;const titleValue=startTitle.value.trim()||source?.title||board.session?.title;if(!titleValue){state(tr('先填写主题名称','Enter a topic title first'),true);startTitle.focus();return;}
 inherit.disabled=blank.disabled=true;
 try{const doc=await api({action:'create',title:titleValue,meetingId:meeting,sourceRevision:source?.revision,inherit:useExisting,template:'solution',lang,preparedEventId:board.preparedEventId||''});if(meeting!==meetingId||epoch!==requestEpoch)return;board.source={...source,motherDocumentId:doc.id,revision:source.revision+1};await openDoc(doc.id,doc);await catalog();}
 catch(e){state(e.message,true);}finally{inherit.disabled=blank.disabled=false;}
}
inherit.onclick=()=>create(true);blank.onclick=()=>create(false);
choose.onchange=async()=>{const id=choose.value,meeting=meetingId,source=board.source,epoch=requestEpoch;if(!id)return;choose.disabled=true;try{const doc=await api({action:'bind',id,meetingId:meeting,sourceRevision:source?.revision});if(meeting!==meetingId||epoch!==requestEpoch)return;board.source={...source,motherDocumentId:id,revision:source.revision+1};await openDoc(id,doc);if(documentLinks.requested(parent.location.href,meeting))parent.history.replaceState(parent.history.state,'',documentLinks.href(location.origin,meeting,id));}catch(e){state(e.message,true);choose.value=active?.id||'';}finally{choose.disabled=false;}};
async function catalog(){
 const meeting=meetingId,epoch=requestEpoch;try{const list=await api(null,{meetingId:meeting,projectId:board.source?.projectManual?board.source.projectId||'':''});if(meeting!==meetingId||epoch!==requestEpoch)return;choose.replaceChildren(el('option',tr('选择主题文档','Choose a topic document')));choose.firstChild.value='';for(const d of list.documents){const o=el('option',d.title||tr('文档暂不可用','Document unavailable'));o.value=d.id;o.disabled=!!d.unavailable;choose.append(o);}if(active)choose.value=active.id;}
 catch{if(!active)state(tr('本机服务暂不可用','Local service unavailable'),true);}
}
async function closeDoc(){
 clearTimeout(collectionNoticeTimer);collectionBar.hidden=true;undoCollected.hidden=menuUndoCollected.hidden=true;collectedSelection=null;if(historyDialog.open)historyDialog.close();options.open=false;
 const old=active;if(!old)return true;clearTimeout(timer);await persist(old);if(old.localError&&!await sync(old)){state(tr('文档尚未保存，不能切换','Document not saved; cannot switch yet'),true);return false;}
 await sync(old);hidePreview();old.closed=true;old.editor?.destroy();if(old.cache)try{await old.cache.close();}catch{}old.doc.destroy();active=null;documentLink.hidden=true;documentLink.removeAttribute('href');inspectBlock();return true;
}
function openDoc(id,remote){
 transition=transition.catch(()=>{}).then(async()=>{
  if(active?.id===id)return;if(!await closeDoc())return;
  const doc=new Y.Doc();let cache,cached;try{cache=await localCache.cache(id);cached=await cache.load();if(cached?.update)Y.applyUpdate(doc,cached.update,'remote');}catch(e){state(tr('本机存储不可用，请保持联网','Local storage unavailable; keep connected'),true);}
  const s={id,doc,cache,revision:0,editor:null,dirty:false,syncPromise:null,title:cached?.title||'',projectId:cached?.projectId||'',localGeneration:0,localSaved:!!cached,localError:cache?null:Error('Local storage unavailable')};
  try{remote=remote||await api(null,{id});Y.applyUpdate(doc,transport.decode(remote.update),'remote');s.revision=remote.revision;s.title=remote.title;s.projectId=remote.projectId;s.collections=remote.collections||[];}
  catch(e){s.syncError=e;if(!doc.getXmlFragment('default').length){state(tr('文档暂时无法打开','Document unavailable'),true);await cache?.close();doc.destroy();return;}}
  active=s;documentLink.href=documentLinks.href(location.origin,meetingId,id);documentLink.hidden=false;localStorage.setItem('tht-mother:'+meetingId,id);title.textContent=s.title;choose.value=id;start.hidden=true;host.hidden=toolbar.hidden=history.hidden=false;root.classList.add('mother-open');
  doc.on('update',(_,origin)=>{if(s.closed)return;persist(s);if(origin!=='remote'){s.actionError=null;s.dirty=true;clearTimeout(timer);timer=setTimeout(()=>sync(s),900);}});
  try{
  s.editor=new Editor({element:host,extensions:[...format.extensions(),require('./solution-evidence-fold').extension.configure({lang}),Collaboration.configure({document:doc})],editorProps:{attributes:{'aria-label':tr('主题主文档，可直接编辑','Topic document, editable'),spellcheck:'true'}}});
  }catch(e){s.editorError=e;console.error('Document editor initialization failed:',e);toolbar.hidden=true;host.hidden=true;root.classList.remove('mother-open');displayStatus(s);throw e;}
  s.editor.on('transaction',({editor,transaction})=>{if(transaction.docChanged&&!applying)assignIds(editor);if(transaction.docChanged){candidates();hidePreview();}inspectBlock();});
  s.editor.on('selectionUpdate',({editor})=>{document.body.classList.toggle('surface-selection',!editor.state.selection.empty);inspectBlock();});
  host.onkeydown=e=>{if(e.key==='/'&&s.editor.state.selection.$from.parent.textContent===''){e.preventDefault();document.body.classList.add('surface-format-open');toolbar.querySelector('button')?.focus();}if(e.key==='Escape'){document.body.classList.remove('surface-format-open','surface-selection');}};
  assignIds(s.editor);candidates();restoreCollection(s);inspectBlock();
  await persist(s);await sync(s);await importDrafts();
 });
 return transition;
}
function assignIds(editor){
 if(applying)return;const trn=editor.state.tr;let changed=false;const seen=new Set();editor.state.doc.forEach((n,pos)=>{const id=n.attrs.blockId;if(!id||seen.has(id)){const next='b-'+crypto.randomUUID();trn.setNodeMarkup(pos,undefined,{...n.attrs,blockId:next});seen.add(next);changed=true;}else seen.add(id);});if(changed){applying=true;try{editor.view.dispatch(trn);}finally{applying=false;}}
}
async function importDrafts(){
 if(importing||!active||board.source?.motherDocumentId!==active.id)return;const s=active,source=board.source,meeting=meetingId;importing=true;
 try{let conflict=false;for(const m of source.board?.modules||[]){if(s!==active||meeting!==meetingId)break;if(m.kind!=='note'||!m.body)continue;const result=await api({action:'import',id:s.id,meetingId:meeting,moduleId:m.id});if(result.conflict)conflict=true;}if(s===active){await sync(s);if(conflict)state(tr('新讨论与人工修改不同 · 已保留原稿','New discussion differs from your edit · Original kept'));}}catch(e){if(s===active&&e.status)state(e.message,true);}finally{importing=false;}
}
history.ontoggle=async()=>{if(!history.open||!active)return;const s=active,list=history.lastElementChild;list.replaceChildren();try{const result=await api(null,{id:s.id,history:1});if(active!==s||!historyDialog.open)return;for(const h of result.history){const row=el('div'),b=el('button',tr('查看','View'));row.append(el('span',h.at.slice(0,16)+' · '+h.author),b);b.onclick=async()=>{if(active!==s)return;try{const version=await api(null,{id:s.id,revision:h.revision});if(active!==s||!historyDialog.open)return;const preview=el('pre','','mother-history-preview');preview.textContent=plain(version.content);const restore=el('button',tr('恢复这版','Restore revision'));preview.append(restore);row.after(preview);b.disabled=true;restore.onclick=async()=>{if(active!==s||!await sync(s)||s.dirty||active!==s)return;if(!confirm(tr('恢复这版文档？当前内容仍保留在历史。','Restore this revision? Current content remains in history.')))return;try{const restored=await api({action:'restore',id:s.id,revision:h.revision,expectedRevision:s.revision});if(active!==s)return;Y.applyUpdate(s.doc,transport.decode(restored.update),'remote');s.revision=restored.revision;state(tr('已恢复','Restored'));restore.disabled=true;}catch(e){state(e.message,true);}};}catch(e){state(e.message,true);}};list.append(row);}if(!result.history.length)list.append(el('p',tr('开始编辑后会保留历史','Edit the document to create history')));}catch(e){list.append(el('p',e.message));}};
function plain(n){if(n.type==='meetingGraph')return n.attrs.graph.nodes.map(x=>x.label+(x.detail?' — '+x.detail:'')).join('\n')+'\n'+n.attrs.graph.edges.map(x=>x.from+' → '+x.to+(x.label?' — '+x.label:'')).join('\n');return n.type==='image'?'[Image: '+(n.attrs?.alt||'')+']':n.text||(n.content||[]).map(plain).join(n.type==='tableRow'?' | ':'\n');}
async function dataChanged(detail){
 if(!detail?.id)return;lang=detail.lang;labels();const changed=meetingId!==detail.id;if(changed&&active&&!await closeDoc())return;meetingId=detail.id;board={...detail.data,preparedEventId:detail.preparedEventId||''};
 if(changed){clearTimeout(collectionNoticeTimer);collectionBar.hidden=true;menuUndoCollected.hidden=true;if(historyDialog.open)historyDialog.close();options.open=false;requestEpoch++;revertAI.hidden=true;appliedAI=null;lastDataKey='';const linked=board.source?.motherDocumentId||localStorage.getItem('tht-mother:'+meetingId),destination=documentLinks.target(parent.location.href,meetingId,linked);if(destination.mismatch){title.textContent='';host.hidden=toolbar.hidden=history.hidden=start.hidden=true;root.classList.add('mother-open');state(tr('这份方案已不在本场关联中。请选择正确方案。','This solution is no longer linked to this meeting. Select the correct solution.'),true);}else if(destination.id)await openDoc(destination.id);else{title.textContent='';host.hidden=toolbar.hidden=history.hidden=true;start.hidden=false;root.classList.remove('mother-open');startTitle.value=board.source?.title||board.session?.title||'';if(board.source&&Number.isFinite(board.source.revision))await create(false);}await catalog();}
 const dataKey=JSON.stringify([meetingId,board.source?.revision,board.source?.motherDocumentId]);if(dataKey!==lastDataKey){lastDataKey=dataKey;await importDrafts();}
}
let dataQueue=Promise.resolve();window.addEventListener('tht-board-data',e=>{dataQueue=dataQueue.catch(()=>{}).then(()=>dataChanged(e.detail)).catch(e=>state(e.message,true));});
window.addEventListener('tht-board-language',e=>{lang=e.detail.lang;labels();refreshCollectionLanguage();});
window.addEventListener('online',()=>sync());
window.addEventListener('beforeunload',e=>{if(active&&(active.localError||!active.localSaved)){e.preventDefault();e.returnValue='';}});
setInterval(()=>sync(),5000);labels();start.hidden=host.hidden=toolbar.hidden=history.hidden=true;state(tr('正在打开方案…','Opening solution…'));
if(parent===window&&!window.__thtMyAgent){const css=el('link');css.rel='stylesheet';css.href='my-agent.css';document.head.append(css);const script=el('script');script.src='my-agent.js';document.body.append(script);}

// Document editing uses the same chat composer and model as the meeting.
let requestEpoch=0;
const revertAI=el('button');revertAI.hidden=true;toolbar.append(revertAI);let appliedAI=null;
function undoLabel(){revertAI.textContent=tr('撤销 AI 修改','Undo AI edit');}
undoLabel();window.addEventListener('tht-board-language',undoLabel);
revertAI.onclick=async()=>{const s=active;if(!s||!appliedAI||appliedAI.id!==s.id)return;revertAI.disabled=true;try{if(!await sync(s)||s.dirty||s!==active)return;const undo=appliedAI;const restored=await api({action:'restore',id:s.id,revision:undo.before,expectedRevision:undo.after});if(s!==active)return;Y.applyUpdate(s.doc,transport.decode(restored.update),'remote');s.revision=restored.revision;await persist(s);revertAI.hidden=true;appliedAI=null;state(tr('已撤销 AI 修改','AI edit reverted'));}catch(e){s.actionError=e.status===409?tr('文档已有后续修改，已保留你的内容；请从版本历史查看旧稿。','Later edits preserved. View the earlier draft in version history.'):e.message;displayStatus(s);}finally{revertAI.disabled=false;}};
window.thtApplyDocumentEdit=async edit=>{
 const s=active,epoch=requestEpoch;if(!s||s.id!==edit.id)throw Error(tr('请先打开这份文档，再采用修改','Open this document before applying the edit'));
 if(!await sync(s)||s.dirty||s!==active||epoch!==requestEpoch)throw Error(tr('文档尚未保存或已切换，未采用修改','Document is unsaved or changed; edit not applied'));
 const before=s.revision,result=await api({action:'apply',id:s.id,token:edit.token});
 if(s!==active||epoch!==requestEpoch)return result;
 s.actionError=null;appliedAI={id:s.id,before,after:result.revision};revertAI.hidden=false;
 Y.applyUpdate(s.doc,transport.decode(result.update),'remote');s.revision=result.revision;await persist(s);state(tr('已放入文档 · 可直接修改或撤销','Added to document · Edit or undo'));return result;
};
// Explicit saved modules use a durable server receipt, shared with automatic draft imports.
const collectionBar=el('div','','mother-collection'),collectionStatus=el('span');collectionStatus.setAttribute('role','status');
const viewCollected=el('button',tr('查看','View')),menuUndoCollected=el('button',tr('撤销最近加入','Undo latest addition'));viewCollected.type=menuUndoCollected.type='button';viewCollected.hidden=menuUndoCollected.hidden=true;optionsPanel.append(menuUndoCollected);
const undoCollected=el('button',tr('撤销加入','Undo collection'));undoCollected.type='button';undoCollected.hidden=true;collectionBar.hidden=true;collectionBar.append(collectionStatus,viewCollected,undoCollected);host.before(collectionBar);
let collectionNoticeTimer;
function collectionState(text,error=false){clearTimeout(collectionNoticeTimer);viewCollected.hidden=true;collectionBar.hidden=false;collectionStatus.textContent=text;collectionBar.classList.toggle('error',error);}
let collectedSelection=null;
const revisionSuggestions=el('section','','mother-revision-suggestions');revisionSuggestions.hidden=true;collectionBar.after(revisionSuggestions);
const collection=require('./document-collection')({session:()=>active,meeting:()=>meetingId,source:()=>board.source,sync,api,
 refresh:async s=>{const saved=await api(null,{id:s.id});if(s.closed)return;Y.applyUpdate(s.doc,transport.decode(saved.update),'remote');s.revision=Math.max(s.revision,saved.revision);s.collections=saved.collections||[];if(!await persist(s))throw Error(tr('服务端已保存，本机缓存未完成；请重试','Saved on server; local cache incomplete. Retry'));},
 locate:(s,blockId)=>{let found=false;s.editor.state.doc.forEach((node,pos)=>{if(node.attrs.blockId===blockId){s.editor.commands.setTextSelection(pos+1);found=true;}});if(found)s.editor.commands.focus();}
});
const retryOrganization=el('button',tr('重试整理','Retry organization')),clarification=el('input');
retryOrganization.type='button';retryOrganization.hidden=true;clarification.hidden=true;clarification.maxLength=1000;clarification.setAttribute('aria-label',tr('补充整理方向','Clarify organization'));collectionBar.append(clarification,retryOrganization);
function organizationFailure(message=''){
 if(message.startsWith('Evidence check found unsupported assertions'))return tr('草稿中有内容尚未获得来源支持，暂未加入。原文和人工修改已保留；可查看草稿与来源，补充意见后重试。','Some draft claims are not supported by the sources and have not been added. Original content and your edits are preserved; review the draft and sources, then retry with feedback.');
 if(message.startsWith('Chapter increments repeat existing paragraphs or containers.'))return tr('生成内容与文档已有段落或表格重复，本次未加入；原始图文已保存，可重试整理。','Generated content repeats existing paragraphs or tables and was not added. Original material is saved; retry organization.');
 return message?tr('原始图文已保存；整理失败：','Original material saved; organization failed: ')+message:tr('原始图文已加入 · 整理未完成，可重试','Original material saved · Organization incomplete; retry');
}
function showRevisionSuggestions(selected,receipt){
 revisionSuggestions.replaceChildren();revisionSuggestions.hidden=true;
 const epoch=requestEpoch,s=active;if(!s||s.id!==selected.id)return;
 const entries=(s.collections||[]).map(c=>c.key===selected.meetingId+':'+selected.moduleId&&receipt?{...c,...receipt}:c);
 if(receipt&&!entries.some(c=>c.key===selected.meetingId+':'+selected.moduleId))entries.push({...receipt,key:selected.meetingId+':'+selected.moduleId});
 for(const owner of entries.filter(c=>!c.undone&&c.organization?.state==='failed'&&c.organization?.evidenceDraft?.length)){
  revisionSuggestions.hidden=false;
  const detail=el('details','','mother-held-draft'),summary=el('summary',tr('草稿尚未加入 · 查看内容与来源','Draft not added · Review content and sources'));
  detail.append(summary,el('p',tr('原文和人工修改已保留。你可以补充意见后重新整理；新草稿仍会核对来源。','Original material and your edits are preserved. Add feedback and retry; the new draft will be checked against its sources.')));
  for(const issue of owner.organization.evidenceIssues||owner.organization.evidenceCheck?.issues||[]){detail.append(el('blockquote',issue.quote),el('p',issue.why));}
  for(const section of owner.organization.evidenceDraft){
   if(section.title)detail.append(el('h3',section.title));
   const preview=el('div','','mother-revision-preview');
   try{preview.append(DOMSerializer.fromSchema(format.schema).serializeFragment(format.schema.nodeFromJSON({type:'doc',content:section.blocks}).content,{document}));}catch{preview.append(el('p',tr('预览不可用；原草稿仍已保存','Preview unavailable; the draft remains saved')));}
   detail.append(preview);
   for(const source of section.evidence||[])detail.append(el('blockquote',source.quote),el('small',(source.meetingId||'')+' · '+(source.segId||'')));
  }
  revisionSuggestions.append(detail);
 }
 for(const owner of entries.filter(c=>!c.undone))for(const proposal of owner.organization?.proposals||[]){
  if(!['pending','accepted'].includes(proposal.state))continue;revisionSuggestions.hidden=false;
  const accepted=proposal.state==='accepted';
  const detail=el('details','','mother-revision-suggestion'),summary=el('summary',accepted?tr('已采用 AI 更新 · 查看或撤销','AI update accepted · Review or undo'):tr('保留了你的修改 · 查看 AI 更新建议','Your edits preserved · Review AI suggestion'));
  detail.append(summary);
  for(const [label,node] of [[tr('提出建议时的原文','Original when suggested'),proposal.before],[tr('建议修改','Suggested revision'),proposal.after]]){
   const preview=el('div','','mother-revision-preview');preview.append(el('strong',label));
   if(node)try{preview.append(DOMSerializer.fromSchema(format.schema).serializeFragment(format.schema.nodeFromJSON({type:'doc',content:[node]}).content,{document}));}catch{preview.append(el('p',tr('预览不可用，原文已保留','Preview unavailable; original preserved')));}
   else preview.append(el('p',tr('原段落已移除，不会自动恢复','Original block removed; it will not be restored automatically')));
   detail.append(preview);
  }
  const controls=el('div','','mother-revision-controls'),accept=el('button',accepted?tr('撤销这处修改','Undo this revision'):tr('采用这处修改','Accept this revision')),reject=el('button',tr('保留原文','Keep original'));
  accept.type=reject.type='button';accept.disabled=!proposal.before;reject.hidden=accepted;controls.append(accept,reject);detail.append(controls);
  const resolve=async decision=>{accept.disabled=reject.disabled=true;try{const delimiter=owner.key.indexOf(':'),result=await collection.resolve(owner.key.slice(delimiter+1),proposal.id,decision,{...owner,collectionMeetingId:owner.key.slice(0,delimiter)});if(s!==active||epoch!==requestEpoch||meetingId!==selected.meetingId)return;if(collectedSelection===selected&&owner.key===selected.meetingId+':'+selected.moduleId){showCollection(selected,result);if(decision==='reject'&&!(s.collections||[]).some(c=>!c.undone&&c.organization?.proposals?.some(p=>p.state==='pending')))collectionStatus.textContent=tr('已保留原文','Original preserved');}else{const current=(s.collections||[]).find(c=>c.key===selected.meetingId+':'+selected.moduleId);if(collectedSelection===selected&&current)showCollection(selected,current);else{showRevisionSuggestions(selected,null);if(!(s.collections||[]).some(c=>!c.undone&&c.organization?.proposals?.some(p=>p.state==='pending')))collectionState(tr('已保留原文','Original preserved'));}}}catch(e){if(s===active&&epoch===requestEpoch&&meetingId===selected.meetingId){collectionState(e.status===409?tr('内容已有新修改，已保留；可保留原文，再选中该段通过 @AI 提出修改。','Content changed; edits preserved. Keep original, then select the block and ask @AI for a new revision.'):e.message,true);reject.disabled=false;accept.disabled=!proposal.before;}}};
  accept.onclick=()=>void resolve(accepted?'undo':'accept');reject.onclick=()=>void resolve('reject');revisionSuggestions.append(detail);
 }
}
function showCollection(selected,receipt,notify=true){
 if(collectedSelection!==selected||active?.id!==selected.id||meetingId!==selected.meetingId)return;
 selected.receipt=receipt;showRevisionSuggestions(selected,receipt);if(notify)(parent!==window?parent:window).thtCollectionChanged?.({...selected,receipt});const org=receipt.organization;menuUndoCollected.hidden=receipt.undone;menuUndoCollected.textContent=tr('撤销最近加入','Undo latest addition');undoCollected.textContent=tr('撤销加入','Undo collection');undoCollected.hidden=receipt.undone;retryOrganization.hidden=receipt.undone||org?.state==='done'||org?.state==='pending';clarification.hidden=receipt.undone||org?.state!=='clarify';
 const held=org?.state==='failed'&&org?.evidenceDraft?.length;
 if(held)clarification.hidden=!!receipt.undone;
 clarification.placeholder=held?tr('给这份草稿补充修改意见…','Add feedback for this draft…'):tr('补充整理方向…','Clarify organization…');
 retryOrganization.textContent=held?tr('带意见重新整理','Retry with feedback'):org?.state==='clarify'?tr('继续整理','Continue organization'):tr('重试整理','Retry organization');
 collectionState(receipt.undone?tr('这次加入已撤销','This collection was undone'):org?.state==='done'&&(org.proposals?.some(p=>p.state==='pending')||(active?.collections||[]).some(c=>!c.undone&&c.organization?.proposals?.some(p=>p.state==='pending')))?tr('已保留你的修改 · 下方有待审阅的局部建议','Your edits preserved · Local suggestions below'):org?.state==='done'?tr('已加入','Added'):org?.state==='pending'?tr('原始图文已加入 · 正在整理章节','Original material saved · Organizing chapters'):org?.state==='clarify'?org.question:organizationFailure(org?.error),org?.state==='failed');
 const needsReview=(active?.collections||[]).some(c=>!c.undone&&c.organization?.proposals?.some(p=>p.state==='pending'))||org?.proposals?.some(p=>p.state==='pending');
 if(!receipt.undone&&org?.state==='done'&&!needsReview){viewCollected.hidden=false;const dismiss=()=>{if(collectedSelection!==selected||active?.id!==selected.id)return;if(collectionBar.matches(':hover')||collectionBar.contains(document.activeElement)){collectionNoticeTimer=setTimeout(dismiss,3000);return;}collectionBar.hidden=true;};collectionNoticeTimer=setTimeout(dismiss,10000);}
}
// Refresh interface text only; language changes must never apply or persist document edits.
function refreshCollectionLanguage(){
 viewCollected.textContent=tr('查看','View');menuUndoCollected.textContent=tr('撤销最近加入','Undo latest addition');undoCollected.textContent=tr('撤销加入','Undo collection');clarification.setAttribute('aria-label',tr('补充整理方向','Clarify organization'));
 const selected=collectedSelection;if(!selected||!selected.receipt||active?.id!==selected.id||meetingId!==selected.meetingId)return;
 const hidden=collectionBar.hidden,expanded=[...revisionSuggestions.children].map(node=>node.open),focused=[...revisionSuggestions.querySelectorAll('summary, button')].indexOf(document.activeElement);
 showCollection(selected,selected.receipt,false);collectionBar.hidden=hidden;
 [...revisionSuggestions.children].forEach((node,index)=>{node.open=!!expanded[index];});
 if(focused>=0)revisionSuggestions.querySelectorAll('summary, button')[focused]?.focus();
}
function restoreCollection(s){
 for(const receipt of s.collections||[]){const prefix=meetingId+':';if(receipt.key.startsWith(prefix))(parent!==window?parent:window).thtCollectionChanged?.({meetingId,moduleId:receipt.key.slice(prefix.length),receipt});}
 revisionSuggestions.hidden=true;revisionSuggestions.replaceChildren();showRevisionSuggestions({id:s.id,meetingId},null);
 const receipt=(s.collections||[]).filter(c=>c.key.startsWith(meetingId+':')&&!c.undone).at(-1);if(!receipt)return;
 const selected={id:s.id,meetingId,moduleId:receipt.key.slice(meetingId.length+1),receipt};collectedSelection=selected;
 // A pending operation may have survived an application restart; allow explicit recovery.
 showCollection(selected,receipt);if(receipt.organization?.state==='pending'){retryOrganization.hidden=false;collectionState(tr('原始图文已保存 · 可重试未完成的整理','Original material saved · Retry unfinished organization'));}
}
async function organizeCollected(selected,question=''){
 if(collectedSelection!==selected||selected.receipt?.undone)return;
 showCollection(selected,{...selected.receipt,organization:{state:'pending'}});
 try{const result=await collection.organize(selected.moduleId,{lang,question});showCollection(selected,result);}
 catch(e){if(collectedSelection===selected&&!selected.receipt?.undone){showCollection(selected,{...selected.receipt,organization:{state:'failed',error:e.message}});}}
}
viewCollected.onclick=()=>{const selected=collectedSelection,s=active;if(!selected||!s||s.id!==selected.id||meetingId!==selected.meetingId)return;const id=selected.receipt.organization?.inserted?.[0]?.id||selected.receipt.blockId;let found=false;s.editor.state.doc.forEach((node,pos)=>{if(node.attrs.blockId===id){s.editor.commands.setTextSelection(pos+1);found=true;}});if(found)s.editor.commands.focus();else collectionState(tr('内容位置已变化，请从版本历史查看','Content has moved; check version history'),true);};
menuUndoCollected.onclick=()=>{options.open=false;undoCollected.click();};
retryOrganization.onclick=()=>{if(collectedSelection)void organizeCollected(collectedSelection,clarification.value);};
window.thtSolutionChapters=()=>{if(!active)return [];let selected='';active.editor.state.doc.forEach((node,pos)=>{if(active.editor.state.selection.from>1&&pos<=active.editor.state.selection.from&&node.type.name==='heading')selected=node.attrs.blockId;});return active.editor.getJSON().content.filter(n=>n.type==='heading'&&n.attrs?.blockId).map(n=>({id:n.attrs.blockId,title:(n.content||[]).map(t=>t.text||'').join(''),selected:n.attrs.blockId===selected}));};
window.thtMeetingCollection=item=>{
 if(!active||item?.meetingId!==meetingId)return undefined;
 return (active.collections||[]).find(c=>c.key===item.meetingId+':'+item.moduleId)||null;
};
window.thtCollectMeetingModule=async item=>{
 if(!active||item?.meetingId!==meetingId)throw Error(tr('请先打开对应的方案文档','Open the matching solution document first'));
 const id=active.id,result=await collection.collect(item.moduleId,item.chatSelection,item.chapterId,item.artifactSelection,item.candidateSelection);
 if(active?.id===id&&meetingId===item.meetingId){const selected={id,meetingId,moduleId:item.moduleId,receipt:result};collectedSelection=selected;clarification.value='';showCollection(selected,result);if(!result.undone&&result.organization?.state!=='done')void organizeCollected(selected);return selected.receipt;}
 return result;
};
undoCollected.onclick=async()=>{const selected=collectedSelection;if(!selected||active?.id!==selected.id||meetingId!==selected.meetingId){undoCollected.hidden=true;return;}undoCollected.disabled=true;try{const receipt=await collection.undo(selected.moduleId);selected.receipt=receipt;if(collectedSelection===selected&&active?.id===selected.id&&meetingId===selected.meetingId){undoCollected.hidden=true;menuUndoCollected.hidden=true;retryOrganization.hidden=true;clarification.hidden=true;(parent!==window?parent:window).thtCollectionUndone?.(selected);collectionState(tr('已撤销加入，保留其他修改','Collection undone; other edits preserved'));}}catch(e){collectionState(e.message==='Selected content has later edits. Your changes are preserved.'?tr('这段内容已有后续修改，已保留你的编辑；未执行撤销。','This content has later edits. Your changes are preserved; undo was not applied.'):e.message,true);}finally{undoCollected.disabled=false;}};
// An explicit insight action creates its own draft block, never replaces the user's selection.
window.thtDraftMeetingItem=item=>{
 // Parent-frame arrays have a different constructor; Yjs cannot encode them.
 // Materialize all bridge data in the editor realm before a CRDT transaction.
 try{item=JSON.parse(JSON.stringify(item));}catch{return false;}
 if(!active||item?.meetingId!==meetingId)return false;
 const text=String(item.text||'').trim();if(!text||text.length>12000)return false;
 const editor=active.editor,candidateId=String(item.candidateId||item.objectId||'').slice(0,1000);
 const existing=candidateId&&editor.state.doc.content.content.find(n=>n.attrs.candidateId===candidateId&&n.attrs.sourceRef?.startsWith(meetingId+':'));
 if(existing){let at=0;for(const node of editor.state.doc.content.content){if(node===existing)break;at+=node.nodeSize;}editor.commands.setTextSelection(at+1);if(item.mode==='place')editor.commands.focus();else ask([existing.attrs.blockId],text);return true;}
 const id='b-'+crypto.randomUUID(),end=editor.state.doc.content.size;
 const sourceRefs=[...new Set((item.sourceRefs||[]).filter(r=>typeof r==='string'&&r.length<=1000))];
 if(sourceRefs.length>format.MAX_SOURCE_REFS)return false;
 const attrs={blockId:id,draft:'AI draft',sourceRef:(item.objectId||candidateId)?meetingId+':'+(item.objectId||candidateId):null,candidateId:candidateId||null,sourceRefs};
 let graph=null;if(item.graph){try{graph=require('../meeting-graph').normalize(item.graph.nodes,item.graph.edges);}catch{return false;}}
 const draftContent=format.fromMarkdown(text).content;
 if(graph)draftContent.push({type:'meetingGraph',attrs:{graph}});
 editor.commands.insertContentAt(end,item.mode==='place'?{type:'blockquote',attrs,content:draftContent}:{type:'paragraph',attrs});
 editor.commands.setTextSelection(end+1);if(item.mode==='place')editor.commands.focus();else ask([id],text);return true;
};
window.addEventListener('message',e=>{if(e.origin===location.origin&&e.source===parent&&e.data?.type==='tht-document-draft')window.thtDraftMeetingItem(e.data.item);});

// Feedback is part of the same CRDT block; it survives reopen and never sends externally.
const feedback=el('details','','mother-block-feedback'),feedbackTitle=el('summary'),comments=el('div'),commentInput=el('input'),addComment=el('button'),accepted=el('button'),revise=el('button');
feedback.hidden=true;commentInput.maxLength=800;feedback.append(feedbackTitle,comments,commentInput,addComment,accepted,revise);toolbar.after(feedback);
let inspected=null,feedbackKey='';
// Unsubmitted feedback belongs to a document and block, even while browsing elsewhere.
const feedbackDrafts=new Map();
commentInput.oninput=()=>{if(feedbackKey){if(commentInput.value)feedbackDrafts.set(feedbackKey,commentInput.value);else feedbackDrafts.delete(feedbackKey);}};
function inspectBlock(){
 inspected=null;
 if(active?.editor){const cursor=active.editor.state.selection.from;
 active.editor.state.doc.forEach((node,pos)=>{if(pos<=cursor&&pos+node.nodeSize>cursor&&/^AI (draft|accepted)$/.test(node.attrs.draft||''))inspected={id:node.attrs.blockId,pos,node};});}
 const nextKey=inspected?JSON.stringify([active.id,inspected.id]):'';
 if(nextKey!==feedbackKey){commentInput.oninput();feedbackKey=nextKey;commentInput.value=feedbackDrafts.get(nextKey)||'';feedback.open=false;}
 feedback.hidden=!inspected;if(!inspected)return;
 feedbackTitle.textContent=tr('AI 内容 · 可直接编辑','AI content · Edit directly');commentInput.placeholder=tr('给这一块留修改意见…','Leave feedback on this block…');addComment.textContent=tr('评论','Comment');accepted.textContent=tr('标记已审阅','Mark reviewed');revise.textContent=tr('让 AI 修改这一块','Revise this block with AI');
 comments.replaceChildren();for(const line of (inspected.node.attrs.aiComments||'').split('\n').filter(Boolean))comments.append(el('p',line));
}
function patchInspected(attrs){if(!inspected||!active)return;const node=active.editor.state.doc.nodeAt(inspected.pos);if(node?.attrs.blockId!==inspected.id)return;active.editor.view.dispatch(active.editor.state.tr.setNodeMarkup(inspected.pos,undefined,{...node.attrs,...attrs}));inspectBlock();}
addComment.onclick=()=>{inspectBlock();const message=commentInput.value.trim();if(!message||!inspected)return;const old=inspected.node.attrs.aiComments||'';if(old.length+message.length+1>4000){state(tr('评论已满，请在文档中继续补充','Comment limit reached; continue in the document'),true);return;}patchInspected({aiComments:(old?old+'\n':'')+message});commentInput.value='';feedbackDrafts.delete(feedbackKey);};
commentInput.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();addComment.click();}};
accepted.onclick=()=>patchInspected({draft:'AI accepted'});
revise.onclick=()=>{if(!inspected||!active)return;const id=inspected.id,notes=inspected.node.attrs.aiComments||plain(inspected.node);ask([id],notes);};
window.addEventListener('tht-board-language',inspectBlock);

// Local previews only: hovering never sends an external request or changes the document.
const hoverPreview=el('aside','','mother-hover-preview');hoverPreview.hidden=true;hoverPreview.setAttribute('role','tooltip');document.body.append(hoverPreview);
function hidePreview(){hoverPreview.hidden=true;hoverPreview.replaceChildren();}
function showPreview(target){
 const image=target.closest?.('.mother-editor img'),link=target.closest?.('.mother-editor a');if(!image&&!link){hidePreview();return;}
 hoverPreview.replaceChildren();
 if(image&&/^data:image\/(png|jpeg|gif|webp);base64,/i.test(image.getAttribute('src')||'')){const p=el('img');p.src=image.getAttribute('src');p.alt=image.alt||'';hoverPreview.append(p);if(image.alt)hoverPreview.append(el('p',image.alt));}
 else if(link){let u;try{u=new URL(link.href);}catch{hidePreview();return;}if(!['https:','http:','mailto:'].includes(u.protocol)||u.username||u.password){hidePreview();return;}hoverPreview.append(el('strong',link.textContent||u.hostname),el('p',u.hostname||u.pathname),el('small',tr('链接 · 点击打开','Link · Click to open')));}
 else{hidePreview();return;}
 const r=target.getBoundingClientRect();hoverPreview.hidden=false;hoverPreview.style.left=Math.max(8,Math.min(r.left,window.innerWidth-340))+'px';hoverPreview.style.top=Math.max(8,Math.min(r.bottom+8,window.innerHeight-hoverPreview.offsetHeight-12))+'px';
}
host.addEventListener('pointerover',e=>showPreview(e.target));host.addEventListener('pointerout',e=>{if(!e.relatedTarget||!host.contains(e.relatedTarget))hidePreview();});host.addEventListener('focusin',e=>showPreview(e.target));host.addEventListener('focusout',hidePreview);window.addEventListener('scroll',hidePreview,true);window.addEventListener('resize',hidePreview);window.addEventListener('keydown',e=>{if(e.key==='Escape')hidePreview();});
