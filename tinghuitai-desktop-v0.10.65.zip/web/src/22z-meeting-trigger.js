  // Explicit, local-only binding. Opening settings never starts or stops capture.
  {
    const host=document.querySelector('#adv');
    if(host){
      const box=document.createElement('section');box.id='meeting-button-settings';box.className='field';box.style.cssText='border-top:1px solid var(--line,#ddd);margin-top:16px;padding-top:16px';
      box.innerHTML='<h3></h3><p class="hint" data-button-target></p><label><span data-button-label></span><input data-button-device value="local-button" maxlength="80" autocomplete="off" spellcheck="false"></label><div class="row" style="margin-top:10px"><button type="button" class="btn" data-button-bind></button><button type="button" class="btn" data-button-revoke hidden></button></div><p class="hint" data-button-status role="status" aria-live="polite"></p><p class="hint" data-button-help></p>';
      host.append(box);
      const q=s=>box.querySelector(s),bind=q('[data-button-bind]'),revoke=q('[data-button-revoke]'),device=q('[data-button-device]'),message=q('[data-button-status]');
      let pending=false,binding=null,editable=false;
      const text=(zh,en)=>ui==='en'?en:zh;
      const errorText=e=>({native_owner_unknown:text('请在桌面 App 中设置录音按钮。','Configure the recording button in the desktop app.'),trigger_rebind_required:text('原绑定所属窗口已退出，请重新绑定当前话题。','The original window has closed. Bind this topic again.'),trigger_command_pending:text('按钮指令正在处理，完成后请重试。','A button command is pending. Retry when it finishes.'),trigger_other_meeting_active:text('另一场会议正在录音，请结束后再绑定。','Another meeting is recording. Finish it before binding.'),trigger_capture_owner_changed:text('当前录音由另一窗口控制，请回到原窗口。','The recording belongs to another window. Return to it.'),trigger_explicit_binding_required:text('按钮名称仅支持字母、数字、下划线和短横线。','Use letters, numbers, underscores or hyphens for the button name.')})[e.message]||e.message;
      function render(){
        q('h3').textContent=text('录音按钮','Recording button');q('[data-button-label]').textContent=text('本机按钮名称','Local button name');
        q('[data-button-target]').textContent=cur?.id?text('当前话题：','Current topic: ')+(cur.title||text('未命名会议','Untitled meeting')):text('先打开要绑定的会议话题，再设置按钮。','Open the meeting topic you want to bind first.');
        bind.textContent=text('绑定当前话题','Bind current topic');revoke.textContent=text('解除绑定','Remove binding');
        bind.disabled=pending||!editable||!cur?.id;revoke.hidden=!binding?.bound;revoke.disabled=pending;device.disabled=pending||!editable;
        q('[data-button-help]').textContent=text('绑定立即生效，不会开始录音。已配置的本机按钮只控制所绑定的话题；切换页面不会更换绑定。解除绑定不会停止正在进行的录音。','Binding takes effect immediately and does not start recording. A configured local button controls only its bound topic; navigation does not change the binding. Removing a binding does not stop a recording.');
      }
      async function refresh(){
        if(pending)return;editable=false;binding=null;render();message.textContent=text('正在读取按钮设置…','Loading button settings…');
        try{binding=await nativeRequest('trigger-status');editable=true;if(binding.bound)device.value=binding.deviceId;message.textContent=binding.bound?text('已绑定话题：','Bound topic: ')+(binding.title||binding.sessionId):text('尚未绑定。','No topic is bound.');}
        catch(e){editable=e.message==='trigger_rebind_required';message.textContent=errorText(e);}render();
      }
      bind.onclick=async()=>{
        if(pending||!cur?.id)return;
        const id=cur.id,name=device.value.trim();if(!/^[-\w]{1,80}$/.test(name)){message.textContent=errorText({message:'trigger_explicit_binding_required'});return;}
        pending=true;render();message.textContent=text('正在绑定…','Binding…');
        try{
          // Prepare the exact existing topic, including a continuation proof when needed; never start capture here.
          const r=await fetch(relayBase()+'/meeting-board?token='+encodeURIComponent(cfg.relayToken||window.THT_BOOT?.relayToken||''),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'start-context',sessionId:id,uiLang:ui}),signal:AbortSignal.timeout(10000)}),out=await r.json();
          if(!r.ok)throw Error(out.error||'Could not read meeting context');if(out.prepared?.sessionId!==id)throw Error(text('话题已变化，请重新打开设置。','The topic changed. Reopen settings.'));
          const result=await nativeRequest('trigger-bind',{sessionId:id,deviceId:name,continuationToken:out.prepared.continuationToken,uiLang:ui});binding={...result,bound:true,deviceId:name};message.textContent=text('绑定已生效，当前录音状态未改变。','Binding saved. The recording state is unchanged.');
        }catch(e){message.textContent=errorText(e);}finally{pending=false;render();}
      };
      revoke.onclick=async()=>{if(pending)return;pending=true;render();try{await nativeRequest('trigger-revoke',{});binding=null;message.textContent=text('已解除绑定，当前录音不受影响。','Binding removed. Any ongoing recording is unchanged.');}catch(e){message.textContent=errorText(e);}finally{pending=false;render();}};
      new MutationObserver(()=>{if(dlg.open)refresh();}).observe(dlg,{attributes:true,attributeFilter:['open']});
      render();
    }
  }
