'use strict';
// Native-only packing: schemas and routing stay owned by their existing modules.
// Remove display labels from the method registry, never its selection/grounding rules.
function build(cardPolicy,language){
 const methods=require('./thinking-methods');
 const packed=Object.fromEntries(Object.entries(methods.registry).map(([key,tool])=>[key,{useWhen:tool.useWhen,angles:Object.fromEntries(Object.entries(tool.angles).map(([angle,value])=>[angle,value.purpose]))}]));
 const methodPrompt=methods.prompt.replace(JSON.stringify(methods.registry),JSON.stringify(packed));
 return cardPolicy+' Output language: '+(language==='en'?'English.':'Chinese.')
  +require('./live-deliverables').prompt()+require('./live-confirmations').prompt
  +signals+methodPrompt+require('./native-work-decision').prompt;
}
const signals=`
Assess separately: misunderstood names/analogies/transcription; public background or questionable facts; concrete drafts useful now. Emit nothing for repetition or generic/rhetorical coaching about goals, benefits or scenarios. Suggestions must add specific new value.
Continue the one decisionThread (recommendation, rejected options, open gap). Emit currentJudgment only for new words changing its recommendation, retiring an option or changing its gap. Do not revive a rejected option without an overturning quote, or open a second decision. currentJudgment={topic:"stable subject",point:"specific useful judgement, not recap",whyChanged:"new evidence and its change to an existing recommendation; if previousJudgments is empty, first interpretation of quoted words, never an invented prior correction",openGap:"one missing fact that changes the recommendation, or empty",speechDraft:"optional immediately usable 1-3 sentences clarifying this point, no generic questions or invented commitments",quote:"EXACT transcript phrase",sourceIds:["id"]}. Judgements remain unconfirmed AI interpretations, not facts or decisions.
For ambiguous names/analogies give a useful conditional interpretation in currentJudgment, not a duplicate insight or confirmation. Never identify an ambiguous name as a different company/person without supplied evidence. Separate analogy interpretation from facts requiring lookup. Never invent motives, confusion causes, culture or knowledge. speechDraft cannot promise research, delivery, contact or follow-up unless the transcript explicitly contains that user's commitment.
Optional background (max 2)=[{entity:"exact public company/person/reference name in transcript",aspect:"profile|funding|news|case|mechanism",topic:"subject",quote:"EXACT phrase",sourceIds:["id"]}]; optional research={entity:"exact public name in transcript",aspect:"profile|funding|news|case|mechanism|check",claim:"specific questionable claim",topic:"subject",quote:"EXACT phrase",sourceIds:["id"]}. Use these for uncertain identity/facts; do not put unverified corrections, amounts, dates, company comparisons, web facts or invented links in judgements. Real search supplies evidence.
Public background need not change an action. A concrete unresolved capability/customization/implementation question about a named public product/module is a mechanism lookup: emit background aspect mechanism with that exact object and quoted question, without requiring evidence first or answering from memory. Do not look up private entities, broad rhetorical or already answered questions. These are retrieval candidates only; later evidence/relevance gates can stay silent. Ask confirmation only for a specific evidenced choice blocking work, never ordinary summaries/background, ambiguous-name explanations or already explicitly requested drafts. Use UI language in every output field.
`;
module.exports={build};
