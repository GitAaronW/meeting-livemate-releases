'use strict';
const crypto=require('crypto');
const {bucketOf,BUCKETS}=require('./work-hub');
const seeds=[];
const hash=s=>crypto.createHash('sha256').update(String(s)).digest('hex').slice(0,20);
const now=()=>new Date().toISOString();
const normalize=s=>String(s||'').normalize('NFKC').toLowerCase().replace(/[\s\p{P}\p{S}]/gu,'');
const branches=[['operations','工作',''],['meeting','会议','operations'],['coordination','待办与协作','operations'],['library','资料',''],['unfiled','待归类','']];
function topic(text,fallback='unfiled'){return /会议|纪要|转写|ASR/.test(text)?'meeting':fallback;}
function refine(id,text){return branches.some(b=>b[0]===id)?id:'unfiled';}
function kind(t){return /待决策|是否/.test(t.text)?'decision':'action';}
function role(s){return s.kind==='meeting'?'evidence':'reference';}

function prepare(hub){
 const d=hub.data;d.knowledgeNodes ||= branches.map(([id,title,parentId])=>({id,title,parentId,notes:'',revision:1}));d.workItems ||= [];for(const [id,title,parentId] of branches)if(!d.knowledgeNodes.some(n=>n.id===id))d.knowledgeNodes.push({id,title,parentId,notes:'',revision:1});
 const mapped=new Map();for(const w of d.workItems)for(const id of w.memberIds||[])mapped.set(id,w);
 for(const t of d.tasks){
  if(mapped.has(t.id))continue;
  const seed=seeds.find(g=>g.ids.includes(t.id));let k=seed?.key||'record:'+t.id;if(d.workItems.some(x=>x.key===k&&x.manual))k='record:'+t.id;
  let w=d.workItems.find(x=>x.key===k);
  if(!w){
   // Automatic duplicate attachment requires the same normalized text, owner and exact source set.
   w=!seed?d.workItems.find(x=>!x.manual&&x.memberIds.some(id=>{const prior=d.tasks.find(a=>a.id===id);return prior&&normalize(prior.text)===normalize(t.text)&&normalize(prior.owner)===normalize(t.owner)&&JSON.stringify([...prior.sourceIds].sort())===JSON.stringify([...t.sourceIds].sort());})):null;
   if(!w){const ty=seed?.kind||kind(t);const node=seed?.nodeId||topic(t.text,undefined||'coordination');w={id:'w-'+hash(k),key:k,title:seed?.title||t.text.split(/——|—|\n/)[0].replace(/^→[^]*?\) /,'').slice(0,160),kind:ty,nodeId:refine(node,seed?.title||t.text),parentId:'',memberIds:[],sourceIds:[],status:'proposed',owner:t.owner||'',due:t.due||'',notes:'',revision:1,created:now(),needsDecision:!!seed?.needsDecision,reason:seed?.reason|| (ty==='insight'?'模型建议，未找到明确承诺；作为研究输入保留。':'来自会议或旧台账，状态未核实。')};d.workItems.push(w);}
  }
  w.memberIds.push(t.id);w.revision++;mapped.set(t.id,w);
 }
 for(const w of d.workItems){const ts=w.memberIds.map(id=>d.tasks.find(t=>t.id===id)).filter(Boolean);if(!w.manual)w.sourceIds=[...new Set([...w.sourceIds,...ts.flatMap(t=>t.sourceIds)])];if(ts.length&&!w.manual){w.acceptanceCriteria=ts.map(t=>t.acceptanceCriteria||'').filter(Boolean).join('\n');w.completionEvidence=ts.map(t=>t.completionEvidence||'').filter(Boolean).join('\n');w.status=ts.every(t=>t.status==='verified')?'verified':ts.every(t=>['done','verified'].includes(t.status))?'done':ts.every(t=>t.status==='cancelled')?'cancelled':ts.some(t=>t.status==='submitted')?'submitted':ts.some(t=>t.status==='draft')?'draft':ts.every(t=>t.status==='dismissed')?'parked':ts.some(t=>t.status==='blocked')?'blocked':ts.some(t=>t.status==='doing')?'doing':ts.some(t=>t.status==='todo')?'todo':'proposed';}// 归类跟着成员走：有一条是「我来做」，这条工作就还留在我的默认页；全是「不是我的 / 忽略」才隐藏。
 // 每次重算都从成员重新推一遍，所以 prepare() 反复跑不会把归类丢掉；手建的没有成员，永远算我的。
 const bs=ts.map(t=>bucketOf(t));
 w.bucket=!ts.length?(BUCKETS.includes(w.bucket)?w.bucket:'mine'):bs.includes('mine')?'mine':bs.includes('candidate')?'candidate':bs.includes('notmine')?'notmine':'ignored';
 const owners=[...new Set(ts.map(t=>t.owner).filter(o=>o&&!/未指定|待定|待确认/.test(o)))];if(!w.manual&&owners.length===1)w.owner=owners[0];if(owners.length>1)w.ownerConflict=owners;else delete w.ownerConflict;}
 for(const s of d.sources){if(!s.nodeId)s.nodeId=refine(topic(s.title+' '+(s.category||''), 'library'),s.title);if(!s.knowledgeRole)s.knowledgeRole=role(s);}
 d.knowledgeVersion=1;
}
function validateParent(list,id,parentId){if(!parentId)return;if(!list.some(x=>x.id===parentId))throw Error('找不到上级');const seen=new Set([id]);let cur=parentId;while(cur){if(seen.has(cur))throw Error('不能把节点放在自己的下级');seen.add(cur);cur=list.find(x=>x.id===cur)?.parentId;}}
function update(hub,j){prepare(hub);const d=hub.data;const list=j.kind==='node'?d.knowledgeNodes:j.kind==='source'?d.sources:d.workItems;const item=list.find(x=>x.id===j.id);if(!item)throw Error('找不到记录');if(item.revision!==j.revision){const e=Error('记录已更新，请刷新后重试');e.status=409;throw e;}const p={...(j.patch||{})};
 const keys=j.kind==='node'?['title','parentId','notes']:j.kind==='source'?['materialPurpose','nodeId','topicIds','knowledgeRole','notes','relatedIds','speakerNames']:['title','nodeId','parentId','kind','status','owner','due','notes','needsDecision','sourceIds','acceptanceCriteria','completionEvidence','attentionPinned'];
 for(const [k,v] of Object.entries(p)){if(!keys.includes(k))throw Error('不支持的字段');if(k==='materialPurpose'){require('./material-purpose').validate(v);}else if(k==='speakerNames'){if(!v||typeof v!=='object'||Array.isArray(v)||Object.entries(v).some(([id,name])=>!/^\d+$/.test(id)||typeof name!=='string'||name.length>80))throw Error('姓名格式不正确');}else if(k==='topicIds'){if(!Array.isArray(v)||v.length>50||new Set(v).size!==v.length||v.some(id=>!d.knowledgeNodes.some(n=>n.id===id&&(n.projectId||'')===(item.projectId||''))))throw Error('主题必须存在且属于同一项目');}else if(k==='sourceIds'||k==='relatedIds'){if(!Array.isArray(v)||v.some(id=>!d.sources.some(s=>s.id===id)))throw Error('来源不存在');}else if(k==='needsDecision'||k==='attentionPinned'){if(typeof v!=='boolean')throw Error('Invalid flag');}else if(typeof v!=='string'||v.length>20000)throw Error('字段格式不正确');}
 if(p.title!==undefined&&p.title.length>200)throw Error('标题最多200字');if(p.owner!==undefined&&p.owner.length>80)throw Error('负责人最多80字');if(p.due&&!/^\d{4}-\d{2}-\d{2}$/.test(p.due))throw Error('日期格式应为YYYY-MM-DD');if(p.title!==undefined&&!p.title.trim())throw Error('标题不能为空');if(p.nodeId!==undefined&&!d.knowledgeNodes.some(n=>n.id===p.nodeId))throw Error('选择所属主题');if(p.kind&&!['action','decision','insight','report'].includes(p.kind))throw Error('类型不正确');if(p.status&&!require('./task-lifecycle').statuses.includes(p.status))throw Error('状态不正确');if(p.knowledgeRole&&!['master','report','evidence','reference','archive'].includes(p.knowledgeRole))throw Error('资料角色不正确');if(p.parentId!==undefined)validateParent(list,item.id,p.parentId);
 if(j.kind==='node'){
  const parent=d.knowledgeNodes.find(n=>n.id===(p.parentId??item.parentId));if(parent&&(parent.projectId||'')!==(item.projectId||''))throw Error('主题必须属于同一项目');
  if((p.title!==undefined||p.parentId!==undefined)&&d.knowledgeNodes.some(n=>n.id!==item.id&&(n.projectId||'')===(item.projectId||'')&&(n.parentId||'')===(p.parentId??item.parentId??'')&&normalize(n.title)===normalize(p.title??item.title)))throw Error('已有同名主题，请打开已有主题');
 }else if(j.kind!=='source'){
  const projectId=d.knowledgeNodes.find(n=>n.id===(p.nodeId||item.nodeId))?.projectId||'',parent=d.workItems.find(w=>w.id===(p.parentId??item.parentId));
  if(parent&&(parent.projectId||'')!==projectId)throw Error('任务必须属于同一项目');
  if(p.sourceIds!==undefined||p.nodeId!==undefined){const ids=p.sourceIds??item.sourceIds??[];if(new Set(ids).size!==ids.length||ids.some(id=>(d.sources.find(s=>s.id===id)?.projectId||'')!==projectId))throw Error('任务来源必须属于同一项目');}
  if(p.nodeId!==undefined&&(item.projectId||'')!==projectId&&d.workItems.some(w=>w.parentId===item.id))throw Error('请先移动下级任务，再切换项目');
  require('./task-lifecycle').validate(item,p);if(p.nodeId!==undefined)p.projectId=projectId;
 }

 const before={...item};Object.assign(item,p);if(j.kind==='source'&&p.speakerNames&&item.transcript)item.body=item.transcript.map(t=>`[${t.t}] ${p.speakerNames[t.speaker]||('Speaker '+(t.speaker||'?'))}: ${t.text}`).join('\n');if(Object.keys(p).some(k=>k!=='attentionPinned')){item.manual=true;item.businessUpdatedAt=now();}item.revision++;item.updated=now();hub.event('knowledge-update',item.id,JSON.stringify({before:Object.fromEntries(Object.keys(p).map(k=>[k,before[k]])),patch:p}));
 if(j.kind!=='node'&&j.kind!=='source'&&p.status&&p.status!==before.status){
  const map={draft:'draft',submitted:'submitted',verified:'verified',cancelled:'cancelled',done:'done',todo:'todo',doing:'doing',blocked:'blocked',parked:'dismissed',proposed:'inbox'};
  const members=item.memberIds.map(id=>d.tasks.find(t=>t.id===id)).filter(Boolean);
  if(p.status==='done'&&before.status!=='done')item.beforeCompletion={status:before.status,members:Object.fromEntries(members.map(t=>[t.id,t.status]))};
  if(p.status==='parked'&&before.status!=='parked')item.beforeParking={members:Object.fromEntries(members.map(t=>[t.id,{status:t.status,bucket:bucketOf(t)}]))};
  const restoring=p.status==='todo'&&before.status==='done'&&item.beforeCompletion;
  if(restoring)item.status=item.beforeCompletion.status;
  for(const t of members){
   const prior=item.beforeParking?.members?.[t.id];
   if(restoring){t.status=item.beforeCompletion.members[t.id]||'todo';}
   else if(before.status==='parked'&&p.status==='proposed'){
    t.status=prior?.status||'inbox';t.bucket=prior?.bucket||'candidate';
   }else if(before.status==='parked'&&p.status==='todo'){
    if(prior?.status==='inbox'){t.status='todo';t.bucket='mine';}
    else if(prior){t.status=prior.status;t.bucket=prior.bucket;}
    else if(t.status==='dismissed'){t.status='todo';t.bucket='mine';}
   }else if(p.status==='parked'){
    // Parking hides the aggregate candidate while preserving member tasks already
    // acted on manually (done, ignored, doing, and so on).
    if(t.status==='inbox'){t.status='dismissed';t.bucket='ignored';}
   }else if(p.status==='todo'){
    if(t.status==='inbox'){t.status='todo';t.bucket='mine';}
   }else if(p.status==='proposed'){
    if(t.status==='dismissed'){t.status='inbox';t.bucket='candidate';}
   }else{t.status=map[p.status];t.bucket='mine';}
   t.acceptanceCriteria=item.acceptanceCriteria||'';t.completionEvidence=item.completionEvidence||'';t.revision++;t.updated=now();t.businessUpdatedAt=t.updated;
  }
  if(before.status==='done')delete item.beforeCompletion;
  if(before.status==='parked'&&p.status!=='parked')delete item.beforeParking;
 }
 hub.save();return item;
}
function create(hub,j){prepare(hub);const d=hub.data;if(typeof j.title!=='string'||!j.title.trim()||j.title.length>200)throw Error('填写标题');const item={id:crypto.randomUUID(),title:j.title,notes:'',revision:1,created:now(),manual:true};if(j.kind==='node'){item.parentId=j.parentId||'';validateParent(d.knowledgeNodes,item.id,item.parentId);const parent=d.knowledgeNodes.find(n=>n.id===item.parentId);item.projectId=j.projectId||parent?.projectId||'';if(item.projectId&&!d.projects.some(p=>p.id===item.projectId))throw Error('项目不存在');if(parent&&(parent.projectId||'')!==item.projectId)throw Error('主题必须属于同一项目');if(d.knowledgeNodes.some(n=>(n.projectId||'')===item.projectId&&(n.parentId||'')===item.parentId&&normalize(n.title)===normalize(item.title)))throw Error('已有同名主题，请打开已有主题');d.knowledgeNodes.push(item);}else{if(!d.knowledgeNodes.some(x=>x.id===j.nodeId))throw Error('选择所属主题');Object.assign(item,{key:'manual:'+item.id,nodeId:j.nodeId,projectId:d.knowledgeNodes.find(n=>n.id===j.nodeId)?.projectId||'',parentId:j.parentId||'',kind:j.type||'action',status:'todo',owner:'',due:'',memberIds:[],sourceIds:[]});if(!['action','decision','insight','report'].includes(item.kind))throw Error('类型不正确');validateParent(d.workItems,item.id,item.parentId);const parent=d.workItems.find(w=>w.id===item.parentId);if(parent&&(parent.projectId||'')!==item.projectId)throw Error('任务必须属于同一项目');d.workItems.push(item);}hub.event('knowledge-create',item.id,item.title);hub.save();return item;}
function split(hub,j){const w=hub.data.workItems.find(x=>x.id===j.id);if(!w||w.revision!==j.revision)throw Error('记录已更新，请刷新');if(!w.memberIds.includes(j.memberId)||w.memberIds.length<2)throw Error('请选择集合中的原始记录');const t=hub.data.tasks.find(x=>x.id===j.memberId);if(!t)throw Error('原始记录不存在，未修改集合');w.memberIds=w.memberIds.filter(id=>id!==j.memberId);if(!w.manual)w.sourceIds=[...new Set(w.memberIds.flatMap(id=>hub.data.tasks.find(t=>t.id===id)?.sourceIds||[]))];w.revision++;const item={...w,id:crypto.randomUUID(),key:'split:'+j.memberId,title:t.text.slice(0,160),memberIds:[j.memberId],sourceIds:[...t.sourceIds],manual:true,revision:1};hub.data.workItems.push(item);hub.event('knowledge-split',w.id,j.memberId);hub.save();return item;}
function csv(hub){prepare(hub);const d=hub.data;const path=id=>{const a=[];let n=d.knowledgeNodes.find(x=>x.id===id);while(n){a.unshift(n.title);n=d.knowledgeNodes.find(x=>x.id===n.parentId);}return a.join(' / ');};const rows=[['记录ID','层级','类型','事项','状态','负责人','期限','上级事项','进展','来源链接','原始记录数'],...d.workItems.map(w=>[w.id,path(w.nodeId),w.kind,w.title,w.status,w.owner,w.due,d.workItems.find(x=>x.id===w.parentId)?.title||'',w.notes,w.sourceIds.map(id=>d.sources.find(s=>s.id===id)?.url||'').filter(Boolean).join('\n'),w.memberIds.length])];return '\uFEFF'+rows.map(r=>r.map(v=>'"'+String(v??'').replace(/^[=+@-]/,"'$&").replace(/"/g,'""')+'"').join(',')).join('\r\n');}
module.exports={prepare,update,create,split,csv,topic,kind,role};
