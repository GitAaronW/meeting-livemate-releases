'use strict';
// Discovery is a candidate list, never proof that a file is a formal deliverable.
const {canonical}=require('./work-hub');
const {terms}=require('./tools/local');
const STOP=new Set('meeting review weekly discussion sync agenda notes team materials material pre preview 会议 周会 讨论 评审 材料 项目'.split(' '));
function queryFor(event){
 const tokens=terms(event.title||'').filter(t=>!STOP.has(t)&&!/^\d+$/.test(t));
 // Acronyms are useful calendar anchors; otherwise retain the descriptive title.
 const acronym=[...String(event.title||'').matchAll(/(?:^|[^A-Za-z0-9])([A-Z]{3,8})(?=$|[^A-Za-z0-9])/g)].map(m=>m[1].toLowerCase()).find(t=>!STOP.has(t));
 return acronym||(!tokens.length?'':String(event.title||'').replace(/[\x00-\x1f]/g,' ').trim().slice(0,160));
}
function urlFor(row){
 try{const u=new URL(row.url);return u.protocol==='https:'&&!u.username&&!u.password?u.href:'';}catch{return '';}
}
function candidate(row,{sourceId='',reason,query}={}){
 const url=urlFor(row);if(!url)return null;
 const title=String(row.title||'').slice(0,200),label=/\bold\b|旧版|过期/i.test(title)?'旧稿线索 / Older draft':/draft|review|草稿|评审/i.test(title)?'过程稿线索 / Working draft':'角色待核实 / Role unverified';
 return {sourceId,url,title,role:row.knowledgeRole||'',roleBasis:row.knowledgeRole?'existing-hub-role':'unverified',titleLabel:label,reason,query,remoteId:String(row.id||row.remoteId||'').slice(0,200),updatedAt:row.updated_at||row.updatedAt||row.updated||'',read:false};
}
async function discover(ctx,source,event,{budgetMs=8000,previous=null,pending=new Map()}={}){
 const query=queryFor(event),linked=new Set(require('./premeeting-brief').materials(ctx.hub.data,source,event,{purpose:'current-work'}).map(r=>canonical(r.url))),seen=new Set(linked),items=[];
 const add=(row,options)=>{const c=candidate(row,options),key=c&&canonical(c.url);if(!key||seen.has(key))return;seen.add(key);items.push(c);};
 // An inferred project is sufficient for a visible suggestion, not automatic evidence.
 for(const s of ctx.hub.data.sources||[]){if(s.id===source.id||s.knowledgeRole==='archive'||s.calendarEvent||!source.projectId||s.projectId!==source.projectId)continue;add(s,{sourceId:s.id,reason:'same-project',query});}
 const resume=previous?.query===query?previous:null;
 for(const row of resume?.items||[]){const existing=(ctx.hub.data.sources||[]).find(s=>s.id===row.sourceId||canonical(s.url)===canonical(row.url));if(existing?.knowledgeRole==='archive'||existing?.projectId&&source.projectId&&existing.projectId!==source.projectId)continue;add(existing?{...row,...existing}:{...row,knowledgeRole:row.role},{sourceId:existing?.id||row.sourceId,reason:row.reason,query});}
 let pages=resume?.pages||0,hasMore=false,error='',token=resume?.nextPageToken||'';
 const visited=new Set(resume?.visitedTokens||[]);
 const deadline=Date.now()+Math.min(8000,Math.max(1,budgetMs));
 const withinDeadline=fn=>new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Material discovery timed out')),Math.max(1,deadline-Date.now()));Promise.resolve().then(fn).then(resolve,reject).finally(()=>clearTimeout(timer));});
 const search=ctx.searchDrive||(ctx.dataDir?((q,o)=>require('./codex-app-bridge').searchDrive(ctx.dataDir,q,o)):null);
 if(query&&search)try{
  if(pages>=3)return {query,items:items.slice(0,60),pages,resumable:false,hasMore:!!token,nextPageToken:token,visitedTokens:[...visited],error,scope:'candidate-metadata',complete:false};
  do{
   const requestKey=query+'\0'+token;
   if(!pending.has(requestKey))pending.set(requestKey,Promise.resolve().then(()=>search(query,{limit:20,pageToken:token})));
   let result;try{result=await withinDeadline(()=>pending.get(requestKey));}catch(e){if(e.message!=='Material discovery timed out')pending.delete(requestKey);throw e;}pending.delete(requestKey);
   visited.add(token);
   if(!Array.isArray(result.results)||result.results.length>20)throw Error('Invalid discovery results');
   pages++;
   for(const row of result.results){const key=canonical(row.url),existing=(ctx.hub.data.sources||[]).find(s=>canonical(s.url)===key);if(existing?.knowledgeRole==='archive'||existing?.projectId&&source.projectId&&existing.projectId!==source.projectId)continue;add(existing?{...row,...existing}:{...row},{sourceId:existing?.id||'',reason:'calendar-title-search',query});}
   token=result.next_page_token||'';hasMore=!!token;
   if(token&&visited.has(token))throw Error('Repeated discovery page token');
  }while(token&&pages<3);
 }catch(e){error=String(e.message||e).slice(0,200);hasMore=pages<3;}
 return {query,items:items.slice(0,60),pages,resumable:hasMore&&pages<3&&!/Repeated|Invalid/.test(error),nextPageToken:token,visitedTokens:[...visited],hasMore:hasMore||items.length>60,error,scope:'candidate-metadata',complete:false};
}
function moduleFor(receipt){
 if(!receipt.items.length)return null;
 const esc=v=>String(v||'').replace(/[\\\[\]*`]/g,'\\$&').replace(/\s+/g,' ');
 return {id:'premeeting-candidates',kind:'note',title:'相关资料候选 / Suggested materials',edited:false,sourceRefs:[],body:[
  '候选列表仅展示关联线索，不确认正式材料身份；加入后的正文读取状态见工作资料。 / Suggestions do not establish formal status. See Working materials for the content read status after adding.',
  ...receipt.items.map(r=>'- ['+esc(r.title||'Material')+']('+r.url.replace(/\(/g,'%28').replace(/\)/g,'%29')+') · '+esc(r.titleLabel)+(r.role?' · Hub: '+esc(r.role):'')+' · '+(r.reason==='same-project'?'同项目 / Same project':'日程关键词 / Calendar query')+(r.updatedAt?' · '+esc(r.updatedAt):'')),
  ...(receipt.hasMore?['搜索尚有后续结果 / More search results remain.']:[]),
  ...(receipt.error?['检索未完成 / Search incomplete: '+esc(receipt.error)]:[])
 ].join('\n')};
}
async function adopt(ctx,source,url){
 const prep=require('./premeeting-preparation'),event=source.calendarEvent,revision=source.revision;
 const receipt=event&&ctx.hub.data.sync.preparation?.[prep.key(event)];
 if(!receipt)throw Object.assign(Error('资料候选已过期，请刷新 / Material suggestions are stale'),{status:409});
 const agenda=await ctx.calendarAgenda();if(agenda.error||!agenda.events?.some(e=>prep.key(e)===prep.key(event)&&prep.fingerprint(e)===receipt.binding))throw Object.assign(Error('日程已变更，请刷新 / Calendar changed'),{status:409});
 if(source.revision!==revision)throw Object.assign(Error('内容已更新，请刷新 / Content changed'),{status:409});
 const selected=receipt.discovery?.items.find(r=>canonical(r.url)===canonical(url));if(!selected)throw Error('候选资料不存在 / Material suggestion not found');
 let material=ctx.hub.data.sources.find(s=>canonical(s.url)===canonical(selected.url));
 if(material?.knowledgeRole==='archive')throw Error('资料已归档 / Material is archived');
 if(material?.projectId&&source.projectId&&material.projectId!==source.projectId)throw Object.assign(Error('资料项目已变更，请刷新 / Material project changed'),{status:409});
 // Adoption confirms relevance to this meeting, never promotes formal status by title.
 if(!material)material=ctx.hub.source({url:selected.url,title:selected.title,body:'',origin:'premeeting-adoption',knowledgeRole:'reference',bodyState:'link-only'});
 ctx.hub.update('sources',source.id,{relatedIds:[...new Set([...(source.relatedIds||[]),material.id])]},source.revision);
 selected.sourceId=material.id;
 ctx.hub.event('premeeting-material-adopted',source.id,JSON.stringify({sourceId:material.id,url:material.url}));ctx.hub.save();
 return {sourceId:material.id,read:false};
}
async function readAdopted(ctx,source,sourceId){
 const prep=require('./premeeting-preparation'),brief=require('./premeeting-brief'),event=source.calendarEvent,revision=source.revision;
 const receipt=ctx.hub.data.sync.preparation?.[prep.key(event)],binding=receipt?.binding;
 let error='';try{await ctx.hub.fetchSource(sourceId,{env:ctx.env,fetchImpl:ctx.fetchImpl});}catch(e){error=String(e.message||e).slice(0,200);}
 const agenda=await ctx.calendarAgenda();if(agenda.error||!agenda.events?.some(e=>prep.key(e)===prep.key(event)&&prep.fingerprint(e)===binding)||source.revision!==revision)throw Object.assign(Error('资料已保留；会议内容变更，请刷新 / Material retained; meeting changed'),{status:409});
 const options={purpose:'current-work',asOf:new Date().toISOString()},modules=source.board?.modules||[],prior=modules.find(m=>m.id==='premeeting-materials');
 if(!prior?.edited){const next=brief.preparationModule(ctx.hub.data,source,event,options),all=modules.filter(m=>m.id!=='premeeting-materials');if(next)all.unshift(next);ctx.hub.update('sources',source.id,{board:{...source.board,modules:all}},revision);}
 const rows=brief.materials(ctx.hub.data,source,event,options),now=Date.now(),online=rows.filter(r=>r.read&&r.readReceipt&&now-Date.parse(r.readReceipt.fetchedAt)<3600000).length,cache=rows.filter(r=>r.read).length-online,links=rows.filter(r=>!r.read).length;
 if(ctx.hub.data.sync.preparation[prep.key(event)]?.binding!==binding)throw Object.assign(Error('日程已更新 / Calendar changed'),{status:409});
 Object.assign(receipt,{materialsBinding:prep.materialBinding(ctx.hub,event,now),materialCount:rows.length,readCount:online,onlineReadCount:online,cacheCount:cache,linkCount:links,status:error||cache||links?'partial':'prepared',errors:error?[{sourceId,error}]:[],checkedAt:now});ctx.hub.save();
 if(error)throw Error(error);
 const target=rows.find(r=>r.sourceId===sourceId),read=!!(target?.read&&target.readReceipt&&now-Date.parse(target.readReceipt.fetchedAt)<3600000);
 return {reply:read?'资料已读取并加入会议上下文 / Material read and added to meeting context':'资料已保留，正文尚未完整读取 / Material retained; content read is incomplete',read,sourceId};
}
module.exports={queryFor,discover,moduleFor,adopt,readAdopted};
