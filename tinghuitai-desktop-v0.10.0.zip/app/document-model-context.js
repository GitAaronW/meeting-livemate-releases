'use strict';
// One model route for inline editing and MyAgent document editing.
const llm=require('./llm'),bridge=require('./codex-app-bridge');
module.exports=function documentModelContext(ctx,{model='',requestId,materials=[],onProgress=()=>{},onModel=()=>{}}={}){
 if(typeof model!=='string'||model.length>100||!/^[a-zA-Z0-9._:-]*$/.test(model))throw Object.assign(Error('Invalid model'),{status:400});
 if(!model&&(ctx.proposeDocument||llm.chainOf(ctx.settings?.load?.()||{})[0]?.type==='openai'))return ctx;
 return {...ctx,proposeDocument:async({question,selected,reference,lang,signal})=>{
  const result=await (ctx.askCodex||bridge.ask)({dataDir:ctx.dataDir,kind:'chat',conversationId:requestId||require('crypto').randomUUID(),signal,requestText:question,model,materials,onProgress,
   context:{documentEdit:'Return only the proposed replacement for the selected blocks, in ordinary Markdown, not JSON. Preserve unknowns. This is a draft, not an applied change. Do not send messages or run actions. Language: '+lang,selected,reference}});
  onModel({model:result.model,effort:result.effort,codexThreadId:result.threadId});
  if(typeof result.text!=='string'||!result.text.trim())throw Object.assign(Error('No document edit returned'),{status:502});
  return {blocks:require('./mother-document-schema').fromMarkdown(result.text).content,summary:lang==='en'?'Selected edit is ready to review.':'局部修改已准备好，可查看后采用。',directionChange:true};
 }};
};
