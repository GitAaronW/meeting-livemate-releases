'use strict';
// Durable tasks: model work is serialized per meeting. Confirmed tool work is
// recorded before dispatch and never replayed automatically after a restart.
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const stores=new Map(),ACTIVE=['queued','running','planning','retrieving','syncing','thinking','awaiting_confirmation','executing','uncertain','stopping'];
const error=(message,status=409)=>Object.assign(Error(message),{status});
function publicJob({request,pendingProposal,actionKey,...j}){return {...j,...(request?.requestId?{requestId:request.requestId}:{}),...(pendingProposal?{proposal:pendingProposal}:{})};}
class Jobs {
 constructor(dir){
  this.file=path.join(dir,'meeting-board-jobs.json');this.items=[];this.controllers=new Map();this.listeners=new Set();this.tails=new Map();this.parallelLimit=3;this.parallelRunning=0;this.parallelQueue=[];
  try{const j=JSON.parse(fs.readFileSync(this.file,'utf8'));if(Array.isArray(j))this.items=j;}catch(e){if(e.code!=='ENOENT')throw e;}
  let dirty=false;for(const j of this.items){
   const installed=j.action==='develop'&&require('./development-preview').installed(j.request?.requestId,dir);
   if(installed&&['queued','running','thinking','retrieving','interrupted','preview'].includes(j.state)){j.state='completed';j.reply='开发修改已通过 Grok 审核并安装本机 '+installed.version+'。';j.deployment={commit:installed.head,reviewReceipt:installed.reviewReceipt,version:installed.version};j.finished=new Date().toISOString();delete j.error;dirty=true;continue;}
   if(['executing','stopping'].includes(j.state)){j.state='uncertain';j.error='执行时服务重启，请先到对方核对结果 / Service restarted during execution; check the destination';dirty=true;}
   else if(['queued','running','planning','retrieving','syncing','thinking'].includes(j.state)){j.state='interrupted';j.error='服务已重启，任务未完成，请重试 / Service restarted; retry the unfinished task';j.finished=new Date().toISOString();dirty=true;}
  }if(dirty)this.save();
 }
 emit(job){for(const fn of this.listeners)try{fn(publicJob(job));}catch{}}
 subscribe(fn){this.listeners.add(fn);return ()=>this.listeners.delete(fn);}
 save(){fs.mkdirSync(path.dirname(this.file),{recursive:true});const tmp=this.file+'.'+crypto.randomUUID()+'.tmp';try{fs.writeFileSync(tmp,JSON.stringify(this.items),{mode:0o600});fs.renameSync(tmp,this.file);for(const j of this.items)if(ACTIVE.includes(j.state))this.emit(j);}finally{try{fs.unlinkSync(tmp);}catch{}}}
 list(id){const all=this.items.filter(j=>j.meetingId===id);return all.filter((j,i)=>ACTIVE.includes(j.state)||i>=all.length-80).map(publicJob);}
 notify(key,meta){
  if(!/^assigned:[a-f0-9]{24}$/.test(key))throw error('Invalid intake notification',400);
  const oldItems=this.items.slice(),existing=this.items.find(j=>j.intakeKey===key),before=existing&&{...existing};
  const stamp=new Date().toISOString(),job=existing||{id:crypto.randomUUID(),meetingId:'assistant:global',contextId:'',action:'draft',comment:'',intakeKey:key,created:stamp,events:[]};
  Object.assign(job,{reply:String(meta.reply||''),error:String(meta.error||''),origin:meta.origin,resultUrl:meta.resultUrl||'',assignmentSourceId:meta.assignmentSourceId||'',state:meta.state==='failed'?'failed':'completed',finished:stamp});
  if(!existing)this.items.push(job);if(this.items.length>1000)this.items=this.items.filter(j=>ACTIVE.includes(j.state)).concat(this.items.filter(j=>!ACTIVE.includes(j.state)).slice(-900));
  try{this.save();}catch(e){this.items=oldItems;if(existing)Object.assign(existing,before);throw e;}this.emit(job);return publicJob(job);
 }
 assistantList(){return this.items.filter(j=>j.meetingId==='assistant:global'||(['comment','task','run','draft','project-draft'].includes(j.action)&&j.comment)).slice(-100).map(publicJob);}
 find(id,jobId){const j=this.items.find(j=>j.meetingId===id&&j.id===jobId);if(!j)throw error('任务不存在 / Task not found',404);return j;}
 enqueue(id,request,run,{parallel=false}={}){
  const duplicate=request.requestId&&this.items.find(j=>j.meetingId===id&&j.request?.requestId===request.requestId);if(duplicate)return publicJob(duplicate);
  if(this.items.filter(j=>['queued','running','planning','retrieving','syncing','thinking','stopping'].includes(j.state)).length>=20)throw error('任务队列已满，请稍后再试 / Task queue full',429);
  const job={id:crypto.randomUUID(),meetingId:id,contextId:request.contextId||id,state:'queued',action:request.action,moduleId:request.moduleId||'',comment:request.comment||'',quote:request.selection?.original||request.pageContext?.quote||'',lang:request.lang==='en'?'en':'zh',created:new Date().toISOString(),request,events:[]};
  const oldItems=this.items.slice();this.items.push(job);if(this.items.length>1000)this.items=this.items.filter(j=>ACTIVE.includes(j.state)).concat(this.items.filter(j=>!ACTIVE.includes(j.state)).slice(-900));try{this.save();}catch(e){this.items=oldItems;throw e;}
  const controller=new AbortController();this.controllers.set(job.id,controller);
  const work=async()=>{
   if(controller.signal.aborted){this.controllers.delete(job.id);return;}
   let savedAt=0;
   const report=(state,message,meta={})=>{
    if(controller.signal.aborted&&state!=='stopping')return;
    if(meta.model)job.model=meta.model;if(meta.effort)job.effort=meta.effort;if(meta.threadId)job.codexThreadId=meta.threadId;if(typeof meta.reply==='string')job.reply=meta.reply;
    job.state=state;job.updated=new Date().toISOString();
    if(!meta.stream&&job.events.at(-1)?.message!==message){job.events.push({at:job.updated,state,message});job.events=job.events.slice(-12);}
    this.emit(job);if(!meta.stream||Date.now()-savedAt>1000){this.save();savedAt=Date.now();}
   };
   job.state=request.action==='run'?'planning':'running';job.started=new Date().toISOString();job.events.push({at:job.started,state:job.state,message:request.action==='run'?'正在拆解任务':'正在处理请求'});
   try{this.save();const result=await run(request,report,controller.signal);
    if(controller.signal.aborted)throw Object.assign(Error('已停止'),{cancelled:true});
    if(result.motherEdit)job.motherEdit=result.motherEdit;job.reply=result.reply||'已保存到本场工作台 / Saved to this workspace';job.resultRevision=result.source?.revision;job.resultIds=result.resultIds||[];if(result.resultContextId)job.resultContextId=result.resultContextId;if(result.model)job.model=result.model;if(result.effort)job.effort=result.effort;if(result.codexThreadId)job.codexThreadId=result.codexThreadId;if(result.codexSyncError)job.codexSyncError=result.codexSyncError;
    if(result.proposal){if(result.attribution)job.attribution=result.attribution;job.pendingProposal=result.proposal;job.actionKey=result.actionKey;job.state='awaiting_confirmation';}
    else job.state=result.preview?'preview':request.action==='run'?'planned':'completed';
   }catch(e){job.state=e.uncertain?'uncertain':e.cancelled?'cancelled':'failed';job.error=e.cancelled?'':e.message;if(e.threadId)job.codexThreadId=e.threadId;}finally{this.controllers.delete(job.id);job.finished=new Date().toISOString();job.events.push({at:job.finished,state:job.state,message:job.state==='cancelled'?'已停止':job.error?'任务未完成':'结果已保存'});this.save();this.emit(job);}
  };
  if(parallel){this.parallelQueue.push(work);this.pumpParallel();}
  else {const previous=this.tails.get(id)||Promise.resolve();const chained=previous.catch(()=>{}).then(work);this.tails.set(id,chained);chained.catch(()=>{}).finally(()=>{if(this.tails.get(id)===chained)this.tails.delete(id);});}
  return publicJob(job);
 }
 pumpParallel(){while(this.parallelRunning<this.parallelLimit&&this.parallelQueue.length){const work=this.parallelQueue.shift();this.parallelRunning++;Promise.resolve().then(work).catch(()=>{}).finally(()=>{this.parallelRunning--;this.pumpParallel();});}}

 cancel(id,jobId){
  const j=this.find(id,jobId);if(['cancelled','stopping'].includes(j.state))return publicJob(j);
  const controller=this.controllers.get(jobId),previous=j.state;
  if(previous!=='awaiting_confirmation'&&!controller)throw error('这条任务不能停止 / This task cannot be stopped');
  j.state=previous==='queued'||previous==='awaiting_confirmation'?'cancelled':'stopping';
  try{this.save();}catch(e){j.state=previous;throw e;}
  controller?.abort();this.emit(j);return publicJob(j);
 }
 confirm(id,jobId,confirmed,validate,run){
  if(confirmed!==true)throw error('请核对后点击确认 / Confirm after reviewing',400);
  const j=this.find(id,jobId);
  if(['executing','completed'].includes(j.state))return publicJob(j);
  if(j.state!=='awaiting_confirmation'||!j.pendingProposal)throw error('提案已失效或结果待核对 / Proposal expired or outcome needs checking');
  validate(j); // No await between checking the target and persisting executing.
  j.state='executing';j.confirmedAt=new Date().toISOString();
  try{this.save();}catch(e){j.state='awaiting_confirmation';delete j.confirmedAt;throw e;}
  Promise.resolve().then(()=>run(j)).then(result=>{
   j.state=result?.ok?'completed':result?.uncertain?'uncertain':'failed';j.reply=result?.text||'';
   if(!result?.ok)j.error=result?.error||result?.reason||'工具未返回成功回执 / No successful tool receipt';
   if(result?.url)j.resultUrl=result.url;
   if(result?.note)j.resultNote=result.note;
   if(result?.ok)j.executedAt=new Date().toISOString();
  },e=>{j.state='uncertain';j.error=e.message;}).finally(()=>{j.finished=new Date().toISOString();this.save();this.emit(j);}).catch(()=>{});
  return publicJob(j);
 }
}
function get(dir){const key=path.resolve(dir);if(!stores.has(key))stores.set(key,new Jobs(key));return stores.get(key);}
module.exports={get,Jobs};
