'use strict';
module.exports=async function(req,res,u,ctx){
 if(u.pathname.replace(/^\/asr-relay/,'')!=='/mother-documents')return false;
 const send=(s,v)=>{res.writeHead(s,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(v));};
 if(!ctx.authed){send(401,{error:'unauthorized'});return true;}
 if(!ctx.hub){send(503,{error:'Workspace unavailable'});return true;}
 try{
  if(!['GET','POST'].includes(req.method)){send(405,{error:'method not allowed'});return true;}
  if(req.method==='POST'&&req.headers.origin&&new URL(req.headers.origin).host!==req.headers.host){send(403,{error:'origin'});return true;}
  let j={};if(req.method==='POST'){const chunks=[];let length=0;for await(const c of req){length+=Buffer.byteLength(c);if(length>12000000){send(413,{error:'too large'});return true;}chunks.push(c);}j=JSON.parse(Buffer.concat(chunks.map(c=>Buffer.from(c))).toString()||'{}');}
  const store=require('./mother-documents').get(ctx.dataDir);
  const id=String(j.id||u.searchParams.get('id')||''),meetingId=String(j.meetingId||u.searchParams.get('meetingId')||'');
  const source=ctx.hub.data.sources.find(s=>s.key==='session:'+meetingId||s.id===meetingId);
  if(req.method==='GET'){
   if(!id){send(200,{documents:store.list().filter(d=>!u.searchParams.has('projectId')||d.projectId===u.searchParams.get('projectId')),current:source?.motherDocumentId||''});return true;}
   if(u.searchParams.has('history')){send(200,{history:store.history(id)});return true;}
   if(u.searchParams.has('revision')){send(200,store.preview(id,u.searchParams.get('revision')));return true;}
   send(200,store.state(id,u.searchParams.get('vector')));return true;
  }
  if(j.action==='create'||j.action==='bind'){
   if(!source)throw Object.assign(Error('Open a saved meeting first'),{status:404});
   if(source.revision!==Number(j.sourceRevision))throw Object.assign(Error('Meeting changed; refresh and retry'),{status:409});
   const projectId=source.projectManual?source.projectId||'':'';
   let created;if(j.action==='create'){
    // Continue the explicitly selected calendar preparation document before a
    // fresh recording opens its editor. Existing links are never replaced.
    const preparation=typeof j.preparedEventId==='string'&&j.preparedEventId.length<=500?ctx.hub.data.sources.find(s=>s.kind==='note'&&s.calendarEvent?.eventId===j.preparedEventId):null;
    const prepared=preparation?.motherDocumentId?store.state(preparation.motherDocumentId):null;
    const continuing=!source.motherDocumentId&&prepared&&prepared.projectId===projectId;
    if(continuing)created=prepared;
    else created=store.create({title:j.title,projectId,meetingId});
    if(j.inherit&&!continuing)for(const m of source.board?.modules||[])if(['note','plan','map','task'].includes(m.kind)&&m.body)store.importModule(created.id,m,meetingId);
    created=store.state(created.id);
   }else{store.read(id);created=store.state(id);if(created.projectId!==projectId)throw Object.assign(Error('This document belongs to another project'),{status:409});}
   ctx.hub.update('sources',source.id,{motherDocumentId:created.id},j.sourceRevision);store.bind(created.id,meetingId);send(200,store.state(created.id));return true;
  }
  if(j.action==='update'){send(200,store.update(id,j.update,j.author));return true;}
  if(j.action==='restore'){send(200,store.restore(id,j.revision,j.expectedRevision,j.author));return true;}
  if(j.action==='propose'){
   const controller=new AbortController();res.on('close',()=>{if(!res.writableEnded)controller.abort();});
   let modelMeta={};const editContext=require('./document-model-context')(ctx,{model:j.model||'',onModel:meta=>{modelMeta=meta;}});
   send(200,{...await store.propose(id,{...j,signal:controller.signal},editContext),...modelMeta});return true;
  }
  if(j.action==='apply'){send(200,store.apply(id,j.token));return true;}
  if(j.action==='import'){
   if(!source||source.motherDocumentId!==id)throw Object.assign(Error('Meeting is no longer linked to this document'),{status:409});
   const module=source.board?.modules?.find(m=>m.id===j.moduleId);if(!module||!['note','plan','map','task'].includes(module.kind))throw Error('No editable meeting draft');send(200,store.importModule(id,module,meetingId)||{unchanged:true});return true;
  }
  throw Error('Unknown document action');
 }catch(e){send(e.status||400,{error:e.message});return true;}
};
