'use strict';
const Y=require('yjs');
const encode=bytes=>{let s='';for(const c of bytes)s+=String.fromCharCode(c);return btoa(s);};
const decode=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
// One in-flight merge per document; never acknowledge edits typed while a
// request was in flight until the server has received them too.
function sync(session,api){
 if(session.syncPromise)return session.syncPromise;
 const run=async()=>{
  try{
   const remote=await api(null,{id:session.id,vector:encode(Y.encodeStateVector(session.doc))});
   Y.applyUpdate(session.doc,decode(remote.update),'remote');
   const delta=Y.encodeStateAsUpdate(session.doc,decode(remote.vector));
   let result=remote;
   if(delta.length>2){result=await api({action:'update',id:session.id,update:encode(delta)});Y.applyUpdate(session.doc,decode(result.update),'remote');}
   session.revision=result.revision;
   session.dirty=delta.length>2?encode(Y.encodeStateAsUpdate(session.doc))!==result.update:false;
   session.syncError=null;return true;
  }catch(error){session.syncError=error;return false;}
 };
 session.syncPromise=run().finally(()=>{session.syncPromise=null;});
 return session.syncPromise;
}
module.exports={sync,encode,decode};
