'use strict';
// Persist a complete Yjs state in one transaction. A save acknowledgement
// means IndexedDB committed, rather than merely scheduling a write.
function openCache(indexedDB=globalThis.indexedDB){
 if(!indexedDB)return Promise.reject(Error('Local storage unavailable'));
 return new Promise((resolve,reject)=>{const r=indexedDB.open('tht-mother-v1',1);r.onupgradeneeded=()=>r.result.createObjectStore('documents');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error||Error('Local storage unavailable'));r.onblocked=()=>reject(Error('Local document storage is blocked'));});
}
function transaction(db,mode,action){return new Promise((resolve,reject)=>{let tx,result;try{tx=db.transaction('documents',mode);const r=action(tx.objectStore('documents'));r.onsuccess=()=>{result=r.result;};}catch(e){reject(e);return;}tx.oncomplete=()=>resolve(result);tx.onabort=tx.onerror=()=>reject(tx.error||Error('Local save failed'));});}
async function cache(id,options={}){
 const db=await openCache(options.indexedDB);let pending=Promise.resolve();
 return {load:()=>transaction(db,'readonly',s=>s.get(id)),save(value){const next=pending.catch(()=>{}).then(()=>transaction(db,'readwrite',s=>s.put(value,id)));pending=next;return next;},async close(){await pending;db.close();}};
}
module.exports={openCache,transaction,cache};
