const {Editor}=require('@tiptap/core');
const Collaboration=require('@tiptap/extension-collaboration').default;
const Y=require('yjs');
import format from '../../app/mother-document-schema.js';
import localCache from './document-cache.js';
import transport from './document-sync.js';

const root=document.getElementById('canvas');
const el=(tag,text='',cls='')=>{const n=document.createElement(tag);n.textContent=text;n.className=cls;return n;};
const box=el('section','','mother-workspace');box.id='mother-workspace';root.prepend(box);
const heading=el('div','','mother-heading'),choose=el('select'),fresh=el('button'),records=el('button'),status=el('small','','mother-status');
choose.setAttribute('aria-label','Topic document');status.setAttribute('role','status');heading.append(choose,fresh,records,status);
const title=el('h1','','mother-title'),toolbar=el('div','','mother-toolbar'),host=el('div','','mother-editor');
const start=el('div','','mother-start'),startTitle=el('input'),inherit=el('button'),blank=el('button');startTitle.maxLength=160;start.append(startTitle,inherit,blank);
const history=el('details','','mother-history');history.append(el('summary'),el('div'));
box.append(heading,title,start,toolbar,host,history);
let meetingId='',board={},lang='zh',active=null,transition=Promise.resolve(),timer,applying=false,lastDataKey='',importing=false;
const tr=(zh,en)=>lang==='en'?en:zh;
const auth=()=>{try{return window.THT_BOOT?.relayToken||parent.THT_BOOT?.relayToken||JSON.parse(localStorage.getItem('tht-settings')||'{}').relayToken||'';}catch{return '';}};
async function api(body,params={}){
 const u=new URL('/mother-documents',location.origin);for(const [k,v] of Object.entries(params))u.searchParams.set(k,v);u.searchParams.set('token',auth());
 const controller=new AbortController(),limit=setTimeout(()=>controller.abort(),body?.action==='propose'?180000:15000);
 try{const r=await fetch(u,{cache:'no-store',signal:controller.signal,...(body?{method:'POST',headers:{'Content-Type':'application/json','x-tht-token':auth()},body:JSON.stringify(body)}:{})});const j=await r.json();if(!r.ok)throw Object.assign(Error(j.error||r.status),{status:r.status});return j;}finally{clearTimeout(limit);}
}
function state(text,error=false){status.textContent=text;status.classList.toggle('error',error);}
function labels(){fresh.textContent=tr('新主题','New topic');records.textContent=tr('会议记录','Meeting notes');startTitle.placeholder=tr('这份文档讨论什么？','What is this document about?');inherit.textContent=tr('从本场成果起稿','Start from this meeting');blank.textContent=tr('完全新建','Start blank');image.textContent=tr('图片','Image');caption.textContent=tr('图注','Caption');history.firstElementChild.textContent=tr('版本历史','History');for(const b of toolbar.querySelectorAll('[data-en]'))b.textContent=lang==='en'?b.dataset.en:b.dataset.zh;}
function displayStatus(s){if(s!==active)return;if(s.editorError){state(s.editorError.message,true);return;}if(s.localError)state(tr('本机保存失败 · 请勿关闭文档','Local save failed · Keep this document open'),true);else if(s.syncError?.status)state(s.syncError.message,true);else if(s.syncError)state(s.localSaved?tr('已存本机 · 离线编辑','Saved locally · Editing offline'):tr('离线 · 正在保存本机','Offline · Saving locally'));else state(s.dirty?tr('正在保存','Saving'):tr('已保存','Saved'));}
function persist(s){
 if(!s.cache){s.localError=Error('Local storage unavailable');displayStatus(s);return Promise.resolve(false);}
 const generation=++s.localGeneration;s.localSaved=false;
 const saved=s.cache.save({update:Y.encodeStateAsUpdate(s.doc),title:s.title,projectId:s.projectId});s.localPromise=saved;
 return saved.then(()=>{if(generation===s.localGeneration){s.localSaved=true;s.localError=null;displayStatus(s);}return true;},e=>{s.localError=e;s.localSaved=false;displayStatus(s);return false;});
}
async function sync(s=active){if(!s||s.closed)return false;const ok=await transport.sync(s,api);displayStatus(s);if(s===active&&ok&&s.dirty){clearTimeout(timer);timer=setTimeout(()=>sync(s),300);}return ok;}
function selection(){if(!active)return [];const {from,to}=active.editor.state.selection,ids=[];active.editor.state.doc.forEach((node,pos)=>{if((from===to?pos<=from&&pos+node.nodeSize>from:pos+node.nodeSize>from&&pos<to)&&node.attrs.blockId)ids.push(node.attrs.blockId);});return ids.slice(0,12);}
async function ask(){
 const s=active;if(!s)return;const ids=selection();if(!ids.length)return;
 const quote=s.editor.state.doc.textBetween(s.editor.state.selection.from,s.editor.state.selection.to,'\n')||s.editor.state.selection.$from.parent.textContent;
 if(!await sync(s)||s.dirty||s!==active){state(tr('先连接本机服务并保存，再让 AI 修改','Reconnect and save before asking AI to edit'),true);return;}
 const meta={contextId:meetingId,motherDocumentId:s.id,blockIds:ids,projectId:s.projectId||'',page:'mother-document'};
 if(parent!==window)parent.postMessage({type:'tht-agent-ask',quote,meta},location.origin);else window.myAgentAsk?.(quote,'',meta);
}
const tools=[['B','B','加粗 / Bold',e=>e.chain().focus().toggleBold().run()],['H2','H2','标题 / Heading',e=>e.chain().focus().toggleHeading({level:2}).run()],['☐','☐','待办 / To-do',e=>e.chain().focus().toggleTaskList().run()],['•','•','列表 / List',e=>e.chain().focus().toggleBulletList().run()],['表格','Table','插入表格 / Insert table',e=>e.chain().focus().insertTable({rows:3,cols:3,withHeaderRow:true}).run()],['＋行','+ Row','加一行 / Add row',e=>e.chain().focus().addRowAfter().run()],['＋列','+ Column','加一列 / Add column',e=>e.chain().focus().addColumnAfter().run()],['↶','↶','撤销 / Undo',e=>e.chain().focus().undo().run()],['↷','↷','重做 / Redo',e=>e.chain().focus().redo().run()]];
for(const [zh,en,hint,run] of tools){const b=el('button',zh);b.dataset.zh=zh;b.dataset.en=en;b.type='button';b.title=hint;b.setAttribute('aria-label',hint);b.onpointerdown=e=>e.preventDefault();b.onclick=()=>active?.editor&&run(active.editor);toolbar.append(b);}
const image=el('button','图片'),imageInput=el('input');image.title='插入图片 / Insert image';image.type='button';imageInput.type='file';imageInput.accept='image/png,image/jpeg,image/webp,image/gif';imageInput.hidden=true;toolbar.append(image,imageInput);image.onclick=()=>imageInput.click();
imageInput.onchange=()=>{const selected=active,f=imageInput.files[0];if(!f||!selected)return;if(f.size>1800000){state(tr('图片须小于 1.8 MB','Image must be smaller than 1.8 MB'),true);return;}const reader=new FileReader();reader.onload=()=>{if(selected!==active)return;selected.editor.chain().focus().setImage({src:reader.result,alt:f.name}).run();};reader.onerror=()=>state(tr('图片未能读取','Could not read image'),true);reader.readAsDataURL(f);imageInput.value='';};
const caption=el('button','图注');caption.title='编辑选中图片说明 / Edit image description';caption.onclick=()=>{if(!active?.editor.isActive('image')){state(tr('先选中图片','Select an image first'));return;}const alt=prompt(tr('图片说明','Image description'),active.editor.getAttributes('image').alt||'');if(alt!==null)active.editor.chain().focus().updateAttributes('image',{alt,title:alt}).run();};toolbar.append(caption);
const ai=el('button','@AI','mother-ai');ai.title='修改当前段落或选中内容 / Edit selected content';ai.onpointerdown=e=>e.preventDefault();ai.onclick=()=>inline.hidden?openInline():inline.hidden=true;toolbar.append(ai);
records.onclick=()=>window.dispatchEvent(new CustomEvent('tht-transcript-toggle'));
fresh.onclick=()=>{start.hidden=false;startTitle.value='';startTitle.focus();};
async function create(useExisting){
 const source=board.source,meeting=meetingId,epoch=requestEpoch;const titleValue=startTitle.value.trim()||source?.title||board.session?.title;if(!titleValue){state(tr('先填写主题名称','Enter a topic title first'),true);startTitle.focus();return;}
 inherit.disabled=blank.disabled=true;
 try{const doc=await api({action:'create',title:titleValue,meetingId:meeting,sourceRevision:source?.revision,inherit:useExisting,preparedEventId:board.preparedEventId||''});if(meeting!==meetingId||epoch!==requestEpoch)return;board.source={...source,motherDocumentId:doc.id,revision:source.revision+1};await openDoc(doc.id,doc);await catalog();}
 catch(e){state(e.message,true);}finally{inherit.disabled=blank.disabled=false;}
}
inherit.onclick=()=>create(true);blank.onclick=()=>create(false);
choose.onchange=async()=>{const id=choose.value,meeting=meetingId,source=board.source,epoch=requestEpoch;if(!id)return;choose.disabled=true;try{const doc=await api({action:'bind',id,meetingId:meeting,sourceRevision:source?.revision});if(meeting!==meetingId||epoch!==requestEpoch)return;board.source={...source,motherDocumentId:id,revision:source.revision+1};await openDoc(id,doc);}catch(e){state(e.message,true);choose.value=active?.id||'';}finally{choose.disabled=false;}};
async function catalog(){
 const meeting=meetingId,epoch=requestEpoch;try{const list=await api(null,{meetingId:meeting,projectId:board.source?.projectManual?board.source.projectId||'':''});if(meeting!==meetingId||epoch!==requestEpoch)return;choose.replaceChildren(el('option',tr('选择主题文档','Choose a topic document')));choose.firstChild.value='';for(const d of list.documents){const o=el('option',d.title||tr('文档暂不可用','Document unavailable'));o.value=d.id;o.disabled=!!d.unavailable;choose.append(o);}if(active)choose.value=active.id;}
 catch{if(!active)state(tr('本机服务暂不可用','Local service unavailable'),true);}
}
async function closeDoc(){
 const old=active;if(!old)return true;clearTimeout(timer);await persist(old);if(old.localError&&!await sync(old)){state(tr('文档尚未保存，不能切换','Document not saved; cannot switch yet'),true);return false;}
 await sync(old);old.closed=true;old.editor?.destroy();if(old.cache)try{await old.cache.close();}catch{}old.doc.destroy();active=null;return true;
}
function openDoc(id,remote){
 transition=transition.catch(()=>{}).then(async()=>{
  if(active?.id===id)return;if(!await closeDoc())return;
  const doc=new Y.Doc();let cache,cached;try{cache=await localCache.cache(id);cached=await cache.load();if(cached?.update)Y.applyUpdate(doc,cached.update,'remote');}catch(e){state(tr('本机存储不可用，请保持联网','Local storage unavailable; keep connected'),true);}
  const s={id,doc,cache,revision:0,editor:null,dirty:false,syncPromise:null,title:cached?.title||'',projectId:cached?.projectId||'',localGeneration:0,localSaved:!!cached,localError:cache?null:Error('Local storage unavailable')};
  try{remote=remote||await api(null,{id});Y.applyUpdate(doc,transport.decode(remote.update),'remote');s.revision=remote.revision;s.title=remote.title;s.projectId=remote.projectId;}
  catch(e){s.syncError=e;if(!doc.getXmlFragment('default').length){state(tr('文档暂时无法打开','Document unavailable'),true);await cache?.close();doc.destroy();return;}}
  active=s;localStorage.setItem('tht-mother:'+meetingId,id);title.textContent=s.title;choose.value=id;start.hidden=true;host.hidden=toolbar.hidden=history.hidden=false;root.classList.add('mother-open');
  doc.on('update',(_,origin)=>{if(s.closed)return;persist(s);if(origin!=='remote'){s.dirty=true;clearTimeout(timer);timer=setTimeout(()=>sync(s),900);}});
  try{
  s.editor=new Editor({element:host,extensions:[...format.extensions(),Collaboration.configure({document:doc})],editorProps:{attributes:{'aria-label':tr('主题主文档，可直接编辑','Topic document, editable'),spellcheck:'true'}}});
  }catch(e){s.editorError=e;console.error('Document editor initialization failed:',e);toolbar.hidden=true;host.hidden=true;root.classList.remove('mother-open');displayStatus(s);throw e;}
  s.editor.on('transaction',({editor,transaction})=>{if(transaction.docChanged&&!applying)assignIds(editor);});
  assignIds(s.editor);
  await persist(s);await sync(s);await importDrafts();
 });
 return transition;
}
function assignIds(editor){
 if(applying)return;const trn=editor.state.tr;let changed=false;const seen=new Set();editor.state.doc.forEach((n,pos)=>{const id=n.attrs.blockId;if(!id||seen.has(id)){const next='b-'+crypto.randomUUID();trn.setNodeMarkup(pos,undefined,{...n.attrs,blockId:next});seen.add(next);changed=true;}else seen.add(id);});if(changed){applying=true;try{editor.view.dispatch(trn);}finally{applying=false;}}
}
async function importDrafts(){
 if(importing||!active||board.source?.motherDocumentId!==active.id)return;const s=active,source=board.source,meeting=meetingId;importing=true;
 try{let conflict=false;for(const m of source.board?.modules||[]){if(s!==active||meeting!==meetingId)break;if(!['note','plan','map','task'].includes(m.kind)||!m.body)continue;const result=await api({action:'import',id:s.id,meetingId:meeting,moduleId:m.id});if(result.conflict)conflict=true;}if(s===active){await sync(s);if(conflict)state(tr('新讨论与人工修改不同 · 已保留原稿','New discussion differs from your edit · Original kept'));}}catch(e){if(s===active&&e.status)state(e.message,true);}finally{importing=false;}
}
history.ontoggle=async()=>{if(!history.open||!active)return;const s=active,list=history.lastElementChild;list.replaceChildren();try{const result=await api(null,{id:s.id,history:1});for(const h of result.history){const row=el('div'),b=el('button',tr('查看','View'));row.append(el('span',h.at.slice(0,16)+' · '+h.author),b);b.onclick=async()=>{if(active!==s)return;try{const version=await api(null,{id:s.id,revision:h.revision});const preview=el('pre','','mother-history-preview');preview.textContent=plain(version.content);const restore=el('button',tr('恢复这版','Restore revision'));preview.append(restore);row.after(preview);b.disabled=true;restore.onclick=async()=>{if(active!==s||!await sync(s)||s.dirty||active!==s)return;if(!confirm(tr('恢复这版文档？当前内容仍保留在历史。','Restore this revision? Current content remains in history.')))return;try{const restored=await api({action:'restore',id:s.id,revision:h.revision,expectedRevision:s.revision});if(active!==s)return;Y.applyUpdate(s.doc,transport.decode(restored.update),'remote');s.revision=restored.revision;state(tr('已恢复','Restored'));restore.disabled=true;}catch(e){state(e.message,true);}};}catch(e){state(e.message,true);}};list.append(row);}if(!result.history.length)list.append(el('p',tr('开始编辑后会保留历史','Edit the document to create history')));}catch(e){list.append(el('p',e.message));}};
function plain(n){return n.type==='image'?'[Image: '+(n.attrs?.alt||'')+']':n.text||(n.content||[]).map(plain).join(n.type==='tableRow'?' | ':'\n');}
async function dataChanged(detail){
 if(!detail?.id)return;lang=detail.lang;labels();const changed=meetingId!==detail.id;if(changed&&active&&!await closeDoc())return;meetingId=detail.id;board={...detail.data,preparedEventId:detail.preparedEventId||''};
 if(changed){requestEpoch++;inline.hidden=true;proposalEditor?.destroy();proposalEditor=null;proposal=null;selectedSnapshot=null;revertAI.hidden=true;lastDataKey='';const linked=board.source?.motherDocumentId||localStorage.getItem('tht-mother:'+meetingId);if(linked)await openDoc(linked);else{title.textContent='';host.hidden=toolbar.hidden=history.hidden=true;start.hidden=false;root.classList.remove('mother-open');startTitle.value=board.source?.title||board.session?.title||'';if(board.source&&Number.isFinite(board.source.revision))await create(false);}await catalog();}
 const dataKey=JSON.stringify([meetingId,board.source?.revision,board.source?.motherDocumentId]);if(dataKey!==lastDataKey){lastDataKey=dataKey;await importDrafts();}
}
let dataQueue=Promise.resolve();window.addEventListener('tht-board-data',e=>{dataQueue=dataQueue.catch(()=>{}).then(()=>dataChanged(e.detail)).catch(e=>state(e.message,true));});
window.addEventListener('tht-board-language',e=>{lang=e.detail.lang;labels();});
window.addEventListener('online',()=>sync());
window.addEventListener('beforeunload',e=>{if(active&&(active.localError||!active.localSaved)){e.preventDefault();e.returnValue='';}});
setInterval(()=>sync(),5000);labels();host.hidden=toolbar.hidden=history.hidden=true;
if(parent===window&&!window.__thtMyAgent){const css=el('link');css.rel='stylesheet';css.href='my-agent.css';document.head.append(css);const script=el('script');script.src='my-agent.js';document.body.append(script);}

const inline=el('section','','mother-inline-ai');inline.hidden=true;
const instruction=el('textarea'),generate=el('button'),dismiss=el('button','×'),preview=el('div','','mother-proposal'),apply=el('button'),refine=el('button');
instruction.maxLength=4000;instruction.rows=2;dismiss.type='button';generate.type='button';apply.type='button';refine.type='button';
const inlineModel=el('select');inlineModel.className='mother-model';inlineModel.setAttribute('aria-label','AI model');
inline.append(instruction,inlineModel,generate,dismiss,preview,apply,refine);host.after(inline);
let proposal=null,proposalEditor=null,request=null,selectedSnapshot=null,requestEpoch=0;
const revertAI=el('button');revertAI.hidden=true;toolbar.append(revertAI);let appliedAI=null;
revertAI.onclick=async()=>{const s=active;if(!s||!appliedAI||appliedAI.id!==s.id)return;revertAI.disabled=true;try{if(!await sync(s)||s.dirty||s!==active)return;const undo=appliedAI;const restored=await api({action:'restore',id:s.id,revision:undo.before,expectedRevision:undo.after});if(s!==active)return;Y.applyUpdate(s.doc,transport.decode(restored.update),'remote');s.revision=restored.revision;await persist(s);revertAI.hidden=true;appliedAI=null;state(tr('已撤销 AI 修改','AI edit reverted'));}catch(e){state(e.message,true);}finally{revertAI.disabled=false;}};
function inlineLabels(){revertAI.textContent=tr('撤销 AI 修改','Undo AI edit');instruction.placeholder=tr('让 AI 在这里写什么，或怎么改？','What should AI write or change here?');generate.textContent=tr('生成草稿','Generate draft');apply.textContent=tr('采用到文档','Apply to document');refine.textContent=tr('在 MyAgent 中继续','Continue in MyAgent');dismiss.setAttribute('aria-label',tr('关闭草稿','Close draft'));}
function positionInline(){if(inline.hidden||!active)return;const coords=active.editor.view.coordsAtPos(active.editor.state.selection.to),base=box.getBoundingClientRect();inline.style.top=Math.max(60,coords.bottom-base.top+8)+'px';}
async function loadInlineModels(){
 const epoch=requestEpoch,chosen=localStorage.getItem('tht-agent-model')||'';inlineModel.replaceChildren();const fallback=el('option',tr('默认模型','Default model'));fallback.value='';inlineModel.append(fallback);if(chosen){const o=el('option',chosen);o.value=chosen;inlineModel.append(o);inlineModel.value=chosen;}
 try{const u=new URL('/workspace-assistant/models',location.origin);u.searchParams.set('token',auth());const r=await fetch(u,{signal:AbortSignal.timeout(15000)});if(!r.ok)throw Error(r.status);const {models}=await r.json();if(epoch!==requestEpoch)return;inlineModel.replaceChildren(fallback);const defaultModel=(models||[]).find(m=>m.isDefault);if(defaultModel)fallback.textContent=tr('默认 · ','Default · ')+(defaultModel.name||defaultModel.id);for(const m of models||[]){const o=el('option',(m.name||m.id||tr('默认模型','Default model'))+(m.reasoningEffort?' · '+m.reasoningEffort:''));o.value=m.id||'';if(o.value)inlineModel.append(o);}if(!inlineModel.options.length)inlineModel.append(fallback);if(chosen&&![...inlineModel.options].some(o=>o.value===chosen)){const o=el('option',chosen);o.value=chosen;inlineModel.append(o);}inlineModel.value=chosen;inlineModel.title=tr('与 MyAgent 使用相同模型；仅影响下一次生成','Same model as MyAgent; applies to the next generation');}catch{inlineModel.title=tr('模型列表暂不可用；可继续使用默认模型','Model list unavailable; default model remains available');}
}
inlineModel.onchange=()=>localStorage.setItem('tht-agent-model',inlineModel.value);
function openInline(){if(!active)return;requestEpoch++;generate.disabled=false;selectedSnapshot={session:active,ids:selection()};inline.hidden=false;preview.replaceChildren();proposalEditor?.destroy();proposalEditor=null;proposal=null;apply.hidden=true;instruction.value='';inlineLabels();positionInline();loadInlineModels();instruction.focus();}
dismiss.onclick=()=>{requestEpoch++;generate.disabled=false;request?.abort();inline.hidden=true;proposalEditor?.destroy();proposalEditor=null;proposal=null;};
// An explicit insight action creates its own draft block, never replaces the user's selection.
window.thtDraftMeetingItem=item=>{
 if(!active||item?.meetingId!==meetingId||generate.disabled)return false;
 const text=String(item.text||'').trim();if(!text||text.length>12000)return false;
 const editor=active.editor,id='b-'+crypto.randomUUID(),end=editor.state.doc.content.size;
 editor.commands.insertContentAt(end,{type:'paragraph',attrs:{blockId:id,draft:'AI draft'}});
 editor.commands.setTextSelection(end+1);openInline();selectedSnapshot.ids=[id];
 instruction.value=tr('结合本场会议，把下面这项推进为具体、可编辑的草稿；事实缺口明确标注：\n','Use this meeting to develop the following item into a concrete editable draft. Clearly mark missing facts:\n')+text;
 generate.disabled=true;generate.onclick();return true;
};
window.addEventListener('message',e=>{if(e.origin===location.origin&&e.source===parent&&e.data?.type==='tht-document-draft')window.thtDraftMeetingItem(e.data.item);});
refine.onclick=ask;
generate.onclick=async()=>{
 const s=selectedSnapshot?.session;if(!s||s!==active||!instruction.value.trim())return;const epoch=++requestEpoch,ids=[...selectedSnapshot.ids],question=instruction.value.trim();
 const saved=await sync(s);if(epoch!==requestEpoch||s!==active||inline.hidden)return;
 if(!saved||s.dirty){generate.disabled=false;state(tr('先保存文档，再生成','Save the document before generating'),true);return;}
 generate.disabled=true;apply.hidden=true;state(tr('正在生成局部草稿 · 原文保留','Generating a local draft · Original preserved'));
 try{const result=await api({action:'propose',id:s.id,blockIds:ids,question,lang,model:inlineModel.value});if(s!==active||inline.hidden||epoch!==requestEpoch)return;
  proposal=result;proposalEditor?.destroy();preview.replaceChildren();proposalEditor=new Editor({element:preview,extensions:format.extensions(),content:{type:'doc',content:result.blocks},editable:false});apply.hidden=false;const selectedNodes=s.editor.getJSON().content.filter(n=>selectedSnapshot.ids.includes(n.attrs?.blockId));if(selectedNodes.length===1&&selectedNodes[0].type==='paragraph'&&!plain(selectedNodes[0]).trim()){await apply.onclick();return;}state(tr('草稿已就位 · 采用后替换选中的部分','Draft ready · Apply to replace the selected part'));
 }catch(e){if(epoch===requestEpoch)state(e.message,true);}finally{if(epoch===requestEpoch)generate.disabled=false;}
};
apply.onclick=async()=>{const s=selectedSnapshot?.session,p=proposal,epoch=requestEpoch;if(!p||s!==active)return;apply.disabled=true;try{if(!await sync(s)||s.dirty||s!==active||epoch!==requestEpoch||proposal!==p)return;const before=s.revision;const result=await api({action:'apply',id:s.id,token:p.token});if(s!==active||epoch!==requestEpoch)return;appliedAI={id:s.id,before,after:result.revision};revertAI.hidden=false;Y.applyUpdate(s.doc,transport.decode(result.update),'remote');s.revision=result.revision;await persist(s);if(s!==active||epoch!==requestEpoch)return;inline.hidden=true;proposalEditor?.destroy();proposalEditor=null;proposal=null;state(tr('已放入文档 · 可直接修改或撤销','Added to document · Edit or undo'));}catch(e){if(s===active&&epoch===requestEpoch)state(e.message,true);}finally{apply.disabled=false;}};
window.addEventListener('resize',positionInline);window.addEventListener('tht-board-language',inlineLabels);inlineLabels();apply.hidden=true;

// Feedback is part of the same CRDT block; it survives reopen and never sends externally.
const feedback=el('section','','mother-block-feedback'),feedbackTitle=el('strong'),comments=el('div'),commentInput=el('input'),addComment=el('button'),accepted=el('button'),revise=el('button');
feedback.hidden=true;commentInput.maxLength=800;feedback.append(feedbackTitle,comments,commentInput,addComment,accepted,revise);toolbar.after(feedback);
let inspected=null;
function inspectBlock(){
 if(!active){feedback.hidden=true;return;}const cursor=active.editor.state.selection.from;inspected=null;
 active.editor.state.doc.forEach((node,pos)=>{if(pos<=cursor&&pos+node.nodeSize>cursor&&/^AI (draft|accepted)$/.test(node.attrs.draft||''))inspected={id:node.attrs.blockId,pos,node};});
 feedback.hidden=!inspected;if(!inspected)return;
 feedbackTitle.textContent=tr('AI 内容 · 可直接编辑','AI content · Edit directly');commentInput.placeholder=tr('给这一块留修改意见…','Leave feedback on this block…');addComment.textContent=tr('评论','Comment');accepted.textContent=tr('标记已审阅','Mark reviewed');revise.textContent=tr('让 AI 修改这一块','Revise this block with AI');
 comments.replaceChildren();for(const line of (inspected.node.attrs.aiComments||'').split('\n').filter(Boolean))comments.append(el('p',line));
}
function patchInspected(attrs){if(!inspected||!active)return;const node=active.editor.state.doc.nodeAt(inspected.pos);if(node?.attrs.blockId!==inspected.id)return;active.editor.view.dispatch(active.editor.state.tr.setNodeMarkup(inspected.pos,undefined,{...node.attrs,...attrs}));inspectBlock();}
addComment.onclick=()=>{const message=commentInput.value.trim();if(!message||!inspected)return;const old=inspected.node.attrs.aiComments||'';if(old.length+message.length+1>4000){state(tr('评论已满，请在文档中继续补充','Comment limit reached; continue in the document'),true);return;}patchInspected({aiComments:(old?old+'\n':'')+message});commentInput.value='';};
commentInput.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();addComment.click();}};
accepted.onclick=()=>patchInspected({draft:'AI accepted'});
revise.onclick=()=>{if(!inspected||!active)return;const id=inspected.id,notes=inspected.node.attrs.aiComments||'';openInline();selectedSnapshot.ids=[id];instruction.value=notes;instruction.focus();};
setInterval(inspectBlock,700);window.addEventListener('tht-board-language',inspectBlock);

// Local previews only: hovering never sends an external request or changes the document.
const hoverPreview=el('aside','','mother-hover-preview');hoverPreview.hidden=true;hoverPreview.setAttribute('role','tooltip');document.body.append(hoverPreview);
function hidePreview(){hoverPreview.hidden=true;hoverPreview.replaceChildren();}
function showPreview(target){
 const image=target.closest?.('.mother-editor img'),link=target.closest?.('.mother-editor a');if(!image&&!link){hidePreview();return;}
 hoverPreview.replaceChildren();
 if(image&&/^data:image\/(png|jpeg|gif|webp);base64,/i.test(image.getAttribute('src')||'')){const p=el('img');p.src=image.getAttribute('src');p.alt=image.alt||'';hoverPreview.append(p);if(image.alt)hoverPreview.append(el('p',image.alt));}
 else if(link){let u;try{u=new URL(link.href);}catch{hidePreview();return;}if(!['https:','http:','mailto:'].includes(u.protocol)||u.username||u.password){hidePreview();return;}hoverPreview.append(el('strong',link.textContent||u.hostname),el('p',u.hostname||u.pathname),el('small',tr('链接 · 点击打开','Link · Click to open')));}
 else{hidePreview();return;}
 const r=target.getBoundingClientRect();hoverPreview.hidden=false;hoverPreview.style.left=Math.max(8,Math.min(r.left,window.innerWidth-340))+'px';hoverPreview.style.top=Math.max(8,Math.min(r.bottom+8,window.innerHeight-hoverPreview.offsetHeight-12))+'px';
}
host.addEventListener('pointerover',e=>showPreview(e.target));host.addEventListener('pointerout',e=>{if(!e.relatedTarget||!host.contains(e.relatedTarget))hidePreview();});host.addEventListener('focusin',e=>showPreview(e.target));host.addEventListener('focusout',hidePreview);window.addEventListener('scroll',hidePreview,true);window.addEventListener('keydown',e=>{if(e.key==='Escape')hidePreview();});
