// Build verification stamp; displayed UI version comes from each page meta tht-build.
window.THT_BUILD="0.10.0";
