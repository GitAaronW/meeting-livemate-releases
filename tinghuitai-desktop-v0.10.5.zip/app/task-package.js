'use strict';
// Evidence contract shared by meeting work and incoming assignments.
// A package is reference data, never authority to write or send.
const crypto=require('crypto');
const text=(x,n=4000)=>typeof x==='string'?x.slice(0,n):'';
const hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
function reference(value){
 try{
  const u=new URL(value);if(u.protocol!=='https:'||u.username||u.password)return null;
  let provider='',nativeId='',match;
  if(u.hostname==='docs.google.com'&&(match=u.pathname.match(/^\/(document|presentation|spreadsheets)\/d\/([\w-]+)/))){provider='google';nativeId=match[2];}
  else if(/(?:^|\.)(?:larksuite\.com|feishu\.cn)$/.test(u.hostname)&&(match=u.pathname.match(/^\/(?:docx|wiki)\/([\w-]+)/))){provider='lark';nativeId=match[1];}
  else if(/(?:^|\.)notion\.(?:so|site)$/.test(u.hostname)&&(match=u.pathname.match(/([a-f0-9]{32}|[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12})\/?$/i))){provider='notion';nativeId=match[1].replace(/-/g,'').toLowerCase();}
  else if(/(?:^|\.)figma\.com$/.test(u.hostname)&&(match=u.pathname.match(/^\/(?:design|file)\/([\w-]+)/))){provider='figma';nativeId=match[1];}
  if(!nativeId)return null;
  const range=provider==='figma'?u.searchParams.get('node-id')||'':provider==='google'?u.searchParams.get('range')||u.hash:'';
  return {provider,nativeId,url:u.href,range:text(range,240),version:null,access:'not_checked'};
 }catch{return null;}
}
function references(body){const seen=new Set();return (String(body||'').match(/https:\/\/[^\s<>"\u3002\uFF0C]+/g)||[]).map(s=>reference(s.replace(/[),.;]+$/,''))).filter(r=>r&&!seen.has(r.url)&&seen.add(r.url)).slice(0,12);}
function meetingQuotes(session,refs=[]){
 const transcript=session?.transcript||[],wanted=new Set(refs),indexes=new Set(),found=new Set();
 for(let i=0;i<transcript.length;i++){
  const id=transcript[i].id||transcript[i].segId;if(!id)continue;
  const keys=[id,session.id+':'+id];if(!keys.some(k=>wanted.has(k)))continue;
  keys.forEach(k=>{if(wanted.has(k))found.add(k);});
  for(let j=Math.max(0,i-2);j<=Math.min(transcript.length-1,i+2);j++)indexes.add(j);
 }
 const positions=[...indexes].sort((a,b)=>a-b);
 return {quotes:positions.slice(0,24).map(i=>transcript[i]),sourceRefs:refs.slice(0,100),partial:!refs.length||found.size<wanted.size||positions.length>24};
}
function supplementExcerpt(value,goal){
 if(value.length<=6000)return {text:value,truncated:false};
 const terms=[...new Set(String(goal).toLowerCase().match(/[a-z0-9]{3,}|[\u4e00-\u9fff]{2,6}/g)||[])];
 const lines=value.split('\n'),ranked=lines.map((line,i)=>({i,score:terms.reduce((n,t)=>n+(line.toLowerCase().includes(t)?t.length:0),0)})).filter(x=>x.score).sort((a,b)=>b.score-a.score);
 const chosen=new Set();for(const x of ranked.slice(0,8))for(let i=Math.max(0,x.i-1);i<=Math.min(lines.length-1,x.i+1);i++)chosen.add(i);
 let excerpt=[...chosen].sort((a,b)=>a-b).map(i=>lines[i]).join('\n').slice(0,3500);
 return {text:value.slice(0,1000)+'\n[excerpt; middle content omitted]\n'+excerpt+'\n[latest tail excerpt]\n'+value.slice(-1400),truncated:true};
}
function build({key='',goal='',projectId='',origin={},sources=[],materials=[],selection={},targetUrls=[],acceptanceCriteria,taskBinding}={}){
 const rawAcceptance=acceptanceCriteria===undefined?origin.acceptanceCriteria:acceptanceCriteria;
 if(rawAcceptance!=null&&(typeof rawAcceptance!=='string'||rawAcceptance.length>20000))throw Error('Invalid acceptance criteria');
 const acceptance=typeof rawAcceptance==='string'&&rawAcceptance.trim()?rawAcceptance:null;
 const evidence=sources.filter(s=>(s.projectId||'')===projectId).slice(0,8).map(s=>({
  id:text(s.id,100),title:text(s.title,160),url:text(s.url,2000),revision:s.revision??null,
  supplements:(s.calibrations||[]).map(c=>({id:c.id,url:c.url,hash:c.hash,reader:c.reader,remoteRevision:c.remoteRevision,...supplementExcerpt(c.text,goal),summary:text(c.summary,3000),actionRevisions:(c.actions||[]).slice(0,40).map(a=>({kind:a.kind,id:a.id,state:a.state,before:a.before,after:a.after,quotes:a.quotes,sourceId:a.sourceId,sourceHash:a.sourceHash,sourceVersion:a.sourceVersion})),binding:c.binding,fullOriginal:'/meeting-board?id='+encodeURIComponent(s.sessionId)+'&supplement='+c.id})),version:s.version??null,kind:text(s.kind,60),body:text(s.body,6000),notes:text(s.notes,3000),
  // Never describe an attached link as already read.
  access:s.body?'excerpt_available':'not_checked',truncated:typeof s.body==='string'&&s.body.length>6000
 }));
 const attachments=materials.slice(0,12).map(m=>({id:text(m.id,100),name:text(m.name,160),type:text(m.type,100),text:text(m.text,4000),localPath:text(m.path,2000),access:m.text?'excerpt_available':'attached_unread',truncated:typeof m.text==='string'&&m.text.length>4000}));
 const quotes=(origin.quotes||[]).slice(0,24).map(q=>({segmentId:text(q.id||q.segId,100),at:q.at??q.t??null,speaker:text(q.speaker||q.spk,100),speakerVerified:q.speakerVerified===true,text:text(q.text,2000)}));
 const candidates=references(goal+' '+text(origin.body,18000)+' '+evidence.map(s=>s.url).join(' '));
 const targets=targetUrls.slice(0,12).map(reference).filter(Boolean); // Only explicitly selected destinations.
 const packageData={version:1,key:text(key,240),goal:text(goal),projectId,
  origin:{id:text(origin.id,100),url:text(origin.url,2000),provider:text(origin.provider,60),at:origin.at??null,version:origin.version??null,body:text(origin.body,18000),partial:origin.partial===true,sourceRefs:(origin.sourceRefs||[]).slice(0,100),quotes},
  ...(taskBinding?{taskBinding:{taskId:text(taskBinding.id,100),revision:taskBinding.revision??null,sourceId:text(taskBinding.sourceId,100),moduleId:text(taskBinding.moduleId,100)}}:{}),
  targets,candidates,selection:{documentId:text(selection.motherDocumentId,100),blockIds:(selection.blockIds||[]).filter(x=>typeof x==='string').slice(0,12),quote:text(selection.quote)},
  evidence,materials:attachments,
  changes:{request:text(goal),acceptance},
  authority:{mode:'draft',readRelated:true,writeExternal:false,sendMessages:false,overwriteHumanEdits:false},
  gaps:[...(!targets.length&&!selection.motherDocumentId?['target_not_identified']:[]),...targets.map(t=>'target_access_not_checked:'+t.nativeId),...(!quotes.length?['no_meeting_quote']:[]),...(quotes.some(q=>q.speaker&&!q.speakerVerified)?['speaker_identity_unverified']:[]),...(!acceptance?['acceptance_not_specified']:[]),...(origin.partial?['source_partial']:[])]};
 return {...packageData,contentHash:hash(packageData)};
}
// Only explicit host bindings connect a board module to a Hub task. Titles,
// shared speech and proximity cannot establish task identity.
function moduleTask(tasks,source,modules,projectId=''){
 if(!source||modules.length!==1||(source.projectId||'')!==projectId)return null;
 const m=modules[0];
 const matches=(tasks||[]).filter(t=>(t.projectId||'')===projectId&&(t.sourceIds||[]).includes(source.id)&&((m.taskId&&t.id===m.taskId)||(t.moduleId===m.id&&t.moduleSourceId===source.id)));
 if(matches.length!==1)return null;
 return {...matches[0],sourceId:source.id,moduleId:m.id};
}
function moduleAcceptance(...args){return moduleTask(...args)?.acceptanceCriteria||null;}
module.exports={moduleTask,build,reference,references,meetingQuotes,moduleAcceptance};
