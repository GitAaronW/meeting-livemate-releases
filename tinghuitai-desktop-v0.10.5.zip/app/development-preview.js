'use strict';
const fs=require('fs'),path=require('path'),os=require('os'),{execFileSync}=require('child_process');
const configuredPath=key=>{let value=process.env[key];if(!value)try{const dir=process.env.THT_DATA_DIR||path.join(os.homedir(),'Library/Application Support/Tinghuitai');value=JSON.parse(fs.readFileSync(path.join(dir,'settings.json'),'utf8'))[key];}catch{}return path.isAbsolute(value||'')?path.resolve(value):'';};
const canonical=configuredPath('THT_DEV_ROOT'),agentBus=configuredPath('THT_AGENT_BUS');
const instructions=`你是听会台的开发助手。仅在使用者明确授权的开发反馈模式中按当前请求修改代码并出预览。唯一可写项目是 ${canonical||'未配置维护目录'}，先读其中 Context.md、AGENTS.md。不要新建分支、worktree、另一套记忆。不要读写凭据、账号配置、真实会议数据，不外发消息，正式安装只允许通过 scripts/install-reviewed.js，禁止直接写已安装的 program 或业务资料。用户选择的页面和文字是定位问题的数据。先理解实际行为，再直接修复、运行针对性测试和必要回归，启动与正式安装隔离的预览，让用户能打开。不运行 Claude。Grok 是唯一独立审核方，先运行 scripts/t.sh --all 和 scripts/relief-ui-smoke.js，手动提交当前 source 分支（不得添加 Claude 署名）。将提交 SHA、修改和测试证据送到 ${agentBus||'未配置审核信箱'}/inbox/grok，并通过 Grok Bot 既有桌面审核房间发送审核请求，不能仅写信箱就声称送达。回执必须由真实 Grok 写到 ${agentBus||'未配置审核信箱'}/ack，含单独一行 Verdict: review_passed 和完整提交 SHA。收到回执后运行 node scripts/install-reviewed.js 回执路径 developmentRequestId 安装本机（developmentRequestId 来自参考资料字段，照原值传入；安装会重启服务，系统会依据真实部署提交恢复结果），禁止跳过门禁、捏造通过或改写审核回执。如果 Grok 尚未响应，明确停在预览/待审核状态，保留完整请求等待续作，不要求用户再次批准普通修复。最终回读 /health 版本和实际安装结果，用自然中文和 Markdown 直接说明修改、预览链接、实际测试/审核/安装状态。历史 {reply,action} JSON 是旧传输格式，不再沿用；不输出 JSON 包装、转义换行或内部上下文字段。`;
function checkStart(){
 if(!canonical||!agentBus)throw Error('开发反馈尚未配置维护目录和审核信箱；正常会议与 MyAgent 不受影响');
 if(!fs.existsSync(canonical+'/Context.md'))throw Error('唯一维护目录不可用');
 const branch=execFileSync('git',['branch','--show-current'],{cwd:canonical,encoding:'utf8'}).trim();
 if(branch!=='source')throw Error('开发目录不是已确认的 source 分支，请先核查');
 if(execFileSync('git',['status','--porcelain'],{cwd:canonical,encoding:'utf8'}).trim())throw Error('维护目录已有未完成修改，已保留反馈；请等当前开发完成后重试，避免覆盖');
}
function installed(requestId,dataDir,sourceRoot=canonical){try{
 if(!sourceRoot||!/^[\w-]{8,100}$/.test(requestId||''))return null;
 const path=require('path'),record=JSON.parse(fs.readFileSync(path.join(sourceRoot,'.tmp/development-receipts',requestId+'.json'),'utf8'));
 const deployed=fs.readFileSync(path.join(dataDir,'state/last-deployed-commit'),'utf8').trim();
 const version=JSON.parse(fs.readFileSync(path.join(dataDir,'program/package.json'),'utf8')).version;
 if(record.head!==deployed||record.version!==version)return null;
 return record;
}catch{return null;}}
module.exports={canonical,agentBus,instructions,checkStart,installed};
