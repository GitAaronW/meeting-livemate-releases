'use strict';
const {loadMeetings,terms}=require('./tools/local');
const clean=(v,n=240)=>String(v==null?'':v).replace(/\s+/g,' ').trim().slice(0,n);
const genericTitleTerms=new Set('catch up catchup meeting sync review weekly notes discussion 会议 周会 讨论 评审 材料'.split(' '));
const wordSet=v=>new Set(terms(clean(v,240)).filter(t=>!genericTitleTerms.has(t.toLowerCase())));
const overlap=(a,b)=>{let n=0;for(const x of a)if(b.has(x))n++;return n;};
const meetingUrl=id=>'/tinghuitai/archive.html?id='+encodeURIComponent(id);
function normalizeEvent(event={}){return {...event,description:String(event.description||event.agendaText||'')};}
function calendarText(value){
 return String(value||'').replace(/<(script|style)\b[^>]*>[\s\S]*?<\/\1\s*>/gi,'')
  .replace(/<a\b[^>]*href=["'](https:\/\/[^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi,(_,url,label)=>'['+label.replace(/<[^>]*>/g,'')+']('+url+')')
  .replace(/<br\s*\/?\s*>|<\/(?:p|div|li|h[1-6]|tr)>/gi,'\n').replace(/<[^>]*>/g,'')
  .replace(/&(#x[0-9a-f]+|#\d+|amp|lt|gt|quot|apos|nbsp);/gi,(all,key)=>{const names={amp:'&',lt:'<',gt:'>',quot:'"',apos:"'",nbsp:' '};if(key[0]!=='#')return names[key.toLowerCase()]||all;const n=parseInt(key.slice(key[1].toLowerCase()==='x'?2:1),key[1].toLowerCase()==='x'?16:10);return n>0&&n<=0x10ffff?String.fromCodePoint(n):'';});
}
function agendaOf(calendar){const raw=calendarText(normalizeEvent(calendar).description).trim();if(!raw)return[];const m=raw.match(/(?:议程|agenda)\s*[：:]\s*([\s\S]+)/i),body=m?m[1]:raw;return body.split(/\n|[；;]/).map(x=>clean(x.replace(/^\s*(?:[-*•]|\d+[.)、])\s*/,''),Number.MAX_SAFE_INTEGER)).filter(x=>x&&!/^(?:https:\/\/\S+|\[[^\]]+\]\(https:\/\/[^)]+\))$/i.test(x));}
function calendarAttendees(calendar={}){return Array.isArray(calendar.attendees)?calendar.attendees:Array.isArray(calendar.attendeeList)?calendar.attendeeList:[];}
function selectPrevious(meetings,current={}){const titleTerms=wordSet((current.calendar&&current.calendar.title)||current.topicTitle||current.title||''),people=new Set(calendarAttendees(current.calendar||{}).map(x=>clean(x&&(x.name||x),80).toLowerCase()).filter(Boolean)),currentStart=Date.parse(current.start||'')||Number(current.start)||Date.now();let best=null;for(const m of meetings){if(!m||m.id===current.id)continue;const at=Date.parse(m.date||'')||0;if(at>=currentStart)continue;const topicHit=overlap(titleTerms,wordSet(m.title));if(!topicHit)continue;const participantHit=(m.participants||[]).filter(x=>people.has(clean(x,80).toLowerCase())).length,score=topicHit*4+participantHit*3;if(!best||score>best.score||(score===best.score&&at>best.at))best={m,score,at};}return best&&best.score>0?best.m:null;}
function build(dataDir,current={}){const {meetings,skipped}=loadMeetings(dataDir,{max:80}),previous=selectPrevious(meetings,current),lines=[];if(previous){const ref={meetingId:previous.id,title:previous.title,date:previous.date,url:meetingUrl(previous.id)},todo=(previous.briefTodos||[]).find(x=>x&&x.what)||(previous.todos||[]).find(x=>x&&x.text);lines.push({kind:'conclusion',label:'上次结论',text:clean((previous.conclusions||[])[0]||previous.summary,180)||'上次没有形成可引用的结论',ref},{kind:'open',label:'未决事项',text:clean((previous.openQuestions||[])[0],180)||'上次没有记录未决事项',ref},{kind:'todo',label:'没做完的待办',text:clean(todo&&(todo.what||todo.text),180)||'上次没有记录待办',ref});}return{lines,agenda:agendaOf(current.calendar||{}),previous:previous?{id:previous.id,title:previous.title,date:previous.date,url:meetingUrl(previous.id)}:null,scanned:meetings.length,skipped};}
// Preparation uses existing Hub records and explicit calendar links; no network or model call.
function materials(hub,current,event,options={}){
 const {canonical}=require('./work-hub'),start=Date.parse(event.start),currentWork=options.purpose==='current-work',asOf=Date.parse(options.asOf||new Date().toISOString()),byUrl=new Map(),items=[];
 const safe=v=>{try{const u=new URL(String(v).replace(/\\([_~*])/g,'$1'));return u.protocol==='https:'&&!u.username&&!u.password?u.href:'';}catch{return '';}};
 const sources=hub.sources||[],explicit=new Set(current.relatedIds||[]),reused=new Map();
 // Reuse only a user's confirmed project boundary and a previous explicit material link.
 // Titles and automatic project guesses never establish a cross-meeting relationship.
 if(current.projectManual&&current.projectId){
  for(const prior of sources){
   const priorAt=Date.parse(prior.calendarEvent?.start||prior.date||'');
   if(prior.id===current.id||prior.knowledgeRole==='archive'||!prior.projectManual||prior.projectId!==current.projectId||!prior.calendarEvent||!Number.isFinite(priorAt)||priorAt>=start)continue;
   for(const id of prior.relatedIds||[]){const material=sources.find(s=>s.id===id);if(!material||material.calendarEvent||material.knowledgeRole==='archive'||(material.projectId&&material.projectId!==current.projectId))continue;
    const previous=reused.get(id);if(!previous||priorAt>previous.at)reused.set(id,{sourceId:prior.id,title:clean(prior.title,200),at:priorAt});
   }
  }
 }
 const description=calendarText(normalizeEvent(event).description),linkTitles=new Map();
 for(const row of require('./calendar-material-links').links(description)){const url=safe(row.url);if(url&&canonical(url)!==canonical(event.meetingUrl)){byUrl.set(canonical(url),url);if(!linkTitles.has(canonical(url)))linkTitles.set(canonical(url),row.title);}}
 for(const s of sources){
  if(s.id===current.id||s.knowledgeRole==='archive')continue;
  const url=safe(s.url),key=canonical(url),linked=explicit.has(s.id)||reused.has(s.id)||(key&&byUrl.has(key))||(current.projectManual&&current.projectId&&s.projectManual&&s.projectId===current.projectId);
  if(!linked)continue;
  const at=Date.parse(s.fetchedAt||s.readReceipt?.fetchedAt||s.date||s.created||''),afterMeeting=Number.isFinite(at)&&at>start,eligible=currentWork?(!Number.isFinite(at)||at<=asOf):!afterMeeting;
  const role=({master:'正式主稿 / Master',report:'报告 / Report',evidence:'原始证据 / Evidence',reference:'参考 / Reference'})[s.knowledgeRole]||'';
  items.push({meetingRecord:!!s.sessionId&&s.kind!=='file'&&!!(s.calendarEvent||s.kind==='meeting'||s.summary),sourceId:s.id,title:clean(s.title,200),url:url||'/tinghuitai/?id='+encodeURIComponent(s.sessionId||s.id),revision:s.revision||0,role,association:reused.get(s.id)||null,date:s.date||'',read:!!s.body&&eligible&&s.bodyCoverage?.complete!==false&&s.bodyState!=='partial',bodyState:s.bodyState||null,bodyCoverage:s.bodyCoverage||null,bodyContinuation:s.bodyContinuation||null,afterMeeting,eligible,purpose:currentWork?'current-work':'meeting-evidence',readReceipt:s.readReceipt?.bodyFingerprint===require('crypto').createHash('sha256').update(String(s.body||'')).digest('hex').slice(0,24)&&s.readReceipt?.url===s.url?s.readReceipt:null});if(key)byUrl.delete(key);
 }
 for(const url of byUrl.values())items.push({sourceId:'',title:clean(linkTitles.get(canonical(url)),100)||new URL(url).hostname,url,revision:null,role:'',date:'',read:false});
 return items;
}
function preparationModule(hub,current,event,options={}){
 const rows=materials(hub,current,event,options),agenda=agendaOf(event),escape=v=>String(v).replace(/[\\\[\]*`]/g,'\\$&').replace(/\s+/g,' '),body=[];
 // The body is for people. Retrieval roles, read receipts and evidence windows stay
 // in Hub sources and the structured materials lookup, never in the default reading surface.
 const visible=rows.filter(r=>/^https:\/\//.test(r.url)||r.meetingRecord);
 if(agenda.length)body.push('### 议程',...agenda.map(x=>'- '+escape(x)));
 if(visible.length)body.push('### 资料',...visible.map(r=>'- ['+escape(r.title||(r.meetingRecord?'会议记录':new URL(r.url).hostname))+']('+r.url.replace(/\(/g,'%28').replace(/\)/g,'%29')+')'));

 if(!body.length)return null;
 return {id:'premeeting-materials',kind:'note',title:options.purpose==='current-work'?'工作资料':'会前准备',body:body.join('\n'),edited:false,sourceRefs:rows.filter(r=>r.eligible!==false).map(r=>r.sourceId).filter(Boolean)};
}
module.exports={build,agendaOf,selectPrevious,calendarAttendees,materials,preparationModule,normalizeEvent,calendarText};
