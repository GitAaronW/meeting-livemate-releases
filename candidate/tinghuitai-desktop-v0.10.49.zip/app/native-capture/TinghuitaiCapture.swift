import Foundation
import AppKit
import ScreenCaptureKit
import Speech
import AVFoundation
import CoreMedia
import CoreImage
import CoreAudio
import Darwin

// CoreAudio inventory reads metadata only; it never requests capture permission.
struct MicrophoneDevice {
    let id:AudioDeviceID;let uid:String;let name:String;let isDefault:Bool
    var json:[String:Any] { ["uid":uid,"name":name,"isDefault":isDefault] }
}
func microphoneDevices()->[MicrophoneDevice] {
    var address=AudioObjectPropertyAddress(mSelector:kAudioHardwarePropertyDevices,mScope:kAudioObjectPropertyScopeGlobal,mElement:kAudioObjectPropertyElementMain)
    var size:UInt32=0
    guard AudioObjectGetPropertyDataSize(AudioObjectID(kAudioObjectSystemObject),&address,0,nil,&size)==noErr else { return [] }
    var ids=[AudioDeviceID](repeating:0,count:Int(size)/MemoryLayout<AudioDeviceID>.size)
    guard AudioObjectGetPropertyData(AudioObjectID(kAudioObjectSystemObject),&address,0,nil,&size,&ids)==noErr else { return [] }
    var defaultID:AudioDeviceID=0;var defaultSize=UInt32(MemoryLayout<AudioDeviceID>.size)
    address.mSelector=kAudioHardwarePropertyDefaultInputDevice
    _ = AudioObjectGetPropertyData(AudioObjectID(kAudioObjectSystemObject),&address,0,nil,&defaultSize,&defaultID)
    func string(_ id:AudioDeviceID,_ selector:AudioObjectPropertySelector)->String {
        var a=AudioObjectPropertyAddress(mSelector:selector,mScope:kAudioObjectPropertyScopeGlobal,mElement:kAudioObjectPropertyElementMain)
        var value:CFString="" as CFString;var n=UInt32(MemoryLayout<CFString>.size)
        guard AudioObjectGetPropertyData(id,&a,0,nil,&n,&value)==noErr else { return "" };return value as String
    }
    return ids.compactMap { id in
        var a=AudioObjectPropertyAddress(mSelector:kAudioDevicePropertyStreamConfiguration,mScope:kAudioDevicePropertyScopeInput,mElement:kAudioObjectPropertyElementMain);var n:UInt32=0
        guard AudioObjectGetPropertyDataSize(id,&a,0,nil,&n)==noErr,n>0 else { return nil }
        let memory=UnsafeMutableRawPointer.allocate(byteCount:Int(n),alignment:MemoryLayout<AudioBufferList>.alignment);defer { memory.deallocate() }
        guard AudioObjectGetPropertyData(id,&a,0,nil,&n,memory)==noErr else { return nil }
        let buffers=UnsafeMutableAudioBufferListPointer(memory.assumingMemoryBound(to:AudioBufferList.self))
        guard buffers.reduce(0,{$0+Int($1.mNumberChannels)})>0 else { return nil }
        let uid=string(id,kAudioDevicePropertyDeviceUID);guard !uid.isEmpty else { return nil }
        return MicrophoneDevice(id:id,uid:uid,name:string(id,kAudioObjectPropertyName),isDefault:id==defaultID)
    }
}

// Desktop system + microphone capture for the existing meeting Session.
// Cloud ASR uses the configured local relay; otherwise Apple recognition stays local.
struct PageGate {
    var anchor: [UInt8]?; var candidate: [UInt8]?; var stable = 0
    var lastSent: Double = -100
    static func distance(_ a: [UInt8], _ b: [UInt8]) -> Double {
        guard a.count == b.count, !a.isEmpty else { return 1 }
        let changed = zip(a,b).filter { abs(Int($0.0)-Int($0.1)) > 22 }.count
        return Double(changed)/Double(a.count)
    }
    mutating func accepts(_ sample: [UInt8], now: Double) -> Bool {
        if let a = anchor, Self.distance(a,sample) < 0.14 { candidate=nil; stable=0; return false }
        if let c=candidate, Self.distance(c,sample) < 0.055 { stable += 1 }
        else { candidate=sample; stable=1 }
        guard stable >= 3, now-lastSent >= 4 else { return false }
        anchor=sample; candidate=nil; stable=0; lastSent=now; return true
    }
}
// Read activity metadata only; no tap, recording, or new permission is created.
@available(macOS 14.2, *)
func meetingInputProcesses() -> Set<Int32>? {
    var list=AudioObjectPropertyAddress(mSelector:kAudioHardwarePropertyProcessObjectList,mScope:kAudioObjectPropertyScopeGlobal,mElement:kAudioObjectPropertyElementMain)
    var size:UInt32=0
    guard AudioObjectGetPropertyDataSize(AudioObjectID(kAudioObjectSystemObject),&list,0,nil,&size)==noErr else { return nil }
    var objects=[AudioObjectID](repeating:0,count:Int(size)/MemoryLayout<AudioObjectID>.size)
    guard AudioObjectGetPropertyData(AudioObjectID(kAudioObjectSystemObject),&list,0,nil,&size,&objects)==noErr else { return nil }
    var result=Set<Int32>()
    for object in objects {
        var input=AudioObjectPropertyAddress(mSelector:kAudioProcessPropertyIsRunningInput,mScope:kAudioObjectPropertyScopeGlobal,mElement:kAudioObjectPropertyElementMain)
        var active:UInt32=0,n:UInt32=4
        guard AudioObjectGetPropertyData(object,&input,0,nil,&n,&active)==noErr,active != 0 else { continue }
        var address=AudioObjectPropertyAddress(mSelector:kAudioProcessPropertyPID,mScope:kAudioObjectPropertyScopeGlobal,mElement:kAudioObjectPropertyElementMain)
        var pid:Int32=0;n=4
        guard AudioObjectGetPropertyData(object,&address,0,nil,&n,&pid)==noErr,pid != ProcessInfo.processInfo.processIdentifier,let app=NSRunningApplication(processIdentifier:pid) else { continue }
        let b=(app.bundleIdentifier ?? "").lowercased()
        if ["lark","feishu","zoom","teams","chrome","safari","firefox","edge","webex"].contains(where:{b.contains($0)}) { result.insert(pid) }
    }
    return result
}
struct MeetingTarget {
    let window: SCWindow
    var json: [String:Any] { ["windowId":Int(window.windowID), "bundleId":window.owningApplication?.bundleIdentifier ?? "", "title":window.title ?? "会议"] }
}
func recognizedMeeting(bundle: String, title: String) -> Bool {
    let b=bundle.lowercased(), t=title.lowercased()
    if b.contains("lark") || b.contains("feishu") { return ["会议","meeting","视频通话","video call"].contains { t.contains($0) } }
    if b.contains("zoom") { return t.contains("zoom meeting") || t.contains("zoom 会议") }
    if b.contains("teams") {
        // Match English words, not Recall / callback / meetingnotes chat names.
        return t.range(of:"\\b(meeting|call)\\b", options:.regularExpression) != nil
            || t.contains("会议") || t.contains("通话")
    }
    if b.contains("webex") { return t.contains("meeting") || t.contains("会议") }
    let browser=["chrome","safari","edgemac","arc","firefox"].contains { b.contains($0) }
    return browser && (t.contains("google meet") || t.hasPrefix("meet -") || t.hasPrefix("meet –") || t.contains("meet.google.com"))
}
enum CaptureError: LocalizedError {
    // A pinned browser window must still show the same meeting tab.
    case message(String)
    var errorDescription: String? { if case .message(let s)=self { return s }; return nil }
}
final class LocalAPI {
    let base: URL;var owner:String
    init(_ server: String,owner:String="") {
        self.owner=owner
        guard let u=URL(string:server),u.scheme=="http",u.host=="127.0.0.1",u.port != nil else { fatalError("Invalid local server") }
        base=u
    }
    func request(_ route: String, _ body: [String:Any]?=nil) async throws -> [String:Any] {
        var req=URLRequest(url:base.appendingPathComponent("native/"+route));req.timeoutInterval = route == "end" ? 20 : 7
        if !owner.isEmpty { req.setValue(owner,forHTTPHeaderField:"X-THT-Native-Owner") }
        if let body=body { req.httpMethod="POST";req.setValue("application/json",forHTTPHeaderField:"Content-Type");req.httpBody=try JSONSerialization.data(withJSONObject:body) }
        let (data,response)=try await URLSession.shared.data(for:req)
        let j=(try? JSONSerialization.jsonObject(with:data)) as? [String:Any] ?? [:]
        guard (response as? HTTPURLResponse)?.statusCode == 200 else { throw CaptureError.message(j["error"] as? String ?? "本机连接失败") }
        return j
    }
}
// Recognizer partials can revise earlier words. Timestamp boundaries ensure
// a correction to old text does not suppress the following new sentence.
struct SpeechPiece { let start:Double;let end:Double;let range:NSRange }
struct SpeechDelta {
    var through:Double = -1
    mutating func take(_ text:String,pieces:[SpeechPiece],limit:Int?=nil) -> String? {
        let source=text as NSString;let end=min(limit ?? source.length,source.length)
        let fresh=pieces.filter { $0.start >= through-0.05 && $0.end > through+0.02 && NSMaxRange($0.range)<=end }
        guard let first=fresh.first,let last=fresh.last,first.range.location<end else { return nil }
        let value=source.substring(with:NSRange(location:first.range.location,length:end-first.range.location)).trimmingCharacters(in:.whitespacesAndNewlines)
        guard !value.isEmpty else { return nil };through=last.end;return value
    }
}
final class SpeechStream {
    let queue: DispatchQueue; let recognizer: SFSpeechRecognizer
    let emit: (String,String)->Void; let failure:(String)->Void
    var request: SFSpeechAudioBufferRecognitionRequest?; var task:SFSpeechRecognitionTask?
    var epoch=0;var delta=SpeechDelta();var latest="";var pieces:[SpeechPiece]=[];var lastUpdate=Date.distantPast
    var rotate: DispatchSourceTimer?;var silence:DispatchSourceTimer?;var running=false;var errors=0
    init(locale:String, queue:DispatchQueue, emit:@escaping(String,String)->Void, failure:@escaping(String)->Void) throws {
        guard let r=SFSpeechRecognizer(locale:Locale(identifier:locale)),r.supportsOnDeviceRecognition else { throw CaptureError.message("这门语言的本机转写不可用；请在 macOS 下载语音识别语言后重试") }
        self.queue=queue;self.recognizer=r;self.emit=emit;self.failure=failure
    }
    func start() {
        guard !running else { return };running=true;errors=0;open()
        let r=DispatchSource.makeTimerSource(queue:queue);r.schedule(deadline:.now()+20,repeating:20);r.setEventHandler { [weak self] in self?.rotateRequest() };r.resume();rotate=r
        let s=DispatchSource.makeTimerSource(queue:queue);s.schedule(deadline:.now()+1,repeating:0.5);s.setEventHandler { [weak self] in
            guard let self=self,self.running,Date().timeIntervalSince(self.lastUpdate)>1.1 else { return };self.commit(self.latest)
        };s.resume();silence=s
    }
    func open() {
        epoch += 1;let token=epoch;delta=SpeechDelta();latest="";pieces=[]
        let r=SFSpeechAudioBufferRecognitionRequest();r.requiresOnDeviceRecognition=true;r.shouldReportPartialResults=true;r.taskHint = .dictation
        request=r
        task=recognizer.recognitionTask(with:r) { [weak self] result,error in
            guard let self=self else { return };self.queue.async {
                guard self.running,self.epoch==token else { return }
                if let result=result {
                    self.errors=0
                    let transcription=result.bestTranscription;let text=transcription.formattedString
                    self.pieces=transcription.segments.map { SpeechPiece(start:$0.timestamp,end:$0.timestamp+$0.duration,range:$0.substringRange) }
                    if text != self.latest { self.lastUpdate=Date();self.latest=text }
                    if result.isFinal { self.commit(text);self.rotateRequest();return }
                    if let end=text.range(of:"[。！？.!?]",options:[.regularExpression,.backwards]) {
                        self.commit(String(text[..<end.upperBound]))
                    }
                }
                if let error=error, (error as NSError).code != 216 {
                    self.failure("本机转写暂时中断："+error.localizedDescription)
                    self.errors += 1
                    if self.errors >= 3 { self.stop() }
                }
            }
        }
    }
    func commit(_ text:String) {
        if let tail=delta.take(latest,pieces:pieces,limit:text.utf16.count) { emit(UUID().uuidString,tail) }
    }
    func rotateRequest() { guard running else { return };commit(latest);request?.endAudio();task?.cancel();open() }
    func append(_ buffer:CMSampleBuffer) { if running { request?.appendAudioSampleBuffer(buffer) } }
    func append(_ buffer:AVAudioPCMBuffer) { if running { request?.append(buffer) } }
    func stop() { commit(latest);running=false;rotate?.cancel();silence?.cancel();request?.endAudio();task?.cancel();request=nil;task=nil;epoch += 1 }
}
// Both sources share the host clock. Never concatenate microphone buffers onto
// system buffers: doing so doubles time and loses overlapping speech.
struct TimelineMixer {
    let origin:Double
    var through=0
    var blocks:[Int:[Float]]=[:]
    mutating func add(_ values:[Float],at:Double) {
        let start=Int(((at-origin)*16000).rounded())
        guard start < through*320+16000*30 else { return }
        for (i,value) in values.enumerated() {
            let sample=start+i;guard sample>=through*320 else { continue }
            let block=sample/320,offset=sample%320
            if blocks[block]==nil { blocks[block]=[Float](repeating:0,count:320) }
            blocks[block]![offset] += value.isFinite ? value:0
        }
    }
    mutating func drain(to time:Double,final:Bool=false)->[[Float]] {
        let target=final ? (blocks.keys.max().map{$0+1} ?? through):max(through,Int((time-origin)*50)-10)
        guard target>through else { return [] }
        var result:[[Float]]=[]
        while through<target { result.append((blocks.removeValue(forKey:through) ?? [Float](repeating:0,count:320)).map{max(-1,min(1,$0))});through += 1 }
        return result
    }
}
final class CaptureEngine: NSObject, SCStreamOutput, SCStreamDelegate {
    let queue=DispatchQueue(label:"com.aaron.tinghuitai.capture")
    let ci=CIContext(options:[.cacheIntermediates:false])
    let pcm:(Data)->Void;var pendingPCM=Data();let text:(String,String)->Void;let frame:(Data)->Void;let failure:(String)->Void
    var screen:SCStream?;var audio:SCStream?;var speech:SpeechStream?;var file:FileHandle?
    var inputUID="";var inputName=""
    var microphone:AVAudioEngine?;var mixTimer:DispatchSourceTimer?;var mixer=TimelineMixer(origin:ProcessInfo.processInfo.systemUptime)
    let mixedFormat=AVAudioFormat(commonFormat:.pcmFormatFloat32,sampleRate:16000,channels:1,interleaved:false)!
    var microphoneFrames=0;var systemFrames=0;var microphonePeak:Float=0;var systemPeak:Float=0;var microphoneLastAt=Date.distantPast;var systemLastAt=Date.distantPast;var microphoneLevel:Float=0;var systemLevel:Float=0
    func audioEvidence()->[String:Any] { queue.sync { ["microphoneFrames":microphoneFrames,"systemFrames":systemFrames,"microphonePeak":microphonePeak,"systemPeak":systemPeak,"microphoneLevel":Date().timeIntervalSince(microphoneLastAt)<1 ? microphoneLevel:0,"systemLevel":Date().timeIntervalSince(systemLastAt)<1 ? systemLevel:0] } }
    let meterLock=NSLock()
    func meterSnapshot()->Double { meterLock.lock();defer{meterLock.unlock()};return Date().timeIntervalSince(audioLevelAt)<1 ? audioLevel:0 }
    var gate=PageGate();var seconds:Double=0;var audioLevel:Double=0;var audioLevelAt=Date.distantPast;var paused=false;var closing=false
    init(pcm:@escaping(Data)->Void,text:@escaping(String,String)->Void,frame:@escaping(Data)->Void,failure:@escaping(String)->Void) { self.pcm=pcm;self.text=text;self.frame=frame;self.failure=failure }
    func start(target:MeetingTarget?,content:SCShareableContent,locale:String,audioPath:String,cloudASR:Bool,inputUID:String="") async throws {
        guard let display=content.displays.first else { throw CaptureError.message("没有可采集的显示器") }
        guard FileManager.default.fileExists(atPath:audioPath) else { throw CaptureError.message("本机录音文件未创建") }
        file=try FileHandle(forWritingTo:URL(fileURLWithPath:audioPath));try file?.seekToEnd()
        if !cloudASR { speech=try SpeechStream(locale:locale,queue:queue,emit:text,failure:failure)
        queue.sync { speech?.start() } }
        if let target=target { let size=target.window.frame.size;let scale=min(1,960/max(size.width,size.height))
        let vc=SCStreamConfiguration();vc.width=max(32,Int(size.width*scale));vc.height=max(32,Int(size.height*scale));vc.minimumFrameInterval=CMTime(value:1,timescale:3);vc.showsCursor=false;vc.queueDepth=3;vc.capturesAudio=false
        let vs=SCStream(filter:SCContentFilter(desktopIndependentWindow:target.window),configuration:vc,delegate:self)
        try vs.addStreamOutput(self,type:.screen,sampleHandlerQueue:queue);screen=vs }
        let ac=SCStreamConfiguration();ac.capturesAudio=true;ac.sampleRate=16000;ac.channelCount=1;ac.excludesCurrentProcessAudio=true;ac.width=32;ac.height=32;ac.minimumFrameInterval=CMTime(value:1,timescale:1)
        let own=content.applications.filter { $0.processID==ProcessInfo.processInfo.processIdentifier }
        let a=SCStream(filter:SCContentFilter(display:display,excludingApplications:own,exceptingWindows:[]),configuration:ac,delegate:self)
        try a.addStreamOutput(self,type:.audio,sampleHandlerQueue:queue);audio=a
        do {
            try switchMicrophone(uid:inputUID)
            queue.sync { mixer=TimelineMixer(origin:ProcessInfo.processInfo.systemUptime) }
            try await screen?.startCapture();try await a.startCapture()
            let timer=DispatchSource.makeTimerSource(queue:queue);timer.schedule(deadline:.now(),repeating:.milliseconds(20));timer.setEventHandler { [weak self] in self?.flushMix() };mixTimer=timer;timer.resume()
        }
        catch { await stop();throw error }
    }
    // Start the replacement first. System stream, timeline, file and ASR stay intact.
    func switchMicrophone(uid:String) throws {
        guard !closing else { throw CaptureError.message("会议已结束") }
        let devices=microphoneDevices()
        guard let device=devices.first(where:{ uid.isEmpty ? $0.isDefault:$0.uid==uid }) else { throw CaptureError.message("所选麦克风已断开；原声音来源保持不变") }
        if microphone != nil && inputUID==device.uid { return }
        let mic=AVAudioEngine(),input=mic.inputNode
        guard let unit=input.audioUnit else { throw CaptureError.message("无法连接麦克风") }
        var deviceID=device.id
        guard AudioUnitSetProperty(unit,kAudioOutputUnitProperty_CurrentDevice,kAudioUnitScope_Global,0,&deviceID,UInt32(MemoryLayout<AudioDeviceID>.size))==noErr else { throw CaptureError.message("无法切换到所选麦克风；原声音来源保持不变") }
        var actualID:AudioDeviceID=0;var actualSize=UInt32(MemoryLayout<AudioDeviceID>.size)
        guard AudioUnitGetProperty(unit,kAudioOutputUnitProperty_CurrentDevice,kAudioUnitScope_Global,0,&actualID,&actualSize)==noErr,actualID==device.id else { throw CaptureError.message("录音端未确认所选麦克风；原声音来源保持不变") }
        let inputFormat=input.outputFormat(forBus:0)
            guard inputFormat.sampleRate>0,inputFormat.channelCount>0,let converter=AVAudioConverter(from:inputFormat,to:mixedFormat) else { throw CaptureError.message("麦克风不可用，未开始仅录系统声音的会议") }
            input.installTap(onBus:0,bufferSize:2048,format:inputFormat) { [weak self] buffer,time in
                guard let self=self,let converted=AVAudioPCMBuffer(pcmFormat:self.mixedFormat,frameCapacity:AVAudioFrameCount(Double(buffer.frameLength)*16000/inputFormat.sampleRate)+32) else { return }
                var supplied=false;var conversionError:NSError?
                converter.convert(to:converted,error:&conversionError) { _,status in
                    if supplied { status.pointee = .noDataNow;return nil };supplied=true;status.pointee = .haveData;return buffer
                }
                if let error=conversionError { self.queue.async { if self.microphone === mic && !self.closing { self.failure("麦克风采集失败："+error.localizedDescription) } };return }
                guard let samples=converted.floatChannelData?[0] else { return }
                let values=Array(UnsafeBufferPointer(start:samples,count:Int(converted.frameLength))),at=AVAudioTime.seconds(forHostTime:time.hostTime)
                self.queue.async { if self.microphone === mic && !self.paused && !self.closing { self.microphoneFrames+=values.count;self.microphoneLastAt=Date();self.microphoneLevel=values.reduce(0){max($0,abs($1))};self.microphonePeak=max(self.microphonePeak,values.reduce(0){max($0,abs($1))});self.mixer.add(values,at:at) } }
            }
        do { try mic.start() } catch { input.removeTap(onBus:0);mic.stop();throw error }
        let old=queue.sync { ()->AVAudioEngine? in
            let previous=microphone;microphone=mic;inputUID=device.uid;inputName=device.name;return previous
        }
        old?.inputNode.removeTap(onBus:0);old?.stop()

    }
    func pause(_ value:Bool) async {
        await withCheckedContinuation { (c:CheckedContinuation<Void,Never>) in queue.async { self.paused=value;if value { self.flushMix(final:true);self.speech?.stop() } else { self.mixer=TimelineMixer(origin:ProcessInfo.processInfo.systemUptime);self.gate=PageGate();self.speech?.start() };c.resume() } }
    }
    func stop() async {
        closing=true;microphone?.inputNode.removeTap(onBus:0);microphone?.stop();microphone=nil;mixTimer?.cancel();mixTimer=nil;try? await screen?.stopCapture();try? await audio?.stopCapture()
        await withCheckedContinuation { (c:CheckedContinuation<Void,Never>) in queue.async { self.flushMix(final:true);self.speech?.stop();try? self.file?.synchronize();try? self.file?.close();self.file=nil;c.resume() } }
        screen=nil;audio=nil
    }
    func stream(_ stream:SCStream,didStopWithError error:Error) { if !closing { failure("会议采集已中断："+error.localizedDescription) } }
    func stream(_ stream:SCStream,didOutputSampleBuffer sampleBuffer:CMSampleBuffer,of type:SCStreamOutputType) {
        guard !paused,!closing,sampleBuffer.isValid else { return }
        if type == .audio {
            acceptSystemAudio(sampleBuffer)
            return
        }
        guard type == .screen,let pixel=sampleBuffer.imageBuffer else { return }
        if let a=CMSampleBufferGetSampleAttachmentsArray(sampleBuffer,createIfNecessary:false) as? [[SCStreamFrameInfo:Any]],let raw=a.first?[.status] as? Int,raw != SCFrameStatus.complete.rawValue { return }
        let image=CIImage(cvPixelBuffer:pixel);let extent=image.extent
        let thumb=image.transformed(by:CGAffineTransform(scaleX:64/extent.width,y:36/extent.height))
        var luminance=[UInt8](repeating:0,count:64*36)
        luminance.withUnsafeMutableBytes { ci.render(thumb,toBitmap:$0.baseAddress!,rowBytes:64,bounds:CGRect(x:0,y:0,width:64,height:36),format:.L8,colorSpace:CGColorSpaceCreateDeviceGray()) }
        guard gate.accepts(luminance,now:ProcessInfo.processInfo.systemUptime),let cg=ci.createCGImage(image,from:extent) else { return }
        let bitmap=NSBitmapImageRep(cgImage:cg)
        for quality in [0.55,0.35,0.20] { if let jpeg=bitmap.representation(using:.jpeg,properties:[.compressionFactor:quality]),jpeg.count<=160000 { frame(jpeg);return } }
    }
    func acceptSystemAudio(_ sampleBuffer:CMSampleBuffer) {
        do { let values=try systemSamples(sampleBuffer);systemFrames+=values.count;systemLastAt=Date();systemLevel=values.reduce(0){max($0,abs($1))};systemPeak=max(systemPeak,systemLevel);mixer.add(values,at:CMSampleBufferGetPresentationTimeStamp(sampleBuffer).seconds) }
        catch { failure("系统声音采集失败："+error.localizedDescription) }
    }
    func systemSamples(_ sample:CMSampleBuffer) throws -> [Float] {
        guard let desc=sample.formatDescription,let format=CMAudioFormatDescriptionGetStreamBasicDescription(desc)?.pointee else { return [] }
        guard format.mFormatID==kAudioFormatLinearPCM,format.mChannelsPerFrame==1,abs(format.mSampleRate-16000)<1 else { throw CaptureError.message("系统声音格式不符合本机录音要求") }
        var list=AudioBufferList(mNumberBuffers:1,mBuffers:AudioBuffer(mNumberChannels:1,mDataByteSize:0,mData:nil));var block:CMBlockBuffer?
        let code=CMSampleBufferGetAudioBufferListWithRetainedBlockBuffer(sample,bufferListSizeNeededOut:nil,bufferListOut:&list,bufferListSize:MemoryLayout<AudioBufferList>.size,blockBufferAllocator:nil,blockBufferMemoryAllocator:nil,flags:0,blockBufferOut:&block)
        guard code==noErr,let ptr=list.mBuffers.mData else { throw CaptureError.message("系统声音缓冲区不可读") }
        let count=CMSampleBufferGetNumSamples(sample)
        // Reject truncated/foreign PCM before constructing an unsafe buffer.
        let bytesPerSample=Int(format.mBitsPerChannel/8)
        guard count>0,bytesPerSample>0,count<=Int(list.mBuffers.mDataByteSize)/bytesPerSample,
              format.mFormatFlags & kAudioFormatFlagIsBigEndian == 0 else {
            throw CaptureError.message("系统声音缓冲区长度或字节序无效")
        }
        if format.mFormatFlags & kAudioFormatFlagIsFloat != 0 && format.mBitsPerChannel==32 {
            return Array(UnsafeBufferPointer(start:ptr.assumingMemoryBound(to:Float.self),count:count))
        } else if format.mBitsPerChannel==16 && format.mFormatFlags & kAudioFormatFlagIsSignedInteger != 0 { return UnsafeBufferPointer(start:ptr.assumingMemoryBound(to:Int16.self),count:count).map{Float($0)/32768} }
        else { throw CaptureError.message("系统声音编码暂不支持") }
    }
    func flushMix(final:Bool=false) {
        guard final || (!paused && !closing) else { return }
        for values in mixer.drain(to:ProcessInfo.processInfo.systemUptime,final:final) {
            guard let buffer=AVAudioPCMBuffer(pcmFormat:mixedFormat,frameCapacity:320),let samples=buffer.floatChannelData?[0] else { continue }
            buffer.frameLength=320;for i in 0..<320 { samples[i]=values[i] };speech?.append(buffer)
            let pcm=values.map{Int16(max(-32768,min(32767,Int($0*32767))))},bytes=pcm.withUnsafeBytes{Data($0)}
            let power=values.reduce(0.0){$0+Double($1*$1)}
            meterLock.lock();audioLevel=min(1,sqrt(power/320)*5);audioLevelAt=Date();meterLock.unlock()
            do { try file?.write(contentsOf:bytes);seconds += 0.02;if speech==nil { pendingPCM.append(bytes);if pendingPCM.count>=6400 { self.pcm(pendingPCM);pendingPCM.removeAll(keepingCapacity:true) } } } catch { failure("原始录音保存失败："+error.localizedDescription) }
        }
        if final && !pendingPCM.isEmpty { self.pcm(pendingPCM);pendingPCM.removeAll(keepingCapacity:true) }
    }
}
final class AudioMeter:NSView {
    var level:Double=0 { didSet { needsDisplay=true } }
    override var intrinsicContentSize:NSSize { NSSize(width:30,height:18) }
    override func draw(_ dirtyRect:NSRect) {
        let value=max(0,min(1,level));let weights:[Double]=[0.45,0.8,1,0.65,0.35]
        for (i,w) in weights.enumerated() {
            let h=max(3,CGFloat(value*w)*16)
            (value>0.015 ? NSColor.controlAccentColor:NSColor.tertiaryLabelColor).setFill()
            NSBezierPath(roundedRect:NSRect(x:CGFloat(i)*6,y:(bounds.height-h)/2,width:3,height:h),xRadius:1.5,yRadius:1.5).fill()
        }
    }
}
enum MiniView:String { case expanded,compact,transcript,hidden }
// Presentation never owns the recording lifecycle. Preserve the top-right anchor.
func miniFrame(_ old:NSRect,size:NSSize,screens:[NSRect])->NSRect {
    guard let screen=screens.max(by:{ a,b in
        let ia=old.intersection(a),ib=old.intersection(b)
        return (ia.isNull ? 0:ia.width*ia.height)<(ib.isNull ? 0:ib.width*ib.height)
    }) else { return NSRect(x:old.maxX-size.width,y:old.maxY-size.height,width:size.width,height:size.height) }
    let width=min(size.width,screen.width),height=min(size.height,screen.height)
    return NSRect(x:min(max(old.maxX-width,screen.minX),screen.maxX-width),y:min(max(old.maxY-height,screen.minY),screen.maxY-height),width:width,height:height)
}
final class MeetingPanel:NSPanel {
    var onHide:(()->Void)?
    override var canBecomeKey:Bool { true };override var canBecomeMain:Bool { false }
    override func cancelOperation(_ sender:Any?) { onHide?() }
}
final class CapsuleSurface:NSView {
    var hoverChanged:((Bool)->Void)?
    override func updateTrackingAreas() {
        super.updateTrackingAreas()
        for area in trackingAreas { removeTrackingArea(area) }
        addTrackingArea(NSTrackingArea(rect:.zero,options:[.mouseEnteredAndExited,.activeAlways,.inVisibleRect],owner:self,userInfo:nil))
    }
    override func mouseEntered(with event:NSEvent) { hoverChanged?(true) }
    override func mouseExited(with event:NSEvent) { hoverChanged?(false) }
}
// Expand the full reminder inside the same mini window.
final class FlippedCardStack:NSStackView { override var isFlipped:Bool { true } }
final class MiniInsightButton:NSButton {
    let category:String;let bodyText:String;var expanded=false;var sourceLabel="";var stableKey="";var readMore="展开全文";var collapse="收起"
    init(category:String,text:String,target:AnyObject?,action:Selector) {
        self.category=category;bodyText=text
        super.init(frame:.zero);title=category+" · "+text;self.target=target;self.action=action
        isBordered=false;setButtonType(.momentaryPushIn);toolTip=title
    }
    required init?(coder:NSCoder) { fatalError("init(coder:) has not been implemented") }
    override var intrinsicContentSize:NSSize {
        let paragraph=NSMutableParagraphStyle();paragraph.lineBreakMode = .byWordWrapping;paragraph.minimumLineHeight=17;paragraph.maximumLineHeight=17
        let rect=(bodyText as NSString).boundingRect(with:NSSize(width:258,height:6000),options:[.usesLineFragmentOrigin,.usesFontLeading],attributes:[.font:NSFont.systemFont(ofSize:13),.paragraphStyle:paragraph])
        return NSSize(width:282,height:50+(expanded ? max(17,ceil(rect.height)):min(51,max(17,ceil(rect.height)))))
    }
    override func draw(_ dirtyRect:NSRect) {
        let shape=NSBezierPath(roundedRect:bounds.insetBy(dx:0.5,dy:0.5),xRadius:10,yRadius:10)
        (isHighlighted ? NSColor.controlAccentColor.withAlphaComponent(0.1):NSColor.controlBackgroundColor).setFill();shape.fill()
        NSColor.separatorColor.withAlphaComponent(0.5).setStroke();shape.lineWidth=1;shape.stroke()
        (category as NSString).draw(at:NSPoint(x:12,y:bounds.height-21),withAttributes:[.font:NSFont.systemFont(ofSize:10,weight:.semibold),.foregroundColor:NSColor.secondaryLabelColor])
        ((expanded ? "−":"+") as NSString).draw(at:NSPoint(x:bounds.width-22,y:bounds.height-21),withAttributes:[.font:NSFont.systemFont(ofSize:11),.foregroundColor:NSColor.tertiaryLabelColor])
        let paragraph=NSMutableParagraphStyle();paragraph.lineBreakMode = .byWordWrapping;paragraph.minimumLineHeight=17;paragraph.maximumLineHeight=17
        (bodyText as NSString).draw(with:NSRect(x:12,y:25,width:258,height:bounds.height-50),options:expanded ? [.usesLineFragmentOrigin]:[.usesLineFragmentOrigin,.truncatesLastVisibleLine],attributes:[.font:NSFont.systemFont(ofSize:13),.foregroundColor:NSColor.labelColor,.paragraphStyle:paragraph])
        let footer=[sourceLabel,expanded ? collapse:readMore].filter { !$0.isEmpty }.joined(separator:" · ")
        (footer as NSString).draw(at:NSPoint(x:12,y:8),withAttributes:[.font:NSFont.systemFont(ofSize:10),.foregroundColor:NSColor.secondaryLabelColor])
    }
}
final class AppDelegate:NSObject,NSApplicationDelegate,NSWindowDelegate {
    let api:LocalAPI;let locale:String;let english:Bool;let autoStart:Bool
    var panel:MeetingPanel!;var status:NSTextField!;var cards=FlippedCardStack();var startButton:NSButton!;var pauseButton:NSButton!;var endButton:NSButton!
    var terminateAfterSave=false;var quitInFlight=false;var quitApproved=false
    var mirroring=false;var meter=AudioMeter();var compactMeter=AudioMeter();var sessionId="";var lastSessionId="";var transportIssue=false;var transportMessage="";var lastMicrophoneRequest="";var lastMicrophoneError="";var heartbeating=false;var engine:CaptureEngine?;var busy=false;var paused=false;var error="";var tick:Timer?
    var audioQueue:[(Int,Data)]=[];var nextAudioSequence=1;var cloudASR=false;var textQueue:[(String,String)]=[];var pendingFrame:Data?;var sending=false;var lastCards="";var lastHeartbeat=Date()
    var lastPanelPolicyKey="",dismissedPanelSession=""
    var viewMode=MiniView.expanded;var expandedRoot:NSStackView!;var compactRoot:NSStackView!;var compactButton:NSButton!;var compactPause:NSButton!;var compactEnd:NSButton!;var compactStart:NSButton!;var mirrorSeconds:Double=0;var statusItem:NSStatusItem!;var pauseItem:NSMenuItem!;var endItem:NSMenuItem!;var expandedHeight:CGFloat=170;var cardCount=0
    var transcriptRoot:NSStackView!;var insightEntry:NSButton!;var transcriptEntry:NSButton!
    var hoverPanel:MeetingPanel?;var hoverText:NSTextView?;var hoverDismiss:DispatchWorkItem?
    var hovering=false;var recentTranscript="";var transcriptPreview:NSTextView!;var transcriptScroll=NSScrollView();var notNowButton:NSButton!
    var watchScanAt=Date.distantPast;var notifiedWindows=[UInt32:Date]();var watchEnabled=true
    var showHistory=false;var expandedCards=Set<String>();var historySession="";var presentedRoot:NSStackView?;var presentationConstraints:[NSLayoutConstraint]=[];var cardScroll=NSScrollView();var cardViewport:NSLayoutConstraint!;var joinTarget:UInt32?
    init(server:String,locale:String,english:Bool,autoStart:Bool,owner:String="") { api=LocalAPI(server,owner:owner);self.locale=locale;self.english=english;self.autoStart=autoStart }
    func tr(_ zh:String,_ en:String)->String { english ? en : zh }
    func applicationDidFinishLaunching(_ notification:Notification) {
        DistributedNotificationCenter.default().addObserver(self,selector:#selector(claimOwner(_:)),name:Notification.Name("LiveMateCaptureOwner"),object:String(api.base.port!))
        if !api.owner.isEmpty { Task { @MainActor in
            do { _ = try await api.request("owner-helper-ready",["pid":Int(ProcessInfo.processInfo.processIdentifier)]) }
            catch { showError("主窗口归属未确认，请从主窗口重新打开小窗") }
        } }
        NSApp.setActivationPolicy(.accessory)
        panel=MeetingPanel(contentRect:NSRect(x:0,y:0,width:310,height:170),styleMask:[.borderless,.nonactivatingPanel],backing:.buffered,defer:false)
        panel.title=tr("听会台 · 小窗","LiveMate · Mini");panel.level = .floating;panel.isFloatingPanel=true;panel.hidesOnDeactivate=false;panel.isReleasedWhenClosed=false
        panel.collectionBehavior=[.canJoinAllSpaces,.fullScreenAuxiliary];panel.standardWindowButton(.zoomButton)?.isHidden=true;panel.standardWindowButton(.miniaturizeButton)?.isHidden=true
        panel.isOpaque=false;panel.backgroundColor = .clear;panel.hasShadow=true
        let surface=CapsuleSurface();surface.wantsLayer=true;surface.layer?.cornerRadius=19
        surface.layer?.backgroundColor=NSColor.windowBackgroundColor.cgColor
        surface.layer?.borderWidth=1;surface.layer?.borderColor=NSColor.separatorColor.withAlphaComponent(0.5).cgColor
        surface.hoverChanged={ [weak self] inside in self?.setTranscriptHover(inside) }
        panel.contentView=surface
        panel.delegate=self;panel.isMovableByWindowBackground=true;panel.onHide={ [weak self] in self?.hidePanel() }
        panel.standardWindowButton(.closeButton)?.toolTip=tr("隐藏小窗，听会继续","Hide mini window; keep listening")
        let root=NSStackView();root.orientation = .vertical;root.alignment = .leading;root.spacing=10;root.edgeInsets=NSEdgeInsets(top:10,left:14,bottom:10,right:14);root.translatesAutoresizingMaskIntoConstraints=false
        expandedRoot=root
        let heading=NSStackView();heading.spacing=8;heading.translatesAutoresizingMaskIntoConstraints=false;root.addArrangedSubview(heading);heading.widthAnchor.constraint(equalToConstant:282).isActive=true
        status=NSTextField(wrappingLabelWithString:tr("切回会议窗口，点开始","Return to your meeting and press Start"));status.font = .systemFont(ofSize:12);status.maximumNumberOfLines=2;status.lineBreakMode = .byTruncatingTail;status.textColor = .secondaryLabelColor;status.setContentCompressionResistancePriority(.defaultLow,for:.horizontal);heading.addArrangedSubview(meter);heading.addArrangedSubview(status)
        let fold=NSButton(title:tr("收起","Collapse"),target:self,action:#selector(collapsePanel));fold.bezelStyle = .rounded;fold.toolTip=tr("缩成迷你条，听会继续","Collapse to a mini bar; keep listening");heading.addArrangedSubview(fold)
        cards.orientation = .vertical;cards.alignment = .leading;cards.spacing=8
        cardScroll.documentView=cards;cardScroll.hasVerticalScroller=true;cardScroll.autohidesScrollers=true;cardScroll.drawsBackground=false;cardScroll.borderType = .noBorder;cardScroll.translatesAutoresizingMaskIntoConstraints=false;root.addArrangedSubview(cardScroll)
        cardScroll.widthAnchor.constraint(equalToConstant:282).isActive=true;cardViewport=cardScroll.heightAnchor.constraint(equalToConstant:0);cardViewport.isActive=true;cardScroll.isHidden=true
        let controls=NSStackView();controls.spacing=8;root.addArrangedSubview(controls)
        startButton=NSButton(title:tr("开始","Start"),target:self,action:#selector(startClicked));startButton.bezelStyle = .rounded;controls.addArrangedSubview(startButton)
        pauseButton=NSButton(title:tr("暂停","Pause"),target:self,action:#selector(pauseClicked));pauseButton.bezelStyle = .rounded;pauseButton.isHidden=true;controls.addArrangedSubview(pauseButton)
        endButton=NSButton(title:tr("结束","End"),target:self,action:#selector(endClicked));endButton.bezelStyle = .rounded;endButton.isHidden=true;controls.addArrangedSubview(endButton)
        let expand=NSButton(title:tr("听会台 ↗","Open LiveMate ↗"),target:self,action:#selector(openMain));expand.bezelStyle = .rounded;controls.addArrangedSubview(expand)
        // One narrow, draggable capsule. Disclosure never starts/stops capture.
        compactRoot=NSStackView();compactRoot.orientation = .vertical;compactRoot.alignment = .centerX;compactRoot.spacing=2;compactRoot.edgeInsets=NSEdgeInsets(top:8,left:8,bottom:8,right:8);compactRoot.translatesAutoresizingMaskIntoConstraints=false
        func icon(_ name:String,_ label:String,_ action:Selector)->NSButton {
            let b=NSButton(title:"",target:self,action:action);b.isBordered=false;b.setButtonType(.momentaryPushIn)
            b.image=NSImage(systemSymbolName:name,accessibilityDescription:label);b.imagePosition = .imageOnly
            b.toolTip=label;b.setAccessibilityLabel(label)
            b.widthAnchor.constraint(equalToConstant:44).isActive=true;b.heightAnchor.constraint(equalToConstant:36).isActive=true
            return b
        }
        insightEntry=icon("lightbulb",tr("主动智能","Intelligence"),#selector(toggleIntelligence));compactRoot.addArrangedSubview(insightEntry)
        compactRoot.addArrangedSubview(compactMeter)
        compactButton=NSButton(title:"00:00",target:self,action:#selector(openMain));compactButton.isBordered=false;compactButton.font = .monospacedDigitSystemFont(ofSize:10,weight:.medium);compactButton.widthAnchor.constraint(equalToConstant:44).isActive=true;compactButton.heightAnchor.constraint(equalToConstant:24).isActive=true;compactButton.setAccessibilityLabel(tr("打开听会台","Open LiveMate"));compactRoot.addArrangedSubview(compactButton)
        compactPause=icon("pause",tr("暂停听会","Pause listening"),#selector(pauseClicked));compactRoot.addArrangedSubview(compactPause)
        compactStart=icon("record.circle",tr("开始听会","Start listening"),#selector(startClicked));compactRoot.addArrangedSubview(compactStart)
        transcriptEntry=icon("captions.bubble",tr("逐字稿 · CC","Transcript · CC"),#selector(toggleTranscript));compactRoot.addArrangedSubview(transcriptEntry)
        compactEnd=icon("stop",tr("结束并保存","End and save"),#selector(endClicked));compactRoot.addArrangedSubview(compactEnd)
        notNowButton=icon("xmark",tr("暂不开始","Not now"),#selector(dismissDetection));notNowButton.isHidden=true;compactRoot.addArrangedSubview(notNowButton)
        transcriptRoot=NSStackView();transcriptRoot.orientation = .vertical;transcriptRoot.alignment = .leading;transcriptRoot.spacing=10;transcriptRoot.edgeInsets=NSEdgeInsets(top:12,left:14,bottom:12,right:14);transcriptRoot.translatesAutoresizingMaskIntoConstraints=false
        let transcriptHeading=NSStackView();transcriptHeading.spacing=8;transcriptHeading.widthAnchor.constraint(equalToConstant:282).isActive=true
        let ccTitle=NSTextField(labelWithString:tr("实时逐字稿","Live transcript"));ccTitle.font = .systemFont(ofSize:13,weight:.semibold);transcriptHeading.addArrangedSubview(ccTitle)
        let ccFold=NSButton(title:tr("收起","Collapse"),target:self,action:#selector(collapsePanel));ccFold.bezelStyle = .rounded;transcriptHeading.addArrangedSubview(ccFold);transcriptRoot.addArrangedSubview(transcriptHeading)
        transcriptPreview=NSTextView(frame:NSRect(x:0,y:0,width:282,height:240));transcriptPreview.font = .systemFont(ofSize:13);transcriptPreview.textColor = .labelColor;transcriptPreview.isEditable=false;transcriptPreview.isSelectable=true;transcriptPreview.drawsBackground=false;transcriptPreview.isVerticallyResizable=true;transcriptPreview.isHorizontallyResizable=false;transcriptPreview.autoresizingMask = [.width];transcriptPreview.textContainer?.widthTracksTextView=true
        transcriptScroll.documentView=transcriptPreview;transcriptScroll.hasVerticalScroller=true;transcriptScroll.autohidesScrollers=true;transcriptScroll.drawsBackground=false;transcriptScroll.translatesAutoresizingMaskIntoConstraints=false;transcriptRoot.addArrangedSubview(transcriptScroll);transcriptScroll.widthAnchor.constraint(equalToConstant:282).isActive=true;transcriptScroll.heightAnchor.constraint(equalToConstant:240).isActive=true
        let ccOpen=NSButton(title:tr("在听会台查看全部","View all in LiveMate"),target:self,action:#selector(openMain));ccOpen.bezelStyle = .rounded;transcriptRoot.addArrangedSubview(ccOpen)
        setupMenu()
        if let rect=NSScreen.main?.visibleFrame { panel.setFrameOrigin(NSPoint(x:rect.maxX-78,y:rect.maxY-panel.frame.height-18)) }
        if !CommandLine.arguments.contains("--presentation-test"),let saved=UserDefaults.standard.string(forKey:"miniWindowFrame") { panel.setFrame(NSRectFromString(saved),display:false) }
        viewMode = .compact
        refreshPresentation();panel.orderFrontRegardless()
        NotificationCenter.default.addObserver(self,selector:#selector(screensChanged),name:NSApplication.didChangeScreenParametersNotification,object:nil)
        tick=Timer.scheduledTimer(withTimeInterval:0.5,repeats:true) { [weak self] _ in self?.heartbeat() }
        if CommandLine.arguments.contains("--watch") { concealPanel() }
        if autoStart { Task { @MainActor in _ = try? await api.request("launch-ack",[:]);startClicked() } }
    }
    func setupMenu() {
        statusItem=NSStatusBar.system.statusItem(withLength:NSStatusItem.variableLength)
        let menu=NSMenu();menu.autoenablesItems=false
        func item(_ title:String,_ action:Selector)->NSMenuItem { let i=NSMenuItem(title:title,action:action,keyEquivalent:"");i.target=self;menu.addItem(i);return i }
        _=item(tr("显示小窗","Show mini window"),#selector(showPanel))
        _=item(tr("隐藏小窗 · 听会继续","Hide mini window · keep listening"),#selector(hidePanel))
        menu.addItem(.separator())
        pauseItem=item(tr("暂停听会","Pause listening"),#selector(pauseClicked))
        endItem=item(tr("结束会议","End meeting"),#selector(endClicked))
        _=item(tr("打开听会台","Open LiveMate"),#selector(openMain))
        menu.addItem(.separator())
        let quit=item(tr("退出听会台","Quit LiveMate"),#selector(quitClicked))
        quit.keyEquivalent="q";quit.keyEquivalentModifierMask=[.command]
        statusItem.menu=menu
        // The app's dotted waveform, as a template so macOS supplies light/dark tint.
        let mark=NSImage(size:NSSize(width:18,height:18),flipped:false){rect in
            NSColor.black.setFill()
            for (column,count) in [3,6,9,6,3].enumerated() {
                for row in 0..<count {
                    let dot=NSRect(x:2+CGFloat(column)*3,y:(18-CGFloat(count)*1.8)/2+CGFloat(row)*1.8,width:1.5,height:1.5)
                    NSBezierPath(ovalIn:dot).fill()
                }
            }
            return true
        }
        mark.isTemplate=true;statusItem.button?.image=mark
        statusItem.button?.imagePosition = .imageLeading
    }
    @objc func quitClicked() { NSApp.terminate(nil) }
    func refreshPresentation() {
        // A hidden expanded stack still contributes its minimum fitting size to
        // NSPanel. Keep only the visible mode attached so the mini bar can shrink.
        let visibleRoot = viewMode == .compact ? compactRoot!:(viewMode == .transcript ? transcriptRoot!:expandedRoot!)
        if presentedRoot !== visibleRoot,let body=panel.contentView {
            NSLayoutConstraint.deactivate(presentationConstraints);presentedRoot?.removeFromSuperview()
            body.addSubview(visibleRoot);presentedRoot=visibleRoot
            presentationConstraints=[visibleRoot.leadingAnchor.constraint(equalTo:body.leadingAnchor),visibleRoot.trailingAnchor.constraint(equalTo:body.trailingAnchor),visibleRoot.topAnchor.constraint(equalTo:body.topAnchor),visibleRoot.bottomAnchor.constraint(lessThanOrEqualTo:body.bottomAnchor)]
            NSLayoutConstraint.activate(presentationConstraints)
            body.layoutSubtreeIfNeeded()
        }
        let active = !sessionId.isEmpty
        notNowButton.isHidden = active || !meetingCandidate || busy
        let transcriptText=recentTranscript.isEmpty ? tr(paused ? "已暂停，点击继续听会":"等待第一段转写…",paused ? "Paused. Resume when ready.":"Waiting for the first transcript…"):recentTranscript
        if transcriptPreview.string != transcriptText {
            let offset=transcriptScroll.contentView.bounds.origin
            let followsLatest=offset.y+transcriptScroll.contentView.bounds.height >= transcriptPreview.bounds.height-24
            transcriptPreview.string=transcriptText;transcriptPreview.layoutManager?.ensureLayout(for:transcriptPreview.textContainer!)
            let needed=transcriptPreview.layoutManager?.usedRect(for:transcriptPreview.textContainer!).height ?? 240
            transcriptPreview.setFrameSize(NSSize(width:282,height:max(240,needed+16)))
            if followsLatest { transcriptPreview.scrollRangeToVisible(NSRange(location:transcriptPreview.string.utf16.count,length:0)) }
            else { transcriptScroll.contentView.scroll(to:offset);transcriptScroll.reflectScrolledClipView(transcriptScroll.contentView) }
        }
        transcriptPreview.isHidden = false
        compactStart.isHidden=active;compactStart.isEnabled = !busy;compactEnd.isHidden = !active;compactEnd.isEnabled = !busy
        startButton.isHidden=active;pauseButton.isHidden = !active;endButton.isHidden = !active;pauseButton.title=tr(paused ? "继续":"暂停",paused ? "Resume":"Pause")
        compactPause.isHidden = !active;compactPause.image=NSImage(systemSymbolName:paused ? "play":"pause",accessibilityDescription:tr(paused ? "继续听会":"暂停听会",paused ? "Resume listening":"Pause listening"));compactPause.setAccessibilityLabel(tr(paused ? "继续听会":"暂停听会",paused ? "Resume listening":"Pause listening"));compactPause.toolTip=compactPause.accessibilityLabel()
        startButton.isEnabled = !busy;pauseButton.isEnabled = !busy;endButton.isEnabled = !busy;compactPause.isEnabled = !busy
        pauseItem.isEnabled=active && !busy;pauseItem.title=tr(paused ? "继续听会":"暂停听会",paused ? "Resume listening":"Pause listening");endItem.isEnabled=active && !busy
        let brief = (!error.isEmpty || transportIssue) ? tr("需注意","Needs attention") : busy ? tr("正在处理","Working") : active ? tr(paused ? "已暂停":"正在听",paused ? "Paused":"Listening") : lastSessionId.isEmpty ? tr("待开始","Ready"):tr("已结束","Ended")
        let elapsed=max(0,Int(mirroring ? mirrorSeconds:(engine?.seconds ?? 0)))
        compactButton.title=active ? String(format:"%02d:%02d",elapsed/60,elapsed%60):tr("打开","Open")
        compactButton.toolTip=brief+" · "+status.stringValue+tr(" · 打开听会台"," · Open LiveMate")
        compactMeter.level = active && !paused && !transportIssue ? compactMeter.level:0
        insightEntry.contentTintColor = cardCount>0 ? .controlAccentColor:.labelColor
        insightEntry.toolTip=tr("主动智能","Intelligence")+(cardCount>0 ? " · \(cardCount)":"")
        statusItem.button?.title=tr("听会", "LiveMate")+(active ? (paused ? " Ⅱ":" ●"):"")
        statusItem.button?.toolTip=status.stringValue
        refreshHoverPreview()
        guard viewMode != .hidden else { return }
        let screenHeight=NSScreen.screens.first(where:{$0.visibleFrame.intersects(panel.frame)})?.visibleFrame.height ?? 800
        cardViewport.constant=min(cards.frame.height,max(80,min(320,screenHeight-140)))
        expandedRoot.layoutSubtreeIfNeeded();expandedHeight=max(80,ceil(expandedRoot.fittingSize.height))
        let chrome=panel.frame.height-(panel.contentView?.frame.height ?? panel.frame.height)
        transcriptRoot.layoutSubtreeIfNeeded();compactRoot.layoutSubtreeIfNeeded()
        let height=viewMode == .compact ? max(156,ceil(compactRoot.fittingSize.height)):(viewMode == .transcript ? max(112,min(screenHeight-40,ceil(transcriptRoot.fittingSize.height))):expandedHeight)
        let size=NSSize(width:viewMode == .compact ? 60:310,height:height+chrome)
        let next=miniFrame(panel.frame,size:size,screens:NSScreen.screens.map { $0.visibleFrame });if next != panel.frame { panel.setFrame(next,display:true) }
    }
    // A separate preview keeps the capsule and pointer target stationary. Moving
    // into the preview cancels dismissal; CC still pins the normal transcript.
    func setTranscriptHover(_ inside:Bool) {
        hovering=inside;hoverDismiss?.cancel()
        guard viewMode == .compact else { hoverPanel?.orderOut(nil);return }
        if inside { refreshHoverPreview();return }
        let work=DispatchWorkItem { [weak self] in
            guard let self=self else { return }
            self.dismissHoverPreview(at:NSEvent.mouseLocation)
        }
        hoverDismiss=work;DispatchQueue.main.asyncAfter(deadline:.now()+0.2,execute:work)
    }
    func dismissHoverPreview(at pointer:NSPoint) {
        guard viewMode == .compact else { hoverPanel?.orderOut(nil);return }
        if panel.frame.contains(pointer) || (hoverPanel?.isVisible == true && hoverPanel!.frame.contains(pointer)) { return }
        hovering=false;hoverPanel?.orderOut(nil)
    }
    func refreshHoverPreview() {
        guard viewMode == .compact else { hoverPanel?.orderOut(nil);return }
        guard hovering || hoverPanel?.isVisible == true else { return }
        if hoverPanel == nil {
            let preview=MeetingPanel(contentRect:NSRect(x:0,y:0,width:310,height:212),styleMask:[.borderless,.nonactivatingPanel],backing:.buffered,defer:false)
            preview.level = .floating;preview.isFloatingPanel=true;preview.hidesOnDeactivate=false;preview.isReleasedWhenClosed=false
            preview.collectionBehavior=[.canJoinAllSpaces,.fullScreenAuxiliary];preview.isOpaque=false;preview.backgroundColor = .clear;preview.hasShadow=true
            let surface=CapsuleSurface();surface.wantsLayer=true;surface.layer?.cornerRadius=14;surface.layer?.backgroundColor=NSColor.windowBackgroundColor.cgColor
            surface.layer?.borderWidth=1;surface.layer?.borderColor=NSColor.separatorColor.withAlphaComponent(0.5).cgColor
            surface.hoverChanged={ [weak self] inside in self?.setTranscriptHover(inside) };preview.contentView=surface
            let title=NSTextField(labelWithString:tr("实时逐字稿","Live transcript"));title.font = .systemFont(ofSize:13,weight:.semibold);title.frame=NSRect(x:14,y:176,width:180,height:20);surface.addSubview(title)
            let pin=NSButton(title:tr("固定展开","Keep open"),target:self,action:#selector(toggleTranscript));pin.bezelStyle = .rounded;pin.frame=NSRect(x:202,y:171,width:96,height:30);surface.addSubview(pin)
            let scroll=NSScrollView(frame:NSRect(x:12,y:12,width:286,height:152));scroll.hasVerticalScroller=true;scroll.autohidesScrollers=true;scroll.drawsBackground=false
            let text=NSTextView(frame:NSRect(x:0,y:0,width:282,height:152));text.isEditable=false;text.isSelectable=true;text.drawsBackground=false;text.font = .systemFont(ofSize:13);text.textContainerInset=NSSize(width:2,height:4);text.isVerticallyResizable=true;text.textContainer?.widthTracksTextView=true
            scroll.documentView=text;surface.addSubview(scroll);hoverText=text;hoverPanel=preview
        }
        let text=recentTranscript.isEmpty ? tr(paused ? "已暂停，点击继续听会":"等待第一段转写…",paused ? "Paused. Resume when ready.":"Waiting for the first transcript…"):recentTranscript
        if hoverText?.string != text {
            let scroll=hoverText?.enclosingScrollView
            let followsLatest=(scroll?.contentView.bounds.maxY ?? 0)>=(hoverText?.bounds.height ?? 0)-24
            hoverText?.string=text
            if followsLatest { hoverText?.scrollRangeToVisible(NSRange(location:text.utf16.count,length:0)) }
        }
        let frame=panel.frame
        let screen=NSScreen.screens.first(where:{$0.visibleFrame.intersects(frame)})?.visibleFrame ?? frame
        let x=frame.minX-310 >= screen.minX ? frame.minX-310:frame.maxX
        let next=miniFrame(NSRect(x:x,y:frame.maxY-212,width:310,height:212),size:NSSize(width:310,height:212),screens:[screen])
        hoverPanel?.setFrame(next,display:true);hoverPanel?.orderFrontRegardless()
    }
    @objc func toggleIntelligence() { hovering=false;hoverDismiss?.cancel();viewMode = viewMode == .expanded ? .compact:.expanded;refreshPresentation();panel.orderFrontRegardless();savePosition() }
    @objc func toggleTranscript() { hovering=false;hoverDismiss?.cancel();viewMode = viewMode == .transcript ? .compact:.transcript;refreshPresentation();panel.orderFrontRegardless();savePosition() }
    @objc func dismissDetection() { inputNotifiedAt=Date();meetingCandidate=false;hidePanel() }
    func presentDetection() {
        showPanel()
        guard !NSWorkspace.shared.accessibilityDisplayShouldReduceMotion else { return }
        let shake=CAKeyframeAnimation(keyPath:"transform.translation.x");shake.values=[0,-3,3,-2,2,0];shake.duration=0.3
        panel.contentView?.layer?.add(shake,forKey:"meeting-detected")
    }
    @objc func showPanel() { viewMode = .compact;refreshPresentation();panel.orderFrontRegardless();savePosition() }
    @objc func collapsePanel() { viewMode = .compact;refreshPresentation();panel.orderFrontRegardless();savePosition() }
    @objc func hidePanel() {
        if !sessionId.isEmpty {
            dismissedPanelSession=sessionId
            let id=sessionId
            Task { _ = try? await api.request("owner-panel-dismiss",["sessionId":id]) }
        }
        concealPanel()
    }
    func applyPanelPolicy(_ j:[String:Any]) {
        guard let policy=j["panelPolicy"] as? [String:Any],policy["managed"] as? Bool == true else { return }
        let id=policy["sessionId"] as? String ?? ""
        let show=policy["show"] as? Bool == true && id != dismissedPanelSession
        let key=id+":"+String(show)
        guard key != lastPanelPolicyKey else { return }
        let hadMeetingPolicy = !lastPanelPolicyKey.isEmpty && lastPanelPolicyKey != ":false"
        lastPanelPolicyKey=key
        if show { showPanel() } else if !sessionId.isEmpty || !id.isEmpty || hadMeetingPolicy { concealPanel() }
    }
    func concealPanel() { hovering=false;hoverDismiss?.cancel();savePosition();viewMode = .hidden;panel.orderOut(nil);refreshPresentation() }
    @objc func screensChanged() { refreshPresentation() }
    func savePosition() { guard !CommandLine.arguments.contains("--presentation-test"),viewMode != .hidden else { return };UserDefaults.standard.set(NSStringFromRect(panel.frame),forKey:"miniWindowFrame");UserDefaults.standard.set(viewMode.rawValue,forKey:"miniWindowMode") }
    func windowDidMove(_ notification:Notification) { refreshHoverPreview();savePosition() }
    func windowShouldClose(_ sender:NSWindow)->Bool { hidePanel();return false }
    func applicationShouldHandleReopen(_ sender:NSApplication,hasVisibleWindows flag:Bool)->Bool { showPanel();return false }
    func showError(_ message:String) { error=message;status.stringValue=message;refreshPresentation() }
    func showTransportError(_ message:String) { transportIssue=true;transportMessage=message;status.stringValue=error.isEmpty ? message:error;refreshPresentation() }
    func recoverTransport() {
        transportIssue=false;transportMessage=""
        if sessionId.isEmpty { status.stringValue=error.isEmpty ? tr("切回会议窗口，点开始","Return to your meeting and press Start"):error }
        refreshPresentation()
    }
    func joinMeeting(_ link:String) {
        if CommandLine.arguments.contains("--owner-binding-test") { return }
        guard !busy,sessionId.isEmpty,let url=URL(string:link),url.scheme=="https",["vc.feishu.cn","vc.larksuite.com","meet.google.com"].contains(url.host ?? "") else { return }
        busy=true;status.stringValue=tr("正在打开会议；如有登录或等候室请先完成","Opening meeting; finish sign-in or the waiting room if needed");refreshPresentation()
        Task { @MainActor in
            var handedToCapture=false
            defer { if !handedToCapture { busy=false;refreshPresentation() } }
            do {
                _ = try await api.request("launch-ack",[:])
                guard NSWorkspace.shared.open(url) else { throw CaptureError.message("会议链接未能打开") }
                busy=false;handedToCapture=true;startClicked()
            } catch { showError(error.localizedDescription) }
        }
    }
    @objc func startClicked() {
        if CommandLine.arguments.contains("--owner-binding-test") { return }
        guard !busy,sessionId.isEmpty else { return };busy=true;status.stringValue=tr("正在接入会议…","Connecting…");refreshPresentation()
        Task { @MainActor in
            do {
                if let current=try? await api.request("status"),current["active"] as? Bool == true,current["captureMode"] as? String == "browser" {
                    adoptBrowser(current);busy=false;refreshPresentation();return
                }
                // Decide from the actual ScreenCaptureKit authorization result.
                // The system permission request remains required; no bypass.
                let audioConfig=try await api.request("audio-config");cloudASR=audioConfig["transport"] as? String == "pcm"
                if !cloudASR { let authorized=await withCheckedContinuation { (c:CheckedContinuation<Bool,Never>) in SFSpeechRecognizer.requestAuthorization { c.resume(returning:$0 == .authorized) } }
                guard authorized else { throw CaptureError.message(tr("请允许听会台使用本机语音识别","Allow on-device Speech Recognition for LiveMate")) }
                }
                let micAuthorized=await AVCaptureDevice.requestAccess(for:.audio)
                guard micAuthorized else { throw CaptureError.message(tr("请允许麦克风，才能同时记录你和同事的声音；尚未开始录制","Allow Microphone to capture both sides; recording has not started")) }
                if !cloudASR { guard let recognizer=SFSpeechRecognizer(locale:Locale(identifier:locale)),recognizer.supportsOnDeviceRecognition else { throw CaptureError.message(tr("这门语言尚未支持本机转写；请先下载系统识别语言","On-device recognition is unavailable for this language")) } }
                let content:SCShareableContent
                do {
                    content=try await SCShareableContent.excludingDesktopWindows(true,onScreenWindowsOnly:true)
                } catch {
                    // Existing SCK grants win over CoreGraphics preflight. For a
                    // first-time denial, request permission normally, then retry
                    // the actual capture API once. Never treat the request as capture.
                    guard (error as NSError).code == SCStreamError.Code.userDeclined.rawValue else { throw error }
                    guard CGRequestScreenCaptureAccess() else {
                        throw CaptureError.message(tr("请在录屏与系统录音中允许当前听会台小窗，再重新打开；尚未开始录制","Allow this LiveMate helper in Screen & System Audio Recording, then reopen it; recording has not started"))
                    }
                    content=try await SCShareableContent.excludingDesktopWindows(true,onScreenWindowsOnly:true)
                }
                // Audio is desktop-wide. A meeting window is optional and does not
                // become an implicit permission to upload its screen contents.
                joinTarget=nil
                let target:MeetingTarget?=nil
                let j=try await api.request("start",["lang":locale.hasPrefix("en") ? "en" : "zh","uiLang":english ? "en" : "zh"])
                guard let id=j["sessionId"] as? String,let file=j["audioPath"] as? String else { throw CaptureError.message("已有会议在采集；请先结束当前采集") }
                sessionId=id;lastSessionId=id;lastHeartbeat=Date();error=""
                guard let asr=j["asr"] as? [String:Any],(asr["transport"] as? String == "pcm")==cloudASR else { throw CaptureError.message("转写配置已变化，请重新开始") }
                nextAudioSequence=1;audioQueue=[]
                let capture=CaptureEngine(pcm:{ [weak self] data in DispatchQueue.main.async { guard let self=self else { return };self.audioQueue.append((self.nextAudioSequence,data));self.nextAudioSequence+=1;if self.audioQueue.count>=150 && !self.paused && !self.busy { self.showError(self.tr("转写连接中断，已暂停；原始录音已保存","ASR connection interrupted; paused with audio saved"));self.pauseClicked() };self.flushEvents() } },text:{ [weak self] key,text in DispatchQueue.main.async { self?.textQueue.append((key,text));self?.flushEvents() } },frame:{ [weak self] data in DispatchQueue.main.async { self?.pendingFrame=data;self?.flushEvents() } },failure:{ [weak self] message in DispatchQueue.main.async { guard let self=self else { return };self.showError(message);if !self.busy && !self.paused { self.pauseClicked() } } })
                engine=capture;try await capture.start(target:target,content:content,locale:locale,audioPath:file,cloudASR:cloudASR,inputUID:j["inputUID"] as? String ?? "")
                _ = try await api.request("ready",["sessionId":id])

                startButton.isHidden=true;pauseButton.isHidden=false;endButton.isHidden=false;lastCards="";renderStatus(j)
            } catch { if !sessionId.isEmpty { await engine?.stop();try? await api.request("end",["sessionId":sessionId]);sessionId="";engine=nil };try? await api.request("cancel-start",["error":error.localizedDescription]);showError(error.localizedDescription) }
            busy=false;refreshPresentation()
        }
    }
    func findTarget(_ content:SCShareableContent,front:pid_t?) throws -> MeetingTarget {
        let order=(CGWindowListCopyWindowInfo(.optionOnScreenOnly,kCGNullWindowID) as? [[String:Any]] ?? []).compactMap { $0[kCGWindowNumber as String] as? UInt32 }
        let windows=content.windows.filter { $0.windowLayer==0 && $0.frame.width>200 && $0.frame.height>120 }
        if let current=windows.filter({$0.owningApplication?.processID==front && $0.owningApplication?.processID != ProcessInfo.processInfo.processIdentifier && !($0.title ?? "").contains("Meeting LiveMate")}).sorted(by:{(order.firstIndex(of:$0.windowID) ?? 999)<(order.firstIndex(of:$1.windowID) ?? 999)}).first { return MeetingTarget(window:current) }
        if let detected=windows.first(where:{recognizedMeeting(bundle:$0.owningApplication?.bundleIdentifier ?? "",title:$0.title ?? "")}) { return MeetingTarget(window:detected) }
        if let pin=UserDefaults.standard.dictionary(forKey:"pinnedMeetingWindow"),let id=pin["windowId"] as? Int,let bundle=pin["bundleId"] as? String,let title=pin["title"] as? String,let old=windows.first(where:{Int($0.windowID)==id && $0.owningApplication?.bundleIdentifier==bundle && $0.title==title}) { return MeetingTarget(window:old) }
        throw CaptureError.message(tr("切回要听的会议或播放窗口，点小窗的开始","Return to the meeting or playback window and press Start here"))
    }
    func flushEvents() {
        guard !sending,!sessionId.isEmpty else { return };sending=true;let id=sessionId
        Task { @MainActor in
            defer { sending=false }
            do {
                while sessionId==id,!audioQueue.isEmpty { let e=audioQueue[0];let ack=try await api.request("audio",["sessionId":id,"seq":e.0,"pcm":e.1.base64EncodedString()]);guard ack["seq"] as? Int == e.0 else { throw CaptureError.message("音频确认不匹配") };audioQueue.removeFirst() }
                while sessionId==id,!textQueue.isEmpty { let e=textQueue[0];try await api.request("text",["sessionId":id,"key":e.0,"text":e.1]);textQueue.removeFirst() }
                if sessionId==id,let image=pendingFrame { pendingFrame=nil;do { try await api.request("frame",["sessionId":id,"jpeg":image.base64EncodedString()]) } catch { if pendingFrame==nil { pendingFrame=image };throw error } }
            } catch { showTransportError(tr("与听会台断开，正在重连","Disconnected, reconnecting")) }
        }
    }
    func adoptBrowser(_ j:[String:Any]) {
        guard let id=j["sessionId"] as? String else { return }
        mirroring=true;sessionId=id;lastSessionId=id;error="";paused=j["phase"] as? String == "paused"
        startButton.isHidden=true;pauseButton.isHidden=false;endButton.isHidden=false;renderStatus(j)
    }
    func resetSession() {
        sessionId="";mirroring=false;paused=false;engine=nil;recentTranscript="";hovering=false;meter.level=0;compactMeter.level=0
        startButton.isHidden=false;pauseButton.isHidden=true;endButton.isHidden=true
        status.stringValue=tr("已结束 · 可回听会台继续","Ended · Continue in LiveMate");refreshPresentation()
    }
    var meetingCandidate=false
    var inputNotifiedAt=Date.distantPast
    func detectMeeting() {
        if CommandLine.arguments.contains("--owner-binding-test") { return }
        guard watchEnabled,sessionId.isEmpty,!busy,Date().timeIntervalSince(watchScanAt)>5 else { return };watchScanAt=Date()
        if #available(macOS 14.2, *),let active=meetingInputProcesses() {
            meetingCandidate = !active.isEmpty
            if meetingCandidate,Date().timeIntervalSince(inputNotifiedAt)>1800 { inputNotifiedAt=Date();status.stringValue=tr("检测到通话，点开始听会","Call activity detected; press Start to listen");presentDetection() }
            return
        }
        // Older macOS fallback: window metadata only; no capture until Start.
        guard CGPreflightScreenCaptureAccess() else { return }
        let windows=(CGWindowListCopyWindowInfo(.optionOnScreenOnly,kCGNullWindowID) as? [[String:Any]] ?? [])
        for w in windows {
            guard let pid=w[kCGWindowOwnerPID as String] as? Int32,let app=NSRunningApplication(processIdentifier:pid),let title=w[kCGWindowName as String] as? String,let id=w[kCGWindowNumber as String] as? UInt32,recognizedMeeting(bundle:app.bundleIdentifier ?? "",title:title) else { continue }
            guard Date().timeIntervalSince(notifiedWindows[id] ?? .distantPast)>1800 else { continue }
            notifiedWindows[id]=Date();meetingCandidate=true;joinTarget=id;status.stringValue=tr("发现会议：","Meeting detected: ")+title;presentDetection();return
        }
    }
    func heartbeat() {
        guard !heartbeating else { return }
        heartbeating=true
        Task { @MainActor in
            defer { heartbeating=false }
            do {
                if sessionId.isEmpty || mirroring {
                    if !api.owner.isEmpty { _ = try? await api.request("input-devices",["inputDevices":microphoneDevices().map{$0.json}]) }
                    let j=try await api.request("status")
                    if j["command"] as? String == "quit",!api.owner.isEmpty { NSApp.terminate(nil);return }
                    if CommandLine.arguments.contains("--owner-binding-test") { return }
                    if transportIssue { recoverTransport() }
                    if j["active"] as? Bool == true,j["captureMode"] as? String == "browser" { adoptBrowser(j) }
                    else if mirroring { resetSession() }
                    else if j["command"] as? String == "join",let link=j["meetingUrl"] as? String,!busy { joinMeeting(link) }
                    else if j["command"] as? String == "start",!busy { _ = try? await api.request("launch-ack",[:]);startClicked() }
                    else if j["active"] as? Bool != true { detectMeeting() }
                    applyPanelPolicy(j)
                    return
                }
                let id=sessionId;flushEvents()
                let level=paused ? 0:(engine?.meterSnapshot() ?? 0)
                meter.level=level;compactMeter.level=level
                let j=try await api.request("heartbeat",["sessionId":id,"audioSeconds":engine?.seconds ?? 0,"audioLevel":level,"error":error,"view":viewMode.rawValue,"inputUID":engine?.inputUID ?? "","inputName":engine?.inputName ?? "","inputDevices":microphoneDevices().map{$0.json},"audioEvidence":engine?.audioEvidence() ?? [:]]);lastHeartbeat=Date()
                guard sessionId==id else { return };if transportIssue && textQueue.isEmpty && audioQueue.isEmpty && pendingFrame==nil { recoverTransport() }
                if let command=j["command"] as? String { if command=="quit",!api.owner.isEmpty { NSApp.terminate(nil);return };if command=="stop" { endClicked();return };if command=="pause" && !paused { pauseClicked() };if command=="resume" && paused { pauseClicked() } }
                if let change=j["microphoneChange"] as? [String:Any],let requestId=change["requestId"] as? String,let uid=change["inputUID"] as? String {
                    var switchError=""
                    if lastMicrophoneRequest==requestId { switchError=lastMicrophoneError }
                    else {
                        do { if let expires=change["expiresAt"] as? Double,Date().timeIntervalSince1970*1000>expires { throw CaptureError.message("设备切换请求已超时，原输入保持不变；可重试") };guard let capture=engine else { throw CaptureError.message("录音引擎未连接，未切换麦克风") };try capture.switchMicrophone(uid:uid) } catch { switchError=error.localizedDescription }
                        lastMicrophoneRequest=requestId;lastMicrophoneError=switchError
                    }
                    _ = try await api.request("microphone-ack",["sessionId":id,"requestId":requestId,"error":switchError,"inputUID":engine?.inputUID ?? "","inputName":engine?.inputName ?? ""])
                }
                renderStatus(j);applyPanelPolicy(j)
            } catch {
                if !api.owner.isEmpty,error.localizedDescription=="native_owner_unknown" {
                    do {
                        _ = try await api.request("owner-register",[:])
                        _ = try await api.request("owner-helper-ready",["pid":Int(ProcessInfo.processInfo.processIdentifier)])
                    } catch { showTransportError(error.localizedDescription) }
                } else { meter.level=0;compactMeter.level=0;showTransportError(error.localizedDescription) }
                // A failed heartbeat never ends capture or claims a save receipt.
            }
        }
    }
    func drainEvents() async -> Bool {
        // Keep the session and its queued final text until the server acknowledges it.
        for _ in 0..<150 {
            flushEvents()
            if !sending && textQueue.isEmpty && audioQueue.isEmpty && pendingFrame==nil { return true }
            try? await Task.sleep(nanoseconds:100_000_000)
        }
        return false
    }
    var confirmationHandlers:[ConfirmationHandler]=[]
    func renderStatus(_ j:[String:Any]) {
        let recent=j["recentTranscript"] as? [[String:Any]] ?? []
        recentTranscript=recent.map { row in
            let seconds=max(0,Int(row["t"] as? Double ?? 0))
            return String(format:"%02d:%02d  ",seconds/60,seconds%60)+(row["text"] as? String ?? "")
        }.joined(separator:"\n")
        if mirroring { mirrorSeconds=j["audioSeconds"] as? Double ?? 0;paused=j["phase"] as? String == "paused";let level=paused ? 0:(j["audioLevel"] as? Double ?? 0);meter.level=level;compactMeter.level=level }
        if error.isEmpty && !transportIssue { let phase=j["phase"] as? String ?? "listening";status.stringValue=phase=="thinking" ? tr("正在判断这条信息…","Assessing new information…") : phase=="paused" ? tr("已暂停","Paused") : phase=="model_unavailable" ? tr("提醒暂不可用，录音继续","Insights unavailable; recording continues") : (mirroring ? tr("正在听 · 与大窗同步","Listening · Synced with main window"):(cloudASR ? tr("正在听 · 已配置转写","Listening · Configured ASR") : tr("正在听 · 本机转写","Listening · On device"))) }
        if mirroring && error.isEmpty && !transportIssue && !paused,let gate=j["gate"] as? [String:Any],gate["degraded"] as? Bool == true { status.stringValue=gate["local"] as? Bool == true ? tr("正在听 · JEV 不可用，改用本机筛选","Listening · JEV unavailable; local selection"):tr("正在听 · JEV 筛选暂停","Listening · JEV selection paused") }
        refreshPresentation()
        let c=j["cards"] as? [String:Any] ?? [:]
        if historySession != sessionId { historySession=sessionId;showHistory=false;expandedCards=[];cardScroll.contentView.scroll(to:.zero) }
        let top=cardScroll.contentView.bounds.origin.y
        let anchor=cards.arrangedSubviews.first { $0.frame.maxY>top }
        let anchorKey=anchor?.identifier;let offset=top-(anchor?.frame.minY ?? top)
        let displayed:[String:Any]=["historyOpen":showHistory,"cards":c,"confirmation":j["confirmation"] ?? NSNull()]
        guard let data=try? JSONSerialization.data(withJSONObject:displayed),let key=String(data:data,encoding:.utf8),key != lastCards else { return };lastCards=key
        confirmationHandlers=[]
        for view in cards.arrangedSubviews { cards.removeArrangedSubview(view);view.removeFromSuperview() }
        var rows:[(String,[String:Any])]=[]
        if let confirmation=j["confirmation"] as? [String:Any],let cid=confirmation["id"] as? String {
            let question=NSTextField(wrappingLabelWithString:tr("需要你确认 · ","Your call · ")+(confirmation["question"] as? String ?? ""));question.font = .systemFont(ofSize:13,weight:.medium);cards.addArrangedSubview(question)
            let statement=confirmation["statement"] as? String ?? ""
            let proposal=NSTextField(wrappingLabelWithString:statement);proposal.font = .systemFont(ofSize:12);proposal.textColor = .secondaryLabelColor;proposal.toolTip=statement;cards.addArrangedSubview(proposal)
            for label in [question,proposal] {
                label.translatesAutoresizingMaskIntoConstraints=false
                let bounds=(label.stringValue as NSString).boundingRect(with:NSSize(width:282,height:2000),options:[.usesLineFragmentOrigin,.usesFontLeading],attributes:[.font:label.font!])
                let height=ceil(bounds.height)+8
                label.widthAnchor.constraint(equalToConstant:282).isActive=true;label.heightAnchor.constraint(equalToConstant:height).isActive=true
            }
            let controls=NSStackView();controls.orientation = .horizontal;controls.spacing=8
            for (label,response) in [(tr("确认","Confirm"),"confirm"),(tr("纠正","Correct"),"correct"),(tr("稍后","Later"),"later")] {
                let button=NSButton(title:label,target:nil,action:nil);button.bezelStyle = .rounded
                let handler=ConfirmationHandler { [weak self] in guard let self=self else { return };if response=="correct" { self.openMain();return };button.isEnabled=false;Task { @MainActor in do { let next=try await self.api.request("confirmation",["sessionId":self.sessionId,"confirmationId":cid,"response":response]);self.lastCards="";self.renderStatus(next) }catch{button.isEnabled=true;self.showError(error.localizedDescription)} } }
                button.target=handler;button.action=#selector(ConfirmationHandler.click);confirmationHandlers.append(handler);controls.addArrangedSubview(button)
            };cards.addArrangedSubview(controls)
        }
        if let s=c["suggestion"] as? [String:Any],s["text"] is String { rows.append((tr("建议","Suggestion"),s)) }
        for insight in (c["insights"] as? [[String:Any]] ?? []).prefix(2) { if insight["text"] is String { rows.append((tr("洞察","Insight"),insight)) } }
        let currentKeys=Set(rows.compactMap { $0.1["key"] as? String })
        let history=(c["history"] as? [[String:Any]] ?? []).filter { !currentKeys.contains($0["key"] as? String ?? "") }
        if !history.isEmpty {
            let toggle=NSButton(title:(showHistory ? "▾ ":"▸ ")+tr("之前的提醒","Earlier reminders")+" (\(history.count))",target:self,action:#selector(toggleHistory));toggle.isBordered=false
            toggle.identifier=NSUserInterfaceItemIdentifier("history-toggle");cards.addArrangedSubview(toggle)
            if showHistory { rows += history.map { (tr("之前的提醒","Earlier reminder"),$0) } }
        }
        for (label,item) in rows {
            let text=item["text"] as? String ?? ""
            let b=MiniInsightButton(category:label,text:text,target:self,action:#selector(toggleCard(_:)));b.stableKey=item["key"] as? String ?? text;b.expanded=expandedCards.contains(b.stableKey);b.sourceLabel=item["sourceLabel"] as? String ?? "";b.readMore=tr("展开全文","Read more");b.collapse=tr("收起","Collapse");b.identifier=NSUserInterfaceItemIdentifier(b.stableKey);b.translatesAutoresizingMaskIntoConstraints=false;cards.addArrangedSubview(b)
            let height=b.intrinsicContentSize.height
            b.widthAnchor.constraint(equalToConstant:282).isActive=true;b.heightAnchor.constraint(equalToConstant:height).isActive=true
        }
        cardCount=rows.count+(j["confirmation"] is [String:Any] ? 1:0)
        let contentHeight=ceil(cards.fittingSize.height)
        cards.setFrameSize(NSSize(width:282,height:contentHeight));cardScroll.isHidden=cardCount==0;refreshPresentation()
        cards.layoutSubtreeIfNeeded()
        if let key=anchorKey,let next=cards.arrangedSubviews.first(where:{$0.identifier==key}) { cardScroll.contentView.scroll(to:NSPoint(x:0,y:max(0,next.frame.minY+offset))) }
        else if showHistory { cardScroll.contentView.scroll(to:NSPoint(x:0,y:top)) }
        cardScroll.reflectScrolledClipView(cardScroll.contentView)
    }
    @objc func toggleHistory() { showHistory.toggle();lastCards="";Task { @MainActor in if let state=try? await api.request("status") { renderStatus(state) } } }
    @objc func toggleCard(_ sender:MiniInsightButton) {
        if expandedCards.contains(sender.stableKey) { expandedCards.remove(sender.stableKey) }else{expandedCards.insert(sender.stableKey)}
        sender.expanded=expandedCards.contains(sender.stableKey)
        for c in sender.constraints where c.firstAttribute == .height { c.constant=sender.intrinsicContentSize.height }
        sender.invalidateIntrinsicContentSize();sender.needsDisplay=true;cards.layoutSubtreeIfNeeded();cards.setFrameSize(NSSize(width:282,height:ceil(cards.fittingSize.height)));refreshPresentation()
    }
    @objc func pauseClicked() {
        guard !busy,!sessionId.isEmpty else { return };busy=true;refreshPresentation();let value = !paused
        Task { @MainActor in
            defer { busy=false;refreshPresentation() }
            if mirroring {
                do { _ = try await api.request("command",["sessionId":sessionId,"command":value ? "pause":"resume"]) }
                catch { showError(error.localizedDescription) };return
            }
            if !value && !audioQueue.isEmpty { guard await drainEvents() else { showError(tr("音频还在重试，请稍后继续","Audio is retrying; resume shortly"));return } }
            await engine?.pause(value)
            if value {
                let saved=await drainEvents()
                if !saved { paused=true;pauseButton.title=tr("继续","Resume");showError(tr("最后一句还在保存，请稍后重试","Saving the last sentence; retry shortly"));return }
            }
            do {
                _ = try await api.request("pause",["sessionId":sessionId,"paused":value])
                paused=value;if !value { error="" };pauseButton.title=tr(paused ? "继续":"暂停",paused ? "Resume":"Pause")
            } catch { if value { paused=true } else { await engine?.pause(true);paused=true };showError(error.localizedDescription) }
        }
    }
    @objc func endClicked() {
        guard !busy,!sessionId.isEmpty else { return };busy=true;refreshPresentation();let id=sessionId
        Task { @MainActor in
            if mirroring {
                do { _ = try await api.request("command",["sessionId":id,"command":"stop"]) }
                catch { showError(error.localizedDescription) };busy=false;refreshPresentation();return
            }
            await engine?.stop();flushEvents()
            // Recognition emits its last local partial before the existing Session is finalized.
            guard await drainEvents() else { showError(tr("最后一句尚未送达，录音已留在本机；正在重试保存","Last sentence not delivered; audio saved locally, retrying"));busy=false;refreshPresentation();finishQuit(false);return }
            do { try await api.request("end",["sessionId":id]);sessionId="";engine=nil;audioQueue=[];textQueue=[];pendingFrame=nil;paused=false;error="";status.stringValue=tr("已结束 · 可回听会台继续","Ended · Continue in LiveMate");startButton.isHidden=false;pauseButton.isHidden=true;endButton.isHidden=true;finishQuit(true) }
            catch { showError(tr("收尾未确认，正在重试","Final save unconfirmed, retrying"));finishQuit(false) }
            busy=false;refreshPresentation()
        }
    }
    @objc func openMain() { let id=sessionId.isEmpty ? lastSessionId:sessionId;Task { @MainActor in do { _ = try await api.request(api.owner.isEmpty ? "open-main":"owner-open-main",["sessionId":id]) }catch{showError(tr("无法打开听会台：","Unable to open LiveMate: ")+error.localizedDescription)} } }
    @objc func claimOwner(_ notification:Notification) {
        guard api.owner.isEmpty,sessionId.isEmpty,!busy,
              let token=notification.userInfo?["owner"] as? String,
              token.range(of:"^[a-f0-9]{64}$",options:.regularExpression) != nil else { return }
        busy=true
        Task { @MainActor in
            defer { busy=false;refreshPresentation() }
            let candidate=LocalAPI(api.base.absoluteString,owner:token)
            do {
                _ = try await candidate.request("owner-helper-ready",["pid":Int(ProcessInfo.processInfo.processIdentifier)])
                api.owner=token
            } catch { showError("主窗口归属未确认，请重试") }
        }
    }
    func finishQuit(_ saved:Bool) {
        guard terminateAfterSave else { return }
        terminateAfterSave=false
        Task { @MainActor in
            do {
                if saved {
                    if !api.owner.isEmpty {
                        _ = try await api.request("owner-quit",[:])
                        _ = try await api.request("owner-quit-ready",[:])
                    }
                    quitApproved=true;NSApp.terminate(nil)
                } else {
                    if !api.owner.isEmpty { _ = try? await api.request("owner-quit-failed",["error":"收尾未确认，录音保留在本机"]) }
                    quitInFlight=false
                }
            } catch {
                quitInFlight=false
                if !api.owner.isEmpty { _ = try? await api.request("owner-quit-failed",["error":"退出回执未确认，请重试"]) }
                showError("退出未确认，请稍后重试")
            }
        }
    }
    func applicationShouldTerminate(_ sender:NSApplication)->NSApplication.TerminateReply {
        if quitApproved { return .terminateNow }
        if quitInFlight { return .terminateCancel }
        if !sessionId.isEmpty && !mirroring {
            guard !busy else { return .terminateCancel }
            quitInFlight=true;terminateAfterSave=true;endClicked();return .terminateCancel
        }
        // Return immediately so Swift concurrency can deliver the save receipt.
        // Re-enter termination only after the asynchronous handshake succeeds.
        if !api.owner.isEmpty { quitInFlight=true;terminateAfterSave=true;finishQuit(true);return .terminateCancel }
        return .terminateNow
    }
}
let argv=CommandLine.arguments
func argument(_ key:String,_ fallback:String)->String { if let i=argv.firstIndex(of:key),i+1<argv.count { return argv[i+1] };return fallback }
// Synthetic pipeline verification: no device, permission prompt, server, or ASR.
// Exercise the actual SCK sample decoder, shared timeline, PCM file and packets.
if argv.contains("--audio-fixture-test") {
    do {
        let directory=URL(fileURLWithPath:argument("--output",NSTemporaryDirectory()+"livemate-fixture-"+UUID().uuidString))
        try FileManager.default.createDirectory(at:directory,withIntermediateDirectories:true,attributes:[.posixPermissions:0o700])
        let path=directory.appendingPathComponent("synthetic-mix.pcm")
        guard !FileManager.default.fileExists(atPath:path.path) else { throw CaptureError.message("Fixture output already exists") }
        _=FileManager.default.createFile(atPath:path.path,contents:nil,attributes:[.posixPermissions:0o600])
        var packets=[Data]();var failures=[String]()
        let engine=CaptureEngine(pcm:{packets.append($0)},text:{_,_ in preconditionFailure("No ASR in fixture test")},frame:{_ in preconditionFailure("No screen in fixture test")},failure:{failures.append($0)})
        engine.file=try FileHandle(forWritingTo:path);engine.mixer=TimelineMixer(origin:100)
        func sample(_ values:[Float],at:Double,rate:Double=16000) throws -> CMSampleBuffer {
            var asbd=AudioStreamBasicDescription(mSampleRate:rate,mFormatID:kAudioFormatLinearPCM,mFormatFlags:kAudioFormatFlagIsFloat|kAudioFormatFlagIsPacked,mBytesPerPacket:4,mFramesPerPacket:1,mBytesPerFrame:4,mChannelsPerFrame:1,mBitsPerChannel:32,mReserved:0)
            var description:CMAudioFormatDescription?
            guard CMAudioFormatDescriptionCreate(allocator:kCFAllocatorDefault,asbd:&asbd,layoutSize:0,layout:nil,magicCookieSize:0,magicCookie:nil,extensions:nil,formatDescriptionOut:&description)==noErr,let description=description else { throw CaptureError.message("Fixture format failed") }
            var block:CMBlockBuffer?
            let data=values.withUnsafeBytes{Data($0)}
            guard CMBlockBufferCreateWithMemoryBlock(allocator:kCFAllocatorDefault,memoryBlock:nil,blockLength:data.count,blockAllocator:kCFAllocatorDefault,customBlockSource:nil,offsetToData:0,dataLength:data.count,flags:0,blockBufferOut:&block)==noErr,let block=block else { throw CaptureError.message("Fixture allocation failed") }
            let code=data.withUnsafeBytes{CMBlockBufferReplaceDataBytes(with:$0.baseAddress!,blockBuffer:block,offsetIntoDestination:0,dataLength:data.count)}
            guard code==noErr else { throw CaptureError.message("Fixture copy failed") }
            var buffer:CMSampleBuffer?
            guard CMAudioSampleBufferCreateReadyWithPacketDescriptions(allocator:kCFAllocatorDefault,dataBuffer:block,formatDescription:description,sampleCount:values.count,presentationTimeStamp:CMTime(seconds:at,preferredTimescale:16000),packetDescriptions:nil,sampleBufferOut:&buffer)==noErr,let buffer=buffer else { throw CaptureError.message("Fixture sample failed") }
            return buffer
        }
        let blocks=53 // 1.06s includes a partial final transport packet.
        var expected=[Float]()
        for block in 0..<blocks {
            var system=[Float](),microphone=[Float]()
            for offset in 0..<320 {
                let phase:Double=Double(block*320+offset)*2.0*Double.pi/16000.0
                system.append(Float(sin(phase*440.0))*Float(0.25))
                microphone.append(Float(sin(phase*880.0))*Float(0.125))
            }
            let timestamp=100+Double(block)*0.02
            engine.acceptSystemAudio(try sample(system,at:timestamp))
            engine.mixer.add(microphone,at:timestamp)
            expected += zip(system,microphone).map { $0.0 + $0.1 }
        }
        engine.flushMix(final:true)
        try engine.file?.synchronize();try engine.file?.close();engine.file=nil
        let data=try Data(contentsOf:path)
        precondition(failures.isEmpty && data.count==blocks*320*2,"No lost frames or doubled duration")
        precondition(packets.reduce(Data(),+)==data,"Transport packets must match saved PCM, including final tail")
        let decoded=data.withUnsafeBytes{Array($0.bindMemory(to:Int16.self))}
        precondition(zip(decoded,expected).allSatisfy{abs(Int($0.0)-Int($0.1*32767))<=1},"Simultaneous sources must mix at the same host timestamp")
        do { _=try engine.systemSamples(sample([0,0],at:100,rate:48000));preconditionFailure("Unexpected format accepted") }
        catch { /* The configured system stream must deliver 16k mono. */ }
        let result:[String:Any]=["result":"passed","syntheticOnly":true,"deviceCapture":false,"networkRequests":0,"frames":decoded.count,"seconds":Double(decoded.count)/16000,"bytes":data.count,"packets":packets.count,"systemFrames":engine.systemFrames,"systemPeak":engine.systemPeak,"checks":["CMSampleBuffer float32 decoding","system + microphone timeline overlap","PCM16LE file equals transport","final partial packet","invalid sample rate rejected"]]
        try JSONSerialization.data(withJSONObject:result,options:[.prettyPrinted,.sortedKeys]).write(to:directory.appendingPathComponent("verification.json"))
        print(String(data:try JSONSerialization.data(withJSONObject:result,options:[.sortedKeys]),encoding:.utf8)!);exit(0)
    } catch { fputs("Audio fixture failed: \(error.localizedDescription)\n",stderr);exit(1) }
}

if argv.contains("--diagnostics") {
    let mic=AVCaptureDevice.authorizationStatus(for:.audio),speech=SFSpeechRecognizer.authorizationStatus()
    let micName:String
    switch mic { case .authorized:micName="authorized";case .denied:micName="denied";case .restricted:micName="restricted";case .notDetermined:micName="notDetermined";@unknown default:micName="unknown" }
    let speechName:String
    switch speech { case .authorized:speechName="authorized";case .denied:speechName="denied";case .restricted:speechName="restricted";case .notDetermined:speechName="notDetermined";@unknown default:speechName="unknown" }
    let result:[String:Any] = ["screenAudioAuthorized":CGPreflightScreenCaptureAccess(),"microphoneAuthorization":mic.rawValue,"speechAuthorization":speech.rawValue,"microphoneStatus":micName,"speechStatus":speechName,"note":"Run outside the execution sandbox; preflight does not prove audio delivery."]
    if let json=try? JSONSerialization.data(withJSONObject:result,options:[.sortedKeys]),let text=String(data:json,encoding:.utf8) { print(text) };exit(0)
}
// Opt-in hardware probe. Capture ONLY this app's generated tone, never global
// output, microphone, video, or a real meeting. Any system permission prompt
// is left for the user; CoreGraphics preflight never substitutes for actual SCK.
if argv.contains("--system-audio-test") {
    let testApp=NSApplication.shared;testApp.setActivationPolicy(.accessory)
    Task { @MainActor in
        var stream:SCStream?
        do {
            // SCK is authoritative; CoreGraphics preflight can be false for an existing SCK grant.
            // A real system authorization prompt remains under user control.
            let directory=URL(fileURLWithPath:argument("--output",NSTemporaryDirectory()+"livemate-system-test-"+UUID().uuidString))
            try FileManager.default.createDirectory(at:directory,withIntermediateDirectories:true,attributes:[.posixPermissions:0o700])
            let testWindow=NSWindow(contentRect:NSRect(x:200,y:200,width:380,height:100),styleMask:[.titled],backing:.buffered,defer:false)
            testWindow.title="LiveMate · 合成系统音频测试"
            let label=NSTextField(labelWithString:"播放 440 Hz 测试音 · 3 秒后停止\n只采集本测试程序，不采集麦克风")
            label.frame=NSRect(x:20,y:25,width:340,height:50);testWindow.contentView?.addSubview(label)
            testWindow.orderFrontRegardless()
            defer { testWindow.orderOut(nil) }
            try await Task.sleep(nanoseconds:500_000_000)
            let content=try await SCShareableContent.excludingDesktopWindows(true,onScreenWindowsOnly:true)
            guard let display=content.displays.first,let own=content.applications.first(where:{$0.processID==ProcessInfo.processInfo.processIdentifier}) else { throw CaptureError.message("Cannot isolate this test application; capture refused") }
            let path=directory.appendingPathComponent("self-tone-only.pcm")
            guard !FileManager.default.fileExists(atPath:path.path) else { throw CaptureError.message("Test output exists") }
            _=FileManager.default.createFile(atPath:path.path,contents:nil,attributes:[.posixPermissions:0o600])
            var errors=[String]()
            let engine=CaptureEngine(pcm:{_ in},text:{_,_ in},frame:{_ in preconditionFailure("No screen output allowed")},failure:{errors.append($0)})
            engine.file=try FileHandle(forWritingTo:path);engine.mixer=TimelineMixer(origin:ProcessInfo.processInfo.systemUptime)
            let config=SCStreamConfiguration();config.capturesAudio=true;config.sampleRate=16000;config.channelCount=1;config.excludesCurrentProcessAudio=false;config.width=32;config.height=32;config.minimumFrameInterval=CMTime(value:1,timescale:1)
            let capture=SCStream(filter:SCContentFilter(display:display,including:[own],exceptingWindows:[]),configuration:config,delegate:engine)
            stream=capture;try capture.addStreamOutput(engine,type:.audio,sampleHandlerQueue:engine.queue)
            try await capture.startCapture()
            var wav=Data()
            func word<T:FixedWidthInteger>(_ value:T) { var v=value.littleEndian;withUnsafeBytes(of:&v){wav.append(contentsOf:$0)} }
            let count=32000
            wav.append(contentsOf:Array("RIFF".utf8));word(UInt32(36+count*2));wav.append(contentsOf:Array("WAVEfmt ".utf8));word(UInt32(16));word(UInt16(1));word(UInt16(1));word(UInt32(16000));word(UInt32(32000));word(UInt16(2));word(UInt16(16));wav.append(contentsOf:Array("data".utf8));word(UInt32(count*2))
            for index in 0..<count { let phase=Double(index)*2.0*Double.pi*440.0/16000.0;word(Int16(sin(phase)*8000.0)) }
            let player=try AVAudioPlayer(data:wav,fileTypeHint:AVFileType.wav.rawValue)
            player.volume=0.3;player.prepareToPlay()
            guard player.play() else { throw CaptureError.message("Synthetic tone playback failed") }
            try await Task.sleep(nanoseconds:3_000_000_000)
            player.stop();try await capture.stopCapture();stream=nil
            engine.queue.sync { engine.flushMix(final:true);try? engine.file?.synchronize();try? engine.file?.close();engine.file=nil }
            let data=try Data(contentsOf:path),samples=data.withUnsafeBytes{Array($0.bindMemory(to:Int16.self))}
            let power=samples.reduce(0.0){$0+pow(Double($1)/32768.0,2)}
            let rms=sqrt(power/Double(max(1,samples.count)))
            let evidence=engine.audioEvidence()
            guard errors.isEmpty,engine.systemFrames>16000,engine.systemPeak>0.005,rms>0.001 else { throw CaptureError.message("No non-silent system tone received; device validation failed") }
            let result:[String:Any]=["result":"passed","bundlePath":Bundle.main.bundlePath,"bundleIdentifier":Bundle.main.bundleIdentifier ?? "","pid":Int(ProcessInfo.processInfo.processIdentifier),"coreGraphicsPreflight":CGPreflightScreenCaptureAccess(),"captureScope":"this app only","testToneHz":440,"microphoneCaptured":false,"screenFramesCaptured":false,"externalRequests":0,"bytes":data.count,"rms":rms,"evidence":evidence]
            try JSONSerialization.data(withJSONObject:result,options:[.sortedKeys,.prettyPrinted]).write(to:directory.appendingPathComponent("system-verification.json"))
            print(String(data:try JSONSerialization.data(withJSONObject:result,options:[.sortedKeys]),encoding:.utf8)!);exit(0)
        } catch {
            try? await stream?.stopCapture()
            let result:[String:Any]=["result":"blocked","error":error.localizedDescription,"bundlePath":Bundle.main.bundlePath,"bundleIdentifier":Bundle.main.bundleIdentifier ?? "","pid":Int(ProcessInfo.processInfo.processIdentifier),"coreGraphicsPreflight":CGPreflightScreenCaptureAccess(),"microphoneCaptured":false]
            if let directory=argv.firstIndex(of:"--output"),directory+1<argv.count { try? JSONSerialization.data(withJSONObject:result,options:[.prettyPrinted,.sortedKeys]).write(to:URL(fileURLWithPath:argv[directory+1]).appendingPathComponent("system-verification.json")) }
            fputs("System audio test blocked: \(error.localizedDescription)\n",stderr);exit(78)
        }
    }
    testApp.run();exit(0)
}

if argv.contains("--self-test") {
    precondition(recognizedMeeting(bundle:"us.zoom.xos",title:"Zoom Meeting"))
    precondition(recognizedMeeting(bundle:"com.microsoft.teams2",title:"Design review | Meeting"))
    precondition(recognizedMeeting(bundle:"com.microsoft.teams2",title:"Call with Alex"))
    precondition(recognizedMeeting(bundle:"com.microsoft.teams2",title:"设计评审 | 会议"))
    precondition(!recognizedMeeting(bundle:"com.microsoft.teams2",title:"Recall project | Chat"))
    precondition(!recognizedMeeting(bundle:"com.microsoft.teams2",title:"Callback discussion | Chat"))
    precondition(!recognizedMeeting(bundle:"com.microsoft.teams2",title:"Meetingnotes | Chat"))
    precondition(!recognizedMeeting(bundle:"com.microsoft.teams2",title:"Calendar | Microsoft Teams"))
    precondition(recognizedMeeting(bundle:"com.bytedance.Lark",title:"视频会议"))
    precondition(!recognizedMeeting(bundle:"com.bytedance.Lark",title:"Messages"))
    var mix=TimelineMixer(origin:100)
    mix.add([Float](repeating:0.25,count:320),at:100);mix.add([Float](repeating:0.5,count:320),at:100)
    let simultaneous=mix.drain(to:100.23)
    precondition(simultaneous.count==1 && simultaneous[0].count==320 && simultaneous[0].allSatisfy{$0==0.75},"Two simultaneous sources must occupy the same 20ms, not 40ms")
    mix.add([Float](repeating:1,count:320),at:100);precondition(mix.blocks.isEmpty,"Late buffers must not rewrite saved audio")
    mix.add([Float](repeating:2,count:320),at:100.02);let final=mix.drain(to:100.25,final:true);precondition(final.count==1 && final[0].allSatisfy{$0==1})
    let screen=NSRect(x:0,y:0,width:1440,height:900),old=NSRect(x:1112,y:500,width:310,height:280)
    let compact=miniFrame(old,size:NSSize(width:246,height:66),screens:[screen])
    precondition(compact.maxX==old.maxX && compact.maxY==old.maxY)
    let restored=miniFrame(compact,size:NSSize(width:310,height:480),screens:[screen])
    precondition(restored.maxX==old.maxX && restored.maxY==old.maxY)
    let removedDisplay=miniFrame(NSRect(x:3000,y:1400,width:310,height:480),size:NSSize(width:246,height:66),screens:[screen])
    precondition(screen.contains(removedDisplay))
    let negativeDisplay=NSRect(x:-1600,y:0,width:1600,height:1000)
    precondition(negativeDisplay.contains(miniFrame(NSRect(x:-350,y:600,width:310,height:200),size:NSSize(width:246,height:66),screens:[screen,negativeDisplay])))
    var g=PageGate();let a=[UInt8](repeating:80,count:2304),b=[UInt8](repeating:200,count:2304)
    precondition(!g.accepts(a,now:0));precondition(!g.accepts(a,now:0.34));precondition(g.accepts(a,now:0.68));precondition(!g.accepts(a,now:9))
    var cursor=a;for i in 0..<40 { cursor[i]=255 };precondition(!g.accepts(cursor,now:10))
    precondition(!g.accepts(b,now:11));precondition(!g.accepts(b,now:11.34));precondition(g.accepts(b,now:11.68))
    precondition(recognizedMeeting(bundle:"com.bytedance.Feishu",title:"飞书会议"));precondition(!recognizedMeeting(bundle:"com.bytedance.Feishu",title:"飞书文档"));precondition(recognizedMeeting(bundle:"com.google.Chrome",title:"Meet - abc-defg-hij"));precondition(!recognizedMeeting(bundle:"com.google.Chrome",title:"Bank account"))
    var speechDelta=SpeechDelta()
    precondition(speechDelta.take("hello",pieces:[SpeechPiece(start:0,end:1,range:NSRange(location:0,length:5))])=="hello")
    precondition(speechDelta.take("hello",pieces:[SpeechPiece(start:0,end:1,range:NSRange(location:0,length:5))])==nil)
    precondition(speechDelta.take("Hallo world",pieces:[SpeechPiece(start:0,end:1,range:NSRange(location:0,length:5)),SpeechPiece(start:1.1,end:2,range:NSRange(location:6,length:5))])=="world")
    print("native_self_test_passed");exit(0)
}
if argv.contains("--probe") {
    let r=SFSpeechRecognizer(locale:Locale(identifier:argument("--locale","zh-CN")))
    let j:[String:Any]=["screenPermission":CGPreflightScreenCaptureAccess(),"speechPermission":SFSpeechRecognizer.authorizationStatus().rawValue,"microphonePermission":AVCaptureDevice.authorizationStatus(for:.audio).rawValue,"onDevice":r?.supportsOnDeviceRecognition ?? false]
    print(String(data:try! JSONSerialization.data(withJSONObject:j),encoding:.utf8)!);exit(0)
}
// LaunchServices must not redirect a different installation/test port to the
// already running helper. A per-endpoint lock keeps repeated -n launches from
// creating a second recorder; the owner consumes the server's queued command.
let endpoint=argument("--server","http://127.0.0.1:47823")
let endpointPort=URL(string:endpoint)?.port ?? 47823
let instanceLock=CommandLine.arguments.contains("--presentation-test") ? -1 : Darwin.open((NSTemporaryDirectory()+"livemate-capture-\(getuid())-\(endpointPort).lock"),O_CREAT|O_RDWR|O_NOFOLLOW,0o600)
if !CommandLine.arguments.contains("--presentation-test") {
    guard instanceLock >= 0 else { fputs("Unable to establish capture instance lock\n",stderr);exit(1) }
    if flock(instanceLock,LOCK_EX|LOCK_NB) != 0 {
        let owner=argument("--owner","")
        if owner.range(of:"^[a-f0-9]{64}$",options:.regularExpression) != nil {
            // An idle watcher adopts only after the server validates this owner.
            // Active helpers keep their current ownership; no process is killed.
            DistributedNotificationCenter.default().postNotificationName(Notification.Name("LiveMateCaptureOwner"),object:String(endpointPort),userInfo:["owner":owner],deliverImmediately:true)
        }
        exit(0)
    }
}
let app=NSApplication.shared
let delegate=AppDelegate(server:argument("--server","http://127.0.0.1:47823"),locale:argument("--locale","zh-CN"),english:argument("--ui-lang",(Locale.preferredLanguages.first ?? "en").lowercased().hasPrefix("zh") ? "zh":"en")=="en",autoStart:argv.contains("--start"),owner:argument("--owner",""))
if argv.contains("--presentation-test") {
    // Exercise actual AppKit sizing and visibility without starting capture or
    // touching meeting data. Pure rectangle tests cannot detect fitting-size bugs.
    delegate.applicationDidFinishLaunching(Notification(name:NSApplication.didFinishLaunchingNotification))
    delegate.tick?.invalidate()
    precondition(delegate.viewMode == .compact && !delegate.compactStart.isHidden)
    delegate.viewMode = .expanded;delegate.refreshPresentation();delegate.panel.orderFrontRegardless()
    delegate.panel.contentView?.layoutSubtreeIfNeeded()
    let idleHeight=delegate.panel.contentView!.frame.height
    precondition(idleHeight<=140,"Empty mini window must not reserve a card area")
    delegate.showTransportError("Temporary connection failure");delegate.recoverTransport()
    precondition(delegate.error.isEmpty && !delegate.status.stringValue.contains("failure"))
    delegate.showError("Capture failed");delegate.showTransportError("Connection failed");delegate.recoverTransport()
    precondition(delegate.error=="Capture failed" && delegate.status.stringValue=="Capture failed","Reconnect must preserve capture errors")
    delegate.error="";delegate.sessionId="presentation-only"
    delegate.mirroring=true
    delegate.renderStatus(["phase":"listening","gate":["degraded":true,"local":true]])
    precondition(delegate.status.stringValue.contains("JEV"),"Shared mini window must reveal local JEV fallback")
    delegate.renderStatus(["phase":"paused","gate":["degraded":true,"local":true]])
    precondition(!delegate.status.stringValue.contains("JEV"),"Pause status takes priority over fallback")
    delegate.showError("Capture failed")
    delegate.renderStatus(["phase":"listening","gate":["degraded":true,"local":true]])
    precondition(delegate.status.stringValue=="Capture failed","Capture errors take priority over fallback")
    delegate.error="";delegate.mirroring=false;delegate.paused=false

    let long=String(repeating:"This is a long preview with evidence. ",count:12)
    delegate.renderStatus(["cards":["suggestion":["text":long],"insights":[["text":long],["text":long]]]])
    delegate.panel.contentView?.layoutSubtreeIfNeeded()
    precondition(delegate.cardCount==3 && delegate.cards.arrangedSubviews.count==3)
    if let card=delegate.cards.arrangedSubviews.first as? MiniInsightButton { delegate.toggleCard(card);delegate.panel.contentView?.layoutSubtreeIfNeeded();precondition(card.frame.height>101,"Expanded text must be readable inside mini window");delegate.toggleCard(card) }
    precondition(delegate.cardScroll.frame.height<=320 && delegate.panel.contentView!.frame.height<=450)
    for card in delegate.cards.arrangedSubviews { precondition(card.frame.height<=101 && card.toolTip?.contains(long)==true) }
    delegate.renderStatus(["cards":["suggestion":["text":long],"insights":[["text":long],["text":long]]],"confirmation":["id":"test-only","question":long,"statement":long]])
    delegate.panel.contentView?.layoutSubtreeIfNeeded()
    precondition(delegate.cardCount==4 && delegate.cardScroll.frame.height<=320)
    precondition(delegate.cards.frame.height>delegate.cardScroll.frame.height,"Long confirmation remains scrollable")
    let old=(0..<8).map { ["key":"old-\($0)","text":long,"sourceLabel":"38:06 · Speaker 1"] }
    delegate.showHistory=true;delegate.lastCards=""
    delegate.renderStatus(["cards":["suggestion":["key":"latest","text":long],"history":old]])
    delegate.panel.contentView?.layoutSubtreeIfNeeded()
    precondition(delegate.cardCount==9 && delegate.cards.frame.height>delegate.cardScroll.frame.height)
    let anchor=delegate.cards.arrangedSubviews.first { $0.identifier?.rawValue=="old-4" }!
    let reading=anchor.frame.minY+12
    delegate.cardScroll.contentView.scroll(to:NSPoint(x:0,y:reading))
    delegate.renderStatus(["cards":["suggestion":["key":"new-latest","text":"A new reminder"],"history":old]])
    delegate.panel.contentView?.layoutSubtreeIfNeeded()
    let kept=delegate.cards.arrangedSubviews.first { $0.identifier?.rawValue=="old-4" }!
    precondition(abs(delegate.cardScroll.contentView.bounds.origin.y-kept.frame.minY-12)<2,"New reminders must preserve the history being read")
    delegate.showHistory=false;delegate.lastCards=""
    delegate.renderStatus(["cards":["suggestion":["text":"A short actionable suggestion"],"insights":[]]])
    delegate.panel.contentView?.layoutSubtreeIfNeeded()
    precondition(delegate.cardCount==1 && delegate.panel.contentView!.frame.height<250)
    delegate.renderStatus(["cards":["insights":[]]])
    delegate.panel.contentView?.layoutSubtreeIfNeeded()
    precondition(delegate.cardScroll.isHidden && delegate.panel.contentView!.frame.height<150)
    delegate.collapsePanel();delegate.panel.contentView?.layoutSubtreeIfNeeded()
    precondition(abs(delegate.panel.frame.width-60)<1,"The capsule must use a narrow vertical footprint")
    func snapshot(_ name:String) {
        guard let base=ProcessInfo.processInfo.environment["THT_PRESENTATION_SNAPSHOT"],let view=delegate.panel.contentView else { return }
        view.layoutSubtreeIfNeeded()
        guard let bitmap=view.bitmapImageRepForCachingDisplay(in:view.bounds) else { return }
        view.cacheDisplay(in:view.bounds,to:bitmap)
        if let data=bitmap.representation(using:.png,properties:[:]) { try? data.write(to:URL(fileURLWithPath:base+"-"+name+".png")) }
    }
    delegate.sessionId="presentation-only";delegate.mirroring=true;delegate.mirrorSeconds=72;delegate.refreshPresentation()
    precondition(delegate.compactButton.title=="01:12" && !delegate.compactPause.isHidden && !delegate.compactEnd.isHidden && delegate.compactStart.isHidden)
    precondition(delegate.startButton.isHidden && !delegate.pauseButton.isHidden && !delegate.endButton.isHidden,"Active mirrored controls agree")
    delegate.mirroring=false;delegate.refreshPresentation();precondition(delegate.startButton.isHidden && !delegate.pauseButton.isHidden && !delegate.endButton.isHidden,"Active native controls agree");delegate.mirroring=true;delegate.refreshPresentation()
    delegate.renderStatus(["phase":"listening","audioSeconds":72.0,"audioLevel":0.4,"recentTranscript":[["t":72.0,"text":"Keep the same meeting open."]]])
    precondition(delegate.compactMeter.level==0.4,"The waveform uses actual reported energy")
    snapshot("capsule")
    let capsuleFrame=delegate.panel.frame
    delegate.setTranscriptHover(true)
    precondition(delegate.hoverPanel?.isVisible == true && delegate.hoverText!.string.contains("01:12"),"Hover previews the same timestamped transcript")
    precondition(delegate.panel.frame==capsuleFrame && delegate.viewMode == .compact && delegate.sessionId=="presentation-only","Preview cannot move capsule or change meeting")
    if let base=ProcessInfo.processInfo.environment["THT_PRESENTATION_SNAPSHOT"],let view=delegate.hoverPanel?.contentView,let bitmap=view.bitmapImageRepForCachingDisplay(in:view.bounds) {
        view.cacheDisplay(in:view.bounds,to:bitmap)
        try? bitmap.representation(using:.png,properties:[:])?.write(to:URL(fileURLWithPath:base+"-hover.png"))
    }
    delegate.setTranscriptHover(false);delegate.setTranscriptHover(true)
    RunLoop.current.run(until:Date().addingTimeInterval(0.25))
    precondition(delegate.hoverPanel?.isVisible == true,"Entering preview cancels pending dismissal")
    delegate.toggleTranscript();delegate.setTranscriptHover(false)
    precondition(delegate.viewMode == .transcript && delegate.hoverPanel?.isVisible == false,"CC pins transcript independently of hover")
    delegate.toggleTranscript();delegate.setTranscriptHover(true);delegate.setTranscriptHover(false)
    delegate.hoverDismiss?.cancel()
    delegate.dismissHoverPreview(at:NSPoint(x:delegate.hoverPanel!.frame.midX,y:delegate.hoverPanel!.frame.midY))
    precondition(delegate.hoverPanel?.isVisible == true,"Moving into preview must not close it")
    delegate.dismissHoverPreview(at:NSPoint(x:-100000,y:-100000))
    precondition(delegate.hoverPanel?.isVisible == false && delegate.viewMode == .compact,"Leaving preview restores compact mode")
    precondition(delegate.panel.frame==capsuleFrame && delegate.sessionId=="presentation-only")
    delegate.toggleTranscript();snapshot("transcript");precondition(delegate.viewMode == .transcript && delegate.transcriptPreview.string.contains("01:12") && delegate.sessionId=="presentation-only")
    let longRows=(0..<120).map { ["t":Double($0*5),"text":"第\($0)段：这是本场会议的中文逐字稿，保留时间并让用户在阅读历史内容时不被新内容打断。"] as [String:Any] }
    delegate.renderStatus(["recentTranscript":longRows]);delegate.panel.contentView?.layoutSubtreeIfNeeded()
    precondition(delegate.transcriptPreview.frame.height>delegate.transcriptScroll.contentView.bounds.height,"Long transcript must scroll")
    delegate.transcriptScroll.contentView.scroll(to:NSPoint(x:0,y:40));delegate.transcriptScroll.reflectScrolledClipView(delegate.transcriptScroll.contentView)
    delegate.renderStatus(["recentTranscript":longRows+[["t":601.0,"text":"新增一段，不跳走正在读的位置。"]]])
    precondition(abs(delegate.transcriptScroll.contentView.bounds.origin.y-40)<2,"Appending preserves history position")
    snapshot("transcript-long")
    delegate.transcriptPreview.scrollRangeToVisible(NSRange(location:delegate.transcriptPreview.string.utf16.count,length:0))
    delegate.renderStatus(["recentTranscript":longRows+[["t":602.0,"text":"继续跟随最新内容。"]]])
    precondition(delegate.transcriptScroll.contentView.bounds.maxY>=delegate.transcriptPreview.bounds.height-24,"Reading latest keeps following latest")
    delegate.toggleTranscript();precondition(delegate.viewMode == .compact && delegate.sessionId=="presentation-only")
    delegate.renderStatus(["cards":["suggestion":["text":"先根据本场讨论生成可展示的方案草稿：用轻松、乐观的未来日常表达科技感，保留真实来源与待确认项。"],"insights":[["text":"老板提到 The Jetsons，指的是《杰森一家》：飞行汽车、机器人管家和充满想象力的家庭生活。这里强调的是乐观、亲切的科技，而非冰冷的机械感。"]]]]);delegate.toggleIntelligence();snapshot("intelligence");precondition(delegate.viewMode == .expanded && delegate.sessionId=="presentation-only")
    delegate.collapsePanel();delegate.paused=true;delegate.refreshPresentation();precondition(delegate.compactMeter.level==0)
    delegate.paused=false;delegate.showTransportError("Disconnected");precondition(delegate.compactMeter.level==0 && delegate.sessionId=="presentation-only")
    delegate.recoverTransport();delegate.renderStatus(["phase":"listening","audioSeconds":74.0,"audioLevel":0.2]);precondition(delegate.compactMeter.level==0.2 && delegate.compactButton.title=="01:14")
    delegate.renderStatus(["phase":"listening","audioSeconds":75.0,"audioLevel":0.0]);precondition(delegate.compactMeter.level==0)
    delegate.sessionId="";delegate.mirroring=false;delegate.meetingCandidate=true;delegate.refreshPresentation()
    precondition(!delegate.notNowButton.isHidden && !delegate.compactStart.isHidden,"Detected call offers Start and Not now")
    precondition(!delegate.startButton.isHidden && delegate.pauseButton.isHidden && delegate.endButton.isHidden,"Idle controls agree")
    delegate.dismissDetection();precondition(!delegate.panel.isVisible && !delegate.meetingCandidate,"Not now dismisses without capture")
    delegate.showPanel();precondition(delegate.panel.isVisible && abs(delegate.panel.frame.width-60)<1)
    delegate.hidePanel();precondition(!delegate.panel.isVisible)
    _=delegate.applicationShouldHandleReopen(app,hasVisibleWindows:false);precondition(delegate.panel.isVisible)
    delegate.hidePanel()
    print("native_presentation_test_passed: 0/1/3 cards; scrollable confirmation; error recovery; vertical capsule 60pt; hover preview/transition/pin/leave; lightbulb/CC; real/zero/paused/disconnected/recovered meter; fold; hide; reopen");exit(0)
}
app.delegate=delegate;app.run()

final class ConfirmationHandler:NSObject { let handler:()->Void;init(_ handler:@escaping()->Void){self.handler=handler};@objc func click(){handler()} }
