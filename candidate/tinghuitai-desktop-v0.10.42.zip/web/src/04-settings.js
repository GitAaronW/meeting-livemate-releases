  // ===== 设置 =====
  const DEF = {provider:'deepseek', key:'', base:'', quick:'deepseek-chat', model:'deepseek-chat', relayToken:window.THT_BOOT?.relayToken||'', micId:'', micLabel:'', hotwords:'', autoEndMin:12};
  const PRESET = {deepseek:{base:'https://api.deepseek.com', quick:'deepseek-chat', model:'deepseek-chat'}, anthropic:{base:'', quick:'claude-haiku-4-5', model:'claude-sonnet-4-5'}, openai:{base:'', quick:'', model:''}};
  let ctx = ''; try { ctx = localStorage.getItem('tht-ctx') || ''; } catch(e){}
  let cfg = Object.assign({}, DEF); try { Object.assign(cfg, JSON.parse(localStorage.getItem('tht-settings')||'{}')); } catch(e){}
  // 手机首次连并服务（09-22）：远端窗口拿不到 bootstrap.js，口令只能自己带。链接里带 ?token= 或 #token= 就收下存好，
  // ?token= 随即从地址里去掉（fragment 不上服务器）。
  // 主屏幕图标（09-22）：iOS 从主屏幕打开是独立存储、看不到 Safari 里存的口令，所以远端页把口令留在地址 #token=，
  // 「添加到主屏幕」时连同口令一起存进图标；manifest 不写 start_url，图标就用添加时的地址。
  try { const sp = new URLSearchParams(location.search), hp = new URLSearchParams(location.hash.replace(/^#/, ''));
    const t = (sp.get('token') || hp.get('token') || '').trim();
    const remote = !/^(127\.0\.0\.1|localhost)$/.test(location.hostname);
    // 只在远端且本窗口还没口令时收下：本机窗口口令以 bootstrap 为准；已有口令不被别人给的链接静默换掉（Codex 意见），要换去设置里改。
    if (remote && t.length >= 24 && !cfg.relayToken) { cfg.relayToken = t; localStorage.setItem('tht-settings', JSON.stringify(cfg)); }
    sp.delete('token'); hp.delete('token');
    if (remote && (cfg.relayToken || '').length >= 24) hp.set('token', cfg.relayToken);
    const q = sp.toString(), h = hp.toString(), url = location.pathname + (q ? '?' + q : '') + (h ? '#' + h : '');
    if (url !== location.pathname + location.search + location.hash) history.replaceState(null, '', url); } catch(e){}
  const ctxHint = () => { $('#s-ctx-hint').textContent = ctx ? `已加载 ${ctx.length} 字。` : '未填：Mac 离线时会中分析只能靠转写本身。'; };
  const dlg = $('#dlg');
  // L-13：以前有两套设置界面——设置弹窗和 setup.html，同一批配置两处都能改，setup.html 还有 5 个入口。
  // 现在 setup.html 只留首次引导（launch.js 在没配好时直接开它），其余入口一律开设置弹窗并跳到对应那一栏。
  const SET_SECTION = {
    asr: {el:'#s-asr', adv:false},           // 转写方式
    llm: {el:'#s-agent-provider', adv:false},// MyAgent 后台
    api: {el:'#s-key', adv:true},            // 自己填 API Key
    mic: {el:'#s-mic', adv:false},           // 收音设备
    ctx: {el:'#s-ctx', adv:true},            // 项目上下文
  };
  function jumpTo(section){
    const t = SET_SECTION[section]; if (!t) return;
    const adv = $('#adv'); if (t.adv && adv) adv.open = true;
    const el = $(t.el); if (!el) return;
    // 等弹窗自己排完版再滚，否则滚到的是旧位置
    requestAnimationFrame(() => {
      try { el.scrollIntoView({block:'center', behavior:'smooth'}); } catch(e) { el.scrollIntoView(); }
      const box = el.closest('.field') || el;
      box.classList.add('jump-hi'); setTimeout(() => box.classList.remove('jump-hi'), 1600);
      try { el.focus({preventScroll:true}); } catch(e) {}
    });
  }
  function openSettings(section){ loadServerSettings(); $('#s-provider').value = cfg.provider; $('#s-key').value = cfg.key; $('#s-base').value = cfg.base; $('#s-quick').value = cfg.quick; $('#s-model').value = cfg.model; $('#s-relay').value = cfg.relayToken||''; $('#s-hot').value = cfg.hotwords||''; fillMics(); $('#s-auto').value = cfg.autoEndMin||12; $('#f-base').hidden = cfg.provider!=='openai'; $('#s-msg').hidden = true; $('#s-ctx').value = ctx; $('#s-project').value = contextProjectId; ctxHint(); renderContextSources(); loadContextSources(); dlg.showModal(); if (section) jumpTo(section); }
  async function autoPickMic(){
    // Auto follows the system default. Virtual and aggregate devices require
    // an explicit selection; their presence does not prove they carry audio.
    return;
  }
  async function fillMics(){
    const sel = $('#s-mic'), hint = $('#s-mic-hint');
    try {
      const ds = (await navigator.mediaDevices.enumerateDevices()).filter(d=>d.kind==='audioinput');
      sel.innerHTML = `<option value="">${T('mic_default')||'系统默认'}</option>` + ds.map(d=>`<option value="${esc(d.deviceId)}">${esc(d.label||('输入设备 '+d.deviceId.slice(0,6)))}</option>`).join('');
      sel.value = cfg.micId || '';
      hint.textContent = ds.some(d=>d.label) ? (T('mic_hint')||'自动跟随系统默认麦克风。虚拟输入仅在已配置且确有声音时选择。') : (T('mic_nolabel')||'先允许一次麦克风权限，设备名才显示得出来。');
    } catch(e){ hint.textContent = String(e.message||e); }
  }
  $('#gear').onclick = () => openSettings('asr');
