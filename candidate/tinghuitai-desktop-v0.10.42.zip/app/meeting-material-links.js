
'use strict';
// Only adopted canonical preparation sources; discovery candidates stay separate.
module.exports=function(hub,current){
 if(!current)return [];
 const sources=hub.data?.sources||[],event=current.calendarEvent||{start:current.date||new Date().toISOString(),description:''};
 return require('./premeeting-brief').materials(hub.data,current,event,{purpose:'current-work',asOf:new Date().toISOString()}).filter(row=>{
  const source=sources.find(s=>s.id===row.sourceId);
  if(source&&(source.archived||current.projectId&&source.projectId&&source.projectId!==current.projectId))return false;
  try{if(row.url.startsWith('/tinghuitai/?id='))return row.meetingRecord===true;const u=new URL(row.url);return ['http:','https:'].includes(u.protocol)&&!u.username&&!u.password;}catch{return false;}
 }).map(row=>{
  const source=sources.find(s=>s.id===row.sourceId);
  return {...row,excerpt:row.read&&source?require('./premeeting-brief').calendarText(source.body||'').slice(0,600):''};
 });
};
