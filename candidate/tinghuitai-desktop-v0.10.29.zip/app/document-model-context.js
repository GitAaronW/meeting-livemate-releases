'use strict';
// One model route for inline editing and MyAgent document editing.
const llm=require('./llm'),bridge=require('./codex-app-bridge');
module.exports=function documentModelContext(ctx,{model='',requestId,materials=[],onProgress=()=>{},onModel=()=>{}}={}){
 if(typeof model!=='string'||model.length>100||!/^[a-zA-Z0-9._:-]*$/.test(model))throw Object.assign(Error('Invalid model'),{status:400});
 if(!model&&(ctx.proposeDocument||llm.chainOf(ctx.settings?.load?.()||{})[0]?.type==='openai'))return ctx;
 return {...ctx,proposeDocument:async({question,selected,reference,taskPackage,lang,signal})=>{
  const graphCount=nodes=>(nodes||[]).reduce((n,b)=>n+(b.type==='meetingGraph'?1:0)+graphCount(b.content),0);
  const structured=graphCount(selected)>0;
  const instruction=structured?'Return JSON {"blocks":[ProseMirror JSON nodes],"summary":"short explanation"}. Preserve each meetingGraph as a meetingGraph block with attrs.graph containing nodes [{id,label,detail}] and edges [{from,to,label}]. Keep existing node IDs and valid relationships unless the requested change requires otherwise. Do not flatten diagrams into text. This is a draft. Do not send messages or run actions. Language: '+lang:'Return only the proposed replacement for the selected blocks, in ordinary Markdown, not JSON. Preserve unknowns. This is a draft, not an applied change. Do not send messages or run actions. Language: '+lang;
  let result;
  if(model.startsWith('api:')){
   const env=llm.selectedEnvironment(ctx.settings?.load?.()||{},model);
   if(materials.some(m=>String(m.type||'').startsWith('image/')))throw Object.assign(Error('Selected model route does not support image attachments'),{status:400});
   const answer=await (ctx.askSelected||llm.ask)(env,{system:instruction,user:JSON.stringify({question,selected,reference,taskPackage,materials:materials.map(({name,type,text})=>({name,type,text}))}),kind:'post',requireFullInput:true,noFallback:true,dataDir:ctx.dataDir,signal});
   if(!answer?.text)throw Object.assign(Error('Selected model failed without substitution: '+(answer?.errorCode||'no_answer')),{status:503});
   result=answer;
  }else result=await (ctx.askCodex||bridge.ask)({dataDir:ctx.dataDir,kind:'chat',conversationId:requestId||require('crypto').randomUUID(),signal,requestText:question,model,materials,onProgress,
   context:{documentEdit:instruction,selected,reference,taskPackage}});
  onModel({provider:result.provider||(model.startsWith('api:')?'API':'Codex'),model:result.model,requestedModel:result.requestedModel,effort:result.effort,codexThreadId:result.threadId});
  if(typeof result.text!=='string'||!result.text.trim())throw Object.assign(Error('No document edit returned'),{status:502});
  const schema=require('./mother-document-schema');let blocks;
  if(structured){let answer;try{answer=JSON.parse(result.text.trim().replace(/^```(?:json)?\s*|\s*```$/g,''));}catch{throw Object.assign(Error('No structured diagram edit returned; document unchanged'),{status:502});}
   blocks=schema.validate({type:'doc',content:answer.blocks}).content;
   if(graphCount(blocks)<graphCount(selected))throw Object.assign(Error('The edit omitted the diagram; document unchanged'),{status:502});
  }else blocks=schema.fromMarkdown(result.text).content;
  return {blocks,summary:lang==='en'?'Selected edit is ready to review.':'局部修改已准备好，可查看后采用。',directionChange:true};
 }};
};
