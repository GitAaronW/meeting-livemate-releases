'use strict';
// Shared by the browser renderer and server validation. Edges are explicit;
// a list of nodes never implies an order or relationship.
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.MeetingGraph=api;})(typeof globalThis==='object'?globalThis:this,()=>{
 const validId=x=>typeof x==='string'&&/^[\w-]{1,80}$/.test(x);
 function normalize(nodes,edges){
  if(!Array.isArray(nodes)||nodes.length>30)throw Error('invalid diagram nodes');
  const ids=new Set(),out=nodes.map((n,i)=>{
   if(!n||typeof n.label!=='string'||n.label.length>240||typeof (n.detail||'')!=='string'||(n.detail||'').length>1000)throw Error('invalid diagram node');
   const id=n.id===undefined?'node-'+i:n.id;if(!validId(id)||ids.has(id))throw Error('invalid diagram node id');ids.add(id);
   return {id,label:n.label,detail:n.detail||''};
  });
  if(!Array.isArray(edges)||edges.length>90)throw Error('invalid diagram edges');
  const seen=new Set(),relations=edges.map(e=>{
   if(!e||!ids.has(e.from)||!ids.has(e.to)||typeof (e.label||'')!=='string'||(e.label||'').length>160)throw Error('invalid diagram relationship');
   const key=e.from+'\0'+e.to+'\0'+(e.label||'');if(seen.has(key))throw Error('duplicate diagram relationship');seen.add(key);
   return {from:e.from,to:e.to,label:e.label||''};
  });return {nodes:out,edges:relations};
 }
 function layout(nodes,edges){
  const graph=normalize(nodes,edges),next=new Map(graph.nodes.map(n=>[n.id,[]]));for(const e of graph.edges)next.get(e.from).push(e.to);
  // Strongly connected components keep loops together. Rank only the acyclic
  // component graph so branch, merge and feedback links cannot hang layout.
  let index=0;const indices=new Map(),low=new Map(),stack=[],active=new Set(),components=[];
  function visit(id){indices.set(id,index);low.set(id,index++);stack.push(id);active.add(id);for(const to of next.get(id)){if(!indices.has(to)){visit(to);low.set(id,Math.min(low.get(id),low.get(to)));}else if(active.has(to))low.set(id,Math.min(low.get(id),indices.get(to)));}if(low.get(id)===indices.get(id)){const c=[];let v;do{v=stack.pop();active.delete(v);c.push(v);}while(v!==id);components.push(c);}}
  for(const n of graph.nodes)if(!indices.has(n.id))visit(n.id);
  const membership=new Map();components.forEach((c,i)=>c.forEach(id=>membership.set(id,i)));
  const outgoing=components.map(()=>new Set()),incoming=components.map(()=>0),ranks=components.map(()=>0);
  for(const e of graph.edges){const a=membership.get(e.from),b=membership.get(e.to);if(a!==b&&!outgoing[a].has(b)){outgoing[a].add(b);incoming[b]++;}}
  const queue=incoming.map((v,i)=>v===0?i:null).filter(v=>v!==null);for(let i=0;i<queue.length;i++){const a=queue[i];for(const b of outgoing[a]){ranks[b]=Math.max(ranks[b],ranks[a]+1);if(--incoming[b]===0)queue.push(b);}}
  const rows=new Map(),positions=graph.nodes.map(n=>{const rank=ranks[membership.get(n.id)],row=rows.get(rank)||0;rows.set(rank,row+1);return {...n,x:48+rank*300,y:40+row*180,width:210,height:120};});
  const byId=new Map(positions.map(n=>[n.id,n]));
  const lanes=new Map();
  const connections=graph.edges.map(edge=>{
   const a=byId.get(edge.from),b=byId.get(edge.to),right=b.x>a.x,same=b.x===a.x,startX=a.x+(right||same?a.width:0),endX=b.x+(right?0:b.width),startY=a.y+a.height/2,endY=b.y+b.height/2;
   const key=[a.id,b.id].sort().join('|'),lane=lanes.get(key)||0;lanes.set(key,lane+1);
   let path,labelX,labelY;if(same){const bend=Math.max(startX,endX)+40+lane*56+(a.id===b.id?24:0);path=a.id===b.id?`M ${startX} ${startY-20} C ${bend+45} ${startY-65}, ${bend+45} ${startY+65}, ${endX} ${endY+20}`:`M ${startX} ${startY} C ${bend} ${startY}, ${bend} ${endY}, ${endX} ${endY}`;labelX=startX*.25+bend*.75;labelY=(startY+endY)/2+(lane%2?18:-18);}else{const mid=(startX+endX)/2,offset=lane===0?0:(lane%2?1:-1)*Math.ceil(lane/2)*44;path=`M ${startX} ${startY} C ${mid} ${startY+offset}, ${mid} ${endY+offset}, ${endX} ${endY}`;labelX=mid;labelY=(startY+endY)/2+offset*.75;}
   const tipY=a.id===b.id?endY+20:endY,sign=right?1:-1;
   return {...edge,path,arrow:`M ${endX-sign*8} ${tipY-5} L ${endX} ${tipY} L ${endX-sign*8} ${tipY+5}`,labelX,labelY:labelY-8};
  });
  return {...graph,nodes:positions,connections,width:Math.max(360,...positions.map(n=>n.x+320),...connections.map(e=>e.labelX+100)),height:Math.max(200,...positions.map(n=>n.y+180))};
 }
 function render(value,document){
  const g=layout(value.nodes,value.edges),ns='http://www.w3.org/2000/svg',wrap=document.createElement('div');wrap.className='meeting-graph-preview';
  const svg=document.createElementNS(ns,'svg');svg.setAttribute('viewBox',`0 0 ${g.width} ${g.height}`);svg.setAttribute('role','img');svg.setAttribute('aria-label','Meeting relationship diagram');svg.style.width='100%';svg.style.minWidth='280px';
  const element=(tag,attrs,text)=>{const e=document.createElementNS(ns,tag);for(const [k,v] of Object.entries(attrs))e.setAttribute(k,String(v));if(text!==undefined)e.textContent=text;svg.append(e);return e;};
  for(const e of g.connections){element('path',{d:e.path,stroke:'#8b9d91','stroke-width':2,fill:'none'});element('path',{d:e.arrow,stroke:'#8b9d91','stroke-width':2,fill:'none'});if(e.label)element('text',{x:e.labelX,y:e.labelY,'text-anchor':'middle','font-size':13,fill:'#565e59'},e.label);}
  for(const n of g.nodes){element('rect',{x:n.x,y:n.y,width:n.width,height:n.height,rx:14,fill:'#f2f5f1',stroke:'#a9baad'});const text=element('text',{x:n.x+14,y:n.y+30,'font-size':15,fill:'#252a26'});for(let i=0;i<Math.min(4,Math.ceil(n.label.length/20));i++){const line=document.createElementNS(ns,'tspan');line.setAttribute('x',String(n.x+14));line.setAttribute('dy',i?'20':'0');line.textContent=n.label.slice(i*20,(i+1)*20);if(i===3&&n.label.length>80)line.textContent=n.label.slice(60,77)+'…';text.append(line);}const title=document.createElementNS(ns,'title');title.textContent=n.label+(n.detail?'\n'+n.detail:'');text.append(title);}
  wrap.style.overflowX='auto';wrap.append(svg);const details=document.createElement('details'),summary=document.createElement('summary');summary.textContent=(document.documentElement?.lang||'zh').startsWith('en')?'Full labels and details':'完整标题与说明';details.append(summary);for(const n of g.nodes){const item=document.createElement('p'),strong=document.createElement('strong');strong.textContent=n.label;item.append(strong);if(n.detail){const body=document.createElement('span');body.textContent=' — '+n.detail;item.append(body);}details.append(item);}wrap.append(details);return wrap;
 }
 return {normalize,layout,render};
});
