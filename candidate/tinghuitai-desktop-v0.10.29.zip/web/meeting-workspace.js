'use strict';
// Layout owns visibility only. Capture, conversation and document keep their owners.
(()=>{
 if(parent!==window)return;
 const frame=document.getElementById('workspace-frame'),panel=document.getElementById('myagent-panel');
 if(!frame||!panel)return;
 const state={left:true,right:true};
 const narrow=()=>window.innerWidth<1100;
 const compact=()=>window.innerWidth<760;
 try{const saved=JSON.parse(localStorage.getItem('tht-meeting-workspace-panels')||'{}');for(const key of ['left','right'])if(typeof saved[key]==='boolean')state[key]=saved[key];}catch{}
 if(compact()){state.left=false;state.right=false;}else if(narrow())state.right=false;
 const bar=document.createElement('nav');bar.className='mw-bar';bar.setAttribute('aria-label','会议工作区 / Meeting workspace');
 const title=document.createElement('strong');title.textContent='会议 / Meeting';
 const buttons={};
 for(const [key,label] of [['left','会议记录 / Meeting records'],['right','本场文档 / Meeting document']]){
  const button=document.createElement('button');button.type='button';const icon=document.createElementNS('http://www.w3.org/2000/svg','svg');icon.setAttribute('viewBox','0 0 24 24');icon.setAttribute('width','18');icon.setAttribute('height','18');icon.setAttribute('fill','none');icon.setAttribute('stroke','currentColor');icon.setAttribute('stroke-width','1.6');icon.setAttribute('aria-hidden','true');const outline=document.createElementNS(icon.namespaceURI,'rect');outline.setAttribute('x','3');outline.setAttribute('y','4');outline.setAttribute('width','18');outline.setAttribute('height','16');outline.setAttribute('rx','3');const divider=document.createElementNS(icon.namespaceURI,'path');divider.setAttribute('d',key==='left'?'M9 4v16':'M15 4v16');icon.append(outline,divider);button.append(icon);button.setAttribute('aria-label',label);button.title=label;
  button.onclick=()=>{state[key]=!state[key];if(state[key]&&narrow())state[key==='left'?'right':'left']=false;localStorage.setItem('tht-meeting-workspace-panels',JSON.stringify(state));layout();};buttons[key]=button;
 }
 const live=document.createElement('span');live.className='mw-live-status';live.hidden=true;const end=document.createElement('button');end.type='button';end.className='mw-end';end.hidden=true;end.onclick=()=>document.getElementById('stop')?.click();bar.append(buttons.left,title,live,end,buttons.right);document.body.append(bar);
 function active(){return !document.body.classList.contains('document-home-open')&&frame.hidden===false;}
 let lastLayout='';
 function layout(force=false){
  const on=active(),key=JSON.stringify([on,state.left,state.right]);if(!force&&lastLayout===key)return;lastLayout=key;document.body.classList.toggle('meeting-workspace',on);bar.hidden=!on;
  for(const key of ['left','right']){document.body.classList.toggle('mw-'+key+'-closed',!state[key]);buttons[key].setAttribute('aria-expanded',String(state[key]));}
  if(on){panel.hidden=false;panel.classList.remove('ma-collapsed');document.body.classList.add('myagent-open');}
  frame.contentWindow?.postMessage({type:'tht-workspace-layout',enabled:on,left:state.left,right:state.right},location.origin);
 }
 window.addEventListener('resize',()=>{if(compact()){state.left=false;state.right=false;}else if(narrow()&&state.left&&state.right)state.right=false;layout();});
 frame.addEventListener('load',()=>layout(true));
 new MutationObserver(()=>layout()).observe(document.body,{attributes:true,attributeFilter:['class']});
 new MutationObserver(()=>layout()).observe(frame,{attributes:true,attributeFilter:['hidden']});
 // Do not move or recreate the composer, editor or conversation when panels fold.
 window.addEventListener('tht-proactive-data',e=>{const data=e.detail;title.textContent=data.source?.title||data.session?.title||'会议 / Meeting';});
 setInterval(()=>{const el=frame.contentDocument?.querySelector('.surface-elapsed'),status=frame.contentDocument?.querySelector('.surface-audio-status');const showing=!!el&&(!!el.classList.contains('recording')||['sound','quiet','paused','waiting','disconnected'].includes(status?.dataset?.state));live.hidden=end.hidden=!showing;live.textContent=showing?((status?.textContent||'')+' · '+el.textContent):'';const en=document.documentElement?.lang==='en';end.textContent=en?'End':'结束';end.disabled=!!document.getElementById('stop')?.disabled;},1000);
 layout();
})();
