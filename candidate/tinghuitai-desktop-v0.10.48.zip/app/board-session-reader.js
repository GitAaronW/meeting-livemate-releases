'use strict';
// One reader per request: historical directories are indexed once, while live
// sessions and enhanced content are still read at the moment they are needed.
// An ended meeting keeps the enhanced copy. Current judgments that exist only
// on the later history snapshot are copied onto it; live capture still wins.
function currentJudgments(session){
 return (session?.factchecks||[]).filter(item=>item&&item.channel==='judgment'&&item.id&&!item.stale&&!item.supersededBy);
}
module.exports=function({live,pipeline,exportState}){
 let jobs,history;
 const historyOf=()=>{if(!history)history=new Map(exportState().sessions.map(s=>[String(s.id),s]));return history;};
 return id=>{
  const current=live.get(id);if(current)return current;
  if(!jobs)jobs=new Map(pipeline.list().map(j=>[String(j.sessionId),j]));
  const enhanced=pipeline.result(id,jobs.get(String(id))||null);
  if(!enhanced)return historyOf().get(String(id));
  const saved=historyOf().get(String(id));
  const seen=new Set((enhanced.factchecks||[]).map(item=>item&&item.id).filter(Boolean));
  const missing=currentJudgments(saved).filter(item=>!seen.has(item.id)).map(item=>({...item}));
  if(!missing.length)return enhanced;
  const existing=enhanced.factchecks||[];
  const factchecks=currentJudgments(enhanced).length?[...missing,...existing]:[...existing,...missing];
  return {...enhanced,factchecks};
 };
};
