// Native mini mode shares the existing meeting canvas; it never finalizes on a view switch.
let nativeState={available:false,active:false,sessionId:''},browserCommandPending=false,nativeClockReceivedAt=0;
// One recording has one id. An ended helper id stays empty, so it cannot stay "the current meeting".
window.thtRecordingMeetingId=function(){if(nativeState.active&&nativeState.sessionId)return nativeState.sessionId;if(typeof running!=='undefined'&&running&&cur?.id)return cur.id;return '';};
// The page still starts on browser capture until the helper answers. Start only opens the share picker when that route was chosen.
window.thtBrowserCapture=window.liveMateNativeWindow!==true;
window.thtBrowserMode='asr-tab';
window.thtSelectCapture=function(browser,mode='asr-tab'){
 if(running||nativeState.active)return false;
 window.thtCaptureChoice=browser?'browser':'system';
 window.thtBrowserCapture=!!browser;window.thtBrowserMode=mode;
 note(browser&&mode==='asr'?(ui==='en'?'Microphone recording: records you and nearby speakers; headphones are not captured.':'麦克风录音：记录你和周围的人；不采集耳机内的会议声音。'):browser?(ui==='en'?'Browser recording: select your meeting tab and enable Share audio. Native meeting apps are not captured.':'浏览器录音：选择会议标签页并勾选共享声音；无法采集原生会议 App。'):(ui==='en'?'Using system audio and microphone.':'使用系统声音和麦克风。'));
 return true;
};
async function nativeRequest(route,body){
  const response=await fetch(relayBase()+'/native/'+route,{method:body?'POST':'GET',headers:body?{'Content-Type':'application/json'}:undefined,body:body?JSON.stringify(body):undefined,cache:'no-store',signal:AbortSignal.timeout(8000)});
  const result=await response.json();if(!response.ok)throw Error(result.error||'HTTP '+response.status);return result;
}
// Adopt a shared session once on attachment, without redirecting deliberate history browsing.
function attachSharedMeeting(next,previous){
  if(!next.active||next.captureMode!=='browser'||running||!next.sessionId)return;
  if(previous.active&&previous.sessionId===next.sessionId)return;
  if(cur?.id!==next.sessionId)cur=normalizeSession({id:next.sessionId,title:next.title,start:next.startedAt||Date.now(),transcript:[],highlights:[],todos:[],factchecks:[],viewOnly:true});
  window.thtOpenMeeting?.(next.sessionId);viewerConnect();
}
function nativeStatus(next){
  const previous=nativeState;nativeState=next;
  try{sessionStorage.setItem('tht-helper-available',next.available?'1':'0');}catch(e){}
  if(!running&&!next.active&&next.available&&window.thtCaptureChoice!=='browser'&&window.liveMateNativeWindow!==true)window.thtBrowserCapture=false;
  attachSharedMeeting(next,previous);document.getElementById('mode-chip').hidden=!!next.available&&!window.thtBrowserCapture;nativeClockReceivedAt=Date.now();window.thtNativeStatus=next;paintMeetingClock();
  const join=document.getElementById('native-join');if(join){join.hidden=true;document.getElementById('native-join-go').disabled=!!next.active||nativeJoinPending;}
  const button=document.getElementById('b-native');button.hidden=!next.available;button.textContent=next.active&&next.view==='hidden'?(ui==='en'?'Show mini window':'显示小窗'):next.active&&next.view==='compact'?(ui==='en'?'Expand mini window':'展开小窗'):(ui==='en'?'Mini window':'小窗模式');button.title=ui==='en'?'Show the same meeting. Hiding the mini window keeps listening.':'显示同一场会议；隐藏小窗不会结束听会。';
  if(next.active&&next.captureMode==='browser'){
    if(next.command&&running&&cur?.id===next.sessionId&&!browserCommandPending){
      browserCommandPending=true;
      (async()=>{const command=next.command;try{if(command==='stop'){await stopAll(true);window.thtMiniPaused=false;}else{setBrowserAudioPaused(command==='pause');await nativeRequest('browser-state',{sessionId:next.sessionId,paused:window.thtMiniPaused});}await nativeRequest('browser-ack',{sessionId:next.sessionId,command});}catch(e){note(e.message,true);}finally{browserCommandPending=false;}})();
    }
  }else if(next.active&&!window.thtBrowserCapture){
    if(running){
      if(asrMode)asrStop(false);
      // Retire browser recognition before changing cur: its last result belongs to the old input.
      if(rec){rec.onresult=null;rec.onerror=null;rec.onend=null;try{rec.abort();}catch{}rec=null;}
      running=false;clearInterval(timer);try{wake?.release();}catch{}
    }
    if(previous.sessionId!==next.sessionId||!cur){
      if(cur?.id!==next.sessionId)cur=normalizeSession({id:next.sessionId,title:next.title,start:next.startedAt||Date.now(),transcript:[],highlights:[],todos:[],factchecks:[],nativeCapture:true});else cur.nativeCapture=true;
      window.thtOpenMeeting?.(next.sessionId);viewerConnect();
    }
    el.start.hidden=true;el.stop.hidden=false;
    el.status.textContent=next.phase==='paused'?(ui==='en'?'Paused':'已暂停'):(ui==='en'?'Listening':'正在听');el.status.className=next.phase==='paused'?'pill':'pill live';
    if(next.error&&next.error!==previous.error)note(next.error,true);
  }else if(previous.active&&!running){el.start.hidden=false;el.stop.hidden=true;el.status.textContent=ui==='en'?'Ended':'已结束';el.status.className='pill';}
  if(!window.thtBrowserCapture&&!next.active&&next.error&&next.error!==previous.error)note(next.error,true);
  window.dispatchEvent(new CustomEvent('tht-native-status',{detail:next}));
}
// The header follows the shared session, including browser capture opened in another view.
function paintMeetingClock(){
 if(!nativeState.active)return;
 const started=Number(nativeState.startedAt),elapsed=nativeState.captureMode==='native'&&Number.isFinite(Number(nativeState.audioSeconds))?Number(nativeState.audioSeconds)+(nativeState.phase==='paused'?0:(Date.now()-nativeClockReceivedAt)/1000):started>0?(Date.now()-started)/1000:Number(nativeState.audioSeconds)+(Date.now()-nativeClockReceivedAt)/1000;
 if(Number.isFinite(elapsed))el.clock.textContent=fmt(Math.floor(Math.max(0,elapsed)));
}
setInterval(paintMeetingClock,1000);
const nativeButton=document.getElementById('b-native');
nativeButton.onclick=async()=>{try{await nativeRequest('launch',{uiLang:ui,lang:cur?.lang||'zh'});}catch(e){note(e.message,true);}};
let nativeJoinPending=false;
const nativeJoinGo=document.getElementById('native-join-go');
function paintNativeJoin(){
 if(!nativeJoinGo)return;const english=ui==='en';
 document.getElementById('native-join-label').textContent=english?'Join an online meeting':'加入线上会议';
 document.getElementById('native-join-url').placeholder=english?'Paste a Lark, Feishu or Google Meet link':'粘贴飞书 / Lark 或 Google Meet 会议链接';
 nativeJoinGo.textContent=english?'Join & record':'加入并录制';
 document.getElementById('native-join-hint').textContent=nativeState.active?(english?'This meeting is already being recorded.':'当前会议正在录制。'):(english?'Captures system audio and your microphone. Allow system permissions on first use.':'记录系统声音和你的麦克风。首次使用需要允许系统权限。');
}
if(nativeJoinGo){
 document.getElementById('mode-chip').addEventListener('click',paintNativeJoin);
 nativeJoinGo.onclick=async()=>{
  if(nativeJoinPending||nativeState.active)return;
  const url=document.getElementById('native-join-url').value.trim(),message=document.getElementById('native-join-error');
  if(!url){message.textContent=ui==='en'?'Paste a meeting link first.':'请先粘贴会议链接。';message.hidden=false;return;}
  nativeJoinPending=true;nativeJoinGo.disabled=true;message.hidden=true;
  try{await nativeRequest('join',{url,uiLang:ui,lang:cur?.lang||'zh'});closeSheets();note(ui==='en'?'Opening your meeting. Follow the mini window for recording status.':'正在打开会议；录制状态请看小窗。');}
  catch(e){message.textContent=e.message;message.hidden=false;}
  finally{nativeJoinPending=false;nativeJoinGo.disabled=!!nativeState.active;}
 };
}
el.stop.addEventListener('click',async e=>{if(!nativeState.active||(nativeState.captureMode==='browser'&&running))return;e.preventDefault();e.stopImmediatePropagation();try{await nativeRequest('command',{sessionId:nativeState.sessionId,command:'stop'});note(ui==='en'?'Saving the last sentence…':'正在保存最后一句…');}catch(error){note(error.message,true);}},true);
setInterval(()=>nativeRequest('status').then(nativeStatus).catch(()=>{}),2000);
nativeRequest('status').then(nativeStatus).catch(()=>{});
